# ============================================================
# Extron Updater
#
# Keeps the newest Extron configuration software (and, when switched on, device firmware)
# from extron.com in the destination folder.
#
#   Version check : public, no sign-in. The Download Center lists (software = filetype 2,
#                   firmware + model map = filetype 44) are read with plain PowerShell using
#                   browser-like headers and the page's anti-forgery token.
#   Download      : Extron requires an Extron Insider sign-in. Only when something new has to be
#                   downloaded, a dedicated Chrome (own profile, DevTools port) signs in with the
#                   saved credential and downloads. Up-to-date runs never sign in.
#   Old versions  : deleted after the new file has been downloaded and checked (no Archive).
#                   Only files matching a product's own file-name pattern are ever touched.
#   Layout        : <ExtronFolder>\Software\   and   <ExtronFolder>\Firmware\<Family>\
#
# All settings come from config.json (written by Install-ExtronUpdater.ps1).
# Dot-sourcing this file (. .\Extron-Updater.ps1) only defines the functions; that is how the
# tests use it. Needs PowerShell 7 to run; the file also parses in Windows PowerShell 5.1.
#
# UNVERIFIED against the real site (as of 2026-10-30): the sign-in form handling and the
# browser download (Open-ExtronBrowser .. Get-ExtronDownloadViaChrome). They follow the findings in
# Discovery\Data\findings.md and the Biamp / Q-Sys browser code and need the one agreed real test.
# ============================================================

param (
    [string]$ConfigPath = (Join-Path $PSScriptRoot "config.json"),

    # Tests only: base URL of a fake Extron site (http://127.0.0.1:port) instead of https://www.extron.com.
    # The sign-in / browser step is replaced by a plain download from that site.
    [string]$TestBackendUrl
)

$ErrorActionPreference = "Stop"

# Error reports (Reporting.ps1 next to this script; never passwords). A missing or damaged
# module never changes a run: the two functions the run calls then do nothing.
$reportingScript = Join-Path $PSScriptRoot "Reporting.ps1"
if (Test-Path -LiteralPath $reportingScript) { try { . $reportingScript } catch { } }
if (-not (Get-Command Send-ErrorReport -CommandType Function -ErrorAction SilentlyContinue) -or
    -not (Get-Command Send-ReportOutbox -CommandType Function -ErrorAction SilentlyContinue)) {
    function Send-ErrorReport { $null }
    function Send-ReportOutbox { 0 }
}

$script:SiteUrl  = "https://www.extron.com"
$script:UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
$script:TestUrl   = $null
$script:Browser   = $null
$script:Cdp       = $null
$script:Credential = $null
$script:Paused     = $null
$script:SignInRejected = $false
$script:MaxUnconfirmedSubmissions = 2


# ------------------------------------------------------------
# Product lists (products.json = software, devices.json = firmware packages)
# ------------------------------------------------------------

function Start-DownloadStatus {
    $statusPath = $null
    try {
        $state = $script:config.StateDir
        if ($state -and (Test-Path -LiteralPath $state)) {
            $statusPath = Join-Path $state 'download-status.json'
            $process = [Diagnostics.Process]::GetCurrentProcess()
            $json = @{ Pid = $PID; StartTicks = $process.StartTime.ToUniversalTime().Ticks.ToString(); Status = 'Downloading' } | ConvertTo-Json -Compress
            [IO.File]::WriteAllText($statusPath, $json)
        }
    } catch { $statusPath = $null }
    return $statusPath
}

function Invoke-TrackedDownload {
    param([scriptblock]$Transfer)
    $statusPath = Start-DownloadStatus
    try { & $Transfer }
    finally { if ($statusPath) { try { [IO.File]::Delete($statusPath) } catch { } } }
}

# An old version that is being installed right now (an installer running from it, or a file in it held open by
# another program) is never moved or deleted: the caller skips that product this run and tries again next run
# (user 2026-11-14). Returns a plain-words reason, or $null when nothing is in use. Missing paths are ignored.
function Get-InUseReason {
    param ([string[]]$Paths)
    $items = @()
    foreach ($p in $Paths) {
        if (-not $p) { continue }
        try { $items += Get-Item -LiteralPath $p -Force -ErrorAction Stop } catch { }
    }
    if ($items.Count -eq 0) { return $null }
    $roots = @($items | ForEach-Object { $_.FullName.TrimEnd('\') })
    foreach ($proc in @(Get-Process -ErrorAction SilentlyContinue)) {
        $exe = $null
        try { $exe = $proc.Path } catch { }
        if (-not $exe) { continue }
        foreach ($r in $roots) {
            if ($exe.Equals($r, [StringComparison]::OrdinalIgnoreCase) -or $exe.StartsWith($r + '\', [StringComparison]::OrdinalIgnoreCase)) {
                return "$(Split-Path -Leaf $r) is in use ($($proc.ProcessName) is running from it)"
            }
        }
    }
    # Offline / RecallOnDataAccess: a cloud-only copy is not held by anything here, and opening it would download it.
    $cloudOnly = [int][IO.FileAttributes]::Offline -bor 0x400000
    foreach ($it in $items) {
        $files = if ($it.PSIsContainer) { @(Get-ChildItem -LiteralPath $it.FullName -Recurse -File -Force -ErrorAction SilentlyContinue) } else { @($it) }
        foreach ($f in $files) {
            if (([int]$f.Attributes -band $cloudOnly) -ne 0) { continue }
            $stream = $null
            try { $stream = [IO.File]::Open($f.FullName, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::None) }
            catch [System.IO.FileNotFoundException] { }
            catch [System.IO.DirectoryNotFoundException] { }
            catch [System.UnauthorizedAccessException] { }
            catch { return "$($f.Name) is in use (open in another program)" }
            finally { if ($stream) { $stream.Dispose() } }
        }
    }
    return $null
}

function Get-ExtronSoftwareProducts {
    $file = Join-Path $PSScriptRoot "products.json"
    if (-not (Test-Path -LiteralPath $file)) { throw "products.json is missing next to Extron-Updater.ps1." }
    @(Get-Content -LiteralPath $file -Raw | ConvertFrom-Json | Where-Object { $_.Supported })
}

function Get-ExtronFirmwarePackages {
    $file = Join-Path $PSScriptRoot "devices.json"
    if (-not (Test-Path -LiteralPath $file)) { throw "devices.json is missing next to Extron-Updater.ps1." }
    @(Get-Content -LiteralPath $file -Raw | ConvertFrom-Json)
}


# ------------------------------------------------------------
# Versions and file names (pure functions, no I/O)
# Extron writes versions in file names with "x" for dots: Toolbelt_v2x35x0x14.exe = 2.35.0.14
# ------------------------------------------------------------

# "2x35x0x14" or "2.35.0" -> @(2,35,0,14); $null when not whole numbers.
function ConvertTo-VersionParts {
    param ([string]$Text)
    if ($Text -notmatch '^\d+([x.]\d+)*$') { return $null }
    , @($Text -split '[x.]' | ForEach-Object { [int]$_ })
}

function Compare-VersionParts {
    param ($A, $B)
    $len = [math]::Max(@($A).Count, @($B).Count)
    for ($i = 0; $i -lt $len; $i++) {
        $x = 0; if ($i -lt @($A).Count) { $x = $A[$i] }
        $y = 0; if ($i -lt @($B).Count) { $y = $B[$i] }
        if ($x -lt $y) { return -1 }
        if ($x -gt $y) { return 1 }
    }
    0
}

# The version written in a file name, as parts; $null when the name has none.
function Get-NameVersionParts {
    param ([string]$FileName)
    $m = [regex]::Match([System.IO.Path]::GetFileNameWithoutExtension($FileName), '(?<![A-Za-z0-9])v?(\d+(?:x\d+)+)(?![A-Za-z0-9])', 'IgnoreCase')
    if (-not $m.Success) { return $null }
    ConvertTo-VersionParts $m.Groups[1].Value
}

# "Toolbelt_v2x35x0x14.exe" -> "Toolbelt"; "NAV_FWv1x01x0006-b185.exe" -> "NAV". A name without a version is its own stem.
function Get-FileStem {
    param ([string]$FileName)
    $base = [System.IO.Path]::GetFileNameWithoutExtension($FileName)
    $stem = [regex]::Replace($base, '[_-]?(FW)?v\d+x.*$', '', 'IgnoreCase')
    $stem.Trim('_', '-', ' ')
}

# Regex that recognises every version of the same firmware file.
function Get-FirmwareMatchPattern {
    param ([string]$FileName)
    if ($null -eq (Get-NameVersionParts $FileName)) { return '^' + [regex]::Escape($FileName) + '$' }
    '^' + [regex]::Escape((Get-FileStem $FileName)) + '[_-]?(FW)?v\d'
}

# Text that sorts like the version (2.9 after 2.10 would be wrong as text): each part padded to 6 digits.
function Get-VersionSortKey {
    param ($Parts)
    (@($Parts) | ForEach-Object { '{0:D6}' -f [int]$_ }) -join '.'
}

# Files already in a folder that belong to this product, newest version first. Unparseable names sort last.
function Get-LocalProductFiles {

    param ([string]$Pattern, [string]$Folder)

    if (-not (Test-Path -LiteralPath $Folder)) { return @() }

    $items = foreach ($f in Get-ChildItem -LiteralPath $Folder -File -ErrorAction SilentlyContinue) {

        if ($f.Name -notmatch $Pattern) { continue }

        $parts = Get-NameVersionParts $f.Name
        $text  = $f.Name
        if ($parts) { $text = ($parts -join '.') }

        [pscustomobject]@{ Name = $f.Name; Parts = $parts; Text = $text; Item = $f }
    }

    $sorted = @($items | Where-Object { $_ }) | Sort-Object -Descending -Property { if ($_.Parts) { Get-VersionSortKey $_.Parts } else { "" } }
    @($sorted)
}


# ------------------------------------------------------------
# Extron's public lists (version check, no sign-in)
# ------------------------------------------------------------

function Get-ExtronBaseUrl {
    if ($script:TestUrl) { return $script:TestUrl.TrimEnd('/') }
    $script:SiteUrl
}

# One web session: the Download Center page (gives the cookie and the anti-forgery token).
function New-ExtronWebSession {

    $base = Get-ExtronBaseUrl
    $headers = @{ "Accept" = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"; "Accept-Language" = "en-US,en;q=0.9" }
    $sess = $null

    $page = Invoke-WebRequest -Uri "$base/download/download-center/" -UserAgent $script:UserAgent -Headers $headers -SessionVariable sess -UseBasicParsing -TimeoutSec 60

    $m = [regex]::Match($page.Content, '(?is)<input[^>]*name="__RequestVerificationToken"[^>]*value="([^"]+)"')
    if (-not $m.Success) { $m = [regex]::Match($page.Content, '(?is)<input[^>]*value="([^"]+)"[^>]*name="__RequestVerificationToken"') }
    if (-not $m.Success) {
        throw "The Extron Download Center page did not have the expected form (the site may have changed or may be blocking this PC)."
    }

    [pscustomobject]@{ Session = $sess; Token = $m.Groups[1].Value; Base = $base }
}

# FileType 2 = software, 44 = firmware. Returns Items (array of file records) and Map (firmware part number -> model names; firmware only).
function Get-ExtronReleaseList {

    param ($Web, [int]$FileType)

    $headers = @{
        "Accept"                     = "application/json, text/javascript, */*; q=0.01"
        "Accept-Language"            = "en-US,en;q=0.9"
        "X-Requested-With"           = "XMLHttpRequest"
        "x-RequestVerificationToken" = $Web.Token
        "Referer"                    = "$($Web.Base)/download/download-center/"
    }

    $r = Invoke-WebRequest -Uri "$($Web.Base)/Download/DownloadCenterCurrentReleases/?filetype=$FileType" -Method Post -WebSession $Web.Session -UserAgent $script:UserAgent -Headers $headers -ContentType "application/x-www-form-urlencoded; charset=UTF-8" -Body "" -UseBasicParsing -TimeoutSec 120

    $json = ConvertFrom-Json -InputObject $r.Content -NoEnumerate

    if ($FileType -eq 44) {
        if (@($json).Count -lt 2) { throw "The Extron firmware list did not have the expected shape (the site may have changed)." }
        return [pscustomobject]@{ Items = @($json[0]); Map = @($json[1]) }
    }

    [pscustomobject]@{ Items = @($json); Map = @() }
}

function ConvertTo-ExtronDate {
    param ([string]$Text)
    try { [datetime]::Parse($Text, [System.Globalization.CultureInfo]::InvariantCulture) } catch { [datetime]::MinValue }
}

# The newest list entry for a software product (by file-name pattern); $null when none.
function Select-SoftwareEntry {
    param ($Product, $Items)
    $hits = @($Items | Where-Object { $_.FileName -match $Product.Match })
    if ($hits.Count -eq 0) { return $null }
    @($hits | Sort-Object -Descending -Property { ConvertTo-ExtronDate $_.RevDate })[0]
}

# The newest list entry for a firmware package (by firmware part number); $null when none.
function Select-FirmwareEntry {
    param ($Package, $Items)
    $hits = @($Items | Where-Object { $_.PartNum -eq $Package.PartNum })
    if ($hits.Count -eq 0) { return $null }
    @($hits | Sort-Object -Descending -Property { ConvertTo-ExtronDate $_.RevDate })[0]
}

# Throws a plain-wording message when the downloaded file is not what the list promised.
function Test-DownloadedFile {

    param ([string]$Path, [int64]$ExpectedSize, [string]$Validate = "size")

    if (-not (Test-Path -LiteralPath $Path)) { throw "The download did not create a file." }

    $size = (Get-Item -LiteralPath $Path).Length

    if ($size -le 0) { throw "The downloaded file is empty." }
    if ($ExpectedSize -gt 0 -and $size -ne $ExpectedSize) {
        throw "The download was cut off or incomplete ($size bytes received, $ExpectedSize expected)."
    }

    if ($Validate -eq "mz") {
        $fs = [System.IO.File]::OpenRead($Path)
        try { $b1 = $fs.ReadByte(); $b2 = $fs.ReadByte() } finally { $fs.Dispose() }
        if ($b1 -ne 0x4D -or $b2 -ne 0x5A) { throw "The downloaded file is not a Windows program (it may be an error page)." }
    }
    elseif ($Validate -eq "zip") {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $zip = $null
        try {
            $zip = [System.IO.Compression.ZipFile]::OpenRead($Path)
            if ($zip.Entries.Count -eq 0) { throw "empty" }
        }
        catch { throw "The downloaded file is not a valid package (it may be an error page)." }
        finally { if ($zip) { $zip.Dispose() } }
    }
}

# How to check a firmware file: programs and packages by extension, everything else by size only.
function Get-FirmwareValidate {
    param ([string]$FileName)
    $ext = [System.IO.Path]::GetExtension($FileName).ToLowerInvariant()
    if ($ext -eq ".exe") { return "mz" }
    if ($ext -eq ".zip") { return "zip" }
    "size"
}


# ------------------------------------------------------------
# Sign-in safety (Q-Sys model): credential file, unconfirmed-submission cap, pause until the password is updated
# ------------------------------------------------------------

function Get-CredentialPath { Join-Path $script:config.StateDir "Extron-Credential.xml" }

function Get-CredentialStamp {
    $path = Get-CredentialPath
    if (Test-Path $path) { (Get-Item $path).LastWriteTimeUtc.Ticks.ToString() } else { "none" }
}

function Get-SignInState {

    $state = [pscustomobject]@{ CredentialStamp = (Get-CredentialStamp); Unconfirmed = 0; LastSubmission = $null }
    $file  = Join-Path $script:config.StateDir "signin-state.json"

    try {
        if (Test-Path $file) {
            $saved = Get-Content $file -Raw | ConvertFrom-Json
            # A different saved password starts the count over.
            if ($saved.CredentialStamp -eq $state.CredentialStamp) {
                $state.Unconfirmed    = [int]$saved.Unconfirmed
                $state.LastSubmission = $saved.LastSubmission
            }
        }
    }
    catch { }

    $state
}

function Save-SignInState {
    param ($State)
    try { $State | ConvertTo-Json | Set-Content -Path (Join-Path $script:config.StateDir "signin-state.json") } catch { }
}

function Register-PasswordSubmission {
    $state = Get-SignInState
    $state.Unconfirmed++
    $state.LastSubmission = (Get-Date).ToString("o")
    Save-SignInState $state
}

function Reset-SignInCounter {
    $state = Get-SignInState
    $state.Unconfirmed = 0
    Save-SignInState $state
}

# The saved sign-in, or a plain-wording error. Cached for the run. The password never goes into a log or a config file.
function Get-ExtronCredential {

    if ($script:Credential) { return $script:Credential }

    $path = Get-CredentialPath
    if (-not (Test-Path -LiteralPath $path)) {
        throw "No Extron sign-in is saved. Open AV Updater and click 'Update password...' on the Extron tab to enter the Extron email and password."
    }

    try {
        $c = Import-Clixml -LiteralPath $path
        $email = $c.UserName
        $pass  = $c.GetNetworkCredential().Password
    }
    catch { throw "The saved Extron sign-in could not be read. Open AV Updater and click 'Update password...' on the Extron tab to enter it again." }

    if ([string]::IsNullOrWhiteSpace($email) -or [string]::IsNullOrWhiteSpace($pass)) {
        throw "The saved Extron sign-in is incomplete. Open AV Updater and click 'Update password...' on the Extron tab to enter it again."
    }

    $script:Credential = [pscustomobject]@{ Email = $email; Password = $pass }
    $script:Credential
}

# Writes the paused state for a rejected sign-in and the notice that goes with it.
function Set-SignInRejected {
    param ([string]$Message)

    $state = $script:config.StateDir

    [ordered]@{ Time = (Get-Date).ToString("o"); Message = $Message; Kind = "failed"; LastReminder = (Get-Date).ToString("o") } |
        ConvertTo-Json | Set-Content -Path (Join-Path $state "login-failed.json")

    [ordered]@{ Kind = "failed"; Message = $Message } |
        ConvertTo-Json | Set-Content -Path (Join-Path $state "pending-signin-failed.json")

    $script:SignInRejected = $true

    $reportPage = $null
    if ($script:Browser) { try { $reportPage = Get-ReportPageState -Port $script:Browser.Port } catch { } }
    try { [void](Send-ErrorReport -Config $script:config -Category SignInFailed -Message $Message -Context @{ Kind = "failed"; Run = $script:runStarted; Page = $reportPage }) } catch { }
}

# Checked at the start of a run. Returns a message when sign-in is paused (downloads are then skipped, the version check still runs),
# otherwise $null. Also applies the cap on unconfirmed password submissions.
function Get-SignInPause {

    $state       = $script:config.StateDir
    $failedFile  = Join-Path $state "login-failed.json"
    $noticeFile  = Join-Path $state "pending-signin-failed.json"
    $credential  = Get-CredentialPath

    if (-not (Test-Path $failedFile)) {

        $cap = Get-SignInState

        if ($cap.Unconfirmed -ge $script:MaxUnconfirmedSubmissions) {

            $capMessage = "The last $($cap.Unconfirmed) sign-ins with this saved password could not be confirmed as successful."

            [ordered]@{ Time = (Get-Date).ToString("o"); Message = $capMessage; Kind = "unconfirmed"; LastReminder = (Get-Date).ToString("o") } |
                ConvertTo-Json | Set-Content -Path $failedFile

            [ordered]@{ Kind = "unconfirmed"; Message = $capMessage } | ConvertTo-Json | Set-Content -Path $noticeFile

            try { Start-PendingNotice } catch { }

            try { [void](Send-ErrorReport -Config $script:config -Category SignInFailed -Message $capMessage -Context @{ Kind = "unconfirmed"; Run = $script:runStarted }) } catch { }
        }
    }

    if (-not (Test-Path $failedFile)) { return $null }

    $info     = Get-Content $failedFile -Raw | ConvertFrom-Json
    $failedAt = [datetime]$info.Time

    if ((Test-Path $credential) -and (Get-Item $credential).LastWriteTime -gt $failedAt) {
        Write-Host "The saved Extron password was updated after the last failed sign-in. Trying again."
        Remove-Item $failedFile -Force
        Remove-Item $noticeFile -Force -ErrorAction SilentlyContinue
        return $null
    }

    "Paused: the last Extron sign-in failed ('$($info.Message)') and the saved password has not been updated since. Open AV Updater and click 'Update password...' on the Extron tab."
}

# Weekly reminder while paused and a download was actually blocked (the first notice, at the failure, counts as the first reminder).
function Show-PauseReminderIfDue {

    $state      = $script:config.StateDir
    $failedFile = Join-Path $state "login-failed.json"
    $noticeFile = Join-Path $state "pending-signin-failed.json"

    if (-not (Test-Path $failedFile)) { return $false }

    try {
        $info = Get-Content $failedFile -Raw | ConvertFrom-Json
        $last = [datetime]$info.Time
        if ($info.LastReminder) { $last = [datetime]$info.LastReminder }

        if (((Get-Date) - $last).TotalDays -ge 7 -and -not (Test-Path $noticeFile)) {

            [ordered]@{ Kind = "reminder"; Message = $info.Message; PausedSince = ([datetime]$info.Time).ToString("o") } | ConvertTo-Json | Set-Content -Path $noticeFile

            if ($info.PSObject.Properties.Name -contains "LastReminder") { $info.LastReminder = (Get-Date).ToString("o") }
            else { $info | Add-Member -NotePropertyName LastReminder -NotePropertyValue (Get-Date).ToString("o") }
            $info | ConvertTo-Json | Set-Content -Path $failedFile

            try { Start-PendingNotice } catch { }
            return $true
        }
    }
    catch { }

    $false
}

# Reads what the sign-in page shows AFTER the sign-in was submitted. Read only.
# LeftSignIn = the page is no longer the sign-in page; Failed = Extron shows a sign-in error; Waiting = nothing yet.
function Resolve-ExtronSignInState {

    param ($Snapshot)

    if ($Snapshot.url -notlike "*/home/login*") { return "LeftSignIn" }
    if (([string]$Snapshot.errorText).Trim()) { return "Failed" }
    "Waiting"
}


# ------------------------------------------------------------
# Browser download (UNVERIFIED against the real site): own Chrome profile, DevTools port, sign in when asked, capture the download
# ------------------------------------------------------------

function Find-ChromeExe {
    foreach ($p in @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")) {
        if ($p -and (Test-Path -LiteralPath $p)) { return $p }
    }
    $null
}

function Send-Cdp {
    param ([string]$Method, $Params)
    $c = $script:Cdp
    $c.Id++
    $json  = ConvertTo-Json -InputObject @{ id = $c.Id; method = $Method; params = $Params } -Depth 8 -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $seg   = New-Object 'System.ArraySegment[byte]' -ArgumentList (, $bytes)
    [void]$c.Sock.SendAsync($seg, [System.Net.WebSockets.WebSocketMessageType]::Text, $true, [System.Threading.CancellationToken]::None).GetAwaiter().GetResult()
    $c.Id
}

# One receive stays pending between calls: cancelling a pending receive aborts the whole socket.
function Read-Cdp {
    param ([int]$Milliseconds)
    $c = $script:Cdp
    $deadline = (Get-Date).AddMilliseconds($Milliseconds)
    while ((Get-Date) -lt $deadline) {
        if (-not $c.Pending) {
            $seg = New-Object 'System.ArraySegment[byte]' -ArgumentList (, $c.Buf)
            $c.Pending = $c.Sock.ReceiveAsync($seg, [System.Threading.CancellationToken]::None)
        }
        if (-not $c.Pending.Wait(300)) { continue }
        $r = $c.Pending.Result; $c.Pending = $null
        if ($r.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) { throw "Chrome closed the remote-control connection." }
        [void]$c.Sb.Append([System.Text.Encoding]::UTF8.GetString($c.Buf, 0, $r.Count))
        if (-not $r.EndOfMessage) { continue }
        $text = $c.Sb.ToString(); [void]$c.Sb.Clear()
        $m = $null
        try { $m = $text | ConvertFrom-Json } catch { continue }
        if ($m.method -eq "Browser.downloadWillBegin") { $c.Begin = $m.params }
        elseif ($m.method -eq "Browser.downloadProgress") { $c.Progress = $m.params }
        return $m
    }
    $null
}

function Invoke-Cdp {
    param ([string]$Method, $Params, [int]$TimeoutSeconds = 30)
    $id = Send-Cdp $Method $Params
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $deadline) {
        $m = Read-Cdp 500
        if ($m -and $m.id -eq $id) { return $m }
    }
    throw "Chrome did not answer ($Method) in time."
}

function Get-CdpValue {
    param ([string]$Expression, [int]$TimeoutSeconds = 20)
    $res = Invoke-Cdp "Runtime.evaluate" @{ expression = $Expression; returnByValue = $true } $TimeoutSeconds
    $res.result.result.value
}

# Starts Chrome with the updater's own profile. Hidden = a real (not headless) window placed off screen, because Extron's bot
# defense rejects headless Chrome. Visible = a normal window.
function Open-ExtronBrowser {

    param ([string]$ProfileFolder, [string]$WorkFolder, [bool]$Visible)

    $chrome = Find-ChromeExe
    if (-not $chrome) { throw "Google Chrome is not installed on this PC." }

    $dl = Join-Path $WorkFolder "dl"
    [void][System.IO.Directory]::CreateDirectory($dl)
    [void][System.IO.Directory]::CreateDirectory($ProfileFolder)

    $listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, 0)
    $listener.Start(); $port = $listener.LocalEndpoint.Port; $listener.Stop()

    $args2 = @("--remote-debugging-port=$port", "--remote-allow-origins=*", "--user-data-dir=`"$ProfileFolder`"", "--no-first-run", "--no-default-browser-check",
        "--disable-extensions", "--disable-background-timer-throttling", "--disable-renderer-backgrounding", "--disable-backgrounding-occluded-windows", "--window-size=1100,800")
    if (-not $Visible) { $args2 += "--window-position=-32000,-32000" }
    $args2 += "about:blank"

    $proc = Start-Process -FilePath $chrome -PassThru -ArgumentList $args2

    $script:Cdp = @{ Id = 0; Pending = $null; Sb = (New-Object System.Text.StringBuilder); Buf = (New-Object byte[] 1048576); Begin = $null; Progress = $null; Sock = $null }
    $script:Browser = @{ Proc = $proc; Profile = $ProfileFolder; Work = $WorkFolder; Download = $dl; Port = $port }

    $wsUrl = $null
    for ($i = 0; $i -lt 40 -and -not $wsUrl; $i++) {
        try {
            $targets = Invoke-RestMethod -Uri "http://127.0.0.1:$port/json" -TimeoutSec 3
            $page = @($targets | Where-Object { $_.type -eq "page" })[0]
            if ($page) { $wsUrl = $page.webSocketDebuggerUrl }
        }
        catch { }
        if (-not $wsUrl) { Start-Sleep -Milliseconds 500 }
    }
    if (-not $wsUrl) { throw "Chrome did not open its remote-control port." }

    $sock = New-Object System.Net.WebSockets.ClientWebSocket
    [void]$sock.ConnectAsync([uri]$wsUrl, [System.Threading.CancellationToken]::None).GetAwaiter().GetResult()
    $script:Cdp.Sock = $sock

    [void](Invoke-Cdp "Browser.setDownloadBehavior" @{ behavior = "allowAndName"; downloadPath = $dl; eventsEnabled = $true })
}

# Always safe to call. Closes Chrome and removes the work folder (the profile stays: it holds the sign-in cookie).
function Close-ExtronBrowser {

    if (-not $script:Browser) { return }

    try { if ($script:Cdp -and $script:Cdp.Sock) { $script:Cdp.Sock.Dispose() } } catch { }
    try { if ($script:Browser.Proc -and -not $script:Browser.Proc.HasExited) { Stop-Process -Id $script:Browser.Proc.Id -Force -ErrorAction SilentlyContinue } } catch { }
    try {
        $needle = [string]$script:Browser.Profile
        Get-CimInstance Win32_Process -Filter "Name = 'chrome.exe'" -ErrorAction SilentlyContinue |
            Where-Object { $_.CommandLine -and $_.CommandLine.Contains($needle) } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    }
    catch { }
    Start-Sleep -Milliseconds 1500
    try { Remove-Item -LiteralPath $script:Browser.Work -Recurse -Force -ErrorAction SilentlyContinue } catch { }

    $script:Browser = $null
    $script:Cdp = $null
}

function Invoke-CdpClick {
    param ($Point)
    [void](Invoke-Cdp "Input.dispatchMouseEvent" @{ type = "mousePressed"; x = $Point.x; y = $Point.y; button = "left"; clickCount = 1 })
    Start-Sleep -Milliseconds 100
    [void](Invoke-Cdp "Input.dispatchMouseEvent" @{ type = "mouseReleased"; x = $Point.x; y = $Point.y; button = "left"; clickCount = 1 })
}

$script:SnapshotScript = @'
(function () {
  var err = '';
  var all = document.querySelectorAll('body *');
  for (var i = 0; i < all.length && !err; i++) {
    var e = all[i];
    if (e.children.length === 0 && e.offsetWidth > 0 && e.offsetHeight > 0) {
      var t = (e.innerText || '').trim();
      if (/invalid username or password|issue with your account/i.test(t)) { err = t.substring(0, 200); }
    }
  }
  return JSON.stringify({ url: location.href.split('?')[0], errorText: err });
})()
'@

# Fills the sign-in form with the saved credential and presses Sign In. Counts the submission (cap). Waits for the result.
# Throws AuthenticationException when Extron shows an error twice in a row.
function Invoke-ExtronBrowserSignIn {

    $cred = Get-ExtronCredential

    $fill = @'
(function () {
  function setv(f, v) {
    var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    setter.call(f, v);
    f.dispatchEvent(new Event('input', { bubbles: true }));
    f.dispatchEvent(new Event('change', { bubbles: true }));
  }
  var em = document.querySelector('input[type="email"]');
  var pw = document.querySelector('input[type="password"]');
  if (!em || !pw) { return 'FIELDS_NOT_FOUND'; }
  setv(em, __EMAIL__);
  setv(pw, __PASSWORD__);
  return em.value.length + ',' + pw.value.length;
})()
'@
    $fill = $fill.Replace("__EMAIL__", (ConvertTo-Json -InputObject $cred.Email -Compress)).Replace("__PASSWORD__", (ConvertTo-Json -InputObject $cred.Password -Compress))

    $filled = [string](Get-CdpValue $fill)
    if ($filled -eq "FIELDS_NOT_FOUND") { throw "The Extron sign-in page did not show the email and password fields (the page may have changed)." }
    if ($filled -match '^0,|,0$') { throw "The Extron sign-in page did not accept the saved email and password." }

    Start-Sleep -Seconds 1

    $where = @'
(function () {
  var pw = document.querySelector('input[type="password"]');
  if (!pw || pw.value.length === 0) { return null; }
  var scope = pw.closest('form') || document;
  var cands = [].slice.call(scope.querySelectorAll('button, input[type="submit"]')).filter(function (b) {
    var t = ((b.innerText || '') + ' ' + (b.value || '')).trim();
    return b.offsetWidth > 0 && /^sign\s*in$/i.test(t);
  });
  var b = cands[0];
  if (!b) { return null; }
  b.scrollIntoView({ behavior: 'instant', block: 'center', inline: 'center' });
  var r = b.getBoundingClientRect();
  return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
})()
'@
    $point = Get-CdpValue $where
    if ($null -eq $point) { throw "Could not find the Sign In button on the Extron sign-in page (the page may have changed)." }

    # The password is submitted now: count it until a sign-in is confirmed.
    Register-PasswordSubmission
    Invoke-CdpClick $point
    $cred = $null

    $failedInARow = 0
    $message = ""

    for ($i = 0; $i -lt 30; $i++) {

        Start-Sleep -Seconds 1

        $snap = $null
        try { $text = Get-CdpValue $script:SnapshotScript 10; if ($text) { $snap = $text | ConvertFrom-Json } } catch { continue }
        if (-not $snap) { continue }

        $state = Resolve-ExtronSignInState $snap

        if ($state -eq "LeftSignIn") { Reset-SignInCounter; return }

        if ($state -eq "Failed") {
            $failedInARow++
            $message = $snap.errorText
            if ($failedInARow -ge 2) {
                Set-SignInRejected $message
                throw (New-Object System.Security.Authentication.AuthenticationException("Extron did not accept the saved sign-in ('$message'). The updater will not try again until the saved password is updated."))
            }
        }
        else { $failedInARow = 0 }
    }

    # No error seen and no result either: the count stays (the cap pauses the updater if this keeps happening).
    Write-Host "No sign-in error seen, but the sign-in page did not change either."
}

# Downloads one file with the signed-in browser into $TempFolder and returns its path.
function Get-ExtronDownloadViaChrome {

    param ($Entry, [string]$TempFolder)

    if (-not $script:Browser) {
        $profileDir = Join-Path $script:config.StateDir "Chrome-Profile"
        $work       = Join-Path $TempFolder ("browser-" + [guid]::NewGuid().ToString("N").Substring(0, 8))
        $visible    = ($script:config.Visible -eq $true)
        Open-ExtronBrowser -ProfileFolder $profileDir -WorkFolder $work -Visible $visible
    }

    $c = $script:Cdp
    $c.Begin = $null; $c.Progress = $null

    $url = "$(Get-ExtronBaseUrl)/download/dltrack.aspx?file=$([uri]::EscapeDataString($Entry.FileName))&id=$($Entry.PKFileID)"
    [void](Invoke-Cdp "Page.navigate" @{ url = $url } 60)

    $deadline    = (Get-Date).AddMinutes(40)
    $navigated   = Get-Date
    $signedIn    = $false
    $retried     = $false
    $lastCheck   = Get-Date

    while ((Get-Date) -lt $deadline) {

        [void](Read-Cdp 500)

        if ($c.Progress -and $c.Progress.state -eq "completed") { break }
        if ($c.Progress -and $c.Progress.state -eq "canceled") { throw "The browser download was cancelled." }
        if ($c.Begin) { continue }

        if (((Get-Date) - $lastCheck).TotalSeconds -lt 2) { continue }
        $lastCheck = Get-Date

        $snap = $null
        try { $text = Get-CdpValue $script:SnapshotScript 10; if ($text) { $snap = $text | ConvertFrom-Json } } catch { }

        if ($snap -and $snap.url -like "*/home/login*") {
            if ($signedIn) { throw "Extron asked for the sign-in again right after it was accepted." }
            Write-Host "  Extron asks for the sign-in..."
            Invoke-ExtronBrowserSignIn
            $signedIn  = $true
            $navigated = Get-Date
            continue
        }

        if (((Get-Date) - $navigated).TotalSeconds -gt 90) {
            if ($signedIn -and -not $retried) {
                $retried = $true; $navigated = Get-Date
                [void](Invoke-Cdp "Page.navigate" @{ url = $url } 60)
                continue
            }
            throw "Extron did not start the download (the page may have changed)."
        }
    }

    if (-not ($c.Progress -and $c.Progress.state -eq "completed")) { throw "The download did not finish within 40 minutes." }

    $got = Join-Path $script:Browser.Download ([string]$c.Progress.guid)
    if (-not (Test-Path -LiteralPath $got)) { throw "The browser reported a finished download but the file is missing." }

    if ($c.Begin -and $c.Begin.suggestedFilename -and [System.IO.Path]::GetFileName([string]$c.Begin.suggestedFilename) -ne $Entry.FileName) {
        Write-Host "  (Extron named the file '$($c.Begin.suggestedFilename)'; keeping the list name '$($Entry.FileName)'.)"
    }

    $target = Join-Path $TempFolder $Entry.FileName
    Move-Item -LiteralPath $got -Destination $target -Force
    $target
}

# Test replacement for the browser step: a plain download from the fake site. A redirect to the sign-in page counts as a rejected sign-in.
function Get-ExtronDownloadFromTestSite {

    param ($Entry, [string]$TempFolder)

    Get-ExtronCredential | Out-Null

    $handler = New-Object System.Net.Http.HttpClientHandler
    $handler.AllowAutoRedirect = $false
    $client = New-Object System.Net.Http.HttpClient($handler)
    $client.Timeout = [System.TimeSpan]::FromMinutes(5)

    try {
        $url = (Get-ExtronBaseUrl) + $Entry.Path + $Entry.FileName
        $response = $client.GetAsync($url, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()

        $code = [int]$response.StatusCode
        if ($code -eq 301 -or $code -eq 302) {
            Register-PasswordSubmission
            $loc = [string]$response.Headers.Location
            if ($loc -like "*/home/login*") {
                Set-SignInRejected "Invalid username or password"
                throw (New-Object System.Security.Authentication.AuthenticationException("Extron did not accept the saved sign-in ('Invalid username or password'). The updater will not try again until the saved password is updated."))
            }
        }
        if ($code -ge 400) { throw "Extron answered $code for $($Entry.FileName)." }

        $target = Join-Path $TempFolder $Entry.FileName
        $in  = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
        $out = [System.IO.File]::Create($target)
        try { $in.CopyTo($out, 1MB) } finally { $out.Dispose(); $in.Dispose() }

        Reset-SignInCounter
        $target
    }
    finally { $client.Dispose() }
}

function Get-ExtronDownload {
    param ($Entry, [string]$TempFolder)
    if ($script:TestUrl) { return (Get-ExtronDownloadFromTestSite -Entry $Entry -TempFolder $TempFolder) }
    Get-ExtronDownloadViaChrome -Entry $Entry -TempFolder $TempFolder
}


# ------------------------------------------------------------
# One file (software product or firmware package)
# Spec: Key, Name, Kind ("Software"/"Firmware"), Validate. Entry: the live list record (or $null = not on the list).
# Status: Current, Updated, Failed, NotFound, Paused (sign-in paused), SignIn (sign-in rejected).
# ------------------------------------------------------------

function Update-ExtronFile {

    param ($Spec, $Entry, [string]$LocalPattern, [string]$Destination, [string]$TempFolder)

    $result = [pscustomobject]@{
        Key = $Spec.Key; Name = $Spec.Name; Kind = $Spec.Kind; Status = "Failed"; Detail = ""
        Previous = $null; New = $null; FilePath = $null; Removed = @(); Folder = $Destination
    }

    $downloaded = $null

    try {

        if (-not $Entry) {
            $result.Status = "NotFound"
            throw "$($Spec.Name) was not found on the Extron download list (Extron may have renamed or retired it)."
        }

        $size = [int64]$Entry.FileSize
        $newParts = Get-NameVersionParts $Entry.FileName
        $newText  = [string]$Entry.Rev
        if (-not $newText) { $newText = $Entry.FileName }

        [void][System.IO.Directory]::CreateDirectory($Destination)
        $local = @(Get-LocalProductFiles -Pattern $LocalPattern -Folder $Destination)

        if ($local.Count -gt 0) { $result.Previous = $local[0].Text }

        # Already there (same name and size), or a newer version than the list offers: nothing to do.
        $same = @($local | Where-Object { $_.Name -eq $Entry.FileName -and $_.Item.Length -eq $size })
        if ($same.Count -gt 0) {
            $result.Status = "Current"; $result.Detail = "$newText is the newest."
            return $result
        }
        if ($newParts -and $local.Count -gt 0 -and $local[0].Parts -and (Compare-VersionParts $local[0].Parts $newParts) -gt 0) {
            $result.Status = "Current"; $result.Detail = "$($local[0].Name) is newer than the Extron list ($newText)."
            return $result
        }

        # A download is needed: this is where the sign-in matters.
        if ($script:SignInRejected) {
            $result.Status = "SignIn"; $result.Detail = "Skipped: Extron rejected the sign-in earlier in this run."
            return $result
        }
        if ($script:Paused) {
            $result.Status = "Paused"; $result.Detail = "$newText is available but sign-in is paused."
            return $result
        }

        # What this update would delete or replace: older files of THIS product and a same-name file. If any is in use
        # (being installed), skip until the next run, before downloading.
        $retire = @($local | Where-Object { $_.Name -ne $Entry.FileName -and -not ($newParts -and $_.Parts -and (Compare-VersionParts $_.Parts $newParts) -ge 0) } | ForEach-Object { $_.Item.FullName })
        $retire += Join-Path $Destination $Entry.FileName
        $busy = Get-InUseReason $retire
        if ($busy) { $result.Status = "InUse"; $result.Detail = "Skipped: $busy. Will try again next run."; return $result }

        # Room for the download in the temp folder and the destination, plus a margin.
        $needed = [int64]($size * 1.1) + 50MB
        foreach ($folder in $TempFolder, $Destination) {
            $root = [System.IO.Path]::GetPathRoot((Resolve-Path -LiteralPath $folder).Path)
            $free = (New-Object System.IO.DriveInfo $root).AvailableFreeSpace
            if ($free -lt $needed) {
                throw "Not enough free disk space on $root ($([math]::Round($free / 1MB)) MB free, about $([math]::Round($needed / 1MB)) MB needed)."
            }
        }

        Write-Host "  Downloading $($Entry.FileName) ($([math]::Round($size / 1MB, 1)) MB)..."
        $downloaded = Invoke-TrackedDownload { Get-ExtronDownload -Entry $Entry -TempFolder $TempFolder }

        Test-DownloadedFile -Path $downloaded -ExpectedSize $size -Validate $Spec.Validate

        $busy = Get-InUseReason $retire
        if ($busy) { $result.Status = "InUse"; $result.Detail = "Skipped: $busy. Will try again next run."; return $result }

        $target = Join-Path $Destination $Entry.FileName
        Move-Item -LiteralPath $downloaded -Destination $target -Force
        $downloaded = $null

        # Only now, with the new file in place and checked, delete the older files of THIS product (never a newer or unrelated one).
        $removed = @()
        foreach ($old in $local) {
            if ($old.Name -eq $Entry.FileName) { continue }
            if ($newParts -and $old.Parts -and (Compare-VersionParts $old.Parts $newParts) -ge 0) { continue }
            Remove-Item -LiteralPath $old.Item.FullName -Force
            $removed += $old.Name
        }

        $result.Status   = "Updated"
        $result.New      = $newText
        $result.FilePath = $target
        $result.Removed  = $removed
        $result.Detail   = "$(if ($result.Previous) { "$($result.Previous) -> " })$newText"
    }
    catch {
        if ($_.Exception -is [System.Security.Authentication.AuthenticationException]) {
            $result.Status = "SignIn"
        }
        elseif ($result.Status -ne "NotFound") { $result.Status = "Failed" }
        $result.Detail = $_.Exception.Message
    }
    finally {
        if ($downloaded) { Remove-Item -LiteralPath $downloaded -Force -ErrorAction SilentlyContinue }
    }

    $result
}


# ------------------------------------------------------------
# Notices, history (same behaviour as the other updaters)
# ------------------------------------------------------------

function Start-PendingNotice {

    $state = $script:config.StateDir

    if (-not ((Test-Path (Join-Path $state "pending-notice.json")) -or (Test-Path (Join-Path $state "pending-error.json")) -or (Test-Path (Join-Path $state "pending-signin-failed.json")))) { return }

    $noticeTask = "Extron Updater Notice"
    if ($script:config.NoticeTaskName) { $noticeTask = $script:config.NoticeTaskName }

    try {
        if (Get-ScheduledTask -TaskName $noticeTask -ErrorAction SilentlyContinue) {
            Start-ScheduledTask -TaskName $noticeTask
            return
        }
    }
    catch { }

    if (-not (Test-Path (Join-Path $state "Show-ExtronNotice.ps1"))) { return }

    Start-Process -FilePath (Get-Process -Id $PID).Path -WindowStyle Hidden -ArgumentList @(
        "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", (Join-Path $state "Show-ExtronNotice.ps1")
    )
}

# One dated line per attempt, even if more than one code path calls this.
function Write-RunHistory {

    param ([string]$Outcome = $script:runOutcome, [string]$Detail = $script:runDetail)

    if ($script:runHistoryWritten) { return }
    $script:runHistoryWritten = $true

    if (-not $Outcome) {
        $Outcome = "UNKNOWN"
        $Detail  = "The run ended without recording a result. See Extron-Updater.log."
    }

    $took = (Get-Date) - $script:runStarted
    if ($took.TotalMinutes -ge 1) { $tookText = "{0}m {1}s" -f [int][math]::Floor($took.TotalMinutes), $took.Seconds }
    else { $tookText = "{0}s" -f [int][math]::Round($took.TotalSeconds) }

    $line = "{0}  {1,-10} {2} (took {3})" -f $script:runStarted.ToString("yyyy-MM-dd HH:mm:ss"), $Outcome, (($Detail -replace '\s+', ' ').Trim()), $tookText

    try {
        $historyFile = Join-Path (Join-Path $script:config.StateDir "Logs") "Run-History.log"
        New-Item -ItemType Directory -Path (Split-Path $historyFile) -Force | Out-Null

        if ((Test-Path $historyFile) -and (Get-Item $historyFile).Length -gt 1MB) {
            Move-Item $historyFile ($historyFile + ".old") -Force
        }

        Add-Content -Path $historyFile -Value $line -Encoding UTF8
    }
    catch { }
}

# Error notice for a failed run. The same error again within 24 hours is logged but not shown again.
function New-ErrorNotice {

    param ([string]$Step, [string]$Message)

    $state     = $script:config.StateDir
    $seenFile  = Join-Path $state "last-error-notice.json"
    $signature = "$Step|$Message"

    try {
        if (Test-Path $seenFile) {
            $seen = Get-Content $seenFile -Raw | ConvertFrom-Json
            if ($seen.Signature -eq $signature -and ((Get-Date) - [datetime]$seen.Time).TotalHours -lt 24) {
                return "not repeated: same error within 24 hours"
            }
        }

        [ordered]@{
            Time        = $script:runStarted.ToString("o")
            Step        = $Step
            Message     = $Message
            HistoryFile = (Join-Path (Join-Path $state "Logs") "Run-History.log")
            LogFile     = (Join-Path (Join-Path $state "Logs") "Extron-Updater.log")
        } | ConvertTo-Json | Set-Content -Path (Join-Path $state "pending-error.json")

        [ordered]@{ Signature = $signature; Time = (Get-Date).ToString("o") } | ConvertTo-Json | Set-Content -Path $seenFile

        "shown to the user"
    }
    catch { "could not be created" }
}

# "new version downloaded" notice: one pending file listing every file updated since the user last acknowledged it.
function Add-UpdateNotice {

    param ($Updated)

    $file  = Join-Path $script:config.StateDir "pending-notice.json"
    $items = @()

    if (Test-Path $file) {
        try { $items = @((Get-Content $file -Raw | ConvertFrom-Json).Items) } catch { }
    }

    foreach ($u in $Updated) {
        $items = @($items | Where-Object { $_.Key -ne $u.Key })
        $items += [ordered]@{ Key = $u.Key; Kind = $u.Kind; Name = $u.Name; Version = $u.New; PreviousVersion = $u.Previous; FilePath = $u.FilePath }
    }

    [ordered]@{
        Folder         = $script:config.ExtronFolder
        SoftwareFolder = (Join-Path $script:config.ExtronFolder "Software")
        FirmwareFolder = (Join-Path $script:config.ExtronFolder "Firmware")
        Items          = $items
    } | ConvertTo-Json -Depth 4 | Set-Content -Path $file
}

# Is the failure just "no internet / site down" (skipped quietly) or a real problem?
function Test-IsOffline {
    param ($ErrorRecord)
    $status = $null
    try { $status = [int]$ErrorRecord.Exception.Response.StatusCode } catch { }
    $inner = $ErrorRecord.Exception.InnerException
    ((-not $status) -and ($ErrorRecord.Exception -is [System.Net.Http.HttpRequestException] -or $ErrorRecord.Exception -is [System.TimeoutException] -or $ErrorRecord.Exception -is [System.Threading.Tasks.TaskCanceledException] -or $inner -is [System.Net.Sockets.SocketException] -or $inner -is [System.IO.IOException])) -or ($status -ge 500)
}

function Test-TcpPort {
    param ([string]$HostName, [int]$Port = 443, [int]$TimeoutMs = 4000)
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $task = $client.ConnectAsync($HostName, $Port)
        return ($task.Wait($TimeoutMs) -and $client.Connected)
    }
    catch { return $false }
    finally { $client.Close() }
}

# At logon or wake the network is often not up yet: poll until the host answers or the time runs out.
function Wait-ForNetwork {
    param ([string]$HostName, [int]$Port = 443, [int]$MaxSeconds = 180, [int]$PollSeconds = 10)
    $waited = 0
    while ($true) {
        if (Test-TcpPort -HostName $HostName -Port $Port) { return $true }
        if ($waited -ge $MaxSeconds) { return $false }
        if ($waited -eq 0) { Write-Host "Waiting for the network (up to $MaxSeconds seconds)..." }
        Start-Sleep -Seconds $PollSeconds
        $waited += $PollSeconds
    }
}

# Retries connection drops (reset, timeout, DNS). An HTTP answer (404 and so on) is not retried.
function Invoke-WebRetry {
    param ([scriptblock]$Call, [int]$Tries = 3, [int]$BaseDelaySeconds = 5)
    for ($i = 1; $i -le $Tries; $i++) {
        try { return & $Call }
        catch {
            $status = $null
            try { $status = [int]$_.Exception.Response.StatusCode } catch { }
            if (($status -and $status -lt 500) -or $i -eq $Tries) { throw }
            Write-Host "Connection problem ($($_.Exception.Message)). Retrying ($i of $($Tries - 1))..."
            Start-Sleep -Seconds ($BaseDelaySeconds * $i)
        }
    }
}


# ------------------------------------------------------------
# Main run
# ------------------------------------------------------------

# Dot-sourced (by the tests): functions only.
if ($MyInvocation.InvocationName -eq '.') { return }

$script:TestUrl    = $TestBackendUrl
$script:config     = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$script:runStarted = Get-Date
$script:runOutcome = $null
$script:runDetail  = $null
$script:runHistoryWritten = $false

$stateDir   = $script:config.StateDir
$logFolder  = Join-Path $stateDir "Logs"
$tempFolder = Join-Path $stateDir "Temp"

New-Item -ItemType Directory -Path $logFolder -Force | Out-Null
Start-Transcript -Path (Join-Path $logFolder "Extron-Updater.log") -Append | Out-Null

Write-Host ""
Write-Host "============================================================"
Write-Host "Extron updater started: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Write-Host "============================================================"

# Never two runs at once.
$mutex = New-Object System.Threading.Mutex($false, "Global\AVSoftwareUpdater-EXTRON")

try { $mutexAcquired = $mutex.WaitOne(0, $false) }
catch [System.Threading.AbandonedMutexException] { $mutexAcquired = $true }

if (-not $mutexAcquired) {
    Write-Host "Extron updater is already running. This instance will exit."
    $script:runOutcome = "SKIPPED"
    $script:runDetail  = "Another update check was already running."
    Write-RunHistory
    try { Stop-Transcript | Out-Null } catch { }
    exit 0
}

$step = "preparing the update check"

try {

    # A notice the user has not acknowledged yet appears again.
    try { Start-PendingNotice } catch { }

    # Error reports that could not be sent earlier (share offline) are sent now.
    try { [void](Send-ReportOutbox -Config $script:config) } catch { }

    # --- Blocked Wi-Fi (phone hotspots) ---
    if (-not $TestBackendUrl) {

        $wifiInfo = netsh wlan show interfaces | Out-String
        $ssid = $null
        if ($wifiInfo -match '(?m)^\s*SSID\s*:\s*(.+)$') { $ssid = $Matches[1].Trim() }

        if ($ssid -and $ssid -in @($script:config.BlockedSSIDs)) {
            Write-Host "Connected to blocked Wi-Fi: $ssid. Update check skipped."
            $script:runOutcome = "SKIPPED"
            $script:runDetail  = "Connected to blocked Wi-Fi network '$ssid'."
            return
        }
    }

    $extronFolder = $script:config.ExtronFolder
    if (-not $extronFolder) { throw "config.json has no ExtronFolder." }

    $softwareFolder = Join-Path $extronFolder "Software"
    $firmwareRoot   = Join-Path $extronFolder "Firmware"
    [void][System.IO.Directory]::CreateDirectory($extronFolder)

    if (Test-Path $tempFolder) { Remove-Item $tempFolder -Recurse -Force -ErrorAction SilentlyContinue }
    New-Item -ItemType Directory -Path $tempFolder -Force | Out-Null

    # Paused after a rejected sign-in: the version check still runs, downloads wait for a new password.
    $script:Paused = Get-SignInPause

    $enabledSoftware = @($script:config.EnabledSoftware)
    $enabledFirmware = @($script:config.EnabledFirmware)
    $firmwareOn      = ($script:config.FirmwareEnabled -eq $true) -and ($enabledFirmware.Count -gt 0)

    $softwareToCheck = @(Get-ExtronSoftwareProducts | Where-Object { $_.Key -in $enabledSoftware })
    $packagesToCheck = @()
    if ($firmwareOn) { $packagesToCheck = @(Get-ExtronFirmwarePackages | Where-Object { $_.Key -in $enabledFirmware -or $_.PartNum -in $enabledFirmware }) }

    # --- Read Extron's public lists ---
    $step = "reading the Extron download lists"
    $softwareList = $null; $firmwareList = $null

    try {
        # Wait for the network first (logon / wake); test runs against the fake server wait only briefly.
        if (-not $script:TestUrl) {
            if (-not (Wait-ForNetwork -HostName ([uri]$script:SiteUrl).Host)) {
                Write-Host "Offline: the Extron website could not be reached. Will retry at the next run."
                $script:runOutcome = "SKIPPED"
                $script:runDetail  = "Offline, will retry next run (the network did not come up)."
                return
            }
        }
        $retryDelay = 5
        if ($script:TestUrl) { $retryDelay = 0 }
        $web = Invoke-WebRetry -BaseDelaySeconds $retryDelay -Call { New-ExtronWebSession }
        if ($softwareToCheck.Count -gt 0) { $softwareList = Invoke-WebRetry -BaseDelaySeconds $retryDelay -Call { Get-ExtronReleaseList -Web $web -FileType 2 } }
        if ($packagesToCheck.Count -gt 0) { $firmwareList = Invoke-WebRetry -BaseDelaySeconds $retryDelay -Call { Get-ExtronReleaseList -Web $web -FileType 44 } }
    }
    catch {
        if (Test-IsOffline $_) {
            # No internet or site down is expected now and then: not an error notice.
            Write-Host "Could not reach Extron: $($_.Exception.Message)"
            $script:runOutcome = "SKIPPED"
            $script:runDetail  = "Could not reach the Extron website (no internet, or the site is down): $($_.Exception.Message)"
            return
        }
        throw
    }

    # --- Each enabled item ---
    $results = @()

    foreach ($product in $softwareToCheck) {
        $step = "checking $($product.Name)"
        Write-Host "$($product.Name)..."
        $entry = Select-SoftwareEntry -Product $product -Items $softwareList.Items
        $r = Update-ExtronFile -Spec $product -Entry $entry -LocalPattern $product.Match -Destination $softwareFolder -TempFolder $tempFolder
        Write-Host "  $($r.Status): $($r.Detail)"
        $results += $r
    }

    foreach ($pkg in $packagesToCheck) {
        $step = "checking $($pkg.Name)"
        Write-Host "$($pkg.Name)..."
        $entry = Select-FirmwareEntry -Package $pkg -Items $firmwareList.Items
        $family = [string]$pkg.Family
        if (-not $family) { $family = "Other" }
        $spec = [pscustomobject]@{ Key = $pkg.Key; Name = $pkg.Name; Kind = "Firmware"; Validate = "size" }
        $pattern = $null
        if ($entry) { $spec.Validate = Get-FirmwareValidate $entry.FileName; $pattern = Get-FirmwareMatchPattern $entry.FileName }
        $r = Update-ExtronFile -Spec $spec -Entry $entry -LocalPattern $pattern -Destination (Join-Path $firmwareRoot $family) -TempFolder $tempFolder
        Write-Host "  $($r.Status): $($r.Detail)"
        $results += $r
    }

    $updated = @($results | Where-Object { $_.Status -eq "Updated" })
    $failed  = @($results | Where-Object { $_.Status -in "Failed", "NotFound" })
    $signin  = @($results | Where-Object { $_.Status -eq "SignIn" })
    # (named pausedResults: at script level $paused IS $script:Paused, the pause message, and would overwrite it)
    $pausedResults = @($results | Where-Object { $_.Status -eq "Paused" })

    if ($updated.Count -gt 0) {
        try { Add-UpdateNotice $updated; Start-PendingNotice } catch { }
    }

    $remindNote = ""
    if ($pausedResults.Count -gt 0) {
        if (Show-PauseReminderIfDue) { $remindNote = " Weekly reminder shown." }
    }

    $summary = ($results | ForEach-Object { "$($_.Name): $($_.Status.ToLower())$(if ($_.Status -ne 'Current') { " ($($_.Detail))" })" }) -join "; "
    if (-not $summary) { $summary = "Nothing is switched on to check." }

    $noticeNote = $null
    if ($failed.Count -gt 0) {
        $noticeNote = New-ErrorNotice -Step "updating" -Message (($failed | ForEach-Object { "$($_.Name): $($_.Detail)" }) -join "`n")
        try { Start-PendingNotice } catch { }

        try { [void](Send-ErrorReport -Config $script:config -Category DownloadFailed -Message (($failed | ForEach-Object { "$($_.Name): $($_.Detail)" }) -join "`n") -Step "updating" -Context @{ Products = @($failed | ForEach-Object { $_.Key }); Notice = $noticeNote; Run = $script:runStarted; Network = (Get-ExtronBaseUrl) }) } catch { }
    }

    if ($failed.Count -gt 0 -or $signin.Count -gt 0) {
        $script:runOutcome = "FAILED"
        $script:runDetail  = "$summary$(if ($noticeNote) { " [error notice $noticeNote]" })"
    }
    elseif ($updated.Count -gt 0) {
        $script:runOutcome = "UPDATED"
        $script:runDetail  = "$summary$(if ($pausedResults.Count -gt 0) { " Some downloads wait for the saved password to be updated." })$remindNote"
    }
    elseif ($pausedResults.Count -gt 0) {
        $script:runOutcome = "SKIPPED"
        $script:runDetail  = "$($script:Paused)$remindNote"
    }
    elseif (@($results | Where-Object { $_.Status -eq "InUse" }).Count -gt 0) {
        # An old version was being installed: nothing moved, no error notice; the next run tries again.
        $script:runOutcome = "SKIPPED"
        $script:runDetail  = "In use, will retry next run: " + (@($results | Where-Object { $_.Status -eq "InUse" } | ForEach-Object { "$($_.Name): $($_.Detail)" }) -join "; ")
    }
    else {
        $script:runOutcome = "CURRENT"
        $script:runDetail  = "All enabled Extron items are up to date."
    }
}
catch {

    $message = $_.Exception.Message
    Write-Host "ERROR while $step`: $message"
    Write-Host $_.ScriptStackTrace

    $noticeNote = New-ErrorNotice -Step $step -Message $message
    try { Start-PendingNotice } catch { }

    $reportPage = $null
    if ($script:Browser) { try { $reportPage = Get-ReportPageState -Port $script:Browser.Port } catch { } }
    try { [void](Send-ErrorReport -Config $script:config -Category RunFailed -Message $message -Step $step -ErrorRecord $_ -Context @{ Notice = $noticeNote; Run = $script:runStarted; Network = (Get-ExtronBaseUrl); Page = $reportPage }) } catch { }

    $script:runOutcome = "FAILED"
    $script:runDetail  = "Failed while $step`: $message [error notice $noticeNote]"
}
finally {

    try { Close-ExtronBrowser } catch { }
    Remove-Item $tempFolder -Recurse -Force -ErrorAction SilentlyContinue

    Write-RunHistory

    try { $mutex.ReleaseMutex() } catch { }
    try { Stop-Transcript | Out-Null } catch { }
}
