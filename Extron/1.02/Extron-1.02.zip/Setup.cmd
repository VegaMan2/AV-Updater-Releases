@echo off
rem Extron Updater setup: double-click this file.
rem Unblocks the scripts (needed after a download or unzip), then opens the setup window.
rem The black console stays hidden; the setup window is the only thing you see.
rem Windows PowerShell is used only to start setup; setup moves itself to PowerShell 7 when it can.
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' -Recurse -File | Unblock-File" >nul 2>&1
start "" /b "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Install-ExtronUpdater.ps1" %*
