# ============================================================
# Extron Updater -- setup (run once per machine and user)
#
# Asks for:
#   - the Extron folder (Software and Firmware folders are kept inside it)
#   - which Extron programs to keep up to date
#   - whether to download device firmware, and which firmware packages
#   - the Extron Insider email and password (Windows credential dialog; stored
#     encrypted for THIS Windows user on THIS PC only). Setup does NOT contact
#     Extron: the login is used only when a file has to be downloaded.
# Then installs the updater to %LOCALAPPDATA%\ExtronUpdater, registers a scheduled
# task that runs at logon and on wake from sleep, and adds an "Extron Updater
# Options" icon (Desktop and Start menu).
#
# Cancelling (or a failure) before setup finishes removes everything this
# run created. After setup completes nothing is removed automatically.
#
# Usage:
#   Double-click Setup.cmd, or from any PowerShell:
#   powershell -ExecutionPolicy Bypass -File Install-ExtronUpdater.ps1
#   (can start in Windows PowerShell 5.1; if PowerShell 7 is missing, setup offers to
#   install it, then continues in PowerShell 7)
#
#   ...Install-ExtronUpdater.ps1 -InstallPrerequisites   (install PowerShell 7 without asking)
#   ...Install-ExtronUpdater.ps1 -UpdateCredentialOnly
#   pwsh -File Install-ExtronUpdater.ps1 -DestinationRoot "D:\For Install\Extron" -NoGui
#   pwsh -File Install-ExtronUpdater.ps1 -Uninstall
#
#   Error reports (a short report when the updater hits an error, never passwords) are on
#   unless this PC turned them off before. -NoErrorReports turns them off, -ErrorReports
#   turns them back on; the setup window has a tick box for it.
# ============================================================

[CmdletBinding()]
param (
    [string]$InstallDir = (Join-Path $env:LOCALAPPDATA "ExtronUpdater"),
    [string]$DestinationRoot,            # the Extron folder; Software\ and Firmware\ are created inside it
    [string[]]$BlockedSSIDs = @(),
    [string]$TaskName = "Extron Updater",
    [string[]]$Software,                 # software keys from products.json (default: all)
    [string[]]$FirmwarePackages,         # firmware package keys from devices.json, or "all" (every tracked package)
    [switch]$FirmwareEnabled,            # download firmware files (default OFF)
    [switch]$Visible,                    # show the browser window while signing in / downloading (default hidden)
    [switch]$InstallPrerequisites,
    [switch]$ReplaceExistingTask,
    [switch]$ConfigureNetworks,
    [switch]$UpdateCredentialOnly,
    [string]$CredentialFromFile,         # a PSCredential saved with Export-Clixml, used instead of the pop-up (unattended installs, tests)
    [switch]$SkipTask,
    [switch]$RunNow,
    [switch]$NoGui,                      # no windows (also used automatically when input is redirected)
    [switch]$NoErrorReports,             # turn error reports off
    [switch]$ErrorReports,               # turn error reports back on after an earlier opt-out
    [switch]$Uninstall
)

$ErrorActionPreference = "Stop"

# -File runs pass arrays as one comma-separated string.
$BlockedSSIDs     = @($BlockedSSIDs     | ForEach-Object { $_ -split "," } | ForEach-Object { $_.Trim() } | Where-Object { $_ })
$Software         = @($Software         | ForEach-Object { $_ -split "," } | ForEach-Object { $_.Trim() } | Where-Object { $_ })
$FirmwarePackages = @($FirmwarePackages | ForEach-Object { $_ -split "," } | ForEach-Object { $_.Trim() } | Where-Object { $_ })

$credentialFile    = Join-Path $InstallDir "Extron-Credential.xml"
$configFile        = Join-Path $InstallDir "config.json"
$updaterName       = "Extron-Updater.ps1"
$launcherName      = "Run-Hidden.vbs"
$optionsScriptName = "Options-ExtronUpdater.ps1"
$optionsLinkName   = "Extron Updater Options.lnk"
$noticeName        = "Show-ExtronNotice.ps1"
$noticeLauncher    = "Run-Notice.vbs"
$noticeTaskName    = "$TaskName Notice"
$passwordName      = "Update-ExtronPassword.ps1"
$productsName      = "products.json"
$pickerName        = "Firmware-Picker.ps1"
$catalogName       = "devices.json"
$reportingFileNames = @("Reporting.ps1", "reporting.json", "version.json")
$ownFiles          = @($updaterName, $optionsScriptName, $noticeName, $passwordName, "CredentialPrompt.ps1", $pickerName, $productsName, $catalogName) + $reportingFileNames

# The Windows sign-in window. If its file is missing, fall back to the text prompt.
$credentialPromptName   = "CredentialPrompt.ps1"
$credentialPromptSource = Join-Path $PSScriptRoot $credentialPromptName

if (Test-Path $credentialPromptSource) {
    . $credentialPromptSource
}
else {
    function Get-ExtronCredentialPrompt {
        param ([string]$Message)
        Get-Credential -Message $Message
    }
}

# Windows instead of console prompts, unless -NoGui or input is redirected (automated tests).
$useGui = -not $NoGui

try { if ([Console]::IsInputRedirected) { $useGui = $false } } catch { }

$wizardDone = $false

# The firmware picker functions (Get-DefaultExtronFolder is used by the Setup window below).
. (Join-Path $PSScriptRoot $pickerName)

# ------------------------------------------------------------
# Uninstall
# ------------------------------------------------------------

if ($Uninstall) {

    # Same removal as the Remove updater button in the Extron Updater Options window.
    & (Join-Path $PSScriptRoot $optionsScriptName) -Uninstall -InstallDir $InstallDir -TaskName $TaskName
    return
}


# ------------------------------------------------------------
# The login
# ------------------------------------------------------------

# The pop-up (or -CredentialFromFile). Returns a PSCredential, or $null if cancelled.
function Get-SetupCredential {

    if ($CredentialFromFile) {
        return (Import-Clixml -Path $CredentialFromFile)
    }

    Get-ExtronCredentialPrompt -Message "Enter your Extron.com username and password"
}

function Test-ValidCredential {

    param ($Credential)

    [bool]($Credential -and -not [string]::IsNullOrWhiteSpace($Credential.UserName) -and $Credential.Password.Length -gt 0)
}

# Encrypted for this Windows user on this PC only (DPAPI), readable by nobody else.
function Save-ExtronCredential {

    param ([string]$Path, $Credential)

    if (-not (Test-ValidCredential $Credential)) {
        throw "No credential was entered. Setup cancelled."
    }

    $Credential | Export-Clixml -Path $Path

    $currentUser = "$env:USERDOMAIN\$env:USERNAME"
    & icacls.exe $Path /inheritance:r /grant:r "${currentUser}:(F)" | Out-Null

    Write-Host "Login saved for $($Credential.UserName)."
    Write-Host "It is encrypted and can only be read by $currentUser on this PC."
}


function Get-WifiProfileNames {

    $names = foreach ($line in (netsh wlan show profiles 2>$null)) {
        if ($line -match '^\s*(All User Profile|User Profile)\s*:\s*(.+)$') {
            $Matches[2].Trim()
        }
    }

    @($names | Sort-Object -Unique)
}

function Get-CurrentSsid {

    $info = netsh wlan show interfaces 2>$null | Out-String

    if ($info -match '(?m)^\s*SSID\s*:\s*(.+)$') {
        return $Matches[1].Trim()
    }

    return $null
}


# ------------------------------------------------------------
# Setup windows (used when a person runs setup; -NoGui and any value given on the
# command line keep the console route)
# ------------------------------------------------------------

function Show-NetworkPicker {

    # Checklist of the PC's saved Wi-Fi networks, plus a box to add a name by hand.
    # Returns the ticked names, or $null if cancelled.
    param ([string[]]$Current = @())

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $profiles    = @(Get-WifiProfileNames)
    $connectedTo = Get-CurrentSsid

    $global:QNet = @{ Names = New-Object System.Collections.ArrayList }

    $form = New-Object System.Windows.Forms.Form
    $global:QNet.Form = $form
    $form.Text = "Wi-Fi networks to avoid"
    $form.ClientSize = New-Object System.Drawing.Size(520, 480)
    $form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false; $form.MinimizeBox = $false
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    $info = New-Object System.Windows.Forms.Label
    $info.Location = New-Object System.Drawing.Point(16, 12); $info.Size = New-Object System.Drawing.Size(488, 66)
    $info.Text = "The updater downloads installers of about 2 GB. It skips the check whenever this PC is connected to a network ticked here, such as a phone hotspot."
    $form.Controls.Add($info)

    $list = New-Object System.Windows.Forms.CheckedListBox
    $list.Name = "NetworkList"; $list.CheckOnClick = $true
    $list.Location = New-Object System.Drawing.Point(16, 84); $list.Size = New-Object System.Drawing.Size(488, 280)
    $form.Controls.Add($list)
    $global:QNet.List = $list

    function Add-NetworkItem ($name, $checked) {
        for ($i = 0; $i -lt $global:QNet.Names.Count; $i++) {
            if ($global:QNet.Names[$i] -eq $name) { $global:QNet.List.SetItemChecked($i, $checked); return }
        }
        [void]$global:QNet.Names.Add($name)
        $text = if ($name -eq $global:QNet.Connected) { "$name   (connected now)" } else { $name }
        [void]$global:QNet.List.Items.Add($text, $checked)
    }

    $global:QNet.Connected = $connectedTo

    foreach ($name in $profiles) { Add-NetworkItem $name ($name -in $Current) }
    foreach ($name in $Current)  { if ($name) { Add-NetworkItem $name $true } }

    $addLabel = New-Object System.Windows.Forms.Label
    $addLabel.Text = "Not listed? Type its name:"
    $addLabel.Location = New-Object System.Drawing.Point(16, 376); $addLabel.Size = New-Object System.Drawing.Size(488, 22)
    $form.Controls.Add($addLabel)

    $box = New-Object System.Windows.Forms.TextBox
    $box.Name = "AddNetworkBox"
    $box.Location = New-Object System.Drawing.Point(16, 400); $box.Size = New-Object System.Drawing.Size(370, 26)
    $form.Controls.Add($box)
    $global:QNet.Box = $box

    $add = New-Object System.Windows.Forms.Button
    $add.Name = "AddNetworkButton"; $add.Text = "Add"
    $add.Location = New-Object System.Drawing.Point(396, 398); $add.Size = New-Object System.Drawing.Size(108, 30)
    $add.Add_Click({
        try {
            $typed = $global:QNet.Box.Text.Trim()
            if ($typed) { Add-NetworkItem $typed $true; $global:QNet.Box.Text = "" }
        } catch { }
    })
    $form.Controls.Add($add)

    $ok = New-Object System.Windows.Forms.Button
    $ok.Name = "NetworksOk"; $ok.Text = "OK"; $ok.DialogResult = "OK"
    $ok.Location = New-Object System.Drawing.Point(290, 440); $ok.Size = New-Object System.Drawing.Size(100, 32)
    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Name = "NetworksCancel"; $cancel.Text = "Cancel"; $cancel.DialogResult = "Cancel"
    $cancel.Location = New-Object System.Drawing.Point(404, 440); $cancel.Size = New-Object System.Drawing.Size(100, 32)
    $form.Controls.AddRange(@($ok, $cancel))
    $form.AcceptButton = $ok; $form.CancelButton = $cancel

    $answer = $form.ShowDialog()

    $picked = $null

    if ($answer -eq "OK") {
        $picked = @()
        for ($i = 0; $i -lt $global:QNet.Names.Count; $i++) {
            if ($list.GetItemChecked($i)) { $picked += $global:QNet.Names[$i] }
        }
    }

    $form.Dispose()
    return $picked
}

function Show-SetupWizard {

    # The one setup window. Returns $null if cancelled; otherwise the chosen values.
    # The login is held in memory only (it is written at Install). Setup does not contact Extron.
    param (
        [string]$StartFolder,
        [string[]]$BlockedNow = @(),
        [string]$Task,
        $ProductList,
        [string[]]$Selected,
        $FirmwareList = @(),
        [bool]$FirmwareOn = $false,
        [string[]]$FirmwareSelected = @(),
        [bool]$VisibleNow = $false,
        [bool]$ErrorReports = $true
    )

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    $global:CS = @{ Blocked = @($BlockedNow); Credential = $null; Advanced = $false; Checks = @{}; FirmwareList = @($FirmwareList); FirmwareKeys = @($FirmwareSelected) }

    $form = New-Object System.Windows.Forms.Form
    $global:CS.Form = $form
    $form.Text = "Extron Updater Setup"
    $form.ClientSize = New-Object System.Drawing.Size(640, 1080)
    $form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false; $form.MinimizeBox = $true
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    function Add-Ctl ($control, $name, $x, $y, $w, $h, $text) {
        $c = New-Object $control
        if ($name) { $c.Name = $name }
        $c.Location = New-Object System.Drawing.Point($x, $y); $c.Size = New-Object System.Drawing.Size($w, $h)
        if ($text) { $c.Text = $text }
        $global:CS.Form.Controls.Add($c)
        $c
    }
    function Add-Heading ($text, $y) {
        $l = Add-Ctl System.Windows.Forms.Label $null 20 $y 600 24 $text
        $l.Font = New-Object System.Drawing.Font("Segoe UI", 10.5, [System.Drawing.FontStyle]::Bold)
    }

    $title = Add-Ctl System.Windows.Forms.Label $null 20 12 600 30 "Set up the Extron Updater"
    $title.Font = New-Object System.Drawing.Font("Segoe UI", 15, [System.Drawing.FontStyle]::Bold)
    [void](Add-Ctl System.Windows.Forms.Label $null 20 46 600 40 "It keeps the newest Extron software (and, if you choose, device firmware) in a folder of your choice. Nothing is changed on this PC until you click Install.")

    # 1. Folder
    Add-Heading "1. Where should the Extron files be saved?" 92
    $global:CS.Folder = Add-Ctl System.Windows.Forms.TextBox "FolderBox" 20 120 480 26 $StartFolder
    $browse = Add-Ctl System.Windows.Forms.Button "BrowseButton" 510 118 110 30 "Browse..."
    $global:CS.Preview = Add-Ctl System.Windows.Forms.Label "FolderPreview" 20 150 600 40 ""
    $global:CS.Preview.ForeColor = [System.Drawing.Color]::DimGray

    function Update-FolderPreview {
        $text = $global:CS.Folder.Text.Trim()
        $global:CS.Preview.Text = if ($text) { "Software goes in: " + (Join-Path $text "Software") + "`r`nFirmware goes in: " + (Join-Path $text "Firmware") + "  (one folder per family)" } else { "" }
    }
    $global:CS.Folder.Add_TextChanged({ try { Update-FolderPreview } catch { } })
    $browse.Add_Click({
        try {
            $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
            $dialog.Description = "Choose the Extron folder. Software and Firmware folders are kept inside it."
            $dialog.ShowNewFolderButton = $true
            if ($global:CS.Folder.Text.Trim() -and (Test-Path $global:CS.Folder.Text.Trim())) { $dialog.SelectedPath = $global:CS.Folder.Text.Trim() }
            if ($dialog.ShowDialog($global:CS.Form) -eq "OK") { $global:CS.Folder.Text = $dialog.SelectedPath }
        } catch { }
    })

    # 2. Software
    Add-Heading "2. Software to keep up to date" 200
    $y = 228
    foreach ($product in $ProductList) {
        $box = Add-Ctl System.Windows.Forms.CheckBox ("Software_" + $product.Key) 36 $y 420 24 $(if ($product.UiName) { $product.UiName } else { $product.Name })
        $box.Checked = ($Selected -contains $product.Key)
        $global:CS.Checks[$product.Key] = $box
        $y += 24
    }
    foreach ($mode in @(@{ Name = "SoftwareAll"; Text = "All"; Value = $true; X = 470 }, @{ Name = "SoftwareNone"; Text = "None"; Value = $false; X = 550 })) {
        $toggleButton = Add-Ctl System.Windows.Forms.Button $mode.Name $mode.X 198 70 26 $mode.Text
        $toggleButton.Tag = $mode.Value
        $toggleButton.Add_Click({
            param ($sender, $e)
            try { foreach ($box in $global:CS.Checks.Values) { $box.Checked = [bool]$sender.Tag } } catch { }
        })
    }
    $y += 4
    [void](Add-Ctl System.Windows.Forms.Label $null 20 $y 600 40 "Only the newest version of each is kept. Older versions of these programs are deleted when a new one is downloaded.")

    # 3. Firmware
    $y += 52
    Add-Heading "3. Firmware (optional)" $y
    $y += 28
    $global:CS.FirmwareCheck = Add-Ctl System.Windows.Forms.CheckBox "FirmwareCheck" 36 $y 590 24 "Download firmware files"
    $global:CS.FirmwareCheck.Checked = $FirmwareOn
    $y += 32
    $global:CS.FirmwareChoose = Add-Ctl System.Windows.Forms.Button "ChooseFirmwarePackages" 20 $y 190 30 "Choose packages..."
    $global:CS.FirmwareSummary = Add-Ctl System.Windows.Forms.Label "FirmwareSummary" 220 ($y + 6) 400 24 ""
    $global:CS.FirmwareSummary.ForeColor = [System.Drawing.Color]::DimGray
    $y += 38
    [void](Add-Ctl System.Windows.Forms.Label $null 20 $y 600 40 "You can choose packages now; nothing is downloaded until the box above is ticked. Firmware is saved in the Firmware folder, one folder per family.")

    function Update-FirmwareState {
        $global:CS.FirmwareSummary.Text = Get-FirmwareSummary -Devices $global:CS.FirmwareList -Keys @($global:CS.FirmwareKeys)
    }
    $global:CS.FirmwareChoose.Add_Click({
        try {
            $picked = Show-FirmwarePicker -Devices $global:CS.FirmwareList -Selected @($global:CS.FirmwareKeys) -Owner $global:CS.Form
            if ($null -ne $picked) { $global:CS.FirmwareKeys = @($picked); Update-FirmwareState }
        } catch { }
    })

    # 4. Login
    $y += 52
    Add-Heading "4. Extron login" $y
    $y += 28
    $enter = Add-Ctl System.Windows.Forms.Button "EnterCredential" 20 $y 300 32 "Enter Extron email and password..."
    $global:CS.CredentialStatus = Add-Ctl System.Windows.Forms.Label "CredentialStatus" 330 ($y + 6) 290 24 "Not entered yet"
    $y += 40
    [void](Add-Ctl System.Windows.Forms.Label $null 20 $y 600 62 "This is your Extron Insider sign-in (the one used on extron.com). Stored encrypted, readable only by your Windows account on this PC; never shown or logged. Setup does not contact Extron. The login is used only when a new file has to be downloaded.")
    $y += 66
    $global:CS.VisibleCheck = Add-Ctl System.Windows.Forms.CheckBox "VisibleCheck" 36 $y 590 24 "Show the browser window while it signs in and downloads (otherwise hidden)"
    $global:CS.VisibleCheck.Checked = $VisibleNow

    $enter.Add_Click({
        try {
            $credential = Get-SetupCredential
            if (Test-ValidCredential $credential) {
                $global:CS.Credential = $credential
                $global:CS.CredentialStatus.Text = "Entered for " + $credential.UserName
            }
        } catch { }
    })

    # 5. Wi-Fi
    $y += 40
    Add-Heading "5. Wi-Fi networks to avoid" $y
    $y += 26
    [void](Add-Ctl System.Windows.Forms.Label $null 20 $y 600 40 "Some downloads are large (several hundred MB). The updater skips the check on any network you choose here, such as a phone hotspot.")
    $y += 42
    $global:CS.Networks = Add-Ctl System.Windows.Forms.Label "NetworksSummary" 20 ($y + 4) 480 24 ""
    $choose = Add-Ctl System.Windows.Forms.Button "ChooseNetworks" 510 $y 110 30 "Choose..."

    function Update-NetworksSummary {
        $global:CS.Networks.Text = if ($global:CS.Blocked.Count) { "Avoiding: " + ($global:CS.Blocked -join ", ") } else { "None chosen (it will download on any network)" }
    }
    $choose.Add_Click({
        try {
            $picked = Show-NetworkPicker -Current @($global:CS.Blocked)
            if ($null -ne $picked) { $global:CS.Blocked = @($picked); Update-NetworksSummary }
        } catch { }
    })

    # Advanced (collapsed)
    $y += 42
    $toggle = Add-Ctl System.Windows.Forms.Button "AdvancedToggle" 20 $y 150 28 "Advanced  >"
    $global:CS.ErrorReports = Add-Ctl System.Windows.Forms.CheckBox "ErrorReportsCheck" 190 ($y + 2) 420 24 "Send error reports to help fix bugs"
    $global:CS.ErrorReports.Checked = $ErrorReports
    $global:CS.AdvancedPanel = New-Object System.Windows.Forms.Panel
    $panel = $global:CS.AdvancedPanel
    $panel.Location = New-Object System.Drawing.Point(20, ($y + 32)); $panel.Size = New-Object System.Drawing.Size(600, 62); $panel.Visible = $false
    $form.Controls.Add($panel)
    $taskLabel = New-Object System.Windows.Forms.Label
    $taskLabel.Text = "Task name (change it for a test install next to a working one):"
    $taskLabel.Location = New-Object System.Drawing.Point(0, 0); $taskLabel.Size = New-Object System.Drawing.Size(600, 22)
    $global:CS.TaskBox = New-Object System.Windows.Forms.TextBox
    $global:CS.TaskBox.Name = "TaskNameBox"; $global:CS.TaskBox.Text = $Task
    $global:CS.TaskBox.Location = New-Object System.Drawing.Point(0, 26); $global:CS.TaskBox.Size = New-Object System.Drawing.Size(400, 26)
    $panel.Controls.AddRange(@($taskLabel, $global:CS.TaskBox))

    $install = Add-Ctl System.Windows.Forms.Button "InstallButton" 400 1036 110 34 "Install"
    $cancel  = Add-Ctl System.Windows.Forms.Button "CancelButton" 520 1036 100 34 "Cancel"
    $cancel.DialogResult = "Cancel"; $form.CancelButton = $cancel

    $toggle.Add_Click({
        try {
            $global:CS.Advanced = -not $global:CS.Advanced
            $global:CS.AdvancedPanel.Visible = $global:CS.Advanced
        } catch { }
    })

    $install.Add_Click({
        try {
            $form = $global:CS.Form
            $folder = $global:CS.Folder.Text.Trim()
            if (-not $folder) {
                [void][System.Windows.Forms.MessageBox]::Show($form, "Choose the Extron folder first (section 1).", "Extron Updater Setup", "OK", "Information")
                return
            }
            if (-not (Test-Path $folder)) {
                $parent = Split-Path $folder.TrimEnd('\') -Parent
                if (-not $parent -or -not (Test-Path $parent)) {
                    [void][System.Windows.Forms.MessageBox]::Show($form, "That folder cannot be created because its parent folder does not exist:`r`n$folder`r`n`r`nChoose an existing folder (Browse... can make a new one).", "Extron Updater Setup", "OK", "Information")
                    return
                }
            }
            if (@($global:CS.Checks.Values | Where-Object { $_.Checked }).Count -eq 0) {
                [void][System.Windows.Forms.MessageBox]::Show($form, "Tick at least one program (section 2).", "Extron Updater Setup", "OK", "Information")
                return
            }
            $firmwareProblem = Test-FirmwareSettings -Keys @($global:CS.FirmwareKeys) -Devices $global:CS.FirmwareList
            if ($firmwareProblem) {
                [void][System.Windows.Forms.MessageBox]::Show($form, $firmwareProblem, "Extron Updater Setup", "OK", "Information")
                return
            }
            if ($global:CS.FirmwareCheck.Checked -and @($global:CS.FirmwareKeys).Count -eq 0) {
                [void][System.Windows.Forms.MessageBox]::Show($form, "You ticked firmware downloads but chose no packages. Choose packages (section 3), or untick the box.", "Extron Updater Setup", "OK", "Information")
                return
            }
            if (-not $global:CS.Credential) {
                [void][System.Windows.Forms.MessageBox]::Show($form, "Enter your Extron email and password first (section 4).", "Extron Updater Setup", "OK", "Information")
                return
            }

            $form.DialogResult = "OK"
        } catch { }
    })
    $form.AcceptButton = $null

    Update-FolderPreview
    Update-NetworksSummary
    Update-FirmwareState

    # A screen shorter than the window: let the window scroll instead of cutting off the buttons.
    $workHeight = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Height
    if ($workHeight -lt 1130) {
        $form.AutoScroll = $true
        $form.AutoScrollMinSize = New-Object System.Drawing.Size(640, 1080)
        $form.ClientSize = New-Object System.Drawing.Size(660, [math]::Max(400, $workHeight - 90))
    }

    $answer = $form.ShowDialog()

    $result = $null

    if ($answer -eq "OK") {

        $taskText = $global:CS.TaskBox.Text.Trim()

        $result = [pscustomobject]@{
            DestinationRoot  = $global:CS.Folder.Text.Trim()
            BlockedSSIDs     = @($global:CS.Blocked)
            Software         = @($global:CS.Checks.Keys | Where-Object { $global:CS.Checks[$_].Checked })
            TaskName         = $(if ($taskText) { $taskText } else { $Task })
            Credential       = $global:CS.Credential
            FirmwareEnabled  = [bool]$global:CS.FirmwareCheck.Checked
            FirmwarePackages = @($global:CS.FirmwareKeys)
            Visible          = [bool]$global:CS.VisibleCheck.Checked
            ErrorReports     = $global:CS.ErrorReports.Checked
        }
    }

    $form.Dispose()
    return $result
}

function Show-SetupDone {

    # Finish window. Returns $true if the person asked to open the Options window.
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Extron Updater Setup"
    $form.ClientSize = New-Object System.Drawing.Size(520, 250)
    $form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false; $form.MinimizeBox = $false; $form.TopMost = $true
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    $title = New-Object System.Windows.Forms.Label
    $title.Name = "DoneTitle"; $title.Text = "Setup complete"
    $title.Font = New-Object System.Drawing.Font("Segoe UI", 15, [System.Drawing.FontStyle]::Bold)
    $title.Location = New-Object System.Drawing.Point(20, 16); $title.Size = New-Object System.Drawing.Size(480, 32)

    $text = New-Object System.Windows.Forms.Label
    $text.Location = New-Object System.Drawing.Point(20, 60); $text.Size = New-Object System.Drawing.Size(480, 120)
    $text.Text = "The updater will check for new Extron software at logon and after the PC wakes from sleep.`r`n`r`nTo stop or resume it, check now, change your Extron password or remove it, open `"Extron Updater Options`" on your Desktop or in the Start menu."

    $open = New-Object System.Windows.Forms.Button
    $open.Name = "OpenOptions"; $open.Text = "Open Extron Updater Options"; $open.DialogResult = "Yes"
    $open.Location = New-Object System.Drawing.Point(100, 196); $open.Size = New-Object System.Drawing.Size(260, 36)
    $close = New-Object System.Windows.Forms.Button
    $close.Name = "DoneClose"; $close.Text = "Close"; $close.DialogResult = "Cancel"
    $close.Location = New-Object System.Drawing.Point(376, 196); $close.Size = New-Object System.Drawing.Size(124, 36)
    $form.Controls.AddRange(@($title, $text, $open, $close)); $form.CancelButton = $close

    $answer = $form.ShowDialog()
    $form.Dispose()

    return ($answer -eq "Yes")
}

function Find-Pwsh {

    $command = Get-Command pwsh.exe -ErrorAction SilentlyContinue

    if ($command) {
        return $command.Source
    }

    # A fresh install is not on PATH in this session yet.
    $default = Join-Path $env:ProgramFiles "PowerShell\7\pwsh.exe"

    if (Test-Path $default) {
        return $default
    }

    return $null
}

function Install-FromMsi {

    # Direct-download fallback when winget is not available.
    param (
        [string]$Name,
        [string]$Url,
        [string]$MsiArguments = ""
    )

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $ProgressPreference = "SilentlyContinue"

    $msi = Join-Path $env:TEMP ("ExtronUpdater-" + $Name.Replace(" ", "") + ".msi")

    Write-Host "Downloading $Name..."
    Invoke-WebRequest -Uri $Url -OutFile $msi -UseBasicParsing

    Write-Host "Installing $Name (a Windows permission prompt will appear)..."

    $process = Start-Process msiexec.exe `
        -ArgumentList "/i `"$msi`" /qn $MsiArguments" `
        -Verb RunAs `
        -Wait `
        -PassThru

    Remove-Item $msi -Force -ErrorAction SilentlyContinue

    if ($process.ExitCode -notin 0, 3010) {
        Write-Warning "$Name installer finished with exit code $($process.ExitCode)."
    }
}

function Install-Prerequisite {

    param (
        [string]$Name,
        [string]$WingetId,
        [scriptblock]$Fallback,
        [scriptblock]$IsInstalled
    )

    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue

    if ($winget) {

        Write-Host "Installing $Name with winget (a Windows permission prompt may appear)..."

        & $winget.Source install `
            --id $WingetId `
            --exact `
            --silent `
            --accept-package-agreements `
            --accept-source-agreements

        if (& $IsInstalled) {
            return
        }

        Write-Warning "winget did not complete the $Name install. Trying a direct download."
    }

    try {
        & $Fallback
    }
    catch {
        Write-Warning "Direct download of $Name failed: $($_.Exception.Message)"
    }
}

function Get-ProductList {

    $file = Join-Path $PSScriptRoot $productsName

    if (-not (Test-Path $file)) {
        throw "$productsName was not found next to this setup script ($PSScriptRoot)."
    }

    @(Get-Content $file -Raw | ConvertFrom-Json)
}

if ($UpdateCredentialOnly) {

    if (-not (Test-Path $InstallDir)) {
        throw "Setup has not been run yet ($InstallDir not found). Run setup first."
    }

    $credential = Get-SetupCredential
    Save-ExtronCredential -Path $credentialFile -Credential $credential

    # Lifts the pause that follows a rejected login.
    Remove-Item (Join-Path $InstallDir "login-failed.json") -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $InstallDir "pending-signin-failed.json") -Force -ErrorAction SilentlyContinue
    return
}

if ($ConfigureNetworks) {

    if (-not (Test-Path $configFile)) {
        throw "Setup has not been run yet ($configFile not found). Run setup first."
    }

    $existingConfig = Get-Content $configFile -Raw | ConvertFrom-Json
    $existingConfig.BlockedSSIDs = @(Show-NetworkPicker -Current @($existingConfig.BlockedSSIDs))
    $existingConfig | ConvertTo-Json -Depth 6 | Set-Content -Path $configFile -Encoding UTF8

    Write-Host "Saved. Blocked networks: $(@($existingConfig.BlockedSSIDs) -join ', ')"
    return
}


# ------------------------------------------------------------
# Prerequisites: PowerShell 7 (the only one; there is no browser)
# ------------------------------------------------------------

foreach ($required in ($ownFiles + $productsName)) {
    if (-not (Test-Path (Join-Path $PSScriptRoot $required))) {
        throw "$required was not found next to this setup script ($PSScriptRoot)."
    }
}

$pwsh = Find-Pwsh

if (-not $pwsh) {

    $installPwsh = $InstallPrerequisites

    if (-not $installPwsh) {

        if ($useGui) {

            Add-Type -AssemblyName System.Windows.Forms

            $message = "This PC is missing PowerShell 7, which runs the updater and its scheduled task.`r`n`r`nSetup can download and install it now (a Windows permission prompt may appear). Setup cannot continue without it.`r`n`r`nInstall it now?  (Yes = install, No = cancel setup)"

            $installPwsh = ([System.Windows.Forms.MessageBox]::Show($message, "Extron Updater Setup", "YesNo", "Question") -eq "Yes")
        }
        else {
            $answer = (Read-Host "PowerShell 7 is missing and is required. Install it now? [Y/n]").Trim()
            $installPwsh = ($answer -eq "" -or $answer -match '^y(es)?$')
        }
    }

    if (-not $installPwsh) {
        Write-Host "Setup cancelled. Nothing was installed or changed."
        exit 1
    }

    Install-Prerequisite `
        -Name "PowerShell 7" `
        -WingetId "Microsoft.PowerShell" `
        -IsInstalled { [bool](Find-Pwsh) } `
        -Fallback {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

            $release = Invoke-RestMethod `
                "https://api.github.com/repos/PowerShell/PowerShell/releases/latest" `
                -Headers @{ "User-Agent" = "ExtronUpdaterSetup" }

            $asset = $release.assets |
                Where-Object { $_.name -like "*win-x64.msi" } |
                Select-Object -First 1

            if (-not $asset) {
                throw "No Windows x64 MSI found in the latest PowerShell release."
            }

            Install-FromMsi -Name "PowerShell 7" -Url $asset.browser_download_url -MsiArguments "ADD_PATH=1"
        }

    $pwsh = Find-Pwsh

    if (-not $pwsh) {
        Write-Host ""
        Write-Host "PowerShell 7 could not be installed automatically. Install it from https://aka.ms/powershell, then run setup again."
        exit 1
    }
}

# This setup may have been started in Windows PowerShell 5.1 so it could
# install PowerShell 7. Continue the rest of setup in PowerShell 7.
if ($PSVersionTable.PSVersion.Major -lt 7) {

    Write-Host "Continuing setup in PowerShell 7..."

    $relaunchArgs = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $PSCommandPath)

    foreach ($name in $PSBoundParameters.Keys) {

        $value = $PSBoundParameters[$name]

        if ($value -is [switch]) {
            if ($value.IsPresent) { $relaunchArgs += "-$name" }
        }
        elseif ($value -is [array]) {
            $relaunchArgs += "-$name"
            $relaunchArgs += ($value -join ",")
        }
        else {
            $relaunchArgs += "-$name"
            $relaunchArgs += [string]$value
        }
    }

    & $pwsh @relaunchArgs
    exit $LASTEXITCODE
}

$productList = Get-ProductList
$productsFile = Join-Path $PSScriptRoot $productsName

if (-not $Software) { $Software = @($productList | Where-Object { $_.Default -ne $false } | ForEach-Object { $_.Key }) }

# Firmware: the picker window and the package list (data only).
. (Join-Path $PSScriptRoot $pickerName)

$firmwareList = @(Get-FirmwareChoices -CatalogPath (Join-Path $PSScriptRoot $catalogName))

# What an earlier setup chose (shown again when setup is re-run).
$previousPackages = @()
$previousFirmwareOn = $true
$previousVisible = $false

if (Test-Path $configFile) {
    try {
        $previousConfig = Get-Content $configFile -Raw | ConvertFrom-Json
        $previousPackages = @($previousConfig.EnabledFirmware | Where-Object { $_ })
        $previousFirmwareOn = [bool]$previousConfig.FirmwareEnabled
        $previousVisible = [bool]$previousConfig.Visible
    }
    catch { }
}

if (-not $PSBoundParameters.ContainsKey("FirmwarePackages")) { $FirmwarePackages = @($previousPackages) }
if (-not $PSBoundParameters.ContainsKey("FirmwareEnabled")) { $FirmwareEnabled = [switch]$previousFirmwareOn }
if (-not $PSBoundParameters.ContainsKey("Visible")) { $Visible = [switch]$previousVisible }

# Error reports: where reports go (reporting.json next to this script).
$reportDestination = [string](Get-Content (Join-Path $PSScriptRoot "reporting.json") -Raw | ConvertFrom-Json).ReportDestination

# Error reports are on, unless this PC turned them off in an earlier setup or in Options
# (then they stay off unless -ErrorReports is given). The setup window's tick box starts
# from this and decides.
$errorReporting = $true

if (Test-Path $configFile) {
    try {
        if ((Get-Content $configFile -Raw | ConvertFrom-Json).ErrorReporting -eq $false) { $errorReporting = $false }
    }
    catch { }
}

if ($ErrorReports)   { $errorReporting = $true }
if ($NoErrorReports) { $errorReporting = $false }


# ------------------------------------------------------------
# Setup window (when the folder was not given on the command line)
# ------------------------------------------------------------

$setupCredential = $null

if ($useGui -and -not $DestinationRoot) {

    $startFolder = Get-DefaultExtronFolder

    $previousBlocked = @($BlockedSSIDs)

    if (-not $PSBoundParameters.ContainsKey("BlockedSSIDs") -and (Test-Path $configFile)) {
        $previousBlocked = @((Get-Content $configFile -Raw | ConvertFrom-Json).BlockedSSIDs | Where-Object { $_ })
    }

    $firmwareKeys = @($FirmwarePackages | Where-Object { $key = $_; @($firmwareList | Where-Object Key -eq $key).Count -gt 0 })

    $choice = Show-SetupWizard -StartFolder $startFolder -BlockedNow $previousBlocked -Task $TaskName -ProductList $productList -Selected $Software `
        -FirmwareList $firmwareList -FirmwareOn ([bool]$FirmwareEnabled) -FirmwareSelected $firmwareKeys -VisibleNow ([bool]$Visible) -ErrorReports $errorReporting

    if (-not $choice) {
        Write-Host "Setup cancelled. Nothing was changed."
        exit 1
    }

    $DestinationRoot  = $choice.DestinationRoot
    $BlockedSSIDs     = @($choice.BlockedSSIDs)
    $Software         = @($choice.Software)
    $TaskName         = $choice.TaskName
    $noticeTaskName   = "$TaskName Notice"
    $setupCredential  = $choice.Credential
    $FirmwarePackages = @($choice.FirmwarePackages)
    $FirmwareEnabled  = [switch]$choice.FirmwareEnabled
    $Visible          = [switch]$choice.Visible
    $errorReporting   = [bool]$choice.ErrorReports    # the tick box decides, also over an earlier opt-out
    $wizardDone      = $true
}
else {

    # Console route: the firmware package keys are checked BEFORE anything is saved.
    $FirmwarePackages = @(Resolve-FirmwareKeys -Requested $FirmwarePackages -Devices $firmwareList)

    $problem = Test-FirmwareSettings -Keys $FirmwarePackages -Devices $firmwareList

    if ($problem) {
        Write-Host "Setup cannot continue: $problem"
        exit 1
    }

    $unknownSoftware = @($Software | Where-Object { $key = $_; @($productList | Where-Object Key -eq $key).Count -eq 0 })

    if ($unknownSoftware.Count -gt 0) {
        Write-Host "Setup cannot continue: these software names are not in products.json: $($unknownSoftware -join ', ')."
        exit 1
    }

    if (-not $DestinationRoot) {
        $DestinationRoot = (Read-Host "Folder to keep Extron files in (Software and Firmware folders are created inside)").Trim()
    }

    if (-not $DestinationRoot) {
        Write-Host "No folder was given. Setup cancelled."
        exit 1
    }

    $setupCredential = Get-SetupCredential

    if (-not (Test-ValidCredential $setupCredential)) {
        Write-Host "No credential was entered. Setup cancelled."
        exit 1
    }
}


# ------------------------------------------------------------
# Rollback support
#
# If setup is cancelled or fails before it finishes, remove only
# what THIS run created. Anything that already existed (folders,
# an earlier install) is never removed. Once setup completes,
# nothing is removed automatically.
# ------------------------------------------------------------

$script:createdPaths = New-Object System.Collections.Generic.List[string]
$script:createdTask  = $false
$script:createdNoticeTask = $false

# Never silently replace a scheduled task that another install is using.
# Re-running setup over its own install is fine.
if (-not $SkipTask) {

    $taskInTheWay = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue

    if ($taskInTheWay) {

        $ownLauncher = Join-Path $InstallDir $launcherName

        $theirCommand = ($taskInTheWay.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join " | "

        if ($useGui -and $theirCommand -notlike "*$ownLauncher*" -and -not $ReplaceExistingTask) {

            Add-Type -AssemblyName System.Windows.Forms

            $replaceAnswer = [System.Windows.Forms.MessageBox]::Show(
                "A scheduled task named '$TaskName' already exists and was not created by this setup:`r`n`r`n$theirCommand`r`n`r`nReplace it? Choose No to keep it (then run setup again with a different task name under Advanced).",
                "Extron Updater Setup", "YesNo", "Warning", "Button2")

            if ($replaceAnswer -eq "Yes") {
                $ReplaceExistingTask = $true
            }
        }

        if ($theirCommand -notlike "*$ownLauncher*" -and -not $ReplaceExistingTask) {

            Write-Host ""
            Write-Host "A scheduled task named '$TaskName' already exists and was not created by this setup:"
            Write-Host "  $theirCommand"
            Write-Host ""
            Write-Host "Setup will not replace it. Either choose a different name, for example:"
            Write-Host "  -TaskName `"$TaskName TEST`""
            Write-Host "or add -ReplaceExistingTask if you really want to replace it."
            exit 1
        }
    }
}

function New-TrackedDirectory {

    param ([string]$Path)

    if (Test-Path $Path) {
        return
    }

    # Remember the top-most folder that does not exist yet, so one
    # removal undoes the whole chain this run created.
    $top = $Path

    while ($true) {
        $parent = Split-Path $top -Parent

        if (-not $parent -or (Test-Path $parent)) {
            break
        }

        $top = $parent
    }

    New-Item -ItemType Directory -Path $Path -Force | Out-Null
    $script:createdPaths.Add($top)
}

function Register-CreatedFile {

    param ([string]$Path)

    if (-not (Test-Path $Path)) {
        $script:createdPaths.Add($Path)
    }
}

function Grant-UserTaskControl {

    # A task registered from an elevated (administrator) window can, by default,
    # only be changed from an elevated window, so the Stop icon (an ordinary
    # window) would get "Access is denied" even for the same person. Give the
    # signed-in user full control of THEIR OWN task; it already runs as them, so
    # this adds no privilege. A failure here is only a warning.
    param ([string]$Name)

    try {

        $sid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value

        $service = New-Object -ComObject Schedule.Service
        $service.Connect()

        $registered = $service.GetFolder("\").GetTask($Name)
        $registered.SetSecurityDescriptor("D:P(A;;FA;;;BA)(A;;FA;;;SY)(A;;FA;;;$sid)", 0)
    }
    catch {
        Write-Warning "Could not give your account control of the task '$Name' ($($_.Exception.Message)). The Stop icon may then need an administrator window."
    }
}

function Undo-Setup {

    if ($script:createdTask) {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
    }

    if ($script:createdNoticeTask) {
        Unregister-ScheduledTask -TaskName $noticeTaskName -Confirm:$false -ErrorAction SilentlyContinue
    }

    for ($i = $script:createdPaths.Count - 1; $i -ge 0; $i--) {
        Remove-Item $script:createdPaths[$i] -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function New-AppShortcut {

    param (
        [string]$Path,
        [string]$ScriptPath,
        [string]$Description = "Stop or resume the Extron Updater, check now, change the saved Extron password, or remove it",
        [string]$Icon = "$env:SystemRoot\System32\shell32.dll,316"   # the blue settings gear
    )

    $shell    = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($Path)

    $shortcut.TargetPath       = $pwsh
    $shortcut.Arguments        = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$ScriptPath`""
    $shortcut.WorkingDirectory = $InstallDir
    $shortcut.Description      = $Description
    $shortcut.IconLocation     = $Icon
    $shortcut.Save()
}

$setupFinished = $false

$progressForm = $null

if ($wizardDone) {

    Add-Type -AssemblyName System.Windows.Forms

    $progressForm = New-Object System.Windows.Forms.Form
    $progressForm.Text = "Extron Updater Setup"
    $progressForm.ClientSize = New-Object System.Drawing.Size(420, 90)
    $progressForm.StartPosition = "CenterScreen"; $progressForm.FormBorderStyle = "FixedDialog"
    $progressForm.ControlBox = $false; $progressForm.TopMost = $true
    $progressForm.Font = New-Object System.Drawing.Font("Segoe UI", 10)

    $progressLabel = New-Object System.Windows.Forms.Label
    $progressLabel.Text = "Installing the Extron Updater, please wait..."
    $progressLabel.Location = New-Object System.Drawing.Point(20, 28); $progressLabel.Size = New-Object System.Drawing.Size(380, 30)
    $progressForm.Controls.Add($progressLabel)

    $progressForm.Show()
    [System.Windows.Forms.Application]::DoEvents()
}

try {

    # --------------------------------------------------------
    # Where installers are saved
    # --------------------------------------------------------

    $extronFolder = $DestinationRoot
    New-TrackedDirectory $extronFolder
    New-TrackedDirectory (Join-Path $extronFolder "Software")
    New-TrackedDirectory (Join-Path $extronFolder "Firmware")

    Write-Host "Software will be saved to: $(Join-Path $extronFolder 'Software')"
    Write-Host "Firmware will be saved to: $(Join-Path $extronFolder 'Firmware') (one folder per family); firmware downloads are $(if ($FirmwareEnabled) { 'ON' } else { 'OFF' }), $(@($FirmwarePackages).Count) package(s) chosen"

    # --------------------------------------------------------
    # Login (the check with Extron already happened above)
    # --------------------------------------------------------

    New-TrackedDirectory $InstallDir

    Register-CreatedFile $credentialFile
    Save-ExtronCredential -Path $credentialFile -Credential $setupCredential

    # --------------------------------------------------------
    # Install files and settings
    # --------------------------------------------------------

    foreach ($file in $ownFiles) {
        $target = Join-Path $InstallDir $file
        Register-CreatedFile $target
        Copy-Item (Join-Path $PSScriptRoot $file) $target -Force
    }

    $updaterPath       = Join-Path $InstallDir $updaterName
    $optionsScriptPath = Join-Path $InstallDir $optionsScriptName
    $noticePath        = Join-Path $InstallDir $noticeName

    $config = [ordered]@{
        StateDir          = $InstallDir
        ExtronFolder      = $extronFolder
        BlockedSSIDs      = @($BlockedSSIDs)
        EnabledSoftware   = @($Software)
        EnabledFirmware   = @($FirmwarePackages)
        Visible           = [bool]$Visible
        FirmwareEnabled   = [bool]$FirmwareEnabled
        NoticeTaskName    = $noticeTaskName
        TaskName          = $TaskName
        ErrorReporting    = $errorReporting
        ReportDestination = $reportDestination
    }

    Register-CreatedFile $configFile
    $config | ConvertTo-Json -Depth 6 | Set-Content -Path $configFile -Encoding UTF8

    $vbs = @"
Set shell = CreateObject("WScript.Shell")
shell.Run """$pwsh"" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File ""$updaterPath""", 0, True
"@

    $launcherPath = Join-Path $InstallDir $launcherName
    Register-CreatedFile $launcherPath
    Set-Content -Path $launcherPath -Value $vbs -Encoding ASCII

    $noticeVbs = @"
Set shell = CreateObject("WScript.Shell")
shell.Run """$pwsh"" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""$noticePath""", 0, False
"@

    $noticeLauncherPath = Join-Path $InstallDir $noticeLauncher
    Register-CreatedFile $noticeLauncherPath
    Set-Content -Path $noticeLauncherPath -Value $noticeVbs -Encoding ASCII

    Write-Host "Installed to $InstallDir"

    # --------------------------------------------------------
    # Scheduled task: at logon and on wake from sleep
    # --------------------------------------------------------

    if (-not $SkipTask) {

        $user = "$env:USERDOMAIN\$env:USERNAME"

        $action = New-ScheduledTaskAction `
            -Execute "wscript.exe" `
            -Argument ('"{0}"' -f $launcherPath)

        # Matches the original working task: 2 minute delay after logon and
        # after resuming from sleep (Kernel-Power event 107).
        $logonTrigger = New-ScheduledTaskTrigger -AtLogOn -User $user
        $logonTrigger.Delay = "PT2M"

        $eventClass = Get-CimClass `
            -Namespace "Root/Microsoft/Windows/TaskScheduler" `
            -ClassName "MSFT_TaskEventTrigger"

        $wakeTrigger = New-CimInstance -CimClass $eventClass -ClientOnly
        $wakeTrigger.Enabled = $true
        $wakeTrigger.Delay = "PT2M"
        $wakeTrigger.Subscription = @"
<QueryList><Query Id="0" Path="System"><Select Path="System">*[System[Provider[@Name='Microsoft-Windows-Kernel-Power'] and EventID=107]]</Select></Query></QueryList>
"@

        $settings = New-ScheduledTaskSettingsSet `
            -StartWhenAvailable `
            -AllowStartIfOnBatteries `
            -DontStopIfGoingOnBatteries `
            -MultipleInstances IgnoreNew `
            -RunOnlyIfNetworkAvailable `
            -RestartCount 3 `
            -RestartInterval (New-TimeSpan -Minutes 5) `
            -ExecutionTimeLimit (New-TimeSpan -Hours 3)

        # Same account type as the original task: the signed-in user's SID, interactive.
        $userSid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value

        $principal = New-ScheduledTaskPrincipal `
            -UserId $userSid `
            -LogonType Interactive `
            -RunLevel Limited

        $existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue

        if ($existing) {
            Write-Host "A scheduled task named '$TaskName' already exists and will be replaced."
        }

        Register-ScheduledTask `
            -TaskName $TaskName `
            -Action $action `
            -Trigger @($logonTrigger, $wakeTrigger) `
            -Settings $settings `
            -Principal $principal `
            -Force |
            Out-Null

        Grant-UserTaskControl -Name $TaskName

        if (-not $existing) {
            $script:createdTask = $true
        }

        Write-Host "Scheduled task '$TaskName' registered (at logon)."

        # On-demand task that shows the "new version downloaded" notice.
        # No triggers and NO time limit: the notice stays open until the
        # user clicks a button, so it must not be tied to the updater's
        # 1 hour limit. The updater starts it with Start-ScheduledTask.
        $noticeAction = New-ScheduledTaskAction `
            -Execute "wscript.exe" `
            -Argument ('"{0}"' -f $noticeLauncherPath)

        $noticeSettings = New-ScheduledTaskSettingsSet `
            -AllowStartIfOnBatteries `
            -DontStopIfGoingOnBatteries `
            -MultipleInstances IgnoreNew `
            -ExecutionTimeLimit ([TimeSpan]::Zero)

        $existingNotice = Get-ScheduledTask -TaskName $noticeTaskName -ErrorAction SilentlyContinue

        Register-ScheduledTask `
            -TaskName $noticeTaskName `
            -Action $noticeAction `
            -Settings $noticeSettings `
            -Principal $principal `
            -Force |
            Out-Null

        Grant-UserTaskControl -Name $noticeTaskName

        if (-not $existingNotice) {
            $script:createdNoticeTask = $true
        }
    }

    # --------------------------------------------------------
    # "Extron Updater Options" icons (Desktop and Start menu)
    # --------------------------------------------------------

    $desktopLink = Join-Path ([Environment]::GetFolderPath("Desktop")) $optionsLinkName
    Register-CreatedFile $desktopLink
    New-AppShortcut -Path $desktopLink -ScriptPath $optionsScriptPath

    $startMenuFolder = Join-Path ([Environment]::GetFolderPath("Programs")) "Extron Updater"
    New-TrackedDirectory $startMenuFolder

    $startMenuLink = Join-Path $startMenuFolder $optionsLinkName
    Register-CreatedFile $startMenuLink
    New-AppShortcut -Path $startMenuLink -ScriptPath $optionsScriptPath

    $setupFinished = $true
}
catch {

    Write-Host ""

    if ($_.Exception.Message -match "cancelled") {
        Write-Host "Setup cancelled."
    }
    else {
        Write-Host "Setup failed: $($_.Exception.Message)"
    }
}
finally {

    if ($progressForm) {
        $progressForm.Close()
        $progressForm.Dispose()
    }

    # Also runs if the window is closed with Ctrl+C.
    if (-not $setupFinished) {
        Write-Host "Removing what this setup created..."
        Undo-Setup
        Write-Host "Done. Nothing from this setup was left behind."

        if ($wizardDone) {
            [void][System.Windows.Forms.MessageBox]::Show("Setup did not finish, so everything it had created was removed. Nothing was left behind.", "Extron Updater Setup", "OK", "Warning")
        }
    }
}

if (-not $setupFinished) {
    exit 1
}


Write-Host ""
Write-Host "Setup complete."
Write-Host "Run history (one dated line per attempt, with the reason if it failed):"
Write-Host "  $(Join-Path $InstallDir 'Logs\Run-History.log')"
Write-Host "Detailed log: $(Join-Path $InstallDir 'Logs\Extron-Updater.log')"
Write-Host ""
Write-Host "To stop or resume the updater, check now, change your Extron password or"
Write-Host "remove it, open 'Extron Updater Options' on your Desktop (or in the Start menu)."

if ($RunNow -and -not $SkipTask) {
    Start-ScheduledTask -TaskName $TaskName
    Write-Host "Started the updater now."
}

if ($useGui -and $wizardDone) {

    if (Show-SetupDone) {

        # Open the Options window (outside the install folder, so it can never block removing it).
        Start-Process -FilePath $pwsh -WorkingDirectory $env:TEMP -WindowStyle Hidden -ArgumentList @(
            "-NoProfile", "-ExecutionPolicy", "Bypass",
            "-File", "`"$optionsScriptPath`"",
            "-InstallDir", "`"$InstallDir`""
        )
    }
}
