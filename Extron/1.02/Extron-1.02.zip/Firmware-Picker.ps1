# Extron Updater -- firmware package picker (functions only; dot-source it).
# Shared by Install-ExtronUpdater.ps1 (Setup) and Options-ExtronUpdater.ps1 (Firmware settings...).
# The window is built from devices.json (one entry per Extron firmware package), grouped by Family, so a new
# package in the catalog shows up here with no code change. Only Tracked packages are listed unless
# "Show all packages" is ticked.

# All packages from devices.json (array of objects). Throws a plain message when the file is missing.
function Get-FirmwareChoices {

    param ([string]$CatalogPath)

    if (-not (Test-Path -LiteralPath $CatalogPath)) {
        throw "devices.json was not found ($CatalogPath)."
    }

    $all = @(Get-Content -LiteralPath $CatalogPath -Raw | ConvertFrom-Json)
    @($all | Where-Object { $_ -and $_.Key })
}

# The packages the picker lists by default: tracked ones only.
function Get-TrackedPackages {

    param ($Devices)

    @($Devices | Where-Object { $_.Tracked })
}

# Console switch -FirmwarePackages: package keys, or "all" = every tracked package. Unknown keys stay in the
# result so Test-FirmwareSettings can name them.
function Resolve-FirmwareKeys {

    param ([string[]]$Requested, $Devices)

    $wanted = @($Requested | ForEach-Object { "$_".Trim() } | Where-Object { $_ })

    if ($wanted -contains "all") {
        return @(Get-TrackedPackages $Devices | ForEach-Object { $_.Key })
    }

    return @($wanted | Select-Object -Unique)
}

function Format-FirmwareSize {

    param ([double]$MB)

    if ($MB -ge 1000) { return ("about {0:N1} GB" -f ($MB / 1024)) }
    return ("about {0} MB" -f [math]::Max(1, [math]::Round($MB)))
}

# "No packages chosen" / "1 package chosen" / "12 packages chosen (about 8.1 GB for the first download)"
function Get-FirmwareSummary {

    param ($Devices, [string[]]$Keys)

    $picked = @($Devices | Where-Object { $Keys -contains $_.Key })

    if ($picked.Count -eq 0) { return "No firmware packages chosen" }

    $noun = if ($picked.Count -eq 1) { "firmware package" } else { "firmware packages" }
    $bytes = 0.0
    foreach ($p in $picked) { $bytes += [double]$p.SizeBytes }
    $mb = $bytes / 1MB

    if ($mb -gt 0) { return "$($picked.Count) $noun chosen ($(Format-FirmwareSize $mb) for the first download)" }
    return "$($picked.Count) $noun chosen"
}

# Suggested Extron folder: "For Install\Extron" inside OneDrive, when a OneDrive folder with "For Install" exists;
# otherwise a folder named Extron under the user's Documents. Software and Firmware sub-folders are created below it.
function Get-DefaultExtronFolder {

    $roots = @($env:OneDrive, $env:OneDriveCommercial, $env:OneDriveConsumer | Where-Object { $_ } | Select-Object -Unique)

    foreach ($root in $roots) {
        $candidate = Join-Path $root "For Install"
        if (Test-Path -LiteralPath $candidate) { return (Join-Path $candidate "Extron") }
    }

    foreach ($root in $roots) {
        return (Join-Path (Join-Path $root "For Install") "Extron")
    }

    return (Join-Path ([Environment]::GetFolderPath("MyDocuments")) "Extron")
}

# Plain-wording problem with the firmware settings, or $null when they are fine.
function Test-FirmwareSettings {

    param ([string[]]$Keys, $Devices)

    $known = @($Devices | ForEach-Object { $_.Key })
    $unknown = @($Keys | Where-Object { $known -notcontains $_ })

    if ($unknown.Count -gt 0) { return "These firmware packages are not in the package list: $($unknown -join ', ')." }

    return $null
}

# The picker window. Returns the chosen keys (possibly none) or $null when cancelled.
function Show-FirmwarePicker {

    param ($Devices, [string[]]$Selected = @(), $Owner)

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $global:FP = @{ Boxes = [ordered]@{}; Chosen = @{}; All = @($Devices); ShowAll = $false }
    foreach ($k in $Selected) { $global:FP.Chosen[$k] = $true }

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Choose firmware packages"
    $form.ClientSize = New-Object System.Drawing.Size(660, 660)
    $form.StartPosition = if ($Owner) { "CenterParent" } else { "CenterScreen" }
    $form.FormBorderStyle = "FixedDialog"; $form.MaximizeBox = $false; $form.MinimizeBox = $false
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)
    $global:FP.Form = $form

    $intro = New-Object System.Windows.Forms.Label
    $intro.Text = "Tick the firmware packages to keep up to date. One package covers every model listed beside it. Only the newest file of each is kept. The updater only downloads firmware; loading it into devices is still done by hand."
    $intro.Location = New-Object System.Drawing.Point(20, 12); $intro.Size = New-Object System.Drawing.Size(620, 44)
    $form.Controls.Add($intro)

    $showAllBox = New-Object System.Windows.Forms.CheckBox
    $showAllBox.Name = "ShowAllPackages"; $showAllBox.Text = "Show all packages (including products outside the usual list)"
    $showAllBox.Location = New-Object System.Drawing.Point(20, 58); $showAllBox.Size = New-Object System.Drawing.Size(620, 24)
    $form.Controls.Add($showAllBox)

    $panel = New-Object System.Windows.Forms.Panel
    $panel.Name = "DevicePanel"
    $panel.Location = New-Object System.Drawing.Point(20, 88); $panel.Size = New-Object System.Drawing.Size(620, 450)
    $panel.AutoScroll = $true; $panel.BorderStyle = "FixedSingle"
    $form.Controls.Add($panel)
    $global:FP.Panel = $panel

    $tips = New-Object System.Windows.Forms.ToolTip
    $tips.AutoPopDelay = 20000
    $global:FP.Tips = $tips

    $estimate = New-Object System.Windows.Forms.Label
    $estimate.Name = "EstimateLabel"
    $estimate.Location = New-Object System.Drawing.Point(20, 546); $estimate.Size = New-Object System.Drawing.Size(620, 44)
    $form.Controls.Add($estimate)
    $global:FP.Estimate = $estimate

    $global:FP.Update = {
        $keys = @($global:FP.Chosen.Keys | Where-Object { $global:FP.Chosen[$_] })
        $global:FP.Estimate.Text = (Get-FirmwareSummary -Devices $global:FP.All -Keys $keys) + "`r`nLater updates only download what is new."
    }

    # Rebuilds the rows. The ticked set lives in $global:FP.Chosen so it survives a rebuild.
    $global:FP.Build = {
        $panel = $global:FP.Panel
        $panel.SuspendLayout()
        $panel.Controls.Clear()
        $global:FP.Boxes = [ordered]@{}

        $list = if ($global:FP.ShowAll) { @($global:FP.All) } else { @(Get-TrackedPackages $global:FP.All) }
        # Packages already chosen stay visible even when they are outside the tracked list.
        $extra = @($global:FP.All | Where-Object { $global:FP.Chosen[$_.Key] -and ($list.Key -notcontains $_.Key) })
        $list = @($list) + $extra

        $y = 8
        $groupIndex = 0
        foreach ($family in (@($list | ForEach-Object { if ($_.Family) { $_.Family } else { $_.Category } } | Select-Object -Unique))) {

            $groupIndex++
            $inFamily = @($list | Where-Object { $(if ($_.Family) { $_.Family } else { $_.Category }) -eq $family })

            $heading = New-Object System.Windows.Forms.Label
            $heading.Text = "$family  ($($inFamily.Count))"
            $heading.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
            $heading.Location = New-Object System.Drawing.Point(8, $y); $heading.Size = New-Object System.Drawing.Size(360, 24)
            $panel.Controls.Add($heading)

            $keysInFamily = @($inFamily | ForEach-Object { $_.Key })

            foreach ($mode in @(@{ Text = "None"; Value = $false; X = 500 }, @{ Text = "All"; Value = $true; X = 420 })) {
                $button = New-Object System.Windows.Forms.Button
                $button.Name = "$($mode.Text)_$groupIndex"
                $button.Text = $mode.Text
                $button.Location = New-Object System.Drawing.Point($mode.X, ($y - 1)); $button.Size = New-Object System.Drawing.Size(70, 26)
                $button.Tag = [pscustomobject]@{ Keys = $keysInFamily; Value = $mode.Value }
                $button.Add_Click({
                    param ($sender, $e)
                    try { foreach ($k in $sender.Tag.Keys) { $global:FP.Boxes[$k].Checked = $sender.Tag.Value } } catch { }
                })
                $panel.Controls.Add($button)
            }
            $y += 30

            foreach ($device in $inFamily) {

                $box = New-Object System.Windows.Forms.CheckBox
                $box.Name = "Device_$($device.Key)"
                $models = @($device.Models) -join ", "
                $label = $device.Name
                if ($models -and $models -ne $device.Name) { $label += "  -  $models" }
                if ($device.Status -eq "Legacy") { $label += "  (legacy)" }
                $box.Text = $label
                $box.AutoEllipsis = $true
                $box.Location = New-Object System.Drawing.Point(26, $y); $box.Size = New-Object System.Drawing.Size(570, 24)
                $box.Checked = [bool]$global:FP.Chosen[$device.Key]
                $box.Tag = $device.Key
                $box.Add_CheckedChanged({
                    param ($sender, $e)
                    try { $global:FP.Chosen[[string]$sender.Tag] = $sender.Checked; & $global:FP.Update } catch { }
                })

                $tip = "$($device.Name)`r`nModels: $models"
                if ($device.SizeBytes -gt 0) { $tip += "`r`nNewest file: $(Format-FirmwareSize ($device.SizeBytes / 1MB)), version $($device.Version)" }
                $global:FP.Tips.SetToolTip($box, $tip)

                $global:FP.Boxes[$device.Key] = $box
                $panel.Controls.Add($box)
                $y += 26
            }
            $y += 8
        }

        $panel.ResumeLayout()
        & $global:FP.Update
    }

    $showAllBox.Add_CheckedChanged({
        try { $global:FP.ShowAll = $global:FP.ShowAllBox.Checked; & $global:FP.Build } catch { }
    })
    $global:FP.ShowAllBox = $showAllBox

    $ok = New-Object System.Windows.Forms.Button
    $ok.Name = "PickerOK"; $ok.Text = "OK"; $ok.DialogResult = "OK"
    $ok.Location = New-Object System.Drawing.Point(460, 612); $ok.Size = New-Object System.Drawing.Size(86, 32)
    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Name = "PickerCancel"; $cancel.Text = "Cancel"; $cancel.DialogResult = "Cancel"
    $cancel.Location = New-Object System.Drawing.Point(554, 612); $cancel.Size = New-Object System.Drawing.Size(86, 32)
    $form.Controls.AddRange(@($ok, $cancel))

    # One toggle for the visible list (each family also has its own All / None).
    foreach ($mode in @(@{ Name = "PickerAll"; Text = "Select all"; Value = $true; X = 20 }, @{ Name = "PickerNone"; Text = "Select none"; Value = $false; X = 120 })) {
        $button = New-Object System.Windows.Forms.Button
        $button.Name = $mode.Name; $button.Text = $mode.Text
        $button.Location = New-Object System.Drawing.Point($mode.X, 612); $button.Size = New-Object System.Drawing.Size(92, 32)
        $button.Tag = $mode.Value
        $button.Add_Click({
            param ($sender, $e)
            try { foreach ($k in @($global:FP.Boxes.Keys)) { $global:FP.Boxes[$k].Checked = [bool]$sender.Tag } } catch { }
        })
        $form.Controls.Add($button)
    }
    $form.AcceptButton = $ok; $form.CancelButton = $cancel

    & $global:FP.Build

    $answer = if ($Owner) { $form.ShowDialog($Owner) } else { $form.ShowDialog() }

    $result = $null
    if ($answer -eq "OK") {
        # Catalog order (a plain hashtable lists its keys in a different order every run); keys not in the catalog come last.
        $catalogKeys = @($global:FP.All | ForEach-Object { $_.Key })
        $ticked = @($global:FP.Chosen.Keys | Where-Object { $global:FP.Chosen[$_] })
        $result = @($catalogKeys | Where-Object { $ticked -contains $_ }) + @($ticked | Where-Object { $catalogKeys -notcontains $_ } | Sort-Object)
    }

    $form.Dispose()
    $tips.Dispose()

    if ($null -eq $result) { return $null }
    Write-Output -NoEnumerate $result
}
