# ============================================================
# Crestron Updater
#
# Keeps the newest installer of each enabled Crestron product (1 Beyond Camera
# Manager, Construct, MasterInstaller, Remote Client) in the destination folder.
# Reads ftp.crestron.com over SFTP with the saved Crestron login (no browser).
# Only the newest version is kept: older versions of the same product are
# deleted AFTER the new one is downloaded, checked and moved in. Files that do
# not match a product's own filename pattern are never touched.
#
# All settings come from config.json (written by Install-CrestronUpdater.ps1).
# Dot-sourcing this file (. .\Crestron-Updater.ps1) only defines the functions;
# that is how the tests use it. Needs PowerShell 7.
# ============================================================

param (
    [string]$ConfigPath = (Join-Path $PSScriptRoot "config.json"),

    # Tests only: use a local folder laid out like the server (software\1_beyond\...)
    # instead of ftp.crestron.com. No login, no network.
    [string]$TestBackendRoot
)

$ErrorActionPreference = "Stop"

# Error reports (Reporting.ps1 next to this script; never passwords). A missing or damaged
# module never changes a run: the two functions the run calls then do nothing.
$reportingScript = Join-Path $PSScriptRoot "Reporting.ps1"
if (Test-Path -LiteralPath $reportingScript) { try { . $reportingScript } catch { } }
if (-not (Get-Command Send-ErrorReport -CommandType Function -ErrorAction SilentlyContinue) -or
    -not (Get-Command Send-ReportOutbox -CommandType Function -ErrorAction SilentlyContinue)) {
    function Send-ErrorReport { $null }
    function Send-ReportOutbox { 0 }
}


# ------------------------------------------------------------
# Versions and filename patterns (pure functions, no I/O)
# ------------------------------------------------------------

# "1.4901.0018" -> @(1,4901,18). Returns $null when it is not dotted whole numbers.
function Start-DownloadStatus {
    $statusPath = $null
    try {
        $state = $script:config.StateDir
        if ($state -and (Test-Path -LiteralPath $state)) {
            $statusPath = Join-Path $state 'download-status.json'
            $process = [Diagnostics.Process]::GetCurrentProcess()
            $json = @{ Pid = $PID; StartTicks = $process.StartTime.ToUniversalTime().Ticks.ToString(); Status = 'Downloading' } | ConvertTo-Json -Compress
            [IO.File]::WriteAllText($statusPath, $json)
        }
    } catch { $statusPath = $null }
    return $statusPath
}

function Invoke-TrackedDownload {
    param([scriptblock]$Transfer)
    $statusPath = Start-DownloadStatus
    try { & $Transfer }
    finally { if ($statusPath) { try { [IO.File]::Delete($statusPath) } catch { } } }
}

# An old version that is being installed right now (an installer running from it, or a file in it held open by
# another program) is never moved or deleted: the caller skips that product this run and tries again next run
# (user 2026-11-14). Returns a plain-words reason, or $null when nothing is in use. Missing paths are ignored.
function Get-InUseReason {
    param ([string[]]$Paths)
    $items = @()
    foreach ($p in $Paths) {
        if (-not $p) { continue }
        try { $items += Get-Item -LiteralPath $p -Force -ErrorAction Stop } catch { }
    }
    if ($items.Count -eq 0) { return $null }
    $roots = @($items | ForEach-Object { $_.FullName.TrimEnd('\') })
    foreach ($proc in @(Get-Process -ErrorAction SilentlyContinue)) {
        $exe = $null
        try { $exe = $proc.Path } catch { }
        if (-not $exe) { continue }
        foreach ($r in $roots) {
            if ($exe.Equals($r, [StringComparison]::OrdinalIgnoreCase) -or $exe.StartsWith($r + '\', [StringComparison]::OrdinalIgnoreCase)) {
                return "$(Split-Path -Leaf $r) is in use ($($proc.ProcessName) is running from it)"
            }
        }
    }
    # Offline / RecallOnDataAccess: a cloud-only copy is not held by anything here, and opening it would download it.
    $cloudOnly = [int][IO.FileAttributes]::Offline -bor 0x400000
    foreach ($it in $items) {
        $files = if ($it.PSIsContainer) { @(Get-ChildItem -LiteralPath $it.FullName -Recurse -File -Force -ErrorAction SilentlyContinue) } else { @($it) }
        foreach ($f in $files) {
            if (([int]$f.Attributes -band $cloudOnly) -ne 0) { continue }
            $stream = $null
            try { $stream = [IO.File]::Open($f.FullName, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::None) }
            catch [System.IO.FileNotFoundException] { }
            catch [System.IO.DirectoryNotFoundException] { }
            catch [System.UnauthorizedAccessException] { }
            catch { return "$($f.Name) is in use (open in another program)" }
            finally { if ($stream) { $stream.Dispose() } }
        }
    }
    return $null
}

function ConvertTo-VersionParts {

    param ([string]$Text)

    if ($Text -notmatch '^\d+(\.\d+)*$') { return $null }

    try { , [int[]]($Text -split '\.') } catch { $null }
}

# -1 / 0 / 1. Missing trailing parts count as 0 (4.0 equals 4.0.0).
function Compare-VersionParts {

    param ([int[]]$A, [int[]]$B)

    $length = [math]::Max($A.Count, $B.Count)

    for ($i = 0; $i -lt $length; $i++) {

        $x = if ($i -lt $A.Count) { $A[$i] } else { 0 }
        $y = if ($i -lt $B.Count) { $B[$i] } else { 0 }

        if ($x -lt $y) { return -1 }
        if ($x -gt $y) { return 1 }
    }

    0
}

# The version in a file name if it matches one of the product's patterns
# (regular expressions with a (?<ver>...) group, matched without regard to case); otherwise $null.
function Get-ProductVersion {

    param ([string]$Name, [string[]]$Patterns)

    foreach ($pattern in $Patterns) {

        if ($Name -match "(?i)$pattern") {

            $parts = ConvertTo-VersionParts $Matches['ver']

            if ($parts) {
                return [pscustomobject]@{ Name = $Name; Parts = $parts; Text = $Matches['ver'] }
            }
        }
    }

    $null
}

# Files from a list of names (or objects with a Name) that belong to the product, newest first.
function Select-ProductFiles {

    param ($Items, [string[]]$Patterns)

    $sorted = [System.Collections.Generic.List[object]]::new()

    foreach ($item in @($Items)) {

        $name = if ($item -is [string]) { $item } else { $item.Name }
        $v = Get-ProductVersion -Name $name -Patterns $Patterns

        if (-not $v) { continue }

        $v | Add-Member -NotePropertyName Item -NotePropertyValue $item

        # Insert before the first entry that is older (keeps newest first).
        $at = 0
        while ($at -lt $sorted.Count -and (Compare-VersionParts $sorted[$at].Parts $v.Parts) -ge 0) { $at++ }

        $sorted.Insert($at, $v)
    }

    $sorted
}

# The md5 for $FileName from the text of its .md5 file, or $null when it cannot be
# told for sure. A line naming the file wins; otherwise exactly one distinct md5 in
# the whole text is used.
function Get-Md5FromText {

    param ([string]$Text, [string]$FileName)

    foreach ($line in ($Text -split "`r?`n")) {
        if ($line -like "*$FileName*" -and $line -match '(?i)\b([0-9a-f]{32})\b') {
            return $Matches[1].ToLower()
        }
    }

    $all = @([regex]::Matches($Text, '(?i)\b[0-9a-f]{32}\b') | ForEach-Object { $_.Value.ToLower() } | Select-Object -Unique)

    if ($all.Count -eq 1) { return $all[0] }

    $null
}

# Throws a plain-wording error when the downloaded file is not what the server listed.
function Test-DownloadedFile {

    # Validate: mz = a Windows program (.exe starts with MZ), zip = opens as a ZIP archive, size = the size check only (.puf, .bin).
    param ([string]$Path, [long]$ExpectedSize, [string]$ExpectedMd5, [string]$Validate = "mz")

    $item = Get-Item -LiteralPath $Path

    if ($item.Length -ne $ExpectedSize) {
        throw "The download is incomplete ($($item.Length) bytes received, $ExpectedSize expected)."
    }

    if ($Validate -eq "mz") {

        $stream = [System.IO.File]::OpenRead($Path)
        try {
            $b1 = $stream.ReadByte(); $b2 = $stream.ReadByte()
        }
        finally { $stream.Dispose() }

        if ($b1 -ne 0x4D -or $b2 -ne 0x5A) {
            throw "The downloaded file is not a Windows program (it does not start with 'MZ')."
        }
    }
    elseif ($Validate -eq "zip") {

        Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue

        $count = -1
        try {
            $zip = [System.IO.Compression.ZipFile]::OpenRead($Path)
            try { $count = $zip.Entries.Count } finally { $zip.Dispose() }
        }
        catch { throw "The downloaded file is not a valid ZIP archive." }

        if ($count -lt 1) { throw "The downloaded ZIP archive is empty." }
    }

    if ($ExpectedMd5) {

        $actual = (Get-FileHash -LiteralPath $Path -Algorithm MD5).Hash.ToLower()

        if ($actual -ne $ExpectedMd5.ToLower()) {
            throw "The download does not match Crestron's checksum (expected $ExpectedMd5, got $actual)."
        }
    }
}


# ------------------------------------------------------------
# Firmware catalog (firmware-catalog.json): the list of devices is DATA
# ------------------------------------------------------------

$script:FirmwareStatuses  = @('current', 'unverified', 'discontinued')
$script:FirmwareValidates = @('size', 'zip', 'mz')

# An entry with UsesFirmwareOf has no firmware of its own: it is another picker row for the same
# firmware (same server folder, patterns, validation and local folder as the entry it names).
function Resolve-FirmwareEntry {

    param ($Entry, $All)

    $target = $null

    if ($Entry.PSObject.Properties.Name -contains 'UsesFirmwareOf' -and $Entry.UsesFirmwareOf) {
        $target = @($All | Where-Object { $_.Key -eq $Entry.UsesFirmwareOf }) | Select-Object -First 1
    }

    $source = if ($target) { $target } else { $Entry }

    [pscustomobject]@{
        Key        = [string]$Entry.Key
        Name       = [string]$Entry.Name
        Category   = [string]$Entry.Category
        Models     = [string]$Entry.Models
        Status     = [string]$Entry.Status
        Notes      = [string]$Entry.Notes
        RemotePath = [string]$source.RemotePath
        Patterns   = @($source.Patterns)
        Validate   = [string]$source.Validate
        SubFolder  = [string]$source.SubFolder
        ApproxMB   = [double]$source.ApproxMB
        UsesFirmwareOf = [string]$Entry.UsesFirmwareOf
    }
}

# What makes two catalog entries "the same firmware": the same server folder and the same patterns.
function Get-FirmwareShape {

    param ($Entry)

    "$($Entry.RemotePath)|$((@($Entry.Patterns) | ForEach-Object { $_.ToLower() } | Sort-Object) -join ';')"
}

# Every problem found in the catalog, in plain wording (empty = the catalog is fine).
# Firmware is stored FLAT in one folder (one current file per device), so safety rests on patterns:
# - entries with the same RemotePath + Patterns are the same firmware (one download, one file);
# - a file name must never be claimed by two DIFFERENT firmware shapes. SampleNames (real file names from
#   the server) lets the check prove that; without them only the structure is checked.
# Discontinued entries must be well formed, but take no part in the overlap check (never downloaded).
function Test-FirmwareCatalog {

    param ($Devices, [string[]]$SampleNames = @())

    $errors = New-Object System.Collections.Generic.List[string]
    $devices = @($Devices)

    $keys = @{}
    foreach ($d in $devices) {

        $label = if ($d.Key) { "'$($d.Key)'" } else { "(entry without a Key)" }

        if (-not $d.Key -or $d.Key -notmatch '^[a-z0-9][a-z0-9-]*$') { $errors.Add("$label has a missing or invalid Key (lowercase letters, digits and dashes).") }
        elseif ($keys.ContainsKey($d.Key)) { $errors.Add("${label}: the Key is used twice.") }
        else { $keys[$d.Key] = $true }

        foreach ($field in 'Name', 'Category', 'Models') {
            if (-not $d.$field) { $errors.Add("$label has no $field.") }
        }

        if ([string]$d.Status -notin $script:FirmwareStatuses) { $errors.Add("$label has Status '$($d.Status)' (use: $($script:FirmwareStatuses -join ', ')).") }

        $hasAlias = $d.PSObject.Properties.Name -contains 'UsesFirmwareOf' -and $d.UsesFirmwareOf

        if ($hasAlias) {

            $target = @($devices | Where-Object { $_.Key -eq $d.UsesFirmwareOf }) | Select-Object -First 1

            if (-not $target) { $errors.Add("${label}: UsesFirmwareOf '$($d.UsesFirmwareOf)' does not exist.") }
            elseif ($target.PSObject.Properties.Name -contains 'UsesFirmwareOf' -and $target.UsesFirmwareOf) { $errors.Add("${label}: UsesFirmwareOf must name an entry that has its own firmware, not another alias.") }

            continue
        }

        if (-not $d.RemotePath -or ([string]$d.RemotePath) -notmatch '^/[^\s]+$') { $errors.Add("$label has no valid RemotePath (starts with /).") }

        if (-not @($d.Patterns).Count) { $errors.Add("$label has no Patterns.") }

        foreach ($pattern in @($d.Patterns)) {

            if ($pattern -notmatch '\(\?<ver>') { $errors.Add("${label}: pattern '$pattern' has no (?<ver>...) group."); continue }

            try { [void][regex]::new("(?i)$pattern") }
            catch { $errors.Add("${label}: pattern '$pattern' is not a valid regular expression ($($_.Exception.Message)).") }

            if ($pattern -notmatch '^\^' -or $pattern -notmatch '\$$') { $errors.Add("${label}: pattern '$pattern' must start with ^ and end with `$ (match the whole file name).") }
        }

        # Optional local sub-folder inside the firmware folder (used for the NVX group); empty = directly in the firmware folder.
        $sub = [string]$d.SubFolder
        if ($sub -and ($sub.IndexOfAny([System.IO.Path]::GetInvalidFileNameChars()) -ge 0 -or $sub -match '^\.|\.\.')) { $errors.Add("$label has an invalid SubFolder name.") }

        if ([string]$d.Validate -notin $script:FirmwareValidates) { $errors.Add("$label has Validate '$($d.Validate)' (use: $($script:FirmwareValidates -join ', ')).") }
    }

    $active = @($devices | Where-Object { [string]$_.Status -ne 'discontinued' -and $_.Key } | ForEach-Object { Resolve-FirmwareEntry $_ $devices } | Where-Object { $_.RemotePath -and @($_.Patterns).Count })

    # The same firmware listed twice is fine (the updater downloads it once), but both entries must agree on how to check it.
    foreach ($group in ($active | Group-Object { Get-FirmwareShape $_ })) {
        if (@($group.Group.Validate | Select-Object -Unique).Count -gt 1) {
            $errors.Add("Entries $(($group.Group | ForEach-Object { "'$($_.Key)'" }) -join ', ') are the same firmware but have different Validate settings.")
        }
    }

    # The same firmware must always go to the same place (otherwise it would be stored, and downloaded, twice).
    foreach ($group in ($active | Group-Object { Get-FirmwareShape $_ })) {
        if (@($group.Group | ForEach-Object { [string]$_.SubFolder } | Select-Object -Unique).Count -gt 1) {
            $errors.Add("Entries $(($group.Group | ForEach-Object { "'$($_.Key)'" }) -join ', ') are the same firmware but have different SubFolder settings (it would be stored twice).")
        }
    }

    foreach ($name in ($SampleNames | Select-Object -Unique)) {

        $claimedBy = @($active | Where-Object { $e = $_; @($e.Patterns | Where-Object { $name -match "(?i)$_" }).Count -gt 0 })
        $shapes = @($claimedBy | ForEach-Object { Get-FirmwareShape $_ } | Select-Object -Unique)

        if ($shapes.Count -gt 1) {
            $errors.Add("The file '$name' would be claimed by DIFFERENT firmware entries ($(($claimedBy | ForEach-Object { "'$($_.Key)'" }) -join ', ')). Firmware is stored in one flat folder, so make the patterns stricter.")
        }
    }

    $errors.ToArray()
}

# The software list is DATA (products.json next to this script). config.json stores only the enabled KEYS.
# Older installs stored whole product objects with an Enabled flag: still accepted, but the definitions
# (RemotePath, Patterns, ...) then come from products.json so catalog edits reach installed machines.
# Without a products.json the stored objects are used as they are.
function Get-SoftwareProducts {

    param ($Config, [string]$CatalogPath)

    $hasKey = @($Config.PSObject.Properties.Name) -contains 'Products'
    $stored = @(if ($hasKey) { @($Config.Products | Where-Object { $_ }) })

    $catalog = $null
    if (Test-Path -LiteralPath $CatalogPath) {
        try { $catalog = @(Get-Content -LiteralPath $CatalogPath -Raw | ConvertFrom-Json) }
        catch { throw "The software list could not be read ($CatalogPath): $($_.Exception.Message)" }
    }

    $legacy = ($stored.Count -gt 0 -and $stored[0] -isnot [string])

    if ($legacy) {
        if (-not $catalog) { return @($stored | Where-Object { $_.Enabled }) }
        $keys = @($stored | Where-Object { $_.Enabled } | ForEach-Object { [string]$_.Key })
    }
    elseif ($hasKey) { $keys = @($stored | ForEach-Object { [string]$_ }) }
    else {
        if (-not $catalog) { throw "The software list was not found: $CatalogPath" }
        $keys = @($catalog | Where-Object { $_.Enabled } | ForEach-Object { [string]$_.Key })
    }

    if (-not $catalog) { throw "The software list was not found: $CatalogPath" }

    @($catalog | Where-Object { $keys -contains $_.Key })
}

# Loads the catalog. Returns Devices (the ACTIVE entries, resolved: current and unverified, never discontinued)
# and Errors (plain-wording problems). A device with a problem is left out; the others still work.
function Get-FirmwareCatalog {

    param ([string]$Path, [string[]]$SampleNames = @())

    if (-not (Test-Path -LiteralPath $Path)) { throw "The firmware device list was not found: $Path" }

    try { $catalog = Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json }
    catch { throw "The firmware device list could not be read ($Path): $($_.Exception.Message)" }

    if (-not $catalog.Devices) { throw "The firmware device list has no Devices ($Path)." }

    $all = @($catalog.Devices)
    $errors = @(Test-FirmwareCatalog $all -SampleNames $SampleNames)

    # Entries named in an error are skipped, everything else is used.
    $badKeys = @{}
    foreach ($e in $errors) { foreach ($m in [regex]::Matches($e, "'([a-z0-9-]+)'")) { $badKeys[$m.Groups[1].Value] = $true } }

    $devices = @($all |
        Where-Object { [string]$_.Status -in 'current', 'unverified' -and $_.Key -and -not $badKeys.ContainsKey([string]$_.Key) } |
        ForEach-Object { Resolve-FirmwareEntry $_ $all })

    [pscustomobject]@{ Devices = $devices; Errors = $errors; All = $all }
}


# ------------------------------------------------------------
# The server (real SFTP, or a local folder for tests)
#
# Everything that touches the server goes through these four functions, so the
# tests replace them. Entries from Get-RemoteList have Name, Length, IsDirectory.
# ------------------------------------------------------------

# Loads SSH.NET and a tiny helper that answers the server-key question. The helper is compiled
# code (not a script block) because SSH.NET raises that event on its own thread.
function Initialize-SftpLibrary {

    if ('CrestronHostKeyCheck' -as [type]) { return }

    $lib = Join-Path $PSScriptRoot "lib"

    foreach ($dll in "Microsoft.Extensions.Logging.Abstractions", "BouncyCastle.Cryptography", "Renci.SshNet") {
        Add-Type -Path (Join-Path $lib "$dll.dll")
    }

    Add-Type -IgnoreWarnings -WarningAction SilentlyContinue -ReferencedAssemblies (Join-Path $lib "Renci.SshNet.dll") -TypeDefinition @'
public class CrestronHostKeyCheck
{
    public string Expected;      // "SHA256:..." recorded at setup
    public bool Record;          // true only during setup: trust whatever the server shows and remember it
    public bool AcceptAny;       // true unless config HostKeyCheck = "Pinned" (see Connect-Remote)
    public bool Refused;
    public string Fingerprint;

    public void Attach(Renci.SshNet.BaseClient client)
    {
        client.HostKeyReceived += delegate(object sender, Renci.SshNet.Common.HostKeyEventArgs e)
        {
            Fingerprint = "SHA256:" + e.FingerPrintSHA256;
            e.CanTrust = Record || AcceptAny || (Expected != null && Expected == Fingerprint);
            if (!e.CanTrust) { Refused = true; }
        };
    }
}
'@
}

# Connection-level trouble (reset, abort, timeout, no route): worth a retry, and never an error notice.
# Looks through the whole inner-exception chain. A plain IOException (disk full, file locked) does NOT count
# unless a socket / SSH connection error sits inside it. A rejected login is never a connection drop.
function Test-ConnectionDrop {

    param ($Exception)

    for ($ex = $Exception; $ex; $ex = $ex.InnerException) {

        $name = $ex.GetType().Name
        if ($name -eq 'SshAuthenticationException') { return $false }
        if ($ex -is [System.Net.Sockets.SocketException] -or $ex -is [System.TimeoutException] -or $name -in 'SshConnectionException', 'SshOperationTimeoutException') { return $true }
    }

    $false
}

# Waits until the Crestron server accepts a TCP connection (at logon / wake the network is often not up yet).
# Polls every few seconds for up to MaxSeconds. Returns $true when reachable, $false when it never was.
function Wait-ForNetwork {

    param ([string]$TargetHost, [int]$Port, [int]$MaxSeconds = 180, [int]$PollSeconds = 5, [int]$ConnectSeconds = 5)

    $deadline = (Get-Date).AddSeconds($MaxSeconds)
    $announced = $false

    while ($true) {

        $client = New-Object System.Net.Sockets.TcpClient
        try {
            $async = $client.BeginConnect($TargetHost, $Port, $null, $null)
            if ($async.AsyncWaitHandle.WaitOne($ConnectSeconds * 1000) -and $client.Connected) { $client.EndConnect($async); return $true }
        }
        catch { }
        finally { $client.Close() }

        if ((Get-Date) -ge $deadline) { return $false }

        if (-not $announced) { Write-Host "Waiting for the network..."; $announced = $true }
        Start-Sleep -Seconds $PollSeconds
    }
}

# -RecordHostKey is for setup only: the first contact, which remembers the server's key in
# $script:hostKeyCheck.Fingerprint.
# Host-key policy (2026-11-13): ftp.crestron.com serves several different keys from one address
# (at least 3 seen, depending on where the client connects from; Data\hostkey-mismatch-investigation.md).
# Until Crestron publishes its list, any key is accepted and the key shown is logged on every run.
# Set config.json "HostKeyCheck": "Pinned" to go back to trusting only HostKeyFingerprint.
function Connect-Remote {

    param ($Config, [pscredential]$Credential, [switch]$RecordHostKey)

    if ($TestBackendRoot) { return }

    Initialize-SftpLibrary

    $client = [Renci.SshNet.SftpClient]::new(
        $Config.Host, [int]$Config.Port, $Credential.UserName, $Credential.GetNetworkCredential().Password
    )

    $client.OperationTimeout = [TimeSpan]::FromMinutes(90)

    $script:hostKeyCheck = [CrestronHostKeyCheck]::new()
    $script:hostKeyCheck.Expected = $Config.HostKeyFingerprint
    $script:hostKeyCheck.Record   = [bool]$RecordHostKey
    $script:hostKeyCheck.AcceptAny = ("$($Config.HostKeyCheck)" -ne 'Pinned')
    $script:hostKeyCheck.Attach($client)

    try {
        $client.Connect()
    }
    catch {
        $client.Dispose()
        throw
    }

    # Public value, no login data: collects the keys Crestron serves, for the list asked of Crestron.
    $savedFp = $Config.HostKeyFingerprint
    $match = if (-not $savedFp) { 'none saved' } elseif ($savedFp -eq $script:hostKeyCheck.Fingerprint) { 'same as saved' } else { "differs from saved $savedFp" }
    Write-Host "Server key: $($script:hostKeyCheck.Fingerprint) ($match; accept-any: $($script:hostKeyCheck.AcceptAny))"

    $script:sftp = $client
}

# Connect-Remote, retried on connection drops (not on a rejected login or a host-key refusal).
# The original error is rethrown when the tries run out.
function Connect-RemoteWithRetry {

    param ($Config, [pscredential]$Credential, [int[]]$DelaySeconds = @(5, 10))

    for ($try = 0; ; $try++) {

        try { Connect-Remote -Config $Config -Credential $Credential; return }
        catch {
            $refused = $script:hostKeyCheck -and $script:hostKeyCheck.Refused
            if ($refused -or $try -ge $DelaySeconds.Count -or -not (Test-ConnectionDrop $_.Exception)) { throw }
            Write-Host "Connection dropped ($($_.Exception.Message)). Trying again in $($DelaySeconds[$try]) seconds."
            Start-Sleep -Seconds $DelaySeconds[$try]
        }
    }
}

function Disconnect-Remote {

    if ($script:sftp) {
        try { $script:sftp.Disconnect() } catch { }
        try { $script:sftp.Dispose() } catch { }
        $script:sftp = $null
    }
}

function Get-RemoteList {

    param ([string]$Path)

    if ($TestBackendRoot) {

        $folder = Join-Path $TestBackendRoot ($Path.TrimStart('/') -replace '/', '\')

        return @(Get-ChildItem -LiteralPath $folder -Force | ForEach-Object {
            [pscustomobject]@{ Name = $_.Name; Length = [long]$(if ($_.PSIsContainer) { 0 } else { $_.Length }); IsDirectory = [bool]$_.PSIsContainer }
        })
    }

    @($script:sftp.ListDirectory($Path) | Where-Object { $_.Name -notin '.', '..' } | ForEach-Object {
        [pscustomobject]@{ Name = $_.Name; Length = [long]$_.Length; IsDirectory = [bool]$_.IsDirectory }
    })
}

function Get-RemoteFile {

    param ([string]$Path, [string]$Destination)

    if ($TestBackendRoot) {
        Copy-Item -LiteralPath (Join-Path $TestBackendRoot ($Path.TrimStart('/') -replace '/', '\')) -Destination $Destination -Force
        return
    }

    $stream = [System.IO.File]::Create($Destination)
    try { $script:sftp.DownloadFile($Path, $stream) }
    finally { $stream.Dispose() }
}

function Get-RemoteText {

    param ([string]$Path)

    $temp = Join-Path ([System.IO.Path]::GetTempPath()) ("crestron-text-" + [guid]::NewGuid().ToString("N"))

    try {
        Get-RemoteFile -Path $Path -Destination $temp
        Get-Content -LiteralPath $temp -Raw
    }
    finally { Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue }
}


# ------------------------------------------------------------
# Updating one product
# ------------------------------------------------------------

# Returns an object: Key, Name, Kind (Software / Firmware), Status (Current / Updated / Shared / Failed), Detail,
# Previous, New, FilePath, Removed. A failure leaves the destination folder exactly as it was.
#   SearchRoot       firmware: the firmware folder. A file with the same name and size already stored anywhere under it
#                    (another sub-folder) is NOT downloaded again (Status Shared).
#   OtherPatternSets patterns (one array per OTHER firmware entry): an old file claimed by any of them is never deleted.
function Update-Product {

    param ($Product, [string]$Destination, [string]$TempFolder, [string]$SearchRoot, $OtherPatternSets = @())

    $names    = $Product.PSObject.Properties.Name
    $kind     = if ($names -contains 'Kind' -and $Product.Kind) { [string]$Product.Kind } else { "Software" }
    $validate = if ($names -contains 'Validate' -and $Product.Validate) { [string]$Product.Validate } else { "mz" }

    $result = [pscustomobject]@{
        Key = $Product.Key; Name = $Product.Name; Kind = $kind; Status = "Failed"; Detail = ""
        Previous = $null; New = $null; FilePath = $null; Removed = @(); Dropped = $false
    }

    $downloaded = $null

    try {

        $patterns = @($Product.Patterns)

        New-Item -ItemType Directory -Path $Destination -Force | Out-Null

        $remote = @(Select-ProductFiles -Items (Get-RemoteList $Product.RemotePath | Where-Object { -not $_.IsDirectory }) -Patterns $patterns)

        if ($remote.Count -eq 0) {
            throw "No $(if ($kind -eq 'Firmware') { 'firmware' } else { 'installer' }) matching the expected file name was found in $($Product.RemotePath)."
        }

        $latest = $remote[0]

        $local = @(Select-ProductFiles -Items (Get-ChildItem -LiteralPath $Destination -File) -Patterns $patterns)

        if ($local.Count -gt 0) {
            $result.Previous = $local[0].Text
        }

        if ($local.Count -gt 0 -and (Compare-VersionParts $local[0].Parts $latest.Parts) -ge 0) {
            $result.Status = "Current"
            $result.Detail = "$($local[0].Text) is the newest."
            return $result
        }

        # The same file (name + size) already stored somewhere else under the search root: never download it twice.
        if ($SearchRoot -and (Test-Path -LiteralPath $SearchRoot)) {

            $here = (Resolve-Path -LiteralPath $Destination).Path.TrimEnd('\')

            $same = @(Get-ChildItem -LiteralPath $SearchRoot -Recurse -File -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -eq $latest.Name -and $_.Length -eq $latest.Item.Length -and $_.DirectoryName.TrimEnd('\') -ne $here })

            if ($same.Count -gt 0) {
                $result.Status = "Shared"
                $result.Detail = "$($latest.Text): the same file is already stored at $($same[0].FullName); not downloaded again."
                return $result
            }
        }

        # What this update would delete or replace: older versions of THIS product (not claimed by another firmware
        # entry) and a same-name file. If any is in use (being installed), skip until the next run, before downloading.
        $retire = @()
        foreach ($old in $local) {
            if ((Compare-VersionParts $old.Parts $latest.Parts) -ge 0) { continue }
            $claimedByOther = $false
            foreach ($set in @($OtherPatternSets)) {
                if (@(Select-ProductFiles -Items @($old.Name) -Patterns @($set)).Count -gt 0) { $claimedByOther = $true; break }
            }
            if (-not $claimedByOther) { $retire += $old.Item.FullName }
        }
        $retire += Join-Path $Destination $latest.Name
        $busy = Get-InUseReason $retire
        if ($busy) { $result.Status = "InUse"; $result.Detail = "Skipped: $busy. Will try again next run."; return $result }

        # Room for the download in the temp folder and the destination, plus a margin.
        $needed = $latest.Item.Length + 100MB
        foreach ($folder in $TempFolder, $Destination) {

            $root = [System.IO.Path]::GetPathRoot((Resolve-Path -LiteralPath $folder).Path)
            $free = (New-Object System.IO.DriveInfo $root).AvailableFreeSpace

            if ($free -lt $needed) {
                throw "Not enough free disk space on $root ($([math]::Round($free / 1MB)) MB free, about $([math]::Round($needed / 1MB)) MB needed)."
            }
        }

        $md5 = $null
        if ($names -contains 'ChecksumSidecar' -and $Product.ChecksumSidecar) {

            $sidecar = @(Get-RemoteList $Product.RemotePath | Where-Object { $_.Name -ieq ($latest.Name + ".md5") })

            if ($sidecar.Count -eq 1) {
                try { $md5 = Get-Md5FromText -Text (Get-RemoteText "$($Product.RemotePath)/$($sidecar[0].Name)") -FileName $latest.Name } catch { }
            }
        }

        $downloaded = Join-Path $TempFolder $latest.Name
        Write-Host "  Downloading $($latest.Name) ($([math]::Round($latest.Item.Length / 1MB, 1)) MB)..."
        Invoke-TrackedDownload { Get-RemoteFile -Path "$($Product.RemotePath)/$($latest.Name)" -Destination $downloaded }

        Test-DownloadedFile -Path $downloaded -ExpectedSize $latest.Item.Length -ExpectedMd5 $md5 -Validate $validate

        $busy = Get-InUseReason $retire
        if ($busy) { $result.Status = "InUse"; $result.Detail = "Skipped: $busy. Will try again next run."; return $result }

        $target = Join-Path $Destination $latest.Name
        Move-Item -LiteralPath $downloaded -Destination $target -Force
        $downloaded = $null

        # Only now, with the new version in place, delete older versions of THIS product. A file that another
        # firmware entry's pattern also claims is never deleted.
        $removed = @()
        foreach ($old in $local) {

            if ((Compare-VersionParts $old.Parts $latest.Parts) -ge 0) { continue }

            $claimedByOther = $false
            foreach ($set in @($OtherPatternSets)) {
                if (@(Select-ProductFiles -Items @($old.Name) -Patterns @($set)).Count -gt 0) { $claimedByOther = $true; break }
            }
            if ($claimedByOther) { continue }

            Remove-Item -LiteralPath $old.Item.FullName -Force
            $removed += $old.Name
        }

        $result.Status   = "Updated"
        $result.New      = $latest.Text
        $result.FilePath = $target
        $result.Removed  = $removed
        $result.Detail   = "$(if ($result.Previous) { "$($result.Previous) -> " })$($latest.Text)"
    }
    catch {
        $result.Status = "Failed"
        $result.Detail = $_.Exception.Message
        $result.Dropped = [bool](Test-ConnectionDrop $_.Exception)
    }
    finally {
        if ($downloaded) { Remove-Item -LiteralPath $downloaded -Force -ErrorAction SilentlyContinue }
    }

    $result
}

# The firmware stage: for the ticked device keys, update each distinct firmware once.
# Returns Results (same objects as Update-Product), Notes (plain-wording remarks: keys not in the list, list problems).
function Update-Firmware {

    param ([string]$CatalogPath, [string]$FirmwareFolder, [string[]]$Keys, [string]$TempFolder)

    $notes   = New-Object System.Collections.Generic.List[string]
    $results = New-Object System.Collections.Generic.List[object]

    $cat = Get-FirmwareCatalog -Path $CatalogPath

    foreach ($e in $cat.Errors) { $notes.Add("Firmware device list problem: $e") }

    $wanted = @()
    foreach ($key in @($Keys | Where-Object { $_ })) {

        $device = @($cat.Devices | Where-Object Key -eq $key) | Select-Object -First 1

        if ($device) { $wanted += $device }
        else { $notes.Add("The ticked firmware device '$key' is not in the current device list (discontinued or removed), so it was skipped.") }
    }

    if ($wanted.Count -eq 0) {
        return [pscustomobject]@{ Results = @(); Notes = $notes.ToArray() }
    }

    # One download per distinct firmware: entries that are the same firmware (same server folder + patterns) are one.
    $groups = @($wanted | Group-Object { Get-FirmwareShape $_ })

    foreach ($group in $groups) {

        $first = $group.Group[0]

        $others = @($cat.Devices | Where-Object { (Get-FirmwareShape $_) -ne $group.Name } | ForEach-Object { , @($_.Patterns) })

        $product = [pscustomobject]@{
            Key = $first.Key; Name = (($group.Group.Name | Select-Object -Unique) -join " / "); Kind = "Firmware"
            RemotePath = $first.RemotePath; Patterns = @($first.Patterns); Validate = $first.Validate
        }

        $destination = if ($first.SubFolder) { Join-Path $FirmwareFolder $first.SubFolder } else { $FirmwareFolder }

        Write-Host "Firmware: $($product.Name)..."

        $r = Update-Product -Product $product -Destination $destination -TempFolder $TempFolder -SearchRoot $FirmwareFolder -OtherPatternSets $others
        Write-Host "  $($r.Status): $($r.Detail)"
        $results.Add($r)
    }

    [pscustomobject]@{ Results = $results.ToArray(); Notes = $notes.ToArray() }
}


# ------------------------------------------------------------
# Run state, notices and history (config-dependent; used by the main run only)
# ------------------------------------------------------------

function Start-PendingNotice {

    $state = $script:config.StateDir

    if (-not ((Test-Path (Join-Path $state "pending-notice.json")) -or
              (Test-Path (Join-Path $state "pending-signin-failed.json")) -or
              (Test-Path (Join-Path $state "pending-error.json")))) {
        return
    }

    $noticeTask = if ($script:config.NoticeTaskName) { $script:config.NoticeTaskName } else { "Crestron Updater Notice" }

    try {
        if (Get-ScheduledTask -TaskName $noticeTask -ErrorAction SilentlyContinue) {
            Start-ScheduledTask -TaskName $noticeTask
            return
        }
    }
    catch { }

    # Fallback if the notice task is not installed.
    if (-not (Test-Path (Join-Path $state "Show-CrestronNotice.ps1"))) { return }

    Start-Process -FilePath (Get-Process -Id $PID).Path -WindowStyle Hidden -ArgumentList @(
        "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", (Join-Path $state "Show-CrestronNotice.ps1")
    )
}

# One dated line per attempt, even if more than one code path calls this.
function Write-RunHistory {

    param ([string]$Outcome = $script:runOutcome, [string]$Detail = $script:runDetail)

    if ($script:runHistoryWritten) { return }
    $script:runHistoryWritten = $true

    if (-not $Outcome) {
        $Outcome = "UNKNOWN"
        $Detail  = "The run ended without recording a result. See Crestron-Updater.log."
    }

    $took = (Get-Date) - $script:runStarted
    $tookText = if ($took.TotalMinutes -ge 1) { "{0}m {1}s" -f [int][math]::Floor($took.TotalMinutes), $took.Seconds } else { "{0}s" -f [int][math]::Round($took.TotalSeconds) }

    $line = "{0}  {1,-10} {2} (took {3})" -f $script:runStarted.ToString("yyyy-MM-dd HH:mm:ss"), $Outcome, (($Detail -replace '\s+', ' ').Trim()), $tookText

    try {
        $historyFile = Join-Path (Join-Path $script:config.StateDir "Logs") "Run-History.log"
        New-Item -ItemType Directory -Path (Split-Path $historyFile) -Force | Out-Null

        if ((Test-Path $historyFile) -and (Get-Item $historyFile).Length -gt 1MB) {
            Move-Item $historyFile ($historyFile + ".old") -Force
        }

        Add-Content -Path $historyFile -Value $line -Encoding UTF8
    }
    catch { }
}

# Error notice for a failed run. The same error again within 24 hours is logged but not shown again.
function New-ErrorNotice {

    param ([string]$Step, [string]$Message)

    $state     = $script:config.StateDir
    $seenFile  = Join-Path $state "last-error-notice.json"
    $signature = "$Step|$Message"

    try {
        if (Test-Path $seenFile) {
            $seen = Get-Content $seenFile -Raw | ConvertFrom-Json
            if ($seen.Signature -eq $signature -and ((Get-Date) - [datetime]$seen.Time).TotalHours -lt 24) {
                return "not repeated: same error within 24 hours"
            }
        }

        [ordered]@{
            Time        = $script:runStarted.ToString("o")
            Step        = $Step
            Message     = $Message
            HistoryFile = (Join-Path (Join-Path $state "Logs") "Run-History.log")
            LogFile     = (Join-Path (Join-Path $state "Logs") "Crestron-Updater.log")
        } | ConvertTo-Json | Set-Content -Path (Join-Path $state "pending-error.json")

        [ordered]@{ Signature = $signature; Time = (Get-Date).ToString("o") } | ConvertTo-Json | Set-Content -Path $seenFile

        "shown to the user"
    }
    catch { "could not be created" }
}

# "new version downloaded" notice: one pending file listing every product updated since the user last acknowledged it.
function Add-UpdateNotice {

    param ($Updated)

    $file  = Join-Path $script:config.StateDir "pending-notice.json"
    $items = @()

    if (Test-Path $file) {
        try { $items = @((Get-Content $file -Raw | ConvertFrom-Json).Items) } catch { }
    }

    foreach ($u in $Updated) {
        $kind = if ($u.Kind) { [string]$u.Kind } else { "Software" }
        $items = @($items | Where-Object { -not ($_.Key -eq $u.Key -and $(if ($_.Kind) { $_.Kind } else { "Software" }) -eq $kind) })
        $items += [ordered]@{ Key = $u.Key; Kind = $kind; Name = $u.Name; Version = $u.New; PreviousVersion = $u.Previous; FilePath = $u.FilePath }
    }

    [ordered]@{ Folder = $script:config.CrestronFolder; FirmwareFolder = $script:config.FirmwareFolder; Items = $items } | ConvertTo-Json -Depth 4 | Set-Content -Path $file
}

# Journal: what this run added and removed, for the record.
function Write-Journal {

    param ($Results)

    try {
        $folder = Join-Path $script:config.StateDir "Journal"
        New-Item -ItemType Directory -Path $folder -Force | Out-Null

        [ordered]@{
            Time    = $script:runStarted.ToString("o")
            Updates = @($Results | Where-Object { $_.Status -eq "Updated" } | ForEach-Object {
                [ordered]@{ Kind = $_.Kind; Product = $_.Name; Added = (Split-Path $_.FilePath -Leaf); Removed = @($_.Removed) }
            })
        } | ConvertTo-Json -Depth 4 | Set-Content -Path (Join-Path $folder ($script:runStarted.ToString("yyyyMMdd-HHmmss") + ".json"))
    }
    catch { }
}


# ------------------------------------------------------------
# Main run
# ------------------------------------------------------------

# Dot-sourced (by the tests): functions only.
if ($MyInvocation.InvocationName -eq '.') { return }

$script:config     = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$script:runStarted = Get-Date
$script:runOutcome = $null
$script:runDetail  = $null

$stateDir        = $script:config.StateDir
$logFolder       = Join-Path $stateDir "Logs"
$credentialPath  = Join-Path $stateDir "Crestron-Credential.xml"
$loginFailedFile = Join-Path $stateDir "login-failed.json"
$signInNotice    = Join-Path $stateDir "pending-signin-failed.json"
$tempFolder      = Join-Path $stateDir "Temp"

New-Item -ItemType Directory -Path $logFolder -Force | Out-Null
Start-Transcript -Path (Join-Path $logFolder "Crestron-Updater.log") -Append | Out-Null

Write-Host ""
Write-Host "============================================================"
Write-Host "Crestron updater started: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Write-Host "============================================================"

# Never two runs at once.
$mutex = New-Object System.Threading.Mutex($false, "Global\AVSoftwareUpdater-CRESTRON")

try { $mutexAcquired = $mutex.WaitOne(0, $false) }
catch [System.Threading.AbandonedMutexException] { $mutexAcquired = $true }

if (-not $mutexAcquired) {
    Write-Host "Crestron updater is already running. This instance will exit."
    $script:runOutcome = "SKIPPED"
    $script:runDetail  = "Another update check was already running."
    Write-RunHistory
    try { Stop-Transcript | Out-Null } catch { }
    exit 0
}

try {

    # A notice the user has not acknowledged yet appears again.
    try { Start-PendingNotice } catch { }

    # Error reports that could not be sent earlier (share offline) are sent now.
    try { [void](Send-ReportOutbox -Config $script:config) } catch { }

    # --- Paused after a rejected login: wait for a newer saved password ---
    if (Test-Path $loginFailedFile) {

        $failedInfo = Get-Content $loginFailedFile -Raw | ConvertFrom-Json
        $failedAt   = [datetime]$failedInfo.Time

        if ((Test-Path $credentialPath) -and (Get-Item $credentialPath).LastWriteTime -gt $failedAt) {

            Write-Host "The saved Crestron password was updated after the last rejected login. Trying again."
            Remove-Item $loginFailedFile -Force
            Remove-Item $signInNotice -Force -ErrorAction SilentlyContinue
        }
        else {

            Write-Host "The last Crestron login was rejected and the saved password has not been updated since. Not trying again until it is."

            $lastReminder = if ($failedInfo.LastReminder) { [datetime]$failedInfo.LastReminder } else { $failedAt }
            $reminderShown = $false

            if (((Get-Date) - $lastReminder).TotalDays -ge 7 -and -not (Test-Path $signInNotice)) {

                [ordered]@{ Kind = "reminder"; Message = $failedInfo.Message; PausedSince = $failedAt.ToString("o") } |
                    ConvertTo-Json | Set-Content -Path $signInNotice

                if ($failedInfo.PSObject.Properties.Name -contains "LastReminder") { $failedInfo.LastReminder = (Get-Date).ToString("o") }
                else { $failedInfo | Add-Member -NotePropertyName LastReminder -NotePropertyValue (Get-Date).ToString("o") }

                $failedInfo | ConvertTo-Json | Set-Content -Path $loginFailedFile
                $reminderShown = $true

                try { Start-PendingNotice } catch { }
            }

            $script:runOutcome = "PAUSED"
            $script:runDetail  = "The last Crestron login was rejected ('$($failedInfo.Message)') and the saved password has not been updated since. Open AV Updater and click 'Update password...' on the Crestron tab.$(if ($reminderShown) { ' Weekly reminder shown.' })"
            return
        }
    }

    # --- Blocked Wi-Fi (phone hotspots) ---
    if (-not $TestBackendRoot) {

        $wifiInfo = netsh wlan show interfaces | Out-String
        $ssid = if ($wifiInfo -match '(?m)^\s*SSID\s*:\s*(.+)$') { $Matches[1].Trim() } else { $null }

        if ($ssid -and $ssid -in @($script:config.BlockedSSIDs)) {
            Write-Host "Connected to blocked Wi-Fi: $ssid. Update check skipped."
            $script:runOutcome = "SKIPPED"
            $script:runDetail  = "Connected to blocked Wi-Fi network '$ssid'."
            return
        }
    }

    $step = "preparing the update check"

    $destination = $script:config.CrestronFolder
    New-Item -ItemType Directory -Path $destination -Force | Out-Null

    # Leftovers from an interrupted run (this updater's own temp folder only).
    if (Test-Path $tempFolder) { Remove-Item $tempFolder -Recurse -Force -ErrorAction SilentlyContinue }
    New-Item -ItemType Directory -Path $tempFolder -Force | Out-Null

    $credential = $null
    if (-not $TestBackendRoot) {

        if (-not (Test-Path $credentialPath)) {
            throw "No saved Crestron login was found. Open AV Updater and click 'Update password...' on the Crestron tab."
        }

        $credential = Import-Clixml $credentialPath
    }

    # --- Connect ---
    $step = "connecting to ftp.crestron.com"
    Write-Host "Connecting..."

    if (-not $TestBackendRoot) {

        $step = "waiting for the network"

        # Optional config value NetworkWaitSeconds (default 180; 0 = do not wait, used by the tests).
        $waitSeconds = if ($script:config.PSObject.Properties.Name -contains 'NetworkWaitSeconds') { [int]$script:config.NetworkWaitSeconds } else { 180 }

        if ($waitSeconds -gt 0 -and -not (Wait-ForNetwork -TargetHost $script:config.Host -Port ([int]$script:config.Port) -MaxSeconds $waitSeconds)) {
            Write-Host "Could not reach $($script:config.Host) after waiting. Offline - will try again at the next run."
            $script:runOutcome = "SKIPPED"
            $script:runDetail  = "Offline: could not reach $($script:config.Host) after waiting $([math]::Round($waitSeconds / 60.0, 1)) minute(s). Will try again at the next logon or wake."
            return
        }

        $step = "connecting to ftp.crestron.com"
    }

    try {
        Connect-RemoteWithRetry -Config $script:config -Credential $credential
    }
    catch {

        # PowerShell wraps errors from .NET method calls; look at the real one.
        $ex = $_.Exception
        while ($ex -is [System.Management.Automation.MethodInvocationException] -and $ex.InnerException) { $ex = $ex.InnerException }

        $isAuth = $ex.GetType().Name -eq 'SshAuthenticationException'

        if ($isAuth) {

            $message = "Crestron rejected the saved login."

            [ordered]@{ Time = (Get-Date).ToString("o"); Message = $message; Kind = "rejected"; LastReminder = (Get-Date).ToString("o") } |
                ConvertTo-Json | Set-Content -Path $loginFailedFile
            [ordered]@{ Kind = "rejected"; Message = $message } | ConvertTo-Json | Set-Content -Path $signInNotice

            try { Start-PendingNotice } catch { }

            try { [void](Send-ErrorReport -Config $script:config -Category SignInFailed -Message $message -Step $step -Context @{ Kind = "rejected" }) } catch { }

            $script:runOutcome = "PAUSED"
            $script:runDetail  = "$message Paused until the password is updated."
            return
        }

        if ($script:hostKeyCheck -and $script:hostKeyCheck.Refused) {
            # Record what was actually shown, so a mismatch can be diagnosed (a second Crestron server, or a
            # network device answering in its place). Fingerprints are public; no login data is logged.
            $seenIp = try { (([System.Net.Dns]::GetHostAddresses($script:config.Host) | Where-Object AddressFamily -eq 'InterNetwork' | Select-Object -First 1).IPAddressToString) } catch { 'unknown' }
            $seenFp = $script:hostKeyCheck.Fingerprint
            Write-Host "Host key refused. Server showed: $seenFp (address $seenIp). Saved at setup: $($script:config.HostKeyFingerprint)."
            throw "The Crestron server's identity (host key) does not match the one saved at setup, so the connection was refused (it showed $seenFp at $seenIp; saved: $($script:config.HostKeyFingerprint)). Run Setup again only if Crestron changed its server."
        }

        # No internet or server down is expected now and then: not an error notice.
        if (Test-ConnectionDrop $ex) {
            Write-Host "Could not reach ftp.crestron.com: $($ex.Message)"
            $script:runOutcome = "SKIPPED"
            $script:runDetail  = "Could not reach ftp.crestron.com (no internet, or the server is down): $($ex.Message)"
            return
        }

        throw
    }

    # --- Each enabled product ---
    $results = @()

    foreach ($product in @(Get-SoftwareProducts -Config $script:config -CatalogPath (Join-Path $PSScriptRoot "products.json"))) {

        $step = "checking $($product.Name)"
        Write-Host "$($product.Name)..."

        $r = Update-Product -Product $product -Destination $destination -TempFolder $tempFolder
        Write-Host "  $($r.Status): $($r.Detail)"
        $results += $r
    }

    # --- Device firmware (only when a firmware folder and at least one device are chosen) ---
    $firmwareNotes = @()
    $configNames = $script:config.PSObject.Properties.Name

    if ($configNames -contains 'FirmwareFolder' -and $script:config.FirmwareFolder -and $configNames -contains 'FirmwareDevices' -and @($script:config.FirmwareDevices).Count -gt 0) {

        $step = "checking device firmware"

        try {
            $fw = Update-Firmware -CatalogPath (Join-Path $PSScriptRoot "firmware-catalog.json") -FirmwareFolder $script:config.FirmwareFolder -Keys @($script:config.FirmwareDevices) -TempFolder $tempFolder
            $results += @($fw.Results)
            $firmwareNotes = @($fw.Notes)
        }
        catch {
            $firmwareNotes = @("Device firmware was not checked: $($_.Exception.Message)")
            $results += [pscustomobject]@{ Key = "firmware"; Name = "Device firmware"; Kind = "Firmware"; Status = "Failed"; Detail = $_.Exception.Message; Previous = $null; New = $null; FilePath = $null; Removed = @(); Dropped = [bool](Test-ConnectionDrop $_.Exception) }
        }

        foreach ($n in $firmwareNotes) { Write-Host $n }
    }

    Write-Journal $results

    $updated = @($results | Where-Object { $_.Status -eq "Updated" })
    $isDropped = { $_.Status -eq "Failed" -and $_.PSObject.Properties.Name -contains 'Dropped' -and $_.Dropped }
    $dropped = @($results | Where-Object $isDropped)
    $failed  = @($results | Where-Object { $_.Status -eq "Failed" -and -not (& $isDropped) })
    $inUse   = @($results | Where-Object { $_.Status -eq "InUse" })

    if ($updated.Count -gt 0) {
        try { Add-UpdateNotice $updated; Start-PendingNotice } catch { }
    }

    $summary = ($results | ForEach-Object {
        $label = if ($_.Kind -eq 'Firmware') { "Firmware $($_.Name)" } else { $_.Name }
        "${label}: $($_.Status.ToLower())$(if ($_.Status -ne 'Current') { " ($($_.Detail))" })"
    }) -join "; "
    if ($firmwareNotes.Count -gt 0) { $summary += "; " + ($firmwareNotes -join "; ") }

    if ($failed.Count -gt 0) {

        $noticeNote = New-ErrorNotice -Step "updating" -Message (($failed | ForEach-Object { "$(if ($_.Kind -eq 'Firmware') { 'Firmware ' })$($_.Name): $($_.Detail)" }) -join "`n")
        try { Start-PendingNotice } catch { }

        try { [void](Send-ErrorReport -Config $script:config -Category DownloadFailed -Message (@($failed | ForEach-Object { "$(if ($_.Kind -eq 'Firmware') { 'Firmware ' })$($_.Name): $($_.Detail)" }) -join "`n") -Step "updating" -Context @{ Products = @($failed | ForEach-Object { $_.Key }); Notice = $noticeNote }) } catch { }

        $script:runOutcome = "FAILED"
        $script:runDetail  = "$summary [error notice $noticeNote]"
    }
    elseif ($updated.Count -gt 0) {
        $script:runOutcome = "UPDATED"
        $script:runDetail  = $summary
        if ($dropped.Count -gt 0) { $script:runDetail += "; connection dropped for $($dropped.Count) item(s), will retry next run" }
    }
    elseif ($inUse.Count -gt 0) {
        # An old version was being installed: nothing moved, no error notice; the next run tries again.
        $script:runOutcome = "SKIPPED"
        $script:runDetail  = "In use, will retry next run: $summary"
    }
    elseif ($dropped.Count -gt 0) {
        # The connection dropped mid-run: nothing was changed, no error notice. The next logon / wake retries.
        $script:runOutcome = "SKIPPED"
        $script:runDetail  = "Connection dropped during the check, will retry next run: $summary"
    }
    else {
        $script:runOutcome = "CURRENT"
        $script:runDetail  = "All enabled products$(if (@($results | Where-Object Kind -eq 'Firmware').Count) { ' and device firmware' }) are up to date.$(if ($firmwareNotes.Count -gt 0) { ' ' + ($firmwareNotes -join '; ') })"
    }
}
catch {

    $message = $_.Exception.Message

    if ((Test-ConnectionDrop $_.Exception) -and -not ($script:hostKeyCheck -and $script:hostKeyCheck.Refused)) {

        # A dropped connection is not an error to show: the next logon / wake tries again.
        Write-Host "Connection dropped while $step`: $message"
        $script:runOutcome = "SKIPPED"
        $script:runDetail  = "Connection dropped while $step, will retry next run: $message"
    }
    else {

        Write-Host "ERROR while $step`: $message"
        Write-Host $_.ScriptStackTrace

        $noticeNote = New-ErrorNotice -Step $step -Message $message
        try { Start-PendingNotice } catch { }

        try { [void](Send-ErrorReport -Config $script:config -Category RunFailed -Message $message -Step $step -ErrorRecord $_ -Context @{ Notice = $noticeNote; HostKeyRefused = [bool]($script:hostKeyCheck -and $script:hostKeyCheck.Refused) }) } catch { }

        $script:runOutcome = "FAILED"
        $script:runDetail  = "Failed while $step`: $message [error notice $noticeNote]"
    }
}
finally {

    Disconnect-Remote
    Remove-Item $tempFolder -Recurse -Force -ErrorAction SilentlyContinue

    Write-RunHistory

    try { $mutex.ReleaseMutex() } catch { }
    try { Stop-Transcript | Out-Null } catch { }
}
