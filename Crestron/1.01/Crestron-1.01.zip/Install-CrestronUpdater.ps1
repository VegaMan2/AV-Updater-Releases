# ============================================================
# Crestron Updater -- setup (run once per machine and user)
#
# Asks for:
#   - the folder to keep installers in
#   - which Crestron programs to keep up to date
#   - the Crestron.com username and password (Windows credential dialog; stored
#     encrypted for THIS Windows user on THIS PC only)
# Makes ONE connection to ftp.crestron.com with that login to prove it works
# and to remember the server's identity key. Then installs the updater to
# %LOCALAPPDATA%\CrestronUpdater, registers a scheduled task that runs at logon
# and on wake from sleep, and adds a "Crestron Updater Options" icon (Desktop
# and Start menu).
#
# Cancelling (or a failure) before setup finishes removes everything this
# run created. After setup completes nothing is removed automatically.
#
# Usage:
#   Double-click Setup.cmd, or from any PowerShell:
#   powershell -ExecutionPolicy Bypass -File Install-CrestronUpdater.ps1
#   (can start in Windows PowerShell 5.1; if PowerShell 7 is missing, setup offers to
#   install it, then continues in PowerShell 7)
#
#   ...Install-CrestronUpdater.ps1 -InstallPrerequisites   (install PowerShell 7 without asking)
#   ...Install-CrestronUpdater.ps1 -UpdateCredentialOnly
#   pwsh -File Install-CrestronUpdater.ps1 -DestinationRoot "D:\For Install\Crestron" -NoGui
#   pwsh -File Install-CrestronUpdater.ps1 -Uninstall
#
#   Error reports (a short report when the updater hits an error, never passwords) are on
#   unless this PC turned them off before. -NoErrorReports turns them off, -ErrorReports
#   turns them back on; the setup window has a tick box for it.
# ============================================================

[CmdletBinding()]
param (
    [string]$InstallDir = (Join-Path $env:LOCALAPPDATA "CrestronUpdater"),
    [string]$DestinationRoot,
    [string[]]$BlockedSSIDs = @(),
    [string]$TaskName = "Crestron Updater",
    [string[]]$Products,                 # keys to keep up to date (default: all four)
    [string]$FirmwareFolder,             # keep device firmware up to date in this folder (needs -FirmwareDevices)
    [string[]]$FirmwareDevices,          # device keys from firmware-catalog.json, or "all" (every current device)
    [switch]$InstallPrerequisites,
    [switch]$ReplaceExistingTask,
    [switch]$ConfigureNetworks,
    [switch]$UpdateCredentialOnly,
    [string]$CredentialFromFile,         # a PSCredential saved with Export-Clixml, used instead of the pop-up (unattended installs, tests)
    [switch]$SkipServerCheck,            # tests only: do not contact Crestron
    [string]$ServerHost = "ftp.crestron.com",
    [int]$ServerPort = 22,
    [switch]$SkipTask,
    [switch]$RunNow,
    [switch]$NoGui,                      # no windows (also used automatically when input is redirected)
    [switch]$NoErrorReports,             # turn error reports off
    [switch]$ErrorReports,               # turn error reports back on after an earlier opt-out
    [switch]$Uninstall
)

$ErrorActionPreference = "Stop"

# -File runs pass arrays as one comma-separated string.
$BlockedSSIDs = @($BlockedSSIDs | ForEach-Object { $_ -split "," } | ForEach-Object { $_.Trim() } | Where-Object { $_ })
$Products     = @($Products     | ForEach-Object { $_ -split "," } | ForEach-Object { $_.Trim() } | Where-Object { $_ })
$FirmwareDevices = @($FirmwareDevices | ForEach-Object { $_ -split "," } | ForEach-Object { $_.Trim().ToLower() } | Where-Object { $_ })

$credentialFile    = Join-Path $InstallDir "Crestron-Credential.xml"
$configFile        = Join-Path $InstallDir "config.json"
$updaterName       = "Crestron-Updater.ps1"
$launcherName      = "Run-Hidden.vbs"
$optionsScriptName = "Options-CrestronUpdater.ps1"
$optionsLinkName   = "Crestron Updater Options.lnk"
$noticeName        = "Show-CrestronNotice.ps1"
$noticeLauncher    = "Run-Notice.vbs"
$noticeTaskName    = "$TaskName Notice"
$passwordName      = "Update-CrestronPassword.ps1"
$productsName      = "products.json"
$pickerName        = "Firmware-Picker.ps1"
$catalogName       = "firmware-catalog.json"
$reportingFileNames = @("Reporting.ps1", "reporting.json", "version.json")
$ownFiles          = @($updaterName, $optionsScriptName, $noticeName, $passwordName, "CredentialPrompt.ps1", $pickerName, $catalogName, $productsName) + $reportingFileNames

# The Windows sign-in window. If its file is missing, fall back to the text prompt.
$credentialPromptName   = "CredentialPrompt.ps1"
$credentialPromptSource = Join-Path $PSScriptRoot $credentialPromptName

if (Test-Path $credentialPromptSource) {
    . $credentialPromptSource
}
else {
    function Get-CrestronCredentialPrompt {
        param ([string]$Message)
        Get-Credential -Message $Message
    }
}

# Windows instead of console prompts, unless -NoGui or input is redirected (automated tests).
$useGui = -not $NoGui

try { if ([Console]::IsInputRedirected) { $useGui = $false } } catch { }

$wizardDone = $false


# ------------------------------------------------------------
# Uninstall
# ------------------------------------------------------------

if ($Uninstall) {

    # Same removal as the Remove updater button in the Crestron Updater Options window.
    & (Join-Path $PSScriptRoot $optionsScriptName) -Uninstall -InstallDir $InstallDir -TaskName $TaskName
    return
}


# ------------------------------------------------------------
# The login
# ------------------------------------------------------------

# The pop-up (or -CredentialFromFile). Returns a PSCredential, or $null if cancelled.
function Get-SetupCredential {

    if ($CredentialFromFile) {
        return (Import-Clixml -Path $CredentialFromFile)
    }

    Get-CrestronCredentialPrompt -Message "Enter your Crestron.com username and password"
}

function Test-ValidCredential {

    param ($Credential)

    [bool]($Credential -and -not [string]::IsNullOrWhiteSpace($Credential.UserName) -and $Credential.Password.Length -gt 0)
}

# Encrypted for this Windows user on this PC only (DPAPI), readable by nobody else.
function Save-CrestronCredential {

    param ([string]$Path, $Credential)

    if (-not (Test-ValidCredential $Credential)) {
        throw "No credential was entered. Setup cancelled."
    }

    $Credential | Export-Clixml -Path $Path

    $currentUser = "$env:USERDOMAIN\$env:USERNAME"
    & icacls.exe $Path /inheritance:r /grant:r "${currentUser}:(F)" | Out-Null

    Write-Host "Login saved for $($Credential.UserName)."
    Write-Host "It is encrypted and can only be read by $currentUser on this PC."
}

# The one contact with Crestron during setup: proves the login works, records the server's
# identity key, and proves the four folders can be read. Returns the key's fingerprint.
# Throws a plain-wording message on any problem. Needs PowerShell 7.
function Test-CrestronServer {

    param ($Credential, [string]$ProductsFile)

    if ($SkipServerCheck) { return "SHA256:skipped-for-tests" }

    . (Join-Path $PSScriptRoot $updaterName)   # defines the server functions only

    $config = [pscustomobject]@{ Host = $ServerHost; Port = $ServerPort; HostKeyFingerprint = $null }

    try {
        Connect-Remote -Config $config -Credential $Credential -RecordHostKey
    }
    catch {
        $ex = $_.Exception
        while ($ex -is [System.Management.Automation.MethodInvocationException] -and $ex.InnerException) { $ex = $ex.InnerException }

        if ($ex.GetType().Name -eq 'SshAuthenticationException') {
            throw "Crestron did not accept that username and password. Check them (you can try signing in at crestron.com) and enter them again."
        }
        throw "Could not connect to $ServerHost ($($ex.Message)). Check the internet connection and try again."
    }

    try {
        $fingerprint = $script:hostKeyCheck.Fingerprint

        foreach ($product in (Get-Content $ProductsFile -Raw | ConvertFrom-Json)) {
            try { $null = Get-RemoteList $product.RemotePath }
            catch { throw "The login works, but this Crestron account cannot read $($product.RemotePath) ($($_.Exception.Message))." }
        }

        $fingerprint
    }
    finally { Disconnect-Remote }
}

function Get-WifiProfileNames {

    $names = foreach ($line in (netsh wlan show profiles 2>$null)) {
        if ($line -match '^\s*(All User Profile|User Profile)\s*:\s*(.+)$') {
            $Matches[2].Trim()
        }
    }

    @($names | Sort-Object -Unique)
}

function Get-CurrentSsid {

    $info = netsh wlan show interfaces 2>$null | Out-String

    if ($info -match '(?m)^\s*SSID\s*:\s*(.+)$') {
        return $Matches[1].Trim()
    }

    return $null
}


# ------------------------------------------------------------
# Setup windows (used when a person runs setup; -NoGui and any value given on the
# command line keep the console route)
# ------------------------------------------------------------

function Show-NetworkPicker {

    # Checklist of the PC's saved Wi-Fi networks, plus a box to add a name by hand.
    # Returns the ticked names, or $null if cancelled.
    param ([string[]]$Current = @())

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $profiles    = @(Get-WifiProfileNames)
    $connectedTo = Get-CurrentSsid

    $global:QNet = @{ Names = New-Object System.Collections.ArrayList }

    $form = New-Object System.Windows.Forms.Form
    $global:QNet.Form = $form
    $form.Text = "Wi-Fi networks to avoid"
    $form.ClientSize = New-Object System.Drawing.Size(520, 480)
    $form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false; $form.MinimizeBox = $false
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    $info = New-Object System.Windows.Forms.Label
    $info.Location = New-Object System.Drawing.Point(16, 12); $info.Size = New-Object System.Drawing.Size(488, 66)
    $info.Text = "The updater downloads installers of about 2 GB. It skips the check whenever this PC is connected to a network ticked here, such as a phone hotspot."
    $form.Controls.Add($info)

    $list = New-Object System.Windows.Forms.CheckedListBox
    $list.Name = "NetworkList"; $list.CheckOnClick = $true
    $list.Location = New-Object System.Drawing.Point(16, 84); $list.Size = New-Object System.Drawing.Size(488, 280)
    $form.Controls.Add($list)
    $global:QNet.List = $list

    function Add-NetworkItem ($name, $checked) {
        for ($i = 0; $i -lt $global:QNet.Names.Count; $i++) {
            if ($global:QNet.Names[$i] -eq $name) { $global:QNet.List.SetItemChecked($i, $checked); return }
        }
        [void]$global:QNet.Names.Add($name)
        $text = if ($name -eq $global:QNet.Connected) { "$name   (connected now)" } else { $name }
        [void]$global:QNet.List.Items.Add($text, $checked)
    }

    $global:QNet.Connected = $connectedTo

    foreach ($name in $profiles) { Add-NetworkItem $name ($name -in $Current) }
    foreach ($name in $Current)  { if ($name) { Add-NetworkItem $name $true } }

    $addLabel = New-Object System.Windows.Forms.Label
    $addLabel.Text = "Not listed? Type its name:"
    $addLabel.Location = New-Object System.Drawing.Point(16, 376); $addLabel.Size = New-Object System.Drawing.Size(488, 22)
    $form.Controls.Add($addLabel)

    $box = New-Object System.Windows.Forms.TextBox
    $box.Name = "AddNetworkBox"
    $box.Location = New-Object System.Drawing.Point(16, 400); $box.Size = New-Object System.Drawing.Size(370, 26)
    $form.Controls.Add($box)
    $global:QNet.Box = $box

    $add = New-Object System.Windows.Forms.Button
    $add.Name = "AddNetworkButton"; $add.Text = "Add"
    $add.Location = New-Object System.Drawing.Point(396, 398); $add.Size = New-Object System.Drawing.Size(108, 30)
    $add.Add_Click({
        try {
            $typed = $global:QNet.Box.Text.Trim()
            if ($typed) { Add-NetworkItem $typed $true; $global:QNet.Box.Text = "" }
        } catch { }
    })
    $form.Controls.Add($add)

    $ok = New-Object System.Windows.Forms.Button
    $ok.Name = "NetworksOk"; $ok.Text = "OK"; $ok.DialogResult = "OK"
    $ok.Location = New-Object System.Drawing.Point(290, 440); $ok.Size = New-Object System.Drawing.Size(100, 32)
    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Name = "NetworksCancel"; $cancel.Text = "Cancel"; $cancel.DialogResult = "Cancel"
    $cancel.Location = New-Object System.Drawing.Point(404, 440); $cancel.Size = New-Object System.Drawing.Size(100, 32)
    $form.Controls.AddRange(@($ok, $cancel))
    $form.AcceptButton = $ok; $form.CancelButton = $cancel

    $answer = $form.ShowDialog()

    $picked = $null

    if ($answer -eq "OK") {
        $picked = @()
        for ($i = 0; $i -lt $global:QNet.Names.Count; $i++) {
            if ($list.GetItemChecked($i)) { $picked += $global:QNet.Names[$i] }
        }
    }

    $form.Dispose()
    return $picked
}

function Show-SetupWizard {

    # The one setup window. Returns $null if cancelled; otherwise the chosen values.
    # The login is held in memory only (it is written at Install). The Install button
    # checks the login with Crestron once and stays in the window if that fails.
    param (
        [string]$StartFolder,
        [string[]]$BlockedNow = @(),
        [string]$Task,
        $ProductList,
        [string[]]$Selected,
        [string]$ProductsFile,
        $FirmwareList = @(),
        [bool]$FirmwareOn = $false,
        [string]$FirmwareStart,
        [string[]]$FirmwareSelected = @(),
        [bool]$ErrorReports = $true
    )

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    $global:CS = @{ Blocked = @($BlockedNow); Credential = $null; Advanced = $false; Fingerprint = $null; ProductsFile = $ProductsFile; Checks = @{}; FirmwareList = @($FirmwareList); FirmwareKeys = @($FirmwareSelected) }

    $form = New-Object System.Windows.Forms.Form
    $global:CS.Form = $form
    $form.Text = "Crestron Updater Setup"
    $form.ClientSize = New-Object System.Drawing.Size(640, 850)
    $form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false; $form.MinimizeBox = $true
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    function Add-Ctl ($control, $name, $x, $y, $w, $h, $text) {
        $c = New-Object $control
        if ($name) { $c.Name = $name }
        $c.Location = New-Object System.Drawing.Point($x, $y); $c.Size = New-Object System.Drawing.Size($w, $h)
        if ($text) { $c.Text = $text }
        $global:CS.Form.Controls.Add($c)
        $c
    }
    function Add-Heading ($text, $y) {
        $l = Add-Ctl System.Windows.Forms.Label $null 20 $y 600 24 $text
        $l.Font = New-Object System.Drawing.Font("Segoe UI", 10.5, [System.Drawing.FontStyle]::Bold)
    }

    $title = Add-Ctl System.Windows.Forms.Label $null 20 12 600 30 "Set up the Crestron Updater"
    $title.Font = New-Object System.Drawing.Font("Segoe UI", 15, [System.Drawing.FontStyle]::Bold)
    [void](Add-Ctl System.Windows.Forms.Label $null 20 46 600 40 "It keeps the newest Crestron installers in a folder of your choice. Nothing is changed on this PC until you click Install.")

    # 1. Folder
    Add-Heading "1. Where should installers be saved?" 92
    $global:CS.Folder = Add-Ctl System.Windows.Forms.TextBox "FolderBox" 20 120 480 26 $StartFolder
    $browse = Add-Ctl System.Windows.Forms.Button "BrowseButton" 510 118 110 30 "Browse..."
    $global:CS.Preview = Add-Ctl System.Windows.Forms.Label "FolderPreview" 20 150 600 22 ""
    $global:CS.Preview.ForeColor = [System.Drawing.Color]::DimGray

    function Update-FolderPreview {
        $text = $global:CS.Folder.Text.Trim()
        $global:CS.Preview.Text = if ($text) { "Installers will go in: " + $text } else { "" }
    }
    $global:CS.Folder.Add_TextChanged({ try { Update-FolderPreview } catch { } })
    $browse.Add_Click({
        try {
            $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
            $dialog.Description = "Choose the folder to keep Crestron installers in. Installers are saved directly in it."
            $dialog.ShowNewFolderButton = $true
            if ($global:CS.Folder.Text.Trim() -and (Test-Path $global:CS.Folder.Text.Trim())) { $dialog.SelectedPath = $global:CS.Folder.Text.Trim() }
            if ($dialog.ShowDialog($global:CS.Form) -eq "OK") { $global:CS.Folder.Text = $dialog.SelectedPath }
        } catch { }
    })

    # 2. Programs
    Add-Heading "2. Programs to keep up to date" 182
    $y = 210
    foreach ($product in $ProductList) {
        $box = Add-Ctl System.Windows.Forms.CheckBox ("Program_" + $product.Key) 36 $y 580 24 $product.Name
        $box.Checked = ($Selected -contains $product.Key)
        $global:CS.Checks[$product.Key] = $box
        $y += 24
    }
    foreach ($mode in @(@{ Name = "ProgramsAll"; Text = "All"; Value = $true; X = 470 }, @{ Name = "ProgramsNone"; Text = "None"; Value = $false; X = 550 })) {
        $toggleButton = Add-Ctl System.Windows.Forms.Button $mode.Name $mode.X 180 70 26 $mode.Text
        $toggleButton.Tag = $mode.Value
        $toggleButton.Add_Click({
            param ($sender, $e)
            try { foreach ($box in $global:CS.Checks.Values) { $box.Checked = [bool]$sender.Tag } } catch { }
        })
    }
    [void](Add-Ctl System.Windows.Forms.Label $null 20 308 600 40 "Only the newest version of each is kept. Older versions of these programs are deleted when a new one is downloaded.")

    # 3. Firmware (optional)
    Add-Heading "3. Firmware (optional)" 356
    $global:CS.FirmwareCheck = Add-Ctl System.Windows.Forms.CheckBox "FirmwareCheck" 36 384 560 24 "Also keep device firmware up to date"
    $global:CS.FirmwareCheck.Checked = $FirmwareOn
    $global:CS.FirmwareFolder = Add-Ctl System.Windows.Forms.TextBox "FirmwareFolderBox" 20 414 480 26 $FirmwareStart
    $global:CS.FirmwareBrowse = Add-Ctl System.Windows.Forms.Button "FirmwareBrowse" 510 412 110 30 "Browse..."
    $global:CS.FirmwareChoose = Add-Ctl System.Windows.Forms.Button "ChooseFirmwareDevices" 20 448 170 30 "Choose devices..."
    $global:CS.FirmwareSummary = Add-Ctl System.Windows.Forms.Label "FirmwareSummary" 200 454 420 24 ""
    $global:CS.FirmwareSummary.ForeColor = [System.Drawing.Color]::DimGray

    function Update-FirmwareState {
        $on = $global:CS.FirmwareCheck.Checked
        $global:CS.FirmwareFolder.Enabled = $on
        $global:CS.FirmwareBrowse.Enabled = $on
        $global:CS.FirmwareChoose.Enabled = $on
        $global:CS.FirmwareSummary.Text = Get-FirmwareSummary -Devices $global:CS.FirmwareList -Keys @($global:CS.FirmwareKeys)
    }
    $global:CS.FirmwareCheck.Add_CheckedChanged({
        try {
            # First time on: suggest a folder next to the installers folder.
            if ($global:CS.FirmwareCheck.Checked -and -not $global:CS.FirmwareFolder.Text.Trim()) {
                $global:CS.FirmwareFolder.Text = Get-DefaultFirmwareFolder $global:CS.Folder.Text.Trim()
            }
            Update-FirmwareState
        } catch { }
    })
    $global:CS.FirmwareBrowse.Add_Click({
        try {
            $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
            $dialog.Description = "Choose the folder to keep device firmware in. Firmware is saved directly in it."
            $dialog.ShowNewFolderButton = $true
            if ($global:CS.FirmwareFolder.Text.Trim() -and (Test-Path $global:CS.FirmwareFolder.Text.Trim())) { $dialog.SelectedPath = $global:CS.FirmwareFolder.Text.Trim() }
            if ($dialog.ShowDialog($global:CS.Form) -eq "OK") { $global:CS.FirmwareFolder.Text = $dialog.SelectedPath }
        } catch { }
    })
    $global:CS.FirmwareChoose.Add_Click({
        try {
            $picked = Show-FirmwarePicker -Devices $global:CS.FirmwareList -Selected @($global:CS.FirmwareKeys) -Owner $global:CS.Form
            if ($null -ne $picked) { $global:CS.FirmwareKeys = @($picked); Update-FirmwareState }
        } catch { }
    })

    # 3. Login
    Add-Heading "4. Crestron login" 486
    $enter = Add-Ctl System.Windows.Forms.Button "EnterCredential" 20 514 300 32 "Enter Crestron username and password..."
    $global:CS.CredentialStatus = Add-Ctl System.Windows.Forms.Label "CredentialStatus" 330 520 290 24 "Not entered yet"
    [void](Add-Ctl System.Windows.Forms.Label $null 20 550 600 44 "Stored encrypted, readable only by your Windows account on this PC. The password is never shown or logged. Clicking Install contacts Crestron once with this login to check that it works.")

    $enter.Add_Click({
        try {
            $credential = Get-SetupCredential
            if (Test-ValidCredential $credential) {
                $global:CS.Credential = $credential
                $global:CS.Fingerprint = $null
                $global:CS.CredentialStatus.Text = "Entered for " + $credential.UserName
            }
        } catch { }
    })

    # 4. Wi-Fi
    Add-Heading "5. Wi-Fi networks to avoid" 602
    [void](Add-Ctl System.Windows.Forms.Label $null 20 628 600 40 "Some downloads are large (Construct is over 500 MB). The updater skips the check on any network you choose here, such as a phone hotspot.")
    $global:CS.Networks = Add-Ctl System.Windows.Forms.Label "NetworksSummary" 20 670 480 24 ""
    $choose = Add-Ctl System.Windows.Forms.Button "ChooseNetworks" 510 666 110 30 "Choose..."

    function Update-NetworksSummary {
        $global:CS.Networks.Text = if ($global:CS.Blocked.Count) { "Avoiding: " + ($global:CS.Blocked -join ", ") } else { "None chosen (it will download on any network)" }
    }
    $choose.Add_Click({
        try {
            $picked = Show-NetworkPicker -Current @($global:CS.Blocked)
            if ($null -ne $picked) { $global:CS.Blocked = @($picked); Update-NetworksSummary }
        } catch { }
    })

    # Advanced (collapsed)
    $toggle = Add-Ctl System.Windows.Forms.Button "AdvancedToggle" 20 710 150 28 "Advanced  >"
    $global:CS.ErrorReports = Add-Ctl System.Windows.Forms.CheckBox "ErrorReportsCheck" 190 712 420 24 "Send error reports to help fix bugs"
    $global:CS.ErrorReports.Checked = $ErrorReports
    $global:CS.AdvancedPanel = New-Object System.Windows.Forms.Panel
    $panel = $global:CS.AdvancedPanel
    $panel.Location = New-Object System.Drawing.Point(20, 742); $panel.Size = New-Object System.Drawing.Size(600, 62); $panel.Visible = $false
    $form.Controls.Add($panel)
    $taskLabel = New-Object System.Windows.Forms.Label
    $taskLabel.Text = "Task name (change it for a test install next to a working one):"
    $taskLabel.Location = New-Object System.Drawing.Point(0, 0); $taskLabel.Size = New-Object System.Drawing.Size(600, 22)
    $global:CS.TaskBox = New-Object System.Windows.Forms.TextBox
    $global:CS.TaskBox.Name = "TaskNameBox"; $global:CS.TaskBox.Text = $Task
    $global:CS.TaskBox.Location = New-Object System.Drawing.Point(0, 26); $global:CS.TaskBox.Size = New-Object System.Drawing.Size(400, 26)
    $panel.Controls.AddRange(@($taskLabel, $global:CS.TaskBox))

    $install = Add-Ctl System.Windows.Forms.Button "InstallButton" 400 806 110 34 "Install"
    $cancel  = Add-Ctl System.Windows.Forms.Button "CancelButton" 520 806 100 34 "Cancel"
    $cancel.DialogResult = "Cancel"; $form.CancelButton = $cancel

    $toggle.Add_Click({
        try {
            $global:CS.Advanced = -not $global:CS.Advanced
            $global:CS.AdvancedPanel.Visible = $global:CS.Advanced
        } catch { }
    })

    $install.Add_Click({
        try {
            $form = $global:CS.Form
            $folder = $global:CS.Folder.Text.Trim()
            if (-not $folder) {
                [void][System.Windows.Forms.MessageBox]::Show($form, "Choose the folder to save installers in first.", "Crestron Updater Setup", "OK", "Information")
                return
            }
            if (-not (Test-Path $folder)) {
                [void][System.Windows.Forms.MessageBox]::Show($form, "That folder does not exist:`r`n$folder`r`n`r`nChoose an existing folder (Browse... can make a new one).", "Crestron Updater Setup", "OK", "Information")
                return
            }
            if (@($global:CS.Checks.Values | Where-Object { $_.Checked }).Count -eq 0) {
                [void][System.Windows.Forms.MessageBox]::Show($form, "Tick at least one program (section 2).", "Crestron Updater Setup", "OK", "Information")
                return
            }
            $firmwareProblem = Test-FirmwareSettings -Enabled $global:CS.FirmwareCheck.Checked -Folder $global:CS.FirmwareFolder.Text -Keys @($global:CS.FirmwareKeys) -Devices $global:CS.FirmwareList -SoftwareFolder $folder
            if ($firmwareProblem) {
                [void][System.Windows.Forms.MessageBox]::Show($form, $firmwareProblem, "Crestron Updater Setup", "OK", "Information")
                return
            }
            if (-not $global:CS.Credential) {
                [void][System.Windows.Forms.MessageBox]::Show($form, "Enter your Crestron username and password first (section 4).", "Crestron Updater Setup", "OK", "Information")
                return
            }

            # The one contact with Crestron: stay in this window if it fails.
            $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
            try {
                $global:CS.Fingerprint = Test-CrestronServer -Credential $global:CS.Credential -ProductsFile $global:CS.ProductsFile
            }
            catch {
                $form.Cursor = [System.Windows.Forms.Cursors]::Default
                $global:CS.Fingerprint = $null
                [void][System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, "Crestron Updater Setup", "OK", "Warning")
                return
            }
            finally { $form.Cursor = [System.Windows.Forms.Cursors]::Default }

            $form.DialogResult = "OK"
        } catch { }
    })
    $form.AcceptButton = $null

    Update-FolderPreview
    Update-NetworksSummary
    Update-FirmwareState

    # A screen shorter than the window: let the window scroll instead of cutting off the buttons.
    $workHeight = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Height
    if ($workHeight -lt 900) {
        $form.AutoScroll = $true
        $form.AutoScrollMinSize = New-Object System.Drawing.Size(620, 850)
        $form.ClientSize = New-Object System.Drawing.Size(660, [math]::Max(400, $workHeight - 90))
    }

    $answer = $form.ShowDialog()

    $result = $null

    if ($answer -eq "OK") {

        $taskText = $global:CS.TaskBox.Text.Trim()

        $result = [pscustomobject]@{
            DestinationRoot = $global:CS.Folder.Text.Trim()
            BlockedSSIDs    = @($global:CS.Blocked)
            Products        = @($global:CS.Checks.Keys | Where-Object { $global:CS.Checks[$_].Checked })
            TaskName        = $(if ($taskText) { $taskText } else { $Task })
            Credential      = $global:CS.Credential
            Fingerprint     = $global:CS.Fingerprint
            FirmwareFolder  = $(if ($global:CS.FirmwareCheck.Checked) { $global:CS.FirmwareFolder.Text.Trim() } else { "" })
            FirmwareDevices = $(if ($global:CS.FirmwareCheck.Checked) { @($global:CS.FirmwareKeys) } else { @() })
            ErrorReports    = $global:CS.ErrorReports.Checked
        }
    }

    $form.Dispose()
    return $result
}

function Show-SetupDone {

    # Finish window. Returns $true if the person asked to open the Options window.
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Crestron Updater Setup"
    $form.ClientSize = New-Object System.Drawing.Size(520, 250)
    $form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false; $form.MinimizeBox = $false; $form.TopMost = $true
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    $title = New-Object System.Windows.Forms.Label
    $title.Name = "DoneTitle"; $title.Text = "Setup complete"
    $title.Font = New-Object System.Drawing.Font("Segoe UI", 15, [System.Drawing.FontStyle]::Bold)
    $title.Location = New-Object System.Drawing.Point(20, 16); $title.Size = New-Object System.Drawing.Size(480, 32)

    $text = New-Object System.Windows.Forms.Label
    $text.Location = New-Object System.Drawing.Point(20, 60); $text.Size = New-Object System.Drawing.Size(480, 120)
    $text.Text = "The updater will check for new Crestron software at logon and after the PC wakes from sleep.`r`n`r`nTo stop or resume it, check now, change your Crestron password or remove it, open `"Crestron Updater Options`" on your Desktop or in the Start menu."

    $open = New-Object System.Windows.Forms.Button
    $open.Name = "OpenOptions"; $open.Text = "Open Crestron Updater Options"; $open.DialogResult = "Yes"
    $open.Location = New-Object System.Drawing.Point(100, 196); $open.Size = New-Object System.Drawing.Size(260, 36)
    $close = New-Object System.Windows.Forms.Button
    $close.Name = "DoneClose"; $close.Text = "Close"; $close.DialogResult = "Cancel"
    $close.Location = New-Object System.Drawing.Point(376, 196); $close.Size = New-Object System.Drawing.Size(124, 36)
    $form.Controls.AddRange(@($title, $text, $open, $close)); $form.CancelButton = $close

    $answer = $form.ShowDialog()
    $form.Dispose()

    return ($answer -eq "Yes")
}

function Find-Pwsh {

    $command = Get-Command pwsh.exe -ErrorAction SilentlyContinue

    if ($command) {
        return $command.Source
    }

    # A fresh install is not on PATH in this session yet.
    $default = Join-Path $env:ProgramFiles "PowerShell\7\pwsh.exe"

    if (Test-Path $default) {
        return $default
    }

    return $null
}

function Install-FromMsi {

    # Direct-download fallback when winget is not available.
    param (
        [string]$Name,
        [string]$Url,
        [string]$MsiArguments = ""
    )

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $ProgressPreference = "SilentlyContinue"

    $msi = Join-Path $env:TEMP ("CrestronUpdater-" + $Name.Replace(" ", "") + ".msi")

    Write-Host "Downloading $Name..."
    Invoke-WebRequest -Uri $Url -OutFile $msi -UseBasicParsing

    Write-Host "Installing $Name (a Windows permission prompt will appear)..."

    $process = Start-Process msiexec.exe `
        -ArgumentList "/i `"$msi`" /qn $MsiArguments" `
        -Verb RunAs `
        -Wait `
        -PassThru

    Remove-Item $msi -Force -ErrorAction SilentlyContinue

    if ($process.ExitCode -notin 0, 3010) {
        Write-Warning "$Name installer finished with exit code $($process.ExitCode)."
    }
}

function Install-Prerequisite {

    param (
        [string]$Name,
        [string]$WingetId,
        [scriptblock]$Fallback,
        [scriptblock]$IsInstalled
    )

    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue

    if ($winget) {

        Write-Host "Installing $Name with winget (a Windows permission prompt may appear)..."

        & $winget.Source install `
            --id $WingetId `
            --exact `
            --silent `
            --accept-package-agreements `
            --accept-source-agreements

        if (& $IsInstalled) {
            return
        }

        Write-Warning "winget did not complete the $Name install. Trying a direct download."
    }

    try {
        & $Fallback
    }
    catch {
        Write-Warning "Direct download of $Name failed: $($_.Exception.Message)"
    }
}

function Get-ProductList {

    $file = Join-Path $PSScriptRoot $productsName

    if (-not (Test-Path $file)) {
        throw "$productsName was not found next to this setup script ($PSScriptRoot)."
    }

    @(Get-Content $file -Raw | ConvertFrom-Json)
}

if ($UpdateCredentialOnly) {

    if (-not (Test-Path $InstallDir)) {
        throw "Setup has not been run yet ($InstallDir not found). Run setup first."
    }

    $credential = Get-SetupCredential
    Save-CrestronCredential -Path $credentialFile -Credential $credential

    # Lifts the pause that follows a rejected login.
    Remove-Item (Join-Path $InstallDir "login-failed.json") -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $InstallDir "pending-signin-failed.json") -Force -ErrorAction SilentlyContinue
    return
}

if ($ConfigureNetworks) {

    if (-not (Test-Path $configFile)) {
        throw "Setup has not been run yet ($configFile not found). Run setup first."
    }

    $existingConfig = Get-Content $configFile -Raw | ConvertFrom-Json
    $existingConfig.BlockedSSIDs = @(Show-NetworkPicker -Current @($existingConfig.BlockedSSIDs))
    $existingConfig | ConvertTo-Json -Depth 6 | Set-Content -Path $configFile -Encoding UTF8

    Write-Host "Saved. Blocked networks: $(@($existingConfig.BlockedSSIDs) -join ', ')"
    return
}


# ------------------------------------------------------------
# Prerequisites: PowerShell 7 (the only one; there is no browser)
# ------------------------------------------------------------

foreach ($required in $ownFiles) {
    if (-not (Test-Path (Join-Path $PSScriptRoot $required))) {
        throw "$required was not found next to this setup script ($PSScriptRoot)."
    }
}

$pwsh = Find-Pwsh

if (-not $pwsh) {

    $installPwsh = $InstallPrerequisites

    if (-not $installPwsh) {

        if ($useGui) {

            Add-Type -AssemblyName System.Windows.Forms

            $message = "This PC is missing PowerShell 7, which runs the updater and its scheduled task.`r`n`r`nSetup can download and install it now (a Windows permission prompt may appear). Setup cannot continue without it.`r`n`r`nInstall it now?  (Yes = install, No = cancel setup)"

            $installPwsh = ([System.Windows.Forms.MessageBox]::Show($message, "Crestron Updater Setup", "YesNo", "Question") -eq "Yes")
        }
        else {
            $answer = (Read-Host "PowerShell 7 is missing and is required. Install it now? [Y/n]").Trim()
            $installPwsh = ($answer -eq "" -or $answer -match '^y(es)?$')
        }
    }

    if (-not $installPwsh) {
        Write-Host "Setup cancelled. Nothing was installed or changed."
        exit 1
    }

    Install-Prerequisite `
        -Name "PowerShell 7" `
        -WingetId "Microsoft.PowerShell" `
        -IsInstalled { [bool](Find-Pwsh) } `
        -Fallback {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

            $release = Invoke-RestMethod `
                "https://api.github.com/repos/PowerShell/PowerShell/releases/latest" `
                -Headers @{ "User-Agent" = "CrestronUpdaterSetup" }

            $asset = $release.assets |
                Where-Object { $_.name -like "*win-x64.msi" } |
                Select-Object -First 1

            if (-not $asset) {
                throw "No Windows x64 MSI found in the latest PowerShell release."
            }

            Install-FromMsi -Name "PowerShell 7" -Url $asset.browser_download_url -MsiArguments "ADD_PATH=1"
        }

    $pwsh = Find-Pwsh

    if (-not $pwsh) {
        Write-Host ""
        Write-Host "PowerShell 7 could not be installed automatically. Install it from https://aka.ms/powershell, then run setup again."
        exit 1
    }
}

# This setup may have been started in Windows PowerShell 5.1 so it could
# install PowerShell 7. Continue the rest of setup in PowerShell 7.
if ($PSVersionTable.PSVersion.Major -lt 7) {

    Write-Host "Continuing setup in PowerShell 7..."

    $relaunchArgs = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $PSCommandPath)

    foreach ($name in $PSBoundParameters.Keys) {

        $value = $PSBoundParameters[$name]

        if ($value -is [switch]) {
            if ($value.IsPresent) { $relaunchArgs += "-$name" }
        }
        elseif ($value -is [array]) {
            $relaunchArgs += "-$name"
            $relaunchArgs += ($value -join ",")
        }
        else {
            $relaunchArgs += "-$name"
            $relaunchArgs += [string]$value
        }
    }

    & $pwsh @relaunchArgs
    exit $LASTEXITCODE
}

$productList = Get-ProductList
$productsFile = Join-Path $PSScriptRoot $productsName

if (-not $Products) { $Products = @($productList | ForEach-Object { $_.Key }) }

# Firmware: the picker window and the device list (data only; the updater is loaded in a child scope).
. (Join-Path $PSScriptRoot $pickerName)

$firmwareCatalog = Get-FirmwareChoices -CatalogPath (Join-Path $PSScriptRoot $catalogName)
$firmwareList    = @($firmwareCatalog.Devices)

foreach ($problem in @($firmwareCatalog.Errors)) { Write-Warning "Firmware device list: $problem" }

# Error reports: where reports go (reporting.json next to this script).
$reportDestination = [string](Get-Content (Join-Path $PSScriptRoot "reporting.json") -Raw | ConvertFrom-Json).ReportDestination

# Error reports are on, unless this PC turned them off in an earlier setup or in Options
# (then they stay off unless -ErrorReports is given). The setup window's tick box starts
# from this and decides.
$errorReporting = $true

if (Test-Path $configFile) {
    try {
        if ((Get-Content $configFile -Raw | ConvertFrom-Json).ErrorReporting -eq $false) { $errorReporting = $false }
    }
    catch { }
}

if ($ErrorReports)   { $errorReporting = $true }
if ($NoErrorReports) { $errorReporting = $false }

# What an earlier setup chose (shown again when setup is re-run).
$previousFirmwareFolder  = ""
$previousFirmwareDevices = @()

if (Test-Path $configFile) {
    try {
        $previousConfig = Get-Content $configFile -Raw | ConvertFrom-Json
        if ($previousConfig.FirmwareFolder) { $previousFirmwareFolder = [string]$previousConfig.FirmwareFolder }
        $previousFirmwareDevices = @($previousConfig.FirmwareDevices | Where-Object { $_ })
    }
    catch { }
}


# ------------------------------------------------------------
# Setup window (when the folder was not given on the command line)
# ------------------------------------------------------------

$serverFingerprint = $null
$setupCredential   = $null

if ($useGui -and -not $DestinationRoot) {

    $startFolder = @($env:OneDriveCommercial, $env:OneDrive) |
        Where-Object { $_ -and (Test-Path $_) } |
        Select-Object -First 1

    if ($startFolder) {
        $crestronFolder = Join-Path $startFolder "For Install\Crestron"
        $startFolder = if (Test-Path $crestronFolder) { $crestronFolder } else { $startFolder }
    }

    $previousBlocked = @($BlockedSSIDs)

    if (-not $PSBoundParameters.ContainsKey("BlockedSSIDs") -and (Test-Path $configFile)) {
        $previousBlocked = @((Get-Content $configFile -Raw | ConvertFrom-Json).BlockedSSIDs | Where-Object { $_ })
    }

    $firmwareStart = if ($previousFirmwareFolder) { $previousFirmwareFolder } else { "" }
    $firmwareKeys  = @($previousFirmwareDevices | Where-Object { $key = $_; @($firmwareList | Where-Object Key -eq $key).Count -gt 0 })

    $choice = Show-SetupWizard -StartFolder $startFolder -BlockedNow $previousBlocked -Task $TaskName -ProductList $productList -Selected $Products -ProductsFile $productsFile `
        -FirmwareList $firmwareList -FirmwareOn ([bool]($previousFirmwareFolder -and $firmwareKeys.Count)) -FirmwareStart $firmwareStart -FirmwareSelected $firmwareKeys -ErrorReports $errorReporting

    if (-not $choice) {
        Write-Host "Setup cancelled. Nothing was changed."
        exit 1
    }

    $DestinationRoot   = $choice.DestinationRoot
    $BlockedSSIDs      = @($choice.BlockedSSIDs)
    $Products          = @($choice.Products)
    $TaskName          = $choice.TaskName
    $noticeTaskName    = "$TaskName Notice"
    $setupCredential   = $choice.Credential
    $serverFingerprint = $choice.Fingerprint
    $FirmwareFolder    = $choice.FirmwareFolder
    $FirmwareDevices   = @($choice.FirmwareDevices)
    $errorReporting    = [bool]$choice.ErrorReports    # the tick box decides, also over an earlier opt-out
    $wizardDone        = $true
}
else {

    # Firmware switches: both or neither, checked BEFORE anything is contacted.
    if ($FirmwareFolder -or $FirmwareDevices.Count -gt 0) {

        $FirmwareDevices = @(Resolve-FirmwareKeys -Requested $FirmwareDevices -Devices $firmwareList)

        $problem = if (-not $FirmwareFolder) { "-FirmwareDevices needs -FirmwareFolder (the folder to keep firmware in)." }
                   else { Test-FirmwareSettings -Enabled $true -Folder $FirmwareFolder -Keys $FirmwareDevices -Devices $firmwareList -SoftwareFolder $DestinationRoot }

        if ($problem) {
            Write-Host "Setup cannot continue: $problem"
            exit 1
        }
    }

    # Console route: the folder must be given.
    if (-not $DestinationRoot) {
        $DestinationRoot = (Read-Host "Folder to keep Crestron installers in").Trim()
    }

    if (-not $DestinationRoot) {
        Write-Host "No folder was given. Setup cancelled."
        exit 1
    }

    $setupCredential = Get-SetupCredential

    if (-not (Test-ValidCredential $setupCredential)) {
        Write-Host "No credential was entered. Setup cancelled."
        exit 1
    }

    Write-Host "Checking the login with ftp.crestron.com (the one contact setup makes)..."

    try { $serverFingerprint = Test-CrestronServer -Credential $setupCredential -ProductsFile $productsFile }
    catch {
        Write-Host "Setup cannot continue: $($_.Exception.Message)"
        exit 1
    }
}


# ------------------------------------------------------------
# Rollback support
#
# If setup is cancelled or fails before it finishes, remove only
# what THIS run created. Anything that already existed (folders,
# an earlier install) is never removed. Once setup completes,
# nothing is removed automatically.
# ------------------------------------------------------------

$script:createdPaths = New-Object System.Collections.Generic.List[string]
$script:createdTask  = $false
$script:createdNoticeTask = $false

# Never silently replace a scheduled task that another install is using.
# Re-running setup over its own install is fine.
if (-not $SkipTask) {

    $taskInTheWay = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue

    if ($taskInTheWay) {

        $ownLauncher = Join-Path $InstallDir $launcherName

        $theirCommand = ($taskInTheWay.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join " | "

        if ($useGui -and $theirCommand -notlike "*$ownLauncher*" -and -not $ReplaceExistingTask) {

            Add-Type -AssemblyName System.Windows.Forms

            $replaceAnswer = [System.Windows.Forms.MessageBox]::Show(
                "A scheduled task named '$TaskName' already exists and was not created by this setup:`r`n`r`n$theirCommand`r`n`r`nReplace it? Choose No to keep it (then run setup again with a different task name under Advanced).",
                "Crestron Updater Setup", "YesNo", "Warning", "Button2")

            if ($replaceAnswer -eq "Yes") {
                $ReplaceExistingTask = $true
            }
        }

        if ($theirCommand -notlike "*$ownLauncher*" -and -not $ReplaceExistingTask) {

            Write-Host ""
            Write-Host "A scheduled task named '$TaskName' already exists and was not created by this setup:"
            Write-Host "  $theirCommand"
            Write-Host ""
            Write-Host "Setup will not replace it. Either choose a different name, for example:"
            Write-Host "  -TaskName `"$TaskName TEST`""
            Write-Host "or add -ReplaceExistingTask if you really want to replace it."
            exit 1
        }
    }
}

function New-TrackedDirectory {

    param ([string]$Path)

    if (Test-Path $Path) {
        return
    }

    # Remember the top-most folder that does not exist yet, so one
    # removal undoes the whole chain this run created.
    $top = $Path

    while ($true) {
        $parent = Split-Path $top -Parent

        if (-not $parent -or (Test-Path $parent)) {
            break
        }

        $top = $parent
    }

    New-Item -ItemType Directory -Path $Path -Force | Out-Null
    $script:createdPaths.Add($top)
}

function Register-CreatedFile {

    param ([string]$Path)

    if (-not (Test-Path $Path)) {
        $script:createdPaths.Add($Path)
    }
}

function Grant-UserTaskControl {

    # A task registered from an elevated (administrator) window can, by default,
    # only be changed from an elevated window, so the Stop icon (an ordinary
    # window) would get "Access is denied" even for the same person. Give the
    # signed-in user full control of THEIR OWN task; it already runs as them, so
    # this adds no privilege. A failure here is only a warning.
    param ([string]$Name)

    try {

        $sid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value

        $service = New-Object -ComObject Schedule.Service
        $service.Connect()

        $registered = $service.GetFolder("\").GetTask($Name)
        $registered.SetSecurityDescriptor("D:P(A;;FA;;;BA)(A;;FA;;;SY)(A;;FA;;;$sid)", 0)
    }
    catch {
        Write-Warning "Could not give your account control of the task '$Name' ($($_.Exception.Message)). The Stop icon may then need an administrator window."
    }
}

function Undo-Setup {

    if ($script:createdTask) {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
    }

    if ($script:createdNoticeTask) {
        Unregister-ScheduledTask -TaskName $noticeTaskName -Confirm:$false -ErrorAction SilentlyContinue
    }

    for ($i = $script:createdPaths.Count - 1; $i -ge 0; $i--) {
        Remove-Item $script:createdPaths[$i] -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function New-AppShortcut {

    param (
        [string]$Path,
        [string]$ScriptPath,
        [string]$Description = "Stop or resume the Crestron Updater, check now, change the saved Crestron password, or remove it",
        [string]$Icon = "$env:SystemRoot\System32\shell32.dll,316"   # the blue settings gear
    )

    $shell    = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($Path)

    $shortcut.TargetPath       = $pwsh
    $shortcut.Arguments        = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$ScriptPath`""
    $shortcut.WorkingDirectory = $InstallDir
    $shortcut.Description      = $Description
    $shortcut.IconLocation     = $Icon
    $shortcut.Save()
}

$setupFinished = $false

$progressForm = $null

if ($wizardDone) {

    Add-Type -AssemblyName System.Windows.Forms

    $progressForm = New-Object System.Windows.Forms.Form
    $progressForm.Text = "Crestron Updater Setup"
    $progressForm.ClientSize = New-Object System.Drawing.Size(420, 90)
    $progressForm.StartPosition = "CenterScreen"; $progressForm.FormBorderStyle = "FixedDialog"
    $progressForm.ControlBox = $false; $progressForm.TopMost = $true
    $progressForm.Font = New-Object System.Drawing.Font("Segoe UI", 10)

    $progressLabel = New-Object System.Windows.Forms.Label
    $progressLabel.Text = "Installing the Crestron Updater, please wait..."
    $progressLabel.Location = New-Object System.Drawing.Point(20, 28); $progressLabel.Size = New-Object System.Drawing.Size(380, 30)
    $progressForm.Controls.Add($progressLabel)

    $progressForm.Show()
    [System.Windows.Forms.Application]::DoEvents()
}

try {

    # --------------------------------------------------------
    # Where installers are saved
    # --------------------------------------------------------

    $crestronFolder = $DestinationRoot
    New-TrackedDirectory $crestronFolder

    Write-Host "Installers will be saved to: $crestronFolder"

    $firmwareOn = [bool]($FirmwareFolder -and @($FirmwareDevices).Count -gt 0)

    if ($firmwareOn) {
        New-TrackedDirectory $FirmwareFolder
        Write-Host "Firmware will be saved to: $FirmwareFolder ($(@($FirmwareDevices).Count) device(s))"
    }

    # --------------------------------------------------------
    # Login (the check with Crestron already happened above)
    # --------------------------------------------------------

    New-TrackedDirectory $InstallDir

    Register-CreatedFile $credentialFile
    Save-CrestronCredential -Path $credentialFile -Credential $setupCredential

    # --------------------------------------------------------
    # Install files and settings
    # --------------------------------------------------------

    foreach ($file in $ownFiles) {
        $target = Join-Path $InstallDir $file
        Register-CreatedFile $target
        Copy-Item (Join-Path $PSScriptRoot $file) $target -Force
    }

    New-TrackedDirectory (Join-Path $InstallDir "lib")

    foreach ($dll in Get-ChildItem (Join-Path $PSScriptRoot "lib") -File) {
        $target = Join-Path (Join-Path $InstallDir "lib") $dll.Name
        Register-CreatedFile $target
        Copy-Item $dll.FullName $target -Force
    }

    $updaterPath       = Join-Path $InstallDir $updaterName
    $optionsScriptPath = Join-Path $InstallDir $optionsScriptName
    $noticePath        = Join-Path $InstallDir $noticeName

    # Only the enabled KEYS go in config.json; the definitions stay in products.json (installed next to the updater).
    $configProducts = @($productList | Where-Object { $Products -contains $_.Key } | ForEach-Object { [string]$_.Key })

    $config = [ordered]@{
        StateDir           = $InstallDir
        CrestronFolder     = $crestronFolder
        BlockedSSIDs       = @($BlockedSSIDs)
        NoticeTaskName     = $noticeTaskName
        TaskName           = $TaskName
        Host               = $ServerHost
        Port               = $ServerPort
        HostKeyFingerprint = $serverFingerprint
        FirmwareFolder     = $(if ($firmwareOn) { $FirmwareFolder } else { "" })
        FirmwareDevices    = @($(if ($firmwareOn) { $FirmwareDevices } else { @() }))
        Products           = $configProducts
        ErrorReporting     = $errorReporting
        ReportDestination  = $reportDestination
    }

    Register-CreatedFile $configFile
    $config | ConvertTo-Json -Depth 6 | Set-Content -Path $configFile -Encoding UTF8

    $vbs = @"
Set shell = CreateObject("WScript.Shell")
shell.Run """$pwsh"" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File ""$updaterPath""", 0, True
"@

    $launcherPath = Join-Path $InstallDir $launcherName
    Register-CreatedFile $launcherPath
    Set-Content -Path $launcherPath -Value $vbs -Encoding ASCII

    $noticeVbs = @"
Set shell = CreateObject("WScript.Shell")
shell.Run """$pwsh"" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""$noticePath""", 0, False
"@

    $noticeLauncherPath = Join-Path $InstallDir $noticeLauncher
    Register-CreatedFile $noticeLauncherPath
    Set-Content -Path $noticeLauncherPath -Value $noticeVbs -Encoding ASCII

    Write-Host "Installed to $InstallDir"

    # --------------------------------------------------------
    # Scheduled task: at logon and on wake from sleep
    # --------------------------------------------------------

    if (-not $SkipTask) {

        $user = "$env:USERDOMAIN\$env:USERNAME"

        $action = New-ScheduledTaskAction `
            -Execute "wscript.exe" `
            -Argument ('"{0}"' -f $launcherPath)

        # Matches the original working task: 2 minute delay after logon and
        # after resuming from sleep (Kernel-Power event 107).
        $logonTrigger = New-ScheduledTaskTrigger -AtLogOn -User $user
        $logonTrigger.Delay = "PT2M"

        $eventClass = Get-CimClass `
            -Namespace "Root/Microsoft/Windows/TaskScheduler" `
            -ClassName "MSFT_TaskEventTrigger"

        $wakeTrigger = New-CimInstance -CimClass $eventClass -ClientOnly
        $wakeTrigger.Enabled = $true
        $wakeTrigger.Delay = "PT2M"
        $wakeTrigger.Subscription = @"
<QueryList><Query Id="0" Path="System"><Select Path="System">*[System[Provider[@Name='Microsoft-Windows-Kernel-Power'] and EventID=107]]</Select></Query></QueryList>
"@

        $settings = New-ScheduledTaskSettingsSet `
            -StartWhenAvailable `
            -AllowStartIfOnBatteries `
            -DontStopIfGoingOnBatteries `
            -MultipleInstances IgnoreNew `
            -RunOnlyIfNetworkAvailable `
            -RestartCount 3 `
            -RestartInterval (New-TimeSpan -Minutes 5) `
            -ExecutionTimeLimit (New-TimeSpan -Hours 3)

        # Same account type as the original task: the signed-in user's SID, interactive.
        $userSid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value

        $principal = New-ScheduledTaskPrincipal `
            -UserId $userSid `
            -LogonType Interactive `
            -RunLevel Limited

        $existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue

        if ($existing) {
            Write-Host "A scheduled task named '$TaskName' already exists and will be replaced."
        }

        Register-ScheduledTask `
            -TaskName $TaskName `
            -Action $action `
            -Trigger @($logonTrigger, $wakeTrigger) `
            -Settings $settings `
            -Principal $principal `
            -Force |
            Out-Null

        Grant-UserTaskControl -Name $TaskName

        if (-not $existing) {
            $script:createdTask = $true
        }

        Write-Host "Scheduled task '$TaskName' registered (at logon)."

        # On-demand task that shows the "new version downloaded" notice.
        # No triggers and NO time limit: the notice stays open until the
        # user clicks a button, so it must not be tied to the updater's
        # 1 hour limit. The updater starts it with Start-ScheduledTask.
        $noticeAction = New-ScheduledTaskAction `
            -Execute "wscript.exe" `
            -Argument ('"{0}"' -f $noticeLauncherPath)

        $noticeSettings = New-ScheduledTaskSettingsSet `
            -AllowStartIfOnBatteries `
            -DontStopIfGoingOnBatteries `
            -MultipleInstances IgnoreNew `
            -ExecutionTimeLimit ([TimeSpan]::Zero)

        $existingNotice = Get-ScheduledTask -TaskName $noticeTaskName -ErrorAction SilentlyContinue

        Register-ScheduledTask `
            -TaskName $noticeTaskName `
            -Action $noticeAction `
            -Settings $noticeSettings `
            -Principal $principal `
            -Force |
            Out-Null

        Grant-UserTaskControl -Name $noticeTaskName

        if (-not $existingNotice) {
            $script:createdNoticeTask = $true
        }
    }

    # --------------------------------------------------------
    # "Crestron Updater Options" icons (Desktop and Start menu)
    # --------------------------------------------------------

    $desktopLink = Join-Path ([Environment]::GetFolderPath("Desktop")) $optionsLinkName
    Register-CreatedFile $desktopLink
    New-AppShortcut -Path $desktopLink -ScriptPath $optionsScriptPath

    $startMenuFolder = Join-Path ([Environment]::GetFolderPath("Programs")) "Crestron Updater"
    New-TrackedDirectory $startMenuFolder

    $startMenuLink = Join-Path $startMenuFolder $optionsLinkName
    Register-CreatedFile $startMenuLink
    New-AppShortcut -Path $startMenuLink -ScriptPath $optionsScriptPath

    $setupFinished = $true
}
catch {

    Write-Host ""

    if ($_.Exception.Message -match "cancelled") {
        Write-Host "Setup cancelled."
    }
    else {
        Write-Host "Setup failed: $($_.Exception.Message)"
    }
}
finally {

    if ($progressForm) {
        $progressForm.Close()
        $progressForm.Dispose()
    }

    # Also runs if the window is closed with Ctrl+C.
    if (-not $setupFinished) {
        Write-Host "Removing what this setup created..."
        Undo-Setup
        Write-Host "Done. Nothing from this setup was left behind."

        if ($wizardDone) {
            [void][System.Windows.Forms.MessageBox]::Show("Setup did not finish, so everything it had created was removed. Nothing was left behind.", "Crestron Updater Setup", "OK", "Warning")
        }
    }
}

if (-not $setupFinished) {
    exit 1
}


Write-Host ""
Write-Host "Setup complete."
Write-Host "Run history (one dated line per attempt, with the reason if it failed):"
Write-Host "  $(Join-Path $InstallDir 'Logs\Run-History.log')"
Write-Host "Detailed log: $(Join-Path $InstallDir 'Logs\Crestron-Updater.log')"
Write-Host ""
Write-Host "To stop or resume the updater, check now, change your Crestron password or"
Write-Host "remove it, open 'Crestron Updater Options' on your Desktop (or in the Start menu)."

if ($RunNow -and -not $SkipTask) {
    Start-ScheduledTask -TaskName $TaskName
    Write-Host "Started the updater now."
}

if ($useGui -and $wizardDone) {

    if (Show-SetupDone) {

        # Open the Options window (outside the install folder, so it can never block removing it).
        Start-Process -FilePath $pwsh -WorkingDirectory $env:TEMP -WindowStyle Hidden -ArgumentList @(
            "-NoProfile", "-ExecutionPolicy", "Bypass",
            "-File", "`"$optionsScriptPath`"",
            "-InstallDir", "`"$InstallDir`""
        )
    }
}
