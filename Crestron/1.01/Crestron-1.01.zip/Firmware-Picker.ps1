# Crestron Updater -- firmware device picker (functions only; dot-source it).
# Shared by Install-CrestronUpdater.ps1 (Setup) and Options-CrestronUpdater.ps1 (Firmware settings...).
# The window is built from firmware-catalog.json, so a new device in the catalog shows up here with no code change.

# The device list for the picker: active entries only (current / unverified), as Get-FirmwareCatalog returns them.
# The updater is loaded in a child scope so none of its names leak into the caller.
function Get-FirmwareChoices {

    param ([string]$CatalogPath)

    $updater = Join-Path $PSScriptRoot "Crestron-Updater.ps1"

    & { param ($u, $c) . $u; Get-FirmwareCatalog -Path $c } $updater $CatalogPath
}

# Console switch -FirmwareDevices: device keys, or "all" = every device whose status is current. Unknown keys stay in the
# result so Test-FirmwareSettings can name them.
function Resolve-FirmwareKeys {

    param ([string[]]$Requested, $Devices)

    $wanted = @($Requested | ForEach-Object { "$_".Trim().ToLower() } | Where-Object { $_ })

    if ($wanted -contains "all") {
        return @($Devices | Where-Object { $_.Status -eq "current" } | ForEach-Object { $_.Key })
    }

    return @($wanted | Select-Object -Unique)
}

function Format-FirmwareSize {

    param ([double]$MB)

    if ($MB -ge 1000) { return ("about {0:N1} GB" -f ($MB / 1024)) }
    return ("about {0} MB" -f [math]::Max(1, [math]::Round($MB)))
}

# "No devices chosen" / "1 device chosen" / "12 devices chosen (about 8.1 GB for the first download)"
function Get-FirmwareSummary {

    param ($Devices, [string[]]$Keys)

    $picked = @($Devices | Where-Object { $Keys -contains $_.Key })

    if ($picked.Count -eq 0) { return "No devices chosen" }

    $noun = if ($picked.Count -eq 1) { "device" } else { "devices" }
    $mb = ($picked | Measure-Object ApproxMB -Sum).Sum

    if ($mb -gt 0) { return "$($picked.Count) $noun chosen ($(Format-FirmwareSize $mb) for the first download)" }
    return "$($picked.Count) $noun chosen"
}

# Suggested firmware folder: next to the installers folder, called "Crestron Firmware". Empty when there is no parent.
function Get-DefaultFirmwareFolder {

    param ([string]$SoftwareFolder)

    if (-not $SoftwareFolder) { return "" }

    $parent = Split-Path $SoftwareFolder.TrimEnd('\') -Parent

    if (-not $parent) { return "" }

    return Join-Path $parent "Crestron Firmware"
}

# Plain-wording problem with the firmware settings, or $null when they are fine.
# The folder may not exist yet when its parent does (Setup creates it).
function Test-FirmwareSettings {

    param ([bool]$Enabled, [string]$Folder, [string[]]$Keys, $Devices, [string]$SoftwareFolder)

    if (-not $Enabled) { return $null }

    $Folder = "$Folder".Trim()

    if (-not $Folder) { return "Choose the folder to save firmware in (Firmware section)." }

    if (-not (Test-Path -LiteralPath $Folder)) {
        $parent = Split-Path $Folder.TrimEnd('\') -Parent
        if (-not $parent -or -not (Test-Path -LiteralPath $parent)) { return "The firmware folder cannot be created because its parent folder does not exist:`r`n$Folder`r`n`r`nChoose an existing folder (Browse... can make a new one)." }
    }

    if ($SoftwareFolder -and ($Folder.TrimEnd('\') -ieq $SoftwareFolder.Trim().TrimEnd('\'))) {
        return "Use a different folder for firmware than the one for installers, so the two kinds of files stay apart."
    }

    if (@($Keys).Count -eq 0) { return "Choose at least one device (Choose devices...), or untick the firmware box." }

    $known = @($Devices | ForEach-Object { $_.Key })
    $unknown = @($Keys | Where-Object { $known -notcontains $_ })

    if ($unknown.Count -gt 0) { return "These firmware devices are not in the device list: $($unknown -join ', ')." }

    return $null
}

# The picker window. Returns the chosen keys (possibly none) or $null when cancelled.
function Show-FirmwarePicker {

    param ($Devices, [string[]]$Selected = @(), $Owner)

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $global:FP = @{ Boxes = [ordered]@{} }

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Choose firmware devices"
    $form.ClientSize = New-Object System.Drawing.Size(620, 640)
    $form.StartPosition = if ($Owner) { "CenterParent" } else { "CenterScreen" }
    $form.FormBorderStyle = "FixedDialog"; $form.MaximizeBox = $false; $form.MinimizeBox = $false
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)
    $global:FP.Form = $form

    $intro = New-Object System.Windows.Forms.Label
    $intro.Text = "Tick the devices whose firmware you want kept up to date. Only the newest file of each is kept. The updater only downloads firmware; loading it into the devices is still done by hand."
    $intro.Location = New-Object System.Drawing.Point(20, 12); $intro.Size = New-Object System.Drawing.Size(580, 44)
    $form.Controls.Add($intro)

    $panel = New-Object System.Windows.Forms.Panel
    $panel.Name = "DevicePanel"
    $panel.Location = New-Object System.Drawing.Point(20, 62); $panel.Size = New-Object System.Drawing.Size(580, 470)
    $panel.AutoScroll = $true; $panel.BorderStyle = "FixedSingle"
    $form.Controls.Add($panel)

    $tips = New-Object System.Windows.Forms.ToolTip
    $tips.AutoPopDelay = 20000

    $estimate = New-Object System.Windows.Forms.Label
    $estimate.Name = "EstimateLabel"
    $estimate.Location = New-Object System.Drawing.Point(20, 540); $estimate.Size = New-Object System.Drawing.Size(580, 44)
    $form.Controls.Add($estimate)
    $global:FP.Estimate = $estimate

    $global:FP.Update = {
        $keys = @($global:FP.Boxes.Keys | Where-Object { $global:FP.Boxes[$_].Checked })
        $global:FP.Estimate.Text = (Get-FirmwareSummary -Devices $global:FP.Devices -Keys $keys) + "`r`nLater updates only download what is new."
    }
    $global:FP.Devices = @($Devices)

    $y = 8
    $categoryIndex = 0
    foreach ($category in (@($Devices | ForEach-Object { $_.Category } | Select-Object -Unique))) {

        $categoryIndex++
        $heading = New-Object System.Windows.Forms.Label
        $heading.Text = $category
        $heading.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
        $heading.Location = New-Object System.Drawing.Point(8, $y); $heading.Size = New-Object System.Drawing.Size(360, 24)
        $panel.Controls.Add($heading)

        $keysInCategory = @($Devices | Where-Object { $_.Category -eq $category } | ForEach-Object { $_.Key })

        foreach ($mode in @(@{ Text = "None"; Value = $false; X = 480 }, @{ Text = "All"; Value = $true; X = 400 })) {
            $button = New-Object System.Windows.Forms.Button
            $button.Name = "$($mode.Text)_$categoryIndex"
            $button.Text = $mode.Text
            $button.Location = New-Object System.Drawing.Point($mode.X, ($y - 1)); $button.Size = New-Object System.Drawing.Size(70, 26)
            $button.Tag = [pscustomobject]@{ Keys = $keysInCategory; Value = $mode.Value }
            $button.Add_Click({
                param ($sender, $e)
                try { foreach ($k in $sender.Tag.Keys) { $global:FP.Boxes[$k].Checked = $sender.Tag.Value } } catch { }
            })
            $panel.Controls.Add($button)
        }
        $y += 30

        foreach ($device in ($Devices | Where-Object { $_.Category -eq $category })) {

            $box = New-Object System.Windows.Forms.CheckBox
            $box.Name = "Device_$($device.Key)"
            $label = $device.Name
            if ($device.Models -and $device.Models -ne $device.Name) { $label += "  -  $($device.Models)" }
            if ($device.Status -eq "unverified") { $label += "  (not confirmed by Crestron yet)" }
            $box.Text = $label
            $box.AutoEllipsis = $true
            $box.Location = New-Object System.Drawing.Point(26, $y); $box.Size = New-Object System.Drawing.Size(530, 24)
            $box.Checked = ($Selected -contains $device.Key)
            $box.Add_CheckedChanged({ try { & $global:FP.Update } catch { } })

            $tip = "$($device.Name)`r`nModels: $($device.Models)"
            if ($device.ApproxMB -gt 0) { $tip += "`r`nNewest file: $(Format-FirmwareSize $device.ApproxMB)" }
            if ($device.Notes) { $tip += "`r`n$($device.Notes)" }
            $tips.SetToolTip($box, $tip)

            $global:FP.Boxes[$device.Key] = $box
            $panel.Controls.Add($box)
            $y += 26
        }
        $y += 8
    }

    $ok = New-Object System.Windows.Forms.Button
    $ok.Name = "PickerOK"; $ok.Text = "OK"; $ok.DialogResult = "OK"
    $ok.Location = New-Object System.Drawing.Point(420, 596); $ok.Size = New-Object System.Drawing.Size(86, 32)
    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Name = "PickerCancel"; $cancel.Text = "Cancel"; $cancel.DialogResult = "Cancel"
    $cancel.Location = New-Object System.Drawing.Point(514, 596); $cancel.Size = New-Object System.Drawing.Size(86, 32)
    $form.Controls.AddRange(@($ok, $cancel))

    # One toggle for the whole list (each category also has its own All / None).
    foreach ($mode in @(@{ Name = "PickerAll"; Text = "Select all"; Value = $true; X = 20 }, @{ Name = "PickerNone"; Text = "Select none"; Value = $false; X = 120 })) {
        $button = New-Object System.Windows.Forms.Button
        $button.Name = $mode.Name; $button.Text = $mode.Text
        $button.Location = New-Object System.Drawing.Point($mode.X, 596); $button.Size = New-Object System.Drawing.Size(92, 32)
        $button.Tag = $mode.Value
        $button.Add_Click({
            param ($sender, $e)
            try { foreach ($k in @($global:FP.Boxes.Keys)) { $global:FP.Boxes[$k].Checked = [bool]$sender.Tag } } catch { }
        })
        $form.Controls.Add($button)
    }
    $form.AcceptButton = $ok; $form.CancelButton = $cancel

    & $global:FP.Update

    $answer = if ($Owner) { $form.ShowDialog($Owner) } else { $form.ShowDialog() }

    $result = $null
    if ($answer -eq "OK") { $result = @($global:FP.Boxes.Keys | Where-Object { $global:FP.Boxes[$_].Checked }) }

    $form.Dispose()
    $tips.Dispose()

    if ($null -eq $result) { return $null }
    return , $result
}
