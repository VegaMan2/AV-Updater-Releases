# ============================================================
# Crestron Updater -- Options
#
# Installed to %LOCALAPPDATA%\CrestronUpdater by Install-CrestronUpdater.ps1 and
# started by the "Crestron Updater Options" icon (Desktop and Start menu).
#
#   (no switch)   Opens the Options window: status, stop or resume the updater,
#                 check now, update the saved Crestron password, open the run
#                 history or the installers folder, turn error reports on or off
#                 (window only), or remove the updater.
#                 Opening it changes nothing by itself. (-NoGui, or redirected
#                 input, gives a one-key console menu instead.)
#   -Uninstall    Removes the scheduled tasks, the icons, and the updater's own
#                 folder (saved Crestron login, logs, run history). Downloaded
#                 installers are always kept. There is no undo: older versions
#                 of the programs are deleted by design when a new one arrives.
# ============================================================
[CmdletBinding()]
param (
    [string]$InstallDir = (Join-Path $env:LOCALAPPDATA "CrestronUpdater"),
    [string]$TaskName = "Crestron Updater",
    [switch]$Uninstall,
    [switch]$NoGui,   # keep the console menu (also used automatically when input is redirected)
    [switch]$Yes      # with -Uninstall: the confirmation was already given (by the window)
)

$ErrorActionPreference = "Stop"

$configFile   = Join-Path $InstallDir "config.json"
$optionsLinkName = "Crestron Updater Options.lnk"
$optionsScript = Join-Path $InstallDir "Options-CrestronUpdater.ps1"

# Error reports on/off (Set-ErrorReporting). Without the module (or with a damaged one) the
# window simply has no Error reports button.
$reportingScript = Join-Path $PSScriptRoot "Reporting.ps1"
if (Test-Path -LiteralPath $reportingScript) { try { . $reportingScript } catch { } }

$crestronFolder = $null
$noticeTaskName = $null

if (Test-Path $configFile) {

    $savedConfig = Get-Content $configFile -Raw | ConvertFrom-Json

    $crestronFolder = $savedConfig.CrestronFolder

    # Use the task name this install was set up with, so a test install with its
    # own task name never touches a different install's task.
    if ($savedConfig.TaskName -and -not $PSBoundParameters.ContainsKey("TaskName")) {
        $TaskName = $savedConfig.TaskName
    }

    $noticeTaskName = $savedConfig.NoticeTaskName
}

if (-not $noticeTaskName) {
    $noticeTaskName = "$TaskName Notice"
}

$task       = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
$noticeTask = Get-ScheduledTask -TaskName $noticeTaskName -ErrorAction SilentlyContinue

# The firmware device picker (installed next to this script by Setup).
$pickerScript  = Join-Path $InstallDir "Firmware-Picker.ps1"
$catalogFile   = Join-Path $InstallDir "firmware-catalog.json"
$pickerPresent = Test-Path $pickerScript
if ($pickerPresent) { . $pickerScript }

# Firmware settings as saved in config.json (read fresh each time: the settings window changes them).
function Get-FirmwareConfig {

    $folder = ""
    $keys   = @()

    if (Test-Path $configFile) {
        try {
            $c = Get-Content $configFile -Raw | ConvertFrom-Json
            if ($c.FirmwareFolder) { $folder = [string]$c.FirmwareFolder }
            $keys = @($c.FirmwareDevices | Where-Object { $_ })
        }
        catch { }
    }

    [pscustomobject]@{ Folder = $folder; Keys = $keys; On = [bool]($folder -and $keys.Count -gt 0) }
}

function Get-FirmwareStatusText {

    $fw = Get-FirmwareConfig

    if (-not $fw.On) { return "Off (use Firmware settings... to turn it on)" }

    $noun = if ($fw.Keys.Count -eq 1) { "device" } else { "devices" }
    return "$($fw.Folder)`r`n$($fw.Keys.Count) $noun chosen"
}


function Invoke-TaskChange {

    # Runs one scheduled-task change. If Windows refuses, say why in plain words
    # and what to do, instead of showing a raw error. Returns $true on success.
    param (
        [scriptblock]$Change,
        [string]$Action,
        [switch]$Quiet   # window: keep the explanation in $global:QOptTaskMessage instead of printing it
    )

    try {
        & $Change
        return $true
    }
    catch {

        $text = @("Could not $Action the scheduled task. Windows said: $($_.Exception.Message)")

        if ($_.Exception.Message -match 'denied') {
            $text += ""
            $text += "This happens when the task was created from a PowerShell window opened with"
            $text += "'Run as administrator': Windows then lets only an administrator window change it."
            $text += "Either run Install-CrestronUpdater.ps1 again (setup now gives your account control"
            $text += "of its own tasks), or run this same command from an administrator window."
        }

        if ($Quiet) {
            $global:QOptTaskMessage = $text -join "`r`n"
        }
        else {
            Write-Host ""
            foreach ($line in $text) { Write-Host $line }
        }

        return $false
    }
}

function Stop-RunningUpdater {

    # Ends only this updater's own process. Nothing else is touched.
    $processes = Get-CimInstance Win32_Process |
        Where-Object {
            $_.Name -eq "pwsh.exe" -and
            $_.CommandLine -like "*$InstallDir*Crestron-Updater.ps1*"
        }

    foreach ($process in $processes) {
        Stop-Process -Id $process.ProcessId -Force -ErrorAction SilentlyContinue
    }
}

function Stop-OpenNotice {

    Get-CimInstance Win32_Process |
        Where-Object {
            $_.Name -eq "pwsh.exe" -and
            $_.CommandLine -like "*$InstallDir*Show-CrestronNotice.ps1*"
        } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

# ------------------------------------------------------------
# Uninstall
# ------------------------------------------------------------

if ($Uninstall) {

    Write-Host "This removes the Crestron Updater from this PC:"
    Write-Host "  - the scheduled tasks '$TaskName' and '$noticeTaskName'"
    Write-Host "  - the Crestron Updater Options icons on the Desktop and in the Start menu"
    Write-Host "  - $InstallDir (saved Crestron login, logs, run history)"
    Write-Host ""
    Write-Host "Downloaded installers are NOT deleted."
    Write-Host ""

    if (-not $Yes) {

        $answer = Read-Host "Remove the updater now? [y/N]"

        if ($answer -notmatch '^(y|yes)$') {
            Write-Host "Nothing was removed."
            return
        }
    }

    Stop-RunningUpdater
    Stop-OpenNotice

    # If Windows will not let the tasks be removed, stop here and remove nothing
    # else: deleting the files while the tasks remain would leave broken tasks.
    if ($task) {

        if (-not (Invoke-TaskChange -Action "remove" -Change { Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction Stop })) {
            Write-Host ""
            Write-Host "Nothing else was removed."
            return
        }

        Write-Host "Removed the scheduled task."
    }

    if ($noticeTask) {

        if (-not (Invoke-TaskChange -Action "remove" -Change { Unregister-ScheduledTask -TaskName $noticeTaskName -Confirm:$false -ErrorAction Stop })) {
            Write-Host ""
            Write-Host "The main task was removed but the notice task was not, and nothing else was removed."
            return
        }
    }

    $desktop     = [Environment]::GetFolderPath("Desktop")
    $startFolder = Join-Path ([Environment]::GetFolderPath("Programs")) "Crestron Updater"

    Remove-Item (Join-Path $desktop $optionsLinkName) -Force -ErrorAction SilentlyContinue
    Remove-Item $startFolder -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Removed the icons."

    # Windows will not delete a folder a program is standing in, and this window
    # may have been started inside the install folder. Step out of it first.
    # (Set-Location only moves PowerShell's own location; the process's working
    # folder, the one Windows checks, has to be moved as well.)
    try {
        Set-Location $env:TEMP
        [System.IO.Directory]::SetCurrentDirectory($env:TEMP)
    }
    catch { }

    try {
        Remove-Item $InstallDir -Recurse -Force
        Write-Host "Removed $InstallDir."
    }
    catch {
        Write-Warning "Could not remove $InstallDir ($($_.Exception.Message)). Close any window that is open in that folder and delete it yourself: it holds your saved Crestron login (encrypted)."
    }

    Write-Host ""
    Write-Host "Still on this PC (remove yourself if you want):"

    if ($crestronFolder) {
        Write-Host "  - Your installers folder: $crestronFolder"
    }

    Write-Host "  - PowerShell 7 (Settings > Apps > Installed apps)"
    return
}


# ------------------------------------------------------------
# Options window (no switch): shows the status, then one-key choices
# ------------------------------------------------------------

$historyFile     = Join-Path $InstallDir "Logs\Run-History.log"
$passwordScript  = Join-Path $InstallDir "Update-CrestronPassword.ps1"
$loginFailedFile = Join-Path $InstallDir "login-failed.json"

try { $Host.UI.RawUI.WindowTitle = "Crestron Updater Options" } catch { }

# One key, no Enter, no copying of commands. If there is no real console (for
# example when input is redirected) it falls back to typing a letter and Enter.
function Read-MenuKey {

    try {

        $pressed = [Console]::ReadKey($true)

        if ($pressed.Key -eq "Enter") {
            return ""
        }

        return $pressed.KeyChar.ToString().ToUpper()
    }
    catch {

        $typed = Read-Host "Choose"

        if ($null -eq $typed) {
            return ""
        }

        return $typed.Trim().ToUpper()
    }
}

function Get-UpdaterTask {

    Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
}

function Test-UpdaterRunning {

    @(
        Get-CimInstance Win32_Process |
            Where-Object {
                $_.Name -eq "pwsh.exe" -and
                $_.CommandLine -like "*$InstallDir*Crestron-Updater.ps1*"
            }
    ).Count -gt 0
}

function Show-Status {

    $current = Get-UpdaterTask

    Write-Host ""
    Write-Host "============================================================"
    Write-Host " Crestron Updater"
    Write-Host "============================================================"

    if (-not $current) {
        Write-Host " Updater:   its scheduled task '$TaskName' was not found"
    }
    elseif ($current.State -eq "Disabled") {
        Write-Host " Updater:   STOPPED (it will not check at logon or after sleep)"
    }
    elseif (Test-UpdaterRunning) {
        Write-Host " Updater:   checking for an update right now"
    }
    else {
        Write-Host " Updater:   ON (checks at logon and after sleep)"
    }

    if (Test-Path $loginFailedFile) {

        $failed = Get-Content $loginFailedFile -Raw | ConvertFrom-Json
        $since  = try { ([datetime]$failed.Time).ToString("MMMM d") } catch { "earlier" }

        Write-Host " Login:     PAUSED since ${since}: $($failed.Message)"
        Write-Host "            It will not try again until you update the password (press P)."
    }
    else {
        Write-Host " Login:     OK"
    }

    if (Test-Path $historyFile) {

        $last = (Get-Content $historyFile -Tail 1)

        if ($last.Length -gt 100) {
            $last = $last.Substring(0, 97) + "..."
        }

        Write-Host " Last check: $last"
    }
    else {
        Write-Host " Last check: none yet"
    }

    if ($crestronFolder) {
        Write-Host " Installers: $crestronFolder"
    }

    $fwConsole = Get-FirmwareConfig
    if ($fwConsole.On) { Write-Host " Firmware:   $($fwConsole.Folder) ($($fwConsole.Keys.Count) device(s))" }
    else { Write-Host " Firmware:   off" }

    Write-Host "------------------------------------------------------------"
}

function Show-Menu {

    $current = Get-UpdaterTask

    Write-Host "Press one key:"
    Write-Host ""

    if ($current -and $current.State -eq "Disabled") {
        Write-Host "   R       Resume the updater"
    }
    else {
        Write-Host "   S       Stop the updater (nothing is deleted)"
    }

    Write-Host "   P       Update my Crestron password"
    Write-Host "   H       Open the run history (one dated line per attempt)"

    if ($crestronFolder) {
        Write-Host "   F       Open the installers folder"
    }

    Write-Host "   C       Check for updates now"
    Write-Host "   X       Remove the updater from this PC (asks you to confirm first)"
    Write-Host "   Enter   Close this window"
    Write-Host ""
}

# ------------------------------------------------------------
# The window (default when a person opens it; the console menu below is used
# with -NoGui or when input is redirected, as in the automated tests)
# ------------------------------------------------------------

function Get-OptionsStatus {

    # The same facts the console status block shows, as data.
    $current = Get-UpdaterTask

    $status = @{
        TaskFound = [bool]$current
        Stopped   = [bool]($current -and $current.State -eq "Disabled")
    }

    if (-not $current) {
        $status.Updater = "Its scheduled task '$TaskName' was not found"
    }
    elseif ($current.State -eq "Disabled") {
        $status.Updater = "STOPPED (it will not check at logon or after sleep)"
    }
    elseif (Test-UpdaterRunning) {
        $status.Updater = "Checking for an update right now"
    }
    else {
        $status.Updater = "ON (checks at logon and after sleep)"
    }

    if (Test-Path $loginFailedFile) {

        $failed = Get-Content $loginFailedFile -Raw | ConvertFrom-Json
        $since  = try { ([datetime]$failed.Time).ToString("MMMM d") } catch { "earlier" }

        $status.SignIn = "PAUSED since ${since}: $($failed.Message)`r`nIt will not try again until you update the Crestron password."
    }
    else {
        $status.SignIn = "OK"
    }

    $status.LastCheck  = if (Test-Path $historyFile) { (Get-Content $historyFile -Tail 1) } else { "None yet" }
    $status.Installers = if ($crestronFolder) { $crestronFolder } else { "Not set" }
    $status.Firmware   = Get-FirmwareStatusText

    $status
}

function Show-OptionsWindow {

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    # Windows will not delete a folder a program is standing in, and this window
    # may have been started inside the install folder.
    try {
        Set-Location $env:TEMP
        [System.IO.Directory]::SetCurrentDirectory($env:TEMP)
    }
    catch { }

    # Hide the console this script was started in, but only if it is ours alone
    # (not a terminal the person opened and is still using).
    try {
        Add-Type -Namespace CrestOpt -Name Native -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern System.IntPtr GetConsoleWindow();
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern uint GetConsoleProcessList(uint[] list, uint count);
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool ShowWindow(System.IntPtr hWnd, int cmd);
'@
        $consoleWindow = [CrestOpt.Native]::GetConsoleWindow()
        $ids = New-Object 'uint32[]' 4
        if ($consoleWindow -ne [IntPtr]::Zero -and [CrestOpt.Native]::GetConsoleProcessList($ids, 4) -le 1) {
            [void][CrestOpt.Native]::ShowWindow($consoleWindow, 0)
        }
    }
    catch { }

    $global:QOptForm = New-Object System.Windows.Forms.Form
    $form = $global:QOptForm
    $form.Text = "Crestron Updater Options"
    $form.ClientSize = New-Object System.Drawing.Size(600, 558)
    $form.StartPosition = "CenterScreen"
    $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false
    $form.MinimizeBox = $true
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    function Add-Label ($text, $x, $y, $w, $h, $bold) {
        $l = New-Object System.Windows.Forms.Label
        $l.Text = $text; $l.Location = New-Object System.Drawing.Point($x, $y); $l.Size = New-Object System.Drawing.Size($w, $h)
        if ($bold) { $l.Font = New-Object System.Drawing.Font("Segoe UI", 9.5, [System.Drawing.FontStyle]::Bold) }
        $form.Controls.Add($l); $l
    }

    $title = Add-Label "Crestron Updater" 20 14 560 28 $true
    $title.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)

    $rows = @(
        @{ Key = "Updater";    Caption = "Updater";    Height = 22 },
        @{ Key = "SignIn";     Caption = "Login";      Height = 40 },
        @{ Key = "LastCheck";  Caption = "Last check"; Height = 40 },
        @{ Key = "Installers"; Caption = "Folder";     Height = 40 },
        @{ Key = "Firmware";   Caption = "Firmware";   Height = 40 }
    )
    $global:QOptValues = @{}
    $y = 54
    foreach ($row in $rows) {
        [void](Add-Label $row.Caption 20 $y 100 $row.Height $true)
        $value = Add-Label "" 125 $y 455 $row.Height $false
        $value.Name = "Status" + $row.Key
        $global:QOptValues[$row.Key] = $value
        $y += $row.Height + 4
    }

    $line = New-Object System.Windows.Forms.Label
    $line.BorderStyle = "Fixed3D"; $line.Location = New-Object System.Drawing.Point(20, 262); $line.Size = New-Object System.Drawing.Size(560, 2)
    $form.Controls.Add($line)

    function Add-Button ($name, $text, $x, $y) {
        $b = New-Object System.Windows.Forms.Button
        $b.Name = $name; $b.Text = $text
        $b.Location = New-Object System.Drawing.Point($x, $y); $b.Size = New-Object System.Drawing.Size(275, 36)
        $form.Controls.Add($b); $b
    }

    $btnCheck    = Add-Button "CheckNow"              "Check for updates now"         20  276
    $global:QOptStopResume = Add-Button "StopResume"  "Stop updater"                  305 276
    $btnPassword = Add-Button "UpdatePassword"        "Update Crestron password..."   20  320
    $btnHistory  = Add-Button "OpenHistory"           "Open run history"              305 320
    $btnFolder   = Add-Button "OpenFolder"            "Open installers folder"        20  364
    $btnRemove   = Add-Button "RemoveUpdater"         "Remove updater..."             305 408
    $btnFirmware = Add-Button "FirmwareSettings"      "Firmware settings..."          20  408
    $btnFwFolder = Add-Button "OpenFirmwareFolder"    "Open firmware folder"          305 364
    $global:QOptErrorReports = Add-Button "ToggleErrorReports" "Error reports: on (click to turn off)" 20 452
    $btnClose    = Add-Button "Close"                 "Close"                         305 452

    $note = Add-Label "Opening this window changes nothing by itself. Stopping the updater deletes nothing. Only the newest version of each program is kept; older versions are deleted when a new one arrives. Firmware is only downloaded; loading it into the devices is still done by hand." 20 496 560 44 $false
    $note.ForeColor = [System.Drawing.Color]::DimGray

    function Show-Box ($text, $buttons = "OK", $icon = "Information") {
        [System.Windows.Forms.MessageBox]::Show($global:QOptForm, $text, "Crestron Updater Options", $buttons, $icon)
    }

    function Update-OptionsStatus {
        $st = Get-OptionsStatus
        $global:QOptValues["Updater"].Text    = $st.Updater
        $global:QOptValues["SignIn"].Text     = $st.SignIn
        $global:QOptValues["LastCheck"].Text  = $st.LastCheck
        $global:QOptValues["Installers"].Text = $st.Installers
        $global:QOptValues["Firmware"].Text   = $st.Firmware
        $btnFwFolder.Enabled = (Get-FirmwareConfig).On
        $global:QOptStopResume.Text = if ($st.Stopped) { "Resume updater" } else { "Stop updater" }
        $global:QOptStopResume.Enabled = $st.TaskFound
    }

    # Every handler is wrapped so an error can never escape into Windows Forms'
    # "unhandled exception" box (a timer would repeat it every tick).
    function Invoke-Safely ($body) {
        try { & $body }
        catch {
            try { [void](Show-Box "Something went wrong and nothing further was changed.`r`n`r`n$($_.Exception.Message)" "OK" "Warning") } catch { }
        }
    }

    $global:QOptStopResume.Add_Click({ Invoke-Safely {
        $current = Get-UpdaterTask
        if (-not $current) {
            [void](Show-Box "The scheduled task '$TaskName' was not found, so there is nothing to stop or resume." "OK" "Warning")
        }
        elseif ($current.State -eq "Disabled") {
            if (Invoke-TaskChange -Quiet -Action "enable" -Change { Enable-ScheduledTask -TaskName $TaskName -ErrorAction Stop | Out-Null }) {
                [void](Show-Box "Resumed. The updater will run at the next logon or after the PC wakes from sleep.")
            }
            else { [void](Show-Box $global:QOptTaskMessage "OK" "Warning") }
        }
        else {
            $stopped = Invoke-TaskChange -Quiet -Action "disable" -Change {
                Disable-ScheduledTask -TaskName $TaskName -ErrorAction Stop | Out-Null
                Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
            }
            Stop-RunningUpdater
            if ($stopped) {
                [void](Show-Box "Stopped. It will not check for updates at logon or after sleep. Nothing was deleted.")
            }
            else {
                [void](Show-Box ("NOT fully stopped: any run in progress was ended, but its scheduled task could not be disabled, so it WILL run again at the next logon or wake.`r`n`r`n" + $global:QOptTaskMessage) "OK" "Warning")
            }
        }
        Update-OptionsStatus
    } })

    $btnCheck.Add_Click({ Invoke-Safely {
        $current = Get-UpdaterTask
        if (-not $current) {
            [void](Show-Box "The scheduled task '$TaskName' was not found, so the updater cannot be started." "OK" "Warning")
        }
        elseif ($current.State -eq "Disabled") {
            [void](Show-Box "The updater is stopped. Click 'Resume updater' first, then check for updates." "OK" "Warning")
        }
        elseif (Test-UpdaterRunning) {
            [void](Show-Box "The updater is already checking for updates right now.")
        }
        elseif (Test-Path $loginFailedFile) {
            [void](Show-Box "The updater is paused because the Crestron login did not work. Click 'Update Crestron password...' first." "OK" "Warning")
        }
        elseif (Invoke-TaskChange -Quiet -Action "start" -Change { Start-ScheduledTask -TaskName $TaskName -ErrorAction Stop }) {
            [void](Show-Box "The check has started in the background. If something new is found you will get a notice. The Last check line above shows the result when it finishes.")
        }
        else { [void](Show-Box $global:QOptTaskMessage "OK" "Warning") }
        Update-OptionsStatus
    } })

    $btnPassword.Add_Click({ Invoke-Safely {
        if (Test-Path $passwordScript) {
            & $passwordScript -StateDir $InstallDir -Gui
        }
        else {
            [void](Show-Box "The password script was not found:`r`n$passwordScript" "OK" "Warning")
        }
        Update-OptionsStatus
    } })

    $btnHistory.Add_Click({ Invoke-Safely {
        if (Test-Path $historyFile) { Start-Process -FilePath "notepad.exe" -ArgumentList "`"$historyFile`"" }
        else { [void](Show-Box "There is no run history yet.") }
    } })

    $btnFolder.Add_Click({ Invoke-Safely {
        if ($crestronFolder -and (Test-Path $crestronFolder)) { Start-Process -FilePath "explorer.exe" -ArgumentList "`"$crestronFolder`"" }
        else { [void](Show-Box "The installers folder does not exist yet:`r`n$crestronFolder") }
    } })

    $btnFwFolder.Add_Click({ Invoke-Safely {
        $fw = Get-FirmwareConfig
        if ($fw.Folder -and (Test-Path $fw.Folder)) { Start-Process -FilePath "explorer.exe" -ArgumentList "`"$($fw.Folder)`"" }
        elseif ($fw.Folder) { [void](Show-Box "The firmware folder does not exist yet (it is created when the first firmware is downloaded, or choose another one in Firmware settings...):`r`n$($fw.Folder)") }
        else { [void](Show-Box "Firmware is off. Use Firmware settings... to turn it on.") }
    } })

    $btnFirmware.Add_Click({ Invoke-Safely {

        if (-not $pickerPresent -or -not (Test-Path $catalogFile)) {
            [void](Show-Box "The firmware device list was not found in the install folder. Run Setup again to add it:`r`n$InstallDir" "OK" "Warning")
            return
        }

        $catalog = Get-FirmwareChoices -CatalogPath $catalogFile
        $now     = Get-FirmwareConfig

        $global:QFw = @{
            Devices = @($catalog.Devices)
            Keys    = @($now.Keys | Where-Object { $k = $_; @($catalog.Devices | Where-Object Key -eq $k).Count -gt 0 })
            Saved   = $false
        }

        $d = New-Object System.Windows.Forms.Form
        $d.Text = "Firmware settings"
        $d.ClientSize = New-Object System.Drawing.Size(600, 300)
        $d.StartPosition = "CenterParent"; $d.FormBorderStyle = "FixedDialog"
        $d.MaximizeBox = $false; $d.MinimizeBox = $false; $d.ShowInTaskbar = $false
        $d.Font = $global:QOptForm.Font
        $global:QFw.Form = $d

        function Add-DialogControl ($type, $name, $x, $y, $w, $h, $text) {
            $c = New-Object $type
            if ($name) { $c.Name = $name }
            $c.Location = New-Object System.Drawing.Point($x, $y); $c.Size = New-Object System.Drawing.Size($w, $h)
            if ($text) { $c.Text = $text }
            $global:QFw.Form.Controls.Add($c); $c
        }

        $global:QFw.Enable  = Add-DialogControl System.Windows.Forms.CheckBox "FwEnable" 20 18 560 26 "Keep device firmware up to date"
        $global:QFw.Enable.Checked = $now.On
        [void](Add-DialogControl System.Windows.Forms.Label $null 20 52 560 22 "Folder to save firmware in:")
        $global:QFw.Folder  = Add-DialogControl System.Windows.Forms.TextBox "FwFolderBox" 20 78 470 26 $now.Folder
        $global:QFw.Browse  = Add-DialogControl System.Windows.Forms.Button "FwBrowse" 500 76 80 30 "Browse..."
        $global:QFw.Choose  = Add-DialogControl System.Windows.Forms.Button "FwChoose" 20 118 170 32 "Choose devices..."
        $global:QFw.Summary = Add-DialogControl System.Windows.Forms.Label "FwSummary" 200 124 380 24 ""
        $global:QFw.Summary.ForeColor = [System.Drawing.Color]::DimGray
        $hint = Add-DialogControl System.Windows.Forms.Label $null 20 164 560 60 "Changes apply from the next check. Only the newest firmware of each chosen device is kept; older files of those devices are deleted when a new one arrives. Firmware is only downloaded: loading it into the devices is still done by hand."
        $hint.ForeColor = [System.Drawing.Color]::DimGray
        $save   = Add-DialogControl System.Windows.Forms.Button "FwSave" 380 250 100 34 "Save"
        $cancel = Add-DialogControl System.Windows.Forms.Button "FwCancel" 490 250 90 34 "Cancel"
        $cancel.DialogResult = "Cancel"; $d.CancelButton = $cancel

        function Update-DialogState {
            $on = $global:QFw.Enable.Checked
            $global:QFw.Folder.Enabled = $on; $global:QFw.Browse.Enabled = $on; $global:QFw.Choose.Enabled = $on
            $global:QFw.Summary.Text = Get-FirmwareSummary -Devices $global:QFw.Devices -Keys @($global:QFw.Keys)
        }

        $global:QFw.Enable.Add_CheckedChanged({ try {
            if ($global:QFw.Enable.Checked -and -not $global:QFw.Folder.Text.Trim()) {
                $global:QFw.Folder.Text = Get-DefaultFirmwareFolder $crestronFolder
            }
            Update-DialogState
        } catch { } })

        $global:QFw.Browse.Add_Click({ try {
            $b = New-Object System.Windows.Forms.FolderBrowserDialog
            $b.Description = "Choose the folder to keep device firmware in. Firmware is saved directly in it."
            $b.ShowNewFolderButton = $true
            if ($global:QFw.Folder.Text.Trim() -and (Test-Path $global:QFw.Folder.Text.Trim())) { $b.SelectedPath = $global:QFw.Folder.Text.Trim() }
            if ($b.ShowDialog($global:QFw.Form) -eq "OK") { $global:QFw.Folder.Text = $b.SelectedPath }
        } catch { } })

        $global:QFw.Choose.Add_Click({ try {
            $picked = Show-FirmwarePicker -Devices $global:QFw.Devices -Selected @($global:QFw.Keys) -Owner $global:QFw.Form
            if ($null -ne $picked) { $global:QFw.Keys = @($picked); Update-DialogState }
        } catch { } })

        $save.Add_Click({ try {

            $on     = $global:QFw.Enable.Checked
            $folder = $global:QFw.Folder.Text.Trim()
            $problem = Test-FirmwareSettings -Enabled $on -Folder $folder -Keys @($global:QFw.Keys) -Devices $global:QFw.Devices -SoftwareFolder $crestronFolder

            if ($problem) {
                [void][System.Windows.Forms.MessageBox]::Show($global:QFw.Form, $problem, "Firmware settings", "OK", "Information")
                return
            }

            if ($on -and -not (Test-Path -LiteralPath $folder)) { New-Item -ItemType Directory -Path $folder -Force | Out-Null }

            $cfg = Get-Content $configFile -Raw | ConvertFrom-Json
            $cfg | Add-Member -NotePropertyName FirmwareFolder -NotePropertyValue $(if ($on) { $folder } else { "" }) -Force
            $cfg | Add-Member -NotePropertyName FirmwareDevices -NotePropertyValue @($(if ($on) { $global:QFw.Keys } else { @() })) -Force

            $tmp = "$configFile.tmp"
            $cfg | ConvertTo-Json -Depth 8 | Set-Content -Path $tmp -Encoding UTF8
            Move-Item -LiteralPath $tmp -Destination $configFile -Force

            $global:QFw.Saved = $true
            $global:QFw.Form.DialogResult = "OK"
        } catch {
            [void][System.Windows.Forms.MessageBox]::Show($global:QFw.Form, "The settings could not be saved. Nothing was changed.`r`n`r`n$($_.Exception.Message)", "Firmware settings", "OK", "Warning")
        } })

        Update-DialogState
        [void]$d.ShowDialog($global:QOptForm)
        $d.Dispose()

        if ($global:QFw.Saved) {
            $fwNow = Get-FirmwareConfig
            [void](Show-Box $(if ($fwNow.On) { "Saved. Firmware for $($fwNow.Keys.Count) device(s) will be kept up to date in:`r`n$($fwNow.Folder)`r`n`r`nIt starts with the next check (or click Check for updates now)." } else { "Saved. Firmware downloads are off." }))
        }
        Update-OptionsStatus
    } })

    $btnRemove.Add_Click({ Invoke-Safely {
        $dialog = New-Object System.Windows.Forms.Form
        $dialog.Text = "Remove the Crestron Updater"
        $dialog.ClientSize = New-Object System.Drawing.Size(560, 250)
        $dialog.StartPosition = "CenterParent"; $dialog.FormBorderStyle = "FixedDialog"
        $dialog.MaximizeBox = $false; $dialog.MinimizeBox = $false; $dialog.ShowInTaskbar = $false
        $dialog.Font = $global:QOptForm.Font

        $info = New-Object System.Windows.Forms.Label
        $info.Location = New-Object System.Drawing.Point(20, 16); $info.Size = New-Object System.Drawing.Size(520, 170)
        $info.Text = "This removes the Crestron Updater from this PC:`r`n`r`n" +
            "  - the scheduled tasks '$TaskName' and '$noticeTaskName'`r`n" +
            "  - the Crestron Updater Options icons on the Desktop and in the Start menu`r`n" +
            "  - $InstallDir (saved Crestron login, logs, run history)`r`n`r`n" +
            "The Crestron installers in your installers folder are NOT deleted."
        $dialog.Controls.Add($info)

        $ok = New-Object System.Windows.Forms.Button
        $ok.Name = "ConfirmRemove"; $ok.Text = "Remove updater"; $ok.DialogResult = "OK"
        $ok.Location = New-Object System.Drawing.Point(250, 196); $ok.Size = New-Object System.Drawing.Size(150, 36)
        $cancel = New-Object System.Windows.Forms.Button
        $cancel.Name = "CancelRemove"; $cancel.Text = "Cancel"; $cancel.DialogResult = "Cancel"
        $cancel.Location = New-Object System.Drawing.Point(410, 196); $cancel.Size = New-Object System.Drawing.Size(130, 36)
        $dialog.Controls.AddRange(@($ok, $cancel)); $dialog.CancelButton = $cancel

        $answer = $dialog.ShowDialog($global:QOptForm)
        $dialog.Dispose()

        if ($answer -eq "OK") {

            $global:QOptTimer.Stop()

            # The removal runs in its own hidden process started outside the install
            # folder (so the folder can be deleted); its report is read back here.
            $report = Join-Path $env:TEMP ("crestron-remove-" + [guid]::NewGuid().ToString("N").Substring(0, 8) + ".txt")
            $argList = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`"", "-Uninstall", "-Yes", "-NoGui", "-InstallDir", "`"$InstallDir`"", "-TaskName", "`"$TaskName`"")

            $pwshPath = (Get-Process -Id $PID).Path
            $child = Start-Process -FilePath $pwshPath -WorkingDirectory $env:TEMP -WindowStyle Hidden -PassThru -ArgumentList $argList -RedirectStandardOutput $report

            $global:QOptForm.Text = "Crestron Updater Options - removing..."
            $global:QOptForm.Enabled = $false
            while (-not $child.HasExited) {
                [System.Windows.Forms.Application]::DoEvents()
                Start-Sleep -Milliseconds 100
            }
            $global:QOptForm.Enabled = $true

            $result = if (Test-Path $report) { (Get-Content $report -Raw) } else { "" }
            Remove-Item $report -Force -ErrorAction SilentlyContinue
            [void](Show-Box ("Removal finished.`r`n`r`n" + "$result".Trim()))
            $global:QOptForm.Close()
        }
    } })

    # Error reports on/off: saved to the settings file at once (a missing setting means on).
    # Turning them off also deletes reports still waiting to be sent.
    function Update-ErrorReportsButton {
        $on = $true
        try { if ((Get-Content $configFile -Raw | ConvertFrom-Json).ErrorReporting -eq $false) { $on = $false } } catch { }
        $global:QOptErrorReports.Text = if ($on) { "Error reports: on (click to turn off)" } else { "Error reports: off (click to turn on)" }
        $on
    }

    $global:QOptErrorReports.Visible = [bool](Get-Command Set-ErrorReporting -CommandType Function -ErrorAction SilentlyContinue)
    [void](Update-ErrorReportsButton)

    $global:QOptErrorReports.Add_Click({ Invoke-Safely {
        $on = Update-ErrorReportsButton
        if (-not (Set-ErrorReporting -ConfigPath $configFile -Enabled (-not $on))) {
            [void](Show-Box "The error reports setting could not be saved:`r`n$configFile" "OK" "Warning")
        }
        [void](Update-ErrorReportsButton)
    } })

    $btnClose.Add_Click({ $global:QOptForm.Close() })
    $form.CancelButton = $btnClose

    $global:QOptTimer = New-Object System.Windows.Forms.Timer
    $global:QOptTimer.Interval = 5000
    $global:QOptTimer.Add_Tick({ try { Update-OptionsStatus } catch { } })

    $form.Add_Shown({ try { Update-OptionsStatus } catch { }; try { $global:QOptTimer.Start() } catch { } })

    [void]$form.ShowDialog()
    $global:QOptTimer.Stop()
}

$useGui = -not $NoGui
try { if ([Console]::IsInputRedirected) { $useGui = $false } } catch { }

if ($useGui) {
    Show-OptionsWindow
    return
}


while ($true) {

    Show-Status
    Show-Menu

    $choice = Read-MenuKey

    if ($choice -eq "") {
        return
    }

    if ($choice -eq "S") {

        $current = Get-UpdaterTask

        if (-not $current) {
            Write-Host "The scheduled task '$TaskName' was not found, so there is nothing to stop."
            continue
        }

        if ($current.State -eq "Disabled") {
            Write-Host "The updater is already stopped."
            continue
        }

        $stopped = Invoke-TaskChange -Action "disable" -Change {
            Disable-ScheduledTask -TaskName $TaskName -ErrorAction Stop | Out-Null
            Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
        }

        Stop-RunningUpdater

        if ($stopped) {
            Write-Host "Stopped. It will not check for updates at logon or after sleep. Nothing was deleted."
        }
        else {
            Write-Host "NOT fully stopped: any run in progress was ended, but its scheduled task could"
            Write-Host "not be disabled, so it WILL run again at the next logon or wake."
        }

        continue
    }

    if ($choice -eq "R") {

        $current = Get-UpdaterTask

        if (-not $current) {
            Write-Host "The scheduled task '$TaskName' was not found, so there is nothing to resume."
            continue
        }

        if ($current.State -ne "Disabled") {
            Write-Host "The updater is already on."
            continue
        }

        if (Invoke-TaskChange -Action "enable" -Change { Enable-ScheduledTask -TaskName $TaskName -ErrorAction Stop | Out-Null }) {
            Write-Host "Resumed. The updater will run at the next logon or after the PC wakes from sleep."
        }

        continue
    }

    if ($choice -eq "P") {

        if (Test-Path $passwordScript) {

            Write-Host ""
            & $passwordScript -StateDir $InstallDir
        }
        else {
            Write-Host "The password script was not found: $passwordScript"
        }

        continue
    }

    if ($choice -eq "H") {

        if (Test-Path $historyFile) {
            Start-Process -FilePath "notepad.exe" -ArgumentList "`"$historyFile`""
        }
        else {
            Write-Host "There is no run history yet: $historyFile"
        }

        continue
    }

    if ($choice -eq "F" -and $crestronFolder) {

        if (Test-Path $crestronFolder) {
            Start-Process -FilePath "explorer.exe" -ArgumentList "`"$crestronFolder`""
        }
        else {
            Write-Host "That folder does not exist yet: $crestronFolder"
        }

        continue
    }

    if ($choice -eq "C") {

        $current = Get-UpdaterTask

        if (-not $current) {
            Write-Host "The scheduled task '$TaskName' was not found, so the updater cannot be started."
        }
        elseif ($current.State -eq "Disabled") {
            Write-Host "The updater is stopped. Resume it first (R), then check."
        }
        elseif (Test-UpdaterRunning) {
            Write-Host "The updater is already checking for updates right now."
        }
        elseif (Test-Path $loginFailedFile) {
            Write-Host "The updater is paused because the Crestron login did not work. Update the password first (P)."
        }
        elseif (Invoke-TaskChange -Action "start" -Change { Start-ScheduledTask -TaskName $TaskName -ErrorAction Stop }) {
            Write-Host "The check has started in the background. See the run history (H) for the result."
        }

        continue
    }

    if ($choice -eq "X") {

        # Open the removal in its own window (it asks before it removes anything),
        # then close this one.
        $pwshPath = (Get-Process -Id $PID).Path

        # (Started in the temp folder, not in the install folder, so the install
        # folder can be deleted.)
        Start-Process -FilePath $pwshPath -WorkingDirectory $env:TEMP -ArgumentList @(
            "-NoProfile",
            "-ExecutionPolicy", "Bypass",
            "-File", "`"$PSCommandPath`"",
            "-Uninstall",
            "-InstallDir", "`"$InstallDir`""
        )

        return
    }

    Write-Host "That key is not one of the choices above."
}
