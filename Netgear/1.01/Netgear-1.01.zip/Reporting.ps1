# ============================================================
# Reporting.ps1 -- master error-report module for the PowerShell updaters (functions only)
#
# Dot-source it from an updater:   . (Join-Path $PSScriptRoot "Reporting.ps1")
# Every product folder carries an identical copy (a project test fails if the copies differ).
# Needs version.json (Component, Version) and reporting.json (ReportDestination) next to it.
#
# Public functions (all take the engine's parsed $config; none ever throws, none writes output
# except the documented return value; none shows a message):
#   Get-ReportingSettings -Config                     -> @{ Enabled; Destination }
#   Send-ErrorReport -Config -Category -Message [-Step] [-ErrorRecord] [-Context] [-LogPath]
#                    [-TimeoutSeconds 10]            -> ReportId, or $null (disabled / suppressed / not written)
#   Send-ReportOutbox -Config [-TimeoutSeconds 10]    -> number delivered (disabled: clears outbox, 0)
#   Clear-ReportOutbox -Config                        -> number of files removed
#   Set-ErrorReporting -ConfigPath -Enabled           -> $true when config.json was rewritten
#   Remove-SecretText -Lines                          -> the lines that hold no secret-shaped text
#
# Rules: the report is always written to the local outbox first (<StateDir>\Reports\Outbox), then
# copied to <ReportDestination>\<COMPUTERNAME>\ as <name>.tmp and renamed. Every touch of the
# destination (it may be a hanging UNC path) runs in a separate runspace that is abandoned after
# the time budget; after one timeout in a process no further destination touch is tried.
# ASCII only; parses in PowerShell 7 and Windows PowerShell 5.1.
# ============================================================

$script:ReportingRoot = $PSScriptRoot
$script:ReportingHung = $false

# Strict pattern: LogTail lines that match are dropped.
$script:ReportingLinePattern = '(?i)(password|passwd|pwd|secret|token|cookie|credential|authorization|bearer)'
# Secret-shaped text only (word followed by : or = and a value): Message / Details / Context lines that match become [removed].
$script:ReportingValuePattern = '(?i)\b(password|passwd|pwd|secret|token|cookie|credential|authorization|bearer)\b\s*[:=]\s*\S'

function Get-ReportingProp {
    param($Object, [string]$Name)
    if ($null -eq $Object) { return $null }
    if ($Object -is [System.Collections.IDictionary]) {
        if ($Object.Contains($Name)) { return $Object[$Name] }
        return $null
    }
    $p = $Object.PSObject.Properties[$Name]
    if ($p) { return $p.Value }
    return $null
}

function Get-ReportingJsonFile {
    param([string]$Path)
    try {
        if (-not (Test-Path -LiteralPath $Path)) { return $null }
        return (Get-Content -LiteralPath $Path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop)
    } catch { return $null }
}

function Get-ReportingSettings {
    param($Config)
    $enabled = $true
    $destination = ""
    try {
        $flag = Get-ReportingProp $Config "ErrorReporting"
        if ($null -ne $flag) {
            if ($flag -is [bool]) { $enabled = $flag }
            elseif ("$flag" -match '^(?i:false|0|no|off)$') { $enabled = $false }
        }
        $dest = Get-ReportingProp $Config "ReportDestination"
        if ($dest -is [string] -and $dest.Trim() -ne "") { $destination = $dest.Trim() }
        else {
            $r = Get-ReportingJsonFile (Join-Path $script:ReportingRoot "reporting.json")
            $d = Get-ReportingProp $r "ReportDestination"
            if ($d -is [string]) { $destination = $d.Trim() }
        }
    } catch { }
    return [pscustomobject]@{ Enabled = [bool]$enabled; Destination = [string]$destination }
}

function Get-ReportingOutboxPath {
    param($Config)
    $state = Get-ReportingProp $Config "StateDir"
    if ($state -isnot [string] -or $state.Trim() -eq "") { return $null }
    return (Join-Path (Join-Path $state "Reports") "Outbox")
}

function Remove-SecretText {
    param([string[]]$Lines)
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($l in @($Lines)) {
        if ($null -eq $l) { continue }
        if ($l -match $script:ReportingLinePattern) { continue }
        $out.Add($l)
    }
    return [string[]]$out.ToArray()
}

# Message / Details / Context text: replaces each secret-shaped line with [removed].
function Protect-ReportValue {
    param($Value)
    if ($null -eq $Value) { return $null }
    if ($Value -is [string]) {
        $parts = $Value -split "\r?\n"
        $changed = $false
        for ($i = 0; $i -lt $parts.Length; $i++) {
            if ($parts[$i] -match $script:ReportingValuePattern) { $parts[$i] = "[removed]"; $changed = $true }
        }
        if ($changed) { return ($parts -join "`n") }
        return $Value
    }
    if ($Value -is [datetime]) { return $Value.ToString("yyyy-MM-ddTHH:mm:ss") }
    if ($Value -is [bool] -or $Value -is [int] -or $Value -is [long] -or $Value -is [double] -or $Value -is [decimal]) { return $Value }
    if ($Value -is [System.Collections.IDictionary]) {
        $h = [ordered]@{}
        foreach ($k in $Value.Keys) { $h["$k"] = Protect-ReportValue $Value[$k] }
        return $h
    }
    if ($Value -is [System.Collections.IEnumerable]) {
        $a = @()
        foreach ($i in $Value) { $a += , (Protect-ReportValue $i) }
        return ,$a
    }
    return (Protect-ReportValue ([string]$Value))
}

# Runs $Script in its own runspace and waits up to $TimeoutSeconds. On a timeout the runspace is left
# running (never Stop(): that can block on the same hung call) and the hang flag is set.
function Invoke-ReportingGuarded {
    param([string]$Script, [object[]]$Arguments, [int]$TimeoutSeconds)
    $ps = $null
    try {
        $ps = [powershell]::Create()
        [void]$ps.AddScript($Script)
        foreach ($a in $Arguments) { [void]$ps.AddArgument($a) }
        $async = $ps.BeginInvoke()
        $ms = [int][Math]::Max(1, $TimeoutSeconds) * 1000
        if ($async.AsyncWaitHandle.WaitOne($ms)) {
            try { [void]$ps.EndInvoke($async) } catch { }
            $ps.Dispose()
            return $true
        }
        $script:ReportingHung = $true
        return $false
    } catch {
        return $false
    }
}

# Copies local report files to <Dest>\<Machine>\ (tmp then rename) and deletes each local file on success.
# Runs inside the guarded runspace, so it is self-contained. $Counter.Delivered counts finished files.
$script:ReportingDeliverScript = @'
param($Dest, $Machine, $Files, $Counter)
if ([string]::IsNullOrWhiteSpace($Dest)) { return }
if (-not [System.IO.Directory]::Exists($Dest)) { return }
$dir = [System.IO.Path]::Combine($Dest, $Machine)
[void][System.IO.Directory]::CreateDirectory($dir)
foreach ($f in $Files) {
    $final = [System.IO.Path]::Combine($dir, [System.IO.Path]::GetFileName($f))
    $tmp = $final + ".tmp"
    try {
        [System.IO.File]::Copy($f, $tmp, $true)
        if ([System.IO.File]::Exists($final)) { [System.IO.File]::Delete($final) }
        [System.IO.File]::Move($tmp, $final)
        [System.IO.File]::Delete($f)
        $Counter.Delivered = $Counter.Delivered + 1
    } catch {
        try { if ([System.IO.File]::Exists($tmp)) { [System.IO.File]::Delete($tmp) } } catch { }
    }
}
'@

function Get-ReportingOutboxFiles {
    param([string]$Outbox)
    try {
        if (-not (Test-Path -LiteralPath $Outbox)) { return @() }
        return @(Get-ChildItem -LiteralPath $Outbox -Filter "*.json" -File -ErrorAction Stop | Sort-Object LastWriteTime, Name)
    } catch { return @() }
}

# Drops outbox files older than 30 days, then the oldest beyond 200.
function Limit-ReportOutbox {
    param([string]$Outbox)
    try {
        $files = @(Get-ReportingOutboxFiles $Outbox)
        $limit = (Get-Date).AddDays(-30)
        $keep = @()
        foreach ($f in $files) {
            if ($f.LastWriteTime -lt $limit) { Remove-Item -LiteralPath $f.FullName -Force -ErrorAction SilentlyContinue }
            else { $keep += $f }
        }
        $extra = $keep.Count - 200
        for ($i = 0; $i -lt $extra; $i++) { Remove-Item -LiteralPath $keep[$i].FullName -Force -ErrorAction SilentlyContinue }
    } catch { }
}

function Clear-ReportOutbox {
    param($Config)
    $n = 0
    try {
        $outbox = Get-ReportingOutboxPath $Config
        if (-not $outbox -or -not (Test-Path -LiteralPath $outbox)) { return 0 }
        foreach ($f in @(Get-ChildItem -LiteralPath $outbox -File -ErrorAction SilentlyContinue)) {
            try { Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop; if ($f.Extension -eq ".json") { $n++ } } catch { }
        }
    } catch { }
    return $n
}

function Send-ReportOutbox {
    param($Config, [int]$TimeoutSeconds = 10)
    try {
        $settings = Get-ReportingSettings $Config
        if (-not $settings.Enabled) { [void](Clear-ReportOutbox $Config); return 0 }
        $outbox = Get-ReportingOutboxPath $Config
        if (-not $outbox -or $script:ReportingHung -or $settings.Destination -eq "") { return 0 }
        $files = @(Get-ReportingOutboxFiles $outbox | ForEach-Object { $_.FullName })
        if ($files.Count -eq 0) { return 0 }
        $counter = [hashtable]::Synchronized(@{ Delivered = 0 })
        [void](Invoke-ReportingGuarded -Script $script:ReportingDeliverScript -Arguments @($settings.Destination, $env:COMPUTERNAME, [string[]]$files, $counter) -TimeoutSeconds $TimeoutSeconds)
        return [int]$counter.Delivered
    } catch { return 0 }
}

function Get-ReportingAVUpdaterVersion {
    try {
        $exe = Join-Path (Join-Path $env:LOCALAPPDATA "AVUpdater") "AVUpdater.exe"
        if (-not (Test-Path -LiteralPath $exe)) { return $null }
        $v = (Get-Item -LiteralPath $exe).VersionInfo.FileVersion
        if ($v -match '^(\d+)\.0\.(\d+)\.0$') { return ("{0}.{1:00}" -f [int]$Matches[1], [int]$Matches[2]) }
        return $null
    } catch { return $null }
}

function Get-ReportingLogTail {
    param([string]$Path)
    try {
        if (-not $Path -or -not (Test-Path -LiteralPath $Path)) { return @() }
        $fs = [System.IO.File]::Open($Path, 'Open', 'Read', 'ReadWrite')
        try {
            if ($fs.Length -gt 1048576) { [void]$fs.Seek(-1048576, 'End') }
            $sr = New-Object System.IO.StreamReader($fs)
            $text = $sr.ReadToEnd()
        } finally { $fs.Dispose() }
        $lines = @($text -split "\r?\n")
        if ($lines.Count -gt 0 -and $lines[$lines.Count - 1] -eq "") { $lines = @($lines[0..($lines.Count - 2)]) }
        $lines = @(Remove-SecretText -Lines ([string[]]$lines))
        if ($lines.Count -gt 50) { $lines = @($lines[($lines.Count - 50)..($lines.Count - 1)]) }
        return $lines
    } catch { return @() }
}

function Get-ReportingFloodState {
    param([string]$File)
    $h = @{}
    try {
        $o = Get-ReportingJsonFile $File
        if ($o) {
            foreach ($p in $o.PSObject.Properties) {
                $last = $p.Value.Last
                if ($last -is [datetime]) { $last = $last.ToUniversalTime() }
                else { $last = [datetime]::Parse([string]$last, [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::AdjustToUniversal -bor [System.Globalization.DateTimeStyles]::AssumeUniversal) }
                $s = 0
                if ($null -ne $p.Value.Suppressed) { $s = [int]$p.Value.Suppressed }
                $h[$p.Name] = @{ Last = $last; Suppressed = $s }
            }
        }
    } catch { }
    return $h
}

function Save-ReportingFloodState {
    param([string]$File, $State)
    try {
        $o = [ordered]@{}
        $cut = [datetime]::UtcNow.AddDays(-30)
        foreach ($k in $State.Keys) {
            if ($State[$k].Last -lt $cut -and $State[$k].Suppressed -eq 0) { continue }
            $o[$k] = [ordered]@{ Last = $State[$k].Last.ToString("yyyy-MM-ddTHH:mm:ssZ", [System.Globalization.CultureInfo]::InvariantCulture); Suppressed = [int]$State[$k].Suppressed }
        }
        $tmp = $File + ".tmp"
        [System.IO.File]::WriteAllText($tmp, (ConvertTo-Json -InputObject $o -Depth 4), (New-Object System.Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $tmp -Destination $File -Force -ErrorAction Stop
    } catch { }
}

function Get-ReportingSha1 {
    param([string]$Text)
    $sha = [System.Security.Cryptography.SHA1]::Create()
    try {
        $b = $sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Text))
        return (($b | ForEach-Object { $_.ToString("x2") }) -join "")
    } finally { $sha.Dispose() }
}

function Send-ErrorReport {
    param(
        $Config,
        [string]$Category,
        [string]$Message,
        [string]$Step,
        [System.Management.Automation.ErrorRecord]$ErrorRecord,
        [hashtable]$Context,
        [string]$LogPath,
        [int]$TimeoutSeconds = 10
    )
    try {
        $settings = Get-ReportingSettings $Config
        if (-not $settings.Enabled) { return $null }
        $outbox = Get-ReportingOutboxPath $Config
        if (-not $outbox) { return $null }

        $version = Get-ReportingJsonFile (Join-Path $script:ReportingRoot "version.json")
        $component = [string](Get-ReportingProp $version "Component")
        $componentVersion = Get-ReportingProp $version "Version"
        if ($null -ne $componentVersion) { $componentVersion = [string]$componentVersion }
        if (-not $component) { $component = "Unknown" }

        # Flood limit: same Component + Category + Message at most once per 24 h.
        $reportsDir = Split-Path -Parent $outbox
        [void][System.IO.Directory]::CreateDirectory($outbox)
        $stateFile = Join-Path $reportsDir "state.json"
        $state = Get-ReportingFloodState $stateFile
        $key = Get-ReportingSha1 ($component + "|" + $Category + "|" + $Message)
        $now = [datetime]::UtcNow
        $suppressed = 0
        if ($state.ContainsKey($key)) {
            if (($now - $state[$key].Last).TotalHours -lt 24) {
                $state[$key].Suppressed = $state[$key].Suppressed + 1
                Save-ReportingFloodState $stateFile $state
                return $null
            }
            $suppressed = $state[$key].Suppressed
        }

        if (-not $LogPath) {
            $stateDir = Get-ReportingProp $Config "StateDir"
            $LogPath = Join-Path (Join-Path $stateDir "Logs") ($component + "-Updater.log")
        }

        $details = [ordered]@{ ExceptionType = $null; Stack = $null; Step = $null; Position = $null }
        if ($Step) { $details.Step = Protect-ReportValue $Step }
        if ($ErrorRecord) {
            $details.ExceptionType = $ErrorRecord.Exception.GetType().FullName
            $details.Stack = Protect-ReportValue ([string]$ErrorRecord.ScriptStackTrace)
            $ii = $ErrorRecord.InvocationInfo
            if ($ii -and $ii.ScriptName) { $details.Position = ("{0}:{1}" -f (Split-Path -Leaf $ii.ScriptName), $ii.ScriptLineNumber) }
        }

        $dotNet = [Environment]::Version.ToString()
        try { $dotNet = [System.Runtime.InteropServices.RuntimeInformation]::FrameworkDescription } catch { }
        $inv = [System.Globalization.CultureInfo]::InvariantCulture
        $local = Get-Date
        $id = [guid]::NewGuid().ToString("N").Substring(0, 8)
        $ctx = [ordered]@{}
        if ($Context) { $ctx = Protect-ReportValue $Context }

        $report = [ordered]@{
            FormatVersion     = 1
            ReportId          = $id
            TimeUtc           = $now.ToString("yyyy-MM-ddTHH:mm:ssZ", $inv)
            TimeLocal         = $local.ToString("yyyy-MM-ddTHH:mm:sszzz", $inv)
            Component         = $component
            ComponentVersion  = $componentVersion
            AVUpdaterVersion  = (Get-ReportingAVUpdaterVersion)
            Category          = $Category
            Message           = (Protect-ReportValue $Message)
            Details           = $details
            Machine           = $env:COMPUTERNAME
            WindowsUser       = $env:USERNAME
            OSVersion         = [Environment]::OSVersion.VersionString
            PowerShellVersion = $PSVersionTable.PSVersion.ToString()
            DotNetVersion     = $dotNet
            LogTail           = [object[]]@(Get-ReportingLogTail $LogPath)
            SuppressedRepeats = [int]$suppressed
            Context           = $ctx
        }

        $user = $env:USERNAME
        foreach ($c in [System.IO.Path]::GetInvalidFileNameChars()) { $user = $user.Replace([string]$c, "-") }
        $name = "{0}_{1}_{2}_{3}_{4}.json" -f $local.ToString("yyyyMMdd-HHmmss", $inv), $component, $user, $Category, $id
        $file = Join-Path $outbox $name
        $tmp = $file + ".tmp"
        [System.IO.File]::WriteAllText($tmp, (ConvertTo-Json -InputObject $report -Depth 6), (New-Object System.Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $tmp -Destination $file -Force -ErrorAction Stop

        $state[$key] = @{ Last = $now; Suppressed = 0 }
        Save-ReportingFloodState $stateFile $state
        Limit-ReportOutbox $outbox

        if (-not $script:ReportingHung -and $settings.Destination -ne "") {
            [void](Invoke-ReportingGuarded -Script $script:ReportingDeliverScript -Arguments @($settings.Destination, $env:COMPUTERNAME, [string[]]@($file), ([hashtable]::Synchronized(@{ Delivered = 0 }))) -TimeoutSeconds $TimeoutSeconds)
        }
        return $id
    } catch { return $null }
}

function Set-ErrorReporting {
    param([string]$ConfigPath, [bool]$Enabled)
    try {
        $cfg = Get-Content -LiteralPath $ConfigPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        if ($cfg.PSObject.Properties["ErrorReporting"]) { $cfg.ErrorReporting = $Enabled }
        else { Add-Member -InputObject $cfg -NotePropertyName "ErrorReporting" -NotePropertyValue $Enabled }
        $tmp = $ConfigPath + ".tmp"
        $cfg | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $tmp -Encoding UTF8 -ErrorAction Stop
        Move-Item -LiteralPath $tmp -Destination $ConfigPath -Force -ErrorAction Stop
        if (-not $Enabled) { [void](Clear-ReportOutbox $cfg) }
        return $true
    } catch { return $false }
}
