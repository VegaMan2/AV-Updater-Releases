# ============================================================
# Netgear Updater (firmware only)
#
# Keeps the newest Netgear AV Line (M4250, M4350) switch firmware in the destination folder.
# Plain HTTPS, anonymous: no sign-in, no browser. The switch list lives ONLY in
# firmware-catalog.json (next to this script); nothing here names a model.
#
# For each enabled catalog group the updater asks Netgear's support page for the
# slug's downloads, takes the one Firmware entry marked LatestVersion (and matching the
# group's titleMatch), downloads the zip, extracts the firmware image (*.stk) into
#   <Destination>\Firmware\<group folder>\
# writes version.txt and Models.txt next to it, then deletes the image(s) it put
# there earlier. Files the updater did not create are never touched.
#
# All settings come from config.json (written by Install-NetgearUpdater.ps1).
# Dot-sourcing this file only defines the functions (that is how the tests use it).
# Needs PowerShell 7.
# ============================================================

param (
    [string]$ConfigPath = (Join-Path $PSScriptRoot "config.json"),

    # Look only: ask Netgear, compare, report what would be downloaded. Changes nothing.
    [switch]$CheckOnly,
    [switch]$WhatIf
)

$ErrorActionPreference = "Stop"

# Error reports (Reporting.ps1 next to this script; never passwords). A missing or damaged
# module never changes a run: the two functions the run calls then do nothing.
$reportingScript = Join-Path $PSScriptRoot "Reporting.ps1"
if (Test-Path -LiteralPath $reportingScript) { try { . $reportingScript } catch { } }
if (-not (Get-Command Send-ErrorReport -CommandType Function -ErrorAction SilentlyContinue) -or
    -not (Get-Command Send-ReportOutbox -CommandType Function -ErrorAction SilentlyContinue)) {
    function Send-ErrorReport { $null }
    function Send-ReportOutbox { 0 }
}

$script:BrowserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
$script:RetryDelaySeconds = 5


# ------------------------------------------------------------
# Catalog and versions (pure functions)
# ------------------------------------------------------------

. (Join-Path $PSScriptRoot "Netgear-Catalog.ps1")   # Get-NetgearCatalog: the one loader shared with Setup and Options

function Start-DownloadStatus {
    $statusPath = $null
    try {
        $state = $script:config.StateDir
        if ($state -and (Test-Path -LiteralPath $state)) {
            $statusPath = Join-Path $state 'download-status.json'
            $process = [Diagnostics.Process]::GetCurrentProcess()
            $json = @{ Pid = $PID; StartTicks = $process.StartTime.ToUniversalTime().Ticks.ToString(); Status = 'Downloading' } | ConvertTo-Json -Compress
            [IO.File]::WriteAllText($statusPath, $json)
        }
    } catch { $statusPath = $null }
    return $statusPath
}

function Invoke-TrackedDownload {
    param([scriptblock]$Transfer)
    $statusPath = Start-DownloadStatus
    try { & $Transfer }
    finally { if ($statusPath) { try { [IO.File]::Delete($statusPath) } catch { } } }
}

function ConvertTo-VersionParts {
    param ([string]$Text)
    if ($Text -notmatch '^\d+(\.\d+)*$') { return $null }
    , @($Text -split '\.' | ForEach-Object { [int]$_ })
}

function Compare-VersionParts {
    param ($A, $B)
    $len = [math]::Max(@($A).Count, @($B).Count)
    for ($i = 0; $i -lt $len; $i++) {
        $x = if ($i -lt @($A).Count) { $A[$i] } else { 0 }
        $y = if ($i -lt @($B).Count) { $B[$i] } else { 0 }
        if ($x -lt $y) { return -1 }
        if ($x -gt $y) { return 1 }
    }
    0
}

# Version number out of a title such as "Firmware Version 13.0.6.8 for M4250 ...". $null when there is none.
function Get-TitleVersion {
    param ([string]$Title)
    $m = [regex]::Match($Title, 'Version\s+([\d.]+)')
    if (-not $m.Success) { return $null }
    $text = $m.Groups[1].Value.TrimEnd('.')
    if (-not (ConvertTo-VersionParts $text)) { return $null }
    $text
}

# Parses the API answer (returnValue is a JSON string inside JSON: parse twice).
# Returns the inner object; throws a plain message when the shape is not what we expect.
function ConvertFrom-NetgearResponse {
    param ([string]$Content)
    $outer = $Content | ConvertFrom-Json
    if (-not $outer -or -not $outer.returnValue) { throw "The Netgear answer has no returnValue." }
    $inner = if ($outer.returnValue -is [string]) { $outer.returnValue | ConvertFrom-Json } else { $outer.returnValue }
    if (-not $inner.meta -or [int]$inner.meta.code -ne 200) {
        $code = if ($inner.meta) { $inner.meta.code } else { "none" }
        throw "The Netgear answer reported code $code."
    }
    $inner
}

# The one latest Firmware entry for a group. Throws when there are none or several (fail closed).
function Select-GroupFirmware {
    param ($Group, $Inner)
    $match = [string]$Group.titleMatch
    $hits = @($Inner.Downloads | Where-Object {
        $_.DownloadType -eq "Firmware" -and $_.LatestVersion -eq $true -and ((-not $match) -or ([string]$_.Title).Contains($match))
    })
    if ($hits.Count -eq 0) { throw "No latest firmware entry for '$($Group.folder)' was found." }
    if ($hits.Count -gt 1) { throw "More than one latest firmware entry matched '$($Group.folder)' ($($hits.Count)); not guessing." }
    $v = Get-TitleVersion $hits[0].Title
    if (-not $v) { throw "The firmware title '$($hits[0].Title)' has no version number." }
    [pscustomobject]@{ Title = [string]$hits[0].Title; Url = ([string]$hits[0].DownloadURL).Trim(); Version = $v; Parts = (ConvertTo-VersionParts $v) }
}


# ------------------------------------------------------------
# Network
# ------------------------------------------------------------

function Test-TcpPort {
    param ([string]$HostName, [int]$Port = 443, [int]$TimeoutMs = 4000)
    $c = New-Object System.Net.Sockets.TcpClient
    try {
        $t = $c.ConnectAsync($HostName, $Port)
        if ($t.Wait($TimeoutMs) -and $c.Connected) { return $true }
        return $false
    }
    catch { return $false }
    finally { $c.Dispose() }
}

function Wait-ForNetwork {
    param ([string]$HostName, [int]$Port = 443, [int]$MaxSeconds = 180, [int]$PollSeconds = 10)
    $waited = 0
    while ($true) {
        if (Test-TcpPort -HostName $HostName -Port $Port) { return $true }
        if ($waited -ge $MaxSeconds) { return $false }
        if ($waited -eq 0) { Write-Host "Waiting for the network (up to $MaxSeconds seconds)..." }
        Start-Sleep -Seconds $PollSeconds
        $waited += $PollSeconds
    }
}

# HTTP status of a failed web call, or $null for a connection-level failure.
function Get-ErrorStatus {
    param ($ErrorRecord)
    try { $r = $ErrorRecord.Exception.Response; if ($r) { return [int]$r.StatusCode } } catch { }
    $null
}

# Retries connection drops (reset, SSL, timeout, DNS): 3 tries, 5 s then 10 s. Any HTTP answer is thrown at once.
function Invoke-WebRetry {
    param ([scriptblock]$Call, [int]$Tries = 3, [int]$BaseDelaySeconds = $script:RetryDelaySeconds)
    for ($i = 1; $i -le $Tries; $i++) {
        try { return & $Call }
        catch {
            if ((Get-ErrorStatus $_) -or $i -eq $Tries) { throw }
            Write-Host "Connection problem ($($_.Exception.Message)). Retrying ($i of $($Tries - 1))..."
            Start-Sleep -Seconds ($BaseDelaySeconds * $i)
        }
    }
}

# True for "no internet / site down" (connection-level failure or HTTP 5xx), false for a real answer such as 404.
function Test-IsOffline {
    param ($ErrorRecord)
    $status = Get-ErrorStatus $ErrorRecord
    if ($status) { return ($status -ge 500) }
    $true
}

function Get-ApiUrl {
    param ($Catalog)
    $Catalog.source.endpoint
}

# Inner API object for one slug.
function Get-SlugData {
    param ($Catalog, [string]$Slug)
    $body = [ordered]@{
        namespace = ""; classname = $Catalog.source.classname; method = $Catalog.source.method; isContinuation = $false
        params = [ordered]@{ productName = $Slug; selectedLanguage = "en_US" }; cacheable = $false
    } | ConvertTo-Json -Depth 5 -Compress
    $url = Get-ApiUrl $Catalog
    $resp = Invoke-WebRetry { Invoke-WebRequest -Uri $url -Method Post -Body $body -ContentType "application/json" -UserAgent $script:BrowserAgent -UseBasicParsing -TimeoutSec 60 }
    ConvertFrom-NetgearResponse $resp.Content
}

# Size of the remote file from HEAD, or $null for a dead link (4xx).
function Get-RemoteLength {
    param ([string]$Url)
    try {
        $r = Invoke-WebRetry { Invoke-WebRequest -Uri $Url -Method Head -UserAgent $script:BrowserAgent -UseBasicParsing -TimeoutSec 60 }
        $len = $r.Headers['Content-Length'] | Select-Object -First 1
        if (-not $len) { return $null }
        [int64]$len
    }
    catch {
        $s = Get-ErrorStatus $_
        if ($s -and $s -ge 400 -and $s -lt 500) { return $null }
        throw
    }
}

# Streams the file to disk. The whole download is retried when the connection drops part way.
function Get-RemoteFile {
    param ([string]$Url, [string]$Destination)
    Invoke-WebRetry {
        $client = New-Object System.Net.Http.HttpClient
        $client.Timeout = [System.Threading.Timeout]::InfiniteTimeSpan
        $client.DefaultRequestHeaders.UserAgent.ParseAdd($script:BrowserAgent)
        try {
            $response = $client.GetAsync($Url, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
            $response.EnsureSuccessStatusCode() | Out-Null
            $in = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
            $out = [System.IO.File]::Create($Destination)
            try { $in.CopyTo($out, 1MB) } finally { $out.Dispose(); $in.Dispose() }
        }
        finally { $client.Dispose() }
    } | Out-Null
}

function Test-DownloadedZip {
    param ([string]$Path, [int64]$ExpectedSize)
    if (-not (Test-Path -LiteralPath $Path)) { throw "The download did not create a file." }
    $size = (Get-Item -LiteralPath $Path).Length
    if ($size -le 0) { throw "The downloaded file is empty." }
    if ($ExpectedSize -gt 0 -and $size -ne $ExpectedSize) { throw "The download was cut off or incomplete ($size bytes received, $ExpectedSize expected)." }
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
        $z = [System.IO.Compression.ZipFile]::OpenRead($Path)
        $z.Dispose()
    }
    catch { throw "The downloaded file is not a valid zip (it may be an error page)." }
}


# ------------------------------------------------------------
# One group
# ------------------------------------------------------------

function Get-LocalGroupState {
    param ([string]$Folder, [string]$Image, $SavedState)
    $images = @()
    if (Test-Path -LiteralPath $Folder) { $images = @(Get-ChildItem -LiteralPath $Folder -File -Filter $Image -ErrorAction SilentlyContinue) }
    $version = $null
    $vf = Join-Path $Folder "version.txt"
    if (Test-Path -LiteralPath $vf) { $version = ([System.IO.File]::ReadAllText($vf)).Trim() }
    elseif ($SavedState -and $SavedState.Version) { $version = [string]$SavedState.Version }
    [pscustomobject]@{ Images = $images; Version = $version; Parts = $(if ($version) { ConvertTo-VersionParts $version } else { $null }) }
}

function Write-ModelsFile {
    param ($Group, [string]$Folder, [string]$Version)
    $lines = @("$($Group.folder)", "Firmware version $Version", "Written by Netgear Updater. Do not edit.", "", ("{0,-22} {1,-12} {2}" -f "Model", "Code", "Ports"))
    foreach ($m in @($Group.models)) { $lines += ("{0,-22} {1,-12} {2}" -f $m.model, $m.code, $m.ports) }
    [System.IO.File]::WriteAllText((Join-Path $Folder "Models.txt"), (($lines -join "`r`n") + "`r`n"))
}

# Status: Current, Updated, WouldUpdate, Failed, NotFound (API shape problem: fail closed), Offline.
function Update-Group {
    param ($Group, $Inner, [string]$FirmwareFolder, [string]$TempFolder, $SavedState, [switch]$LookOnly)

    $result = [pscustomobject]@{
        Key = $Group.key; Name = $Group.folder; Kind = "Firmware"; Status = "Failed"; Detail = ""
        Previous = $null; New = $null; FilePath = $null; Removed = @(); Archived = @(); Files = @()
    }
    $zip = $null
    $stage = $null

    try {
        $image = if ($Group.image) { [string]$Group.image } else { "*.stk" }

        try { $fw = Select-GroupFirmware -Group $Group -Inner $Inner }
        catch { $result.Status = "NotFound"; throw }

        $folder = Join-Path $FirmwareFolder $Group.folder
        $local = Get-LocalGroupState -Folder $folder -Image $image -SavedState $SavedState
        $result.Previous = $local.Version

        $needs = ($local.Images.Count -eq 0) -or (-not $local.Parts) -or ((Compare-VersionParts $local.Parts $fw.Parts) -lt 0)
        if (-not $needs) {
            $result.Status = "Current"; $result.Detail = "$($local.Version) is the newest."
            return $result
        }

        if ($LookOnly) {
            $result.Status = "WouldUpdate"; $result.New = $fw.Version
            $result.Detail = "$(if ($local.Version) { "$($local.Version) -> " })$($fw.Version) would be downloaded."
            return $result
        }

        $length = Get-RemoteLength -Url $fw.Url
        if ($null -eq $length) { throw "The download link for $($Group.folder) does not work." }

        $root = [System.IO.Path]::GetPathRoot((Resolve-Path -LiteralPath $TempFolder).Path)
        $free = (New-Object System.IO.DriveInfo $root).AvailableFreeSpace
        if ($free -lt ($length * 3 + 50MB)) { throw "Not enough free disk space on $root ($([math]::Round($free / 1MB)) MB free)." }

        $zip = Join-Path $TempFolder ("{0}-{1}.zip" -f $Group.key, $fw.Version)
        Write-Host "  Downloading $($fw.Title) ($([math]::Round($length / 1MB, 1)) MB)..."
        Invoke-TrackedDownload { Get-RemoteFile -Url $fw.Url -Destination $zip }
        Test-DownloadedZip -Path $zip -ExpectedSize $length

        # Extract only the firmware image(s), flat, into a staging folder.
        $stage = Join-Path $TempFolder ("stage-" + $Group.key)
        New-Item -ItemType Directory -Path $stage -Force | Out-Null
        Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
        $za = [System.IO.Compression.ZipFile]::OpenRead($zip)
        try {
            foreach ($e in $za.Entries) {
                if (-not $e.Name) { continue }
                if ($e.Name -notlike $image) { continue }
                [System.IO.Compression.ZipFileExtensions]::ExtractToFile($e, (Join-Path $stage $e.Name), $true)
            }
        }
        finally { $za.Dispose() }
        $staged = @(Get-ChildItem -LiteralPath $stage -File)
        if ($staged.Count -eq 0) { throw "The zip for $($Group.folder) holds no firmware image ($image)." }

        # Install: new image(s) in, then the previous image(s) THIS updater created go.
        New-Item -ItemType Directory -Path $folder -Force | Out-Null
        $newNames = @()
        foreach ($f in $staged) { Move-Item -LiteralPath $f.FullName -Destination (Join-Path $folder $f.Name) -Force; $newNames += $f.Name }
        [System.IO.File]::WriteAllText((Join-Path $folder "version.txt"), $fw.Version + "`r`n")
        Write-ModelsFile -Group $Group -Folder $folder -Version $fw.Version

        $removed = @()
        $prior = @()
        if ($SavedState -and $SavedState.Files) { $prior = @($SavedState.Files) }
        elseif ($local.Version) { $prior = @($local.Images | ForEach-Object { $_.Name }) }   # version.txt proves the folder is ours
        foreach ($name in $prior) {
            if ($name -in $newNames) { continue }
            $p = Join-Path $folder $name
            if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force; $removed += $name }
        }

        $result.Status = "Updated"; $result.New = $fw.Version
        $result.FilePath = Join-Path $folder $newNames[0]
        $result.Files = $newNames; $result.Removed = $removed
        $result.Detail = "$(if ($local.Version) { "$($local.Version) -> " })$($fw.Version)"
    }
    catch {
        if ($result.Status -ne "NotFound") { $result.Status = "Failed" }
        $result.Detail = $_.Exception.Message
    }
    finally {
        if ($zip) { Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue }
        if ($stage) { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue }
    }
    $result
}


# ------------------------------------------------------------
# Notices, history, journal, state
# ------------------------------------------------------------

function Start-PendingNotice {
    $state = $script:config.StateDir
    if (-not ((Test-Path (Join-Path $state "pending-notice.json")) -or (Test-Path (Join-Path $state "pending-error.json")))) { return }
    $noticeTask = if ($script:config.NoticeTaskName) { $script:config.NoticeTaskName } else { "Netgear Updater Notice" }
    try {
        if (Get-ScheduledTask -TaskName $noticeTask -ErrorAction SilentlyContinue) { Start-ScheduledTask -TaskName $noticeTask; return }
    }
    catch { }
    if (-not (Test-Path (Join-Path $state "Show-NetgearNotice.ps1"))) { return }
    Start-Process -FilePath (Get-Process -Id $PID).Path -WindowStyle Hidden -ArgumentList @(
        "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", (Join-Path $state "Show-NetgearNotice.ps1"))
}

function Write-RunHistory {
    param ([string]$Outcome = $script:runOutcome, [string]$Detail = $script:runDetail)
    if ($script:runHistoryWritten) { return }
    $script:runHistoryWritten = $true
    if ($script:LookOnly) { return }
    if (-not $Outcome) { $Outcome = "UNKNOWN"; $Detail = "The run ended without recording a result. See Netgear-Updater.log." }
    $took = (Get-Date) - $script:runStarted
    $tookText = if ($took.TotalMinutes -ge 1) { "{0}m {1}s" -f [int][math]::Floor($took.TotalMinutes), $took.Seconds } else { "{0}s" -f [int][math]::Round($took.TotalSeconds) }
    $line = "{0}  {1,-10} {2} (took {3})" -f $script:runStarted.ToString("yyyy-MM-dd HH:mm:ss"), $Outcome, (($Detail -replace '\s+', ' ').Trim()), $tookText
    try {
        $historyFile = Join-Path (Join-Path $script:config.StateDir "Logs") "Run-History.log"
        New-Item -ItemType Directory -Path (Split-Path $historyFile) -Force | Out-Null
        if ((Test-Path $historyFile) -and (Get-Item $historyFile).Length -gt 1MB) { Move-Item $historyFile ($historyFile + ".old") -Force }
        Add-Content -Path $historyFile -Value $line -Encoding UTF8
    }
    catch { }
}

# Error notice. The same error again within $RepeatHours is logged but not shown again.
function New-ErrorNotice {
    param ([string]$Step, [string]$Message, [string]$SeenName = "last-error-notice.json", [int]$RepeatHours = 24)
    $state = $script:config.StateDir
    $seenFile = Join-Path $state $SeenName
    $signature = "$Step|$Message"
    try {
        if (Test-Path $seenFile) {
            $seen = Get-Content $seenFile -Raw | ConvertFrom-Json
            if ($seen.Signature -eq $signature -and ((Get-Date) - [datetime]$seen.Time).TotalHours -lt $RepeatHours) {
                return "not repeated: same error within $RepeatHours hours"
            }
        }
        [ordered]@{
            Time = $script:runStarted.ToString("o"); Step = $Step; Message = $Message
            HistoryFile = (Join-Path (Join-Path $state "Logs") "Run-History.log")
            LogFile = (Join-Path (Join-Path $state "Logs") "Netgear-Updater.log")
        } | ConvertTo-Json | Set-Content -Path (Join-Path $state "pending-error.json")
        [ordered]@{ Signature = $signature; Time = (Get-Date).ToString("o") } | ConvertTo-Json | Set-Content -Path $seenFile
        "shown to the user"
    }
    catch { "could not be created" }
}

function Add-UpdateNotice {
    param ($Updated)
    $file = Join-Path $script:config.StateDir "pending-notice.json"
    $items = @()
    if (Test-Path $file) { try { $items = @((Get-Content $file -Raw | ConvertFrom-Json).Items) } catch { } }
    foreach ($u in $Updated) {
        $items = @($items | Where-Object { $_.Key -ne $u.Key })
        $items += [ordered]@{ Key = $u.Key; Kind = $u.Kind; Name = $u.Name; Version = $u.New; PreviousVersion = $u.Previous; FilePath = $u.FilePath }
    }
    [ordered]@{ Folder = $script:config.NetgearFolder; FirmwareFolder = $script:firmwareFolder; Items = $items } | ConvertTo-Json -Depth 4 | Set-Content -Path $file
}

function Write-Journal {
    param ($Results)
    try {
        $folder = Join-Path $script:config.StateDir "Journal"
        New-Item -ItemType Directory -Path $folder -Force | Out-Null
        $updates = @($Results | Where-Object { $_.Status -eq "Updated" })
        if ($updates.Count -eq 0) { return }
        [ordered]@{
            Time = $script:runStarted.ToString("o")
            Updates = @($updates | ForEach-Object {
                [ordered]@{ Kind = $_.Kind; Key = $_.Key; Product = $_.Name; Added = $_.FilePath; Archived = @(); Removed = @($_.Removed) }
            })
        } | ConvertTo-Json -Depth 5 | Set-Content -Path (Join-Path $folder ($script:runStarted.ToString("yyyyMMdd-HHmmss") + ".json"))
    }
    catch { }
}

function Read-UpdaterState {
    param ([string]$StateDir)
    $f = Join-Path $StateDir "state.json"
    if (Test-Path -LiteralPath $f) { try { return (Get-Content -LiteralPath $f -Raw | ConvertFrom-Json) } catch { } }
    $null
}

function Save-UpdaterState {
    param ([string]$StateDir, $Old, $Results)
    $groups = [ordered]@{}
    if ($Old -and $Old.Groups) { foreach ($p in $Old.Groups.PSObject.Properties) { $groups[$p.Name] = $p.Value } }
    foreach ($r in $Results) {
        if ($r.Status -eq "Updated") {
            $groups[$r.Key] = [ordered]@{ Version = $r.New; Files = @($r.Files); Time = (Get-Date).ToString("o") }
        }
    }
    [ordered]@{ Groups = $groups } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $StateDir "state.json")
}


# ------------------------------------------------------------
# Main run
# ------------------------------------------------------------

# Dot-sourced (by the tests): functions only.
if ($MyInvocation.InvocationName -eq '.') { return }

$script:LookOnly     = [bool]($CheckOnly -or $WhatIf)
$script:runStarted   = Get-Date
$script:runOutcome   = $null
$script:runDetail    = $null
$script:runHistoryWritten = $false
$tempFolder = $null
$mutex = $null
$mutexAcquired = $false

if (Test-Path -LiteralPath $ConfigPath) {
    $script:config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
}
elseif ($script:LookOnly) {
    $base = Join-Path $env:TEMP "NetgearUpdaterCheck"
    $script:config = [pscustomobject]@{ NetgearFolder = (Join-Path $base "Netgear"); StateDir = (Join-Path $base "State") }
}
else { throw "config.json not found at $ConfigPath. Run Setup first." }

if ($script:config.RetryDelaySeconds -ne $null) { $script:RetryDelaySeconds = [int]$script:config.RetryDelaySeconds }

$stateDir   = $script:config.StateDir
$logFolder  = Join-Path $stateDir "Logs"
$tempFolder = Join-Path $stateDir "Temp"

New-Item -ItemType Directory -Path $logFolder -Force | Out-Null
Start-Transcript -Path (Join-Path $logFolder "Netgear-Updater.log") -Append | Out-Null

Write-Host ""
Write-Host "============================================================"
Write-Host "Netgear updater started: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')$(if ($script:LookOnly) { ' (check only, nothing is changed)' })"
Write-Host "============================================================"

if (-not $script:LookOnly) {
    $mutex = New-Object System.Threading.Mutex($false, "Global\AVSoftwareUpdater-NETGEAR")
    try { $mutexAcquired = $mutex.WaitOne(0, $false) }
    catch [System.Threading.AbandonedMutexException] { $mutexAcquired = $true }

    if (-not $mutexAcquired) {
        Write-Host "Netgear updater is already running. This instance will exit."
        $script:runOutcome = "SKIPPED"
        $script:runDetail  = "Another update check was already running."
        Write-RunHistory
        try { Stop-Transcript | Out-Null } catch { }
        exit 0
    }
}

$step = "preparing the update check"
$results = @()

try {
    if (-not $script:LookOnly) { try { Start-PendingNotice } catch { } }

    # Error reports that could not be sent earlier (share offline) are sent now.
    if (-not $script:LookOnly) { try { [void](Send-ReportOutbox -Config $script:config) } catch { } }

    # --- Blocked Wi-Fi (phone hotspots) ---
    if ($true) {
        $wifiInfo = netsh wlan show interfaces | Out-String
        $ssid = if ($wifiInfo -match '(?m)^\s*SSID\s*:\s*(.+)$') { $Matches[1].Trim() } else { $null }
        if ($ssid -and $ssid -in @($script:config.BlockedSSIDs)) {
            Write-Host "Connected to blocked Wi-Fi: $ssid. Update check skipped."
            $script:runOutcome = "SKIPPED"
            $script:runDetail  = "Connected to blocked Wi-Fi network '$ssid'."
            return
        }
    }

    # CatalogPath is TESTS ONLY (Setup never writes it): the real catalog is always firmware-catalog.json next to this script.
    $catalogPath = if ($script:config.CatalogPath) { $script:config.CatalogPath } else { Join-Path $PSScriptRoot "firmware-catalog.json" }
    $catalog = Get-NetgearCatalog -Path $catalogPath

    $destination = $script:config.NetgearFolder
    $script:firmwareFolder = if ($script:config.FirmwareFolder) { $script:config.FirmwareFolder } else { Join-Path $destination "Firmware" }

    if (Test-Path $tempFolder) { Remove-Item $tempFolder -Recurse -Force -ErrorAction SilentlyContinue }
    New-Item -ItemType Directory -Path $tempFolder -Force | Out-Null

    # --- Wait for the network (quiet SKIPPED when it never comes) ---
    $step = "waiting for the network"
    $waitSeconds = if ($script:config.NetworkWaitSeconds -ne $null) { [int]$script:config.NetworkWaitSeconds } else { 180 }
    $hosts = @()
    if ($script:config.NetworkHosts) {
        # Tests only: "host:port" entries replace the Netgear hosts (for example an unreachable name).
        foreach ($e in @($script:config.NetworkHosts)) { $parts = ([string]$e) -split ':'; $hosts += , @($parts[0], [int]$parts[1]) }
    }
    else { foreach ($h in @($catalog.source.hosts)) { $hosts += , @([string]$h, 443) } }

    foreach ($h in $hosts) {
        if (-not (Wait-ForNetwork -HostName $h[0] -Port $h[1] -MaxSeconds $waitSeconds)) {
            Write-Host "Offline: cannot reach $($h[0]). Will retry next run."
            $script:runOutcome = "SKIPPED"
            $script:runDetail  = "Offline (cannot reach $($h[0])); will retry next run."
            return
        }
    }

    # --- Which groups ---
    $enabled = if ($script:config.EnabledProducts) { @($script:config.EnabledProducts) } else { @($catalog.groups | ForEach-Object { $_.key }) }
    $groups = @($catalog.groups | Where-Object { $_.key -in $enabled })
    $saved = Read-UpdaterState -StateDir $stateDir

    # --- One API call per distinct slug ---
    $slugData = @{}
    $apiProblems = @()
    foreach ($slug in @($groups | ForEach-Object { $_.slug } | Select-Object -Unique)) {
        $step = "asking Netgear for the $slug downloads"
        Write-Host "Netgear $slug..."
        try { $slugData[$slug] = Get-SlugData -Catalog $catalog -Slug $slug }
        catch {
            if (Test-IsOffline $_) {
                Write-Host "Could not reach Netgear: $($_.Exception.Message)"
                $script:runOutcome = "SKIPPED"
                $script:runDetail  = "Could not reach Netgear (no internet, or the site is down): $($_.Exception.Message)"
                return
            }
            Write-Host "API problem for $slug`: $($_.Exception.Message)"
            $apiProblems += "$slug`: $($_.Exception.Message)"
        }
    }

    # --- Each group ---
    foreach ($g in $groups) {
        $step = "checking $($g.folder)"
        Write-Host "$($g.folder)..."
        if (-not $slugData.ContainsKey($g.slug)) {
            $results += [pscustomobject]@{ Key = $g.key; Name = $g.folder; Kind = "Firmware"; Status = "NotFound"; Detail = "Netgear's answer could not be used."; Previous = $null; New = $null; FilePath = $null; Removed = @(); Archived = @(); Files = @() }
            continue
        }
        $savedGroup = if ($saved -and $saved.Groups) { $saved.Groups.PSObject.Properties[$g.key].Value } else { $null }
        $r = Update-Group -Group $g -Inner $slugData[$g.slug] -FirmwareFolder $script:firmwareFolder -TempFolder $tempFolder -SavedState $savedGroup -LookOnly:$script:LookOnly
        Write-Host "  $($r.Status): $($r.Detail)"
        $results += $r
    }

    $updated = @($results | Where-Object { $_.Status -eq "Updated" })
    $failed  = @($results | Where-Object { $_.Status -eq "Failed" })
    $shape   = @($results | Where-Object { $_.Status -eq "NotFound" })

    if (-not $script:LookOnly) {
        Write-Journal $results
        Save-UpdaterState -StateDir $stateDir -Old $saved -Results $results
        if ($updated.Count -gt 0) { try { Add-UpdateNotice $updated; Start-PendingNotice } catch { } }
    }

    $summary = ($results | ForEach-Object { "$($_.Name): $($_.Status.ToLower())$(if ($_.Status -ne 'Current') { " ($($_.Detail))" })" }) -join "; "
    $noteText = ""

    if (-not $script:LookOnly) {
        if ($shape.Count -gt 0 -or $apiProblems.Count -gt 0) {
            $msg = "Netgear changed its page API, rediscovery needed (Discovery\Tools\netgear-probe.ps1). Firmware checks were skipped for: " + (($shape | ForEach-Object { $_.Name }) -join ", ")
            $note = New-ErrorNotice -Step "reading Netgear" -Message $msg -SeenName "last-api-notice.json" -RepeatHours 168
            $noteText = " [api notice $note]"
            try { Start-PendingNotice } catch { }

            try { [void](Send-ErrorReport -Config $script:config -Category SourceChanged -Message $msg -Step "reading Netgear" -Context @{ Groups = @($shape | ForEach-Object { $_.Key }); ApiProblems = @($apiProblems); Notice = $note }) } catch { }
        }
        if ($failed.Count -gt 0) {
            $note = New-ErrorNotice -Step "updating" -Message (($failed | ForEach-Object { "$($_.Name): $($_.Detail)" }) -join "`n")
            $noteText += " [error notice $note]"
            try { Start-PendingNotice } catch { }

            try { [void](Send-ErrorReport -Config $script:config -Category DownloadFailed -Message (($failed | ForEach-Object { "$($_.Name): $($_.Detail)" }) -join "`n") -Step "updating" -Context @{ Groups = @($failed | ForEach-Object { $_.Key }); Notice = $note }) } catch { }
        }
    }

    if ($failed.Count -gt 0 -or $shape.Count -gt 0) {
        $script:runOutcome = "FAILED"
        $script:runDetail  = "$summary$noteText"
    }
    elseif ($updated.Count -gt 0) {
        $script:runOutcome = "UPDATED"
        $script:runDetail  = $summary
    }
    elseif (@($results | Where-Object { $_.Status -eq "WouldUpdate" }).Count -gt 0) {
        $script:runOutcome = "WOULDUPDATE"
        $script:runDetail  = $summary
    }
    else {
        $script:runOutcome = "CURRENT"
        $script:runDetail  = "All enabled Netgear firmware is up to date."
    }
}
catch {
    $failureRecord = $_
    $message = $_.Exception.Message
    Write-Host "ERROR while $step`: $message"
    Write-Host $_.ScriptStackTrace
    $noteNote = "none"
    if (-not $script:LookOnly) {
        $noteNote = New-ErrorNotice -Step $step -Message $message; try { Start-PendingNotice } catch { }
        try { [void](Send-ErrorReport -Config $script:config -Category RunFailed -Message $message -Step $step -ErrorRecord $failureRecord -Context @{ Notice = $noteNote }) } catch { }
    }
    $script:runOutcome = "FAILED"
    $script:runDetail  = "Failed while $step`: $message [error notice $noteNote]"
}
finally {
    if ($tempFolder) { Remove-Item $tempFolder -Recurse -Force -ErrorAction SilentlyContinue }
    Write-RunHistory
    if ($script:LookOnly) { Write-Host "Result: $($script:runOutcome) - $($script:runDetail)" }
    if ($mutex -and $mutexAcquired) { try { $mutex.ReleaseMutex() } catch { } }
    try { Stop-Transcript | Out-Null } catch { }
}
