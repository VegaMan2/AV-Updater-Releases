# Netgear-Catalog.ps1 -- the ONE loader for firmware-catalog.json.
# Dot-sourced by Netgear-Updater.ps1, Install-NetgearUpdater.ps1 and Options-NetgearUpdater.ps1, so all three
# read and check the catalog the same way. Windows PowerShell 5.1 compatible (Setup runs on it).

function Get-NetgearCatalog {
    param ([string]$Path = (Join-Path $PSScriptRoot "firmware-catalog.json"))
    if (-not (Test-Path -LiteralPath $Path)) { throw "firmware-catalog.json is missing (looked for $Path). Copy it next to the Netgear Updater scripts." }
    try { $catalog = Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json }
    catch { throw "firmware-catalog.json cannot be read as JSON: $($_.Exception.Message)" }
    if (-not $catalog.source -or -not $catalog.source.endpoint -or -not $catalog.source.pageUrl -or -not $catalog.source.hosts) { throw "firmware-catalog.json has no complete 'source' section (endpoint, pageUrl, hosts)." }
    if (@($catalog.groups).Count -eq 0) { throw "firmware-catalog.json has no firmware groups." }
    $catalog
}
