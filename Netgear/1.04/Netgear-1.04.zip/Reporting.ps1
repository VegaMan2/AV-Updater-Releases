# ============================================================
# Reporting.ps1 -- master error-report module for the PowerShell updaters (functions only)
#
# Dot-source it from an updater:   . (Join-Path $PSScriptRoot "Reporting.ps1")
# Every product folder carries an identical copy (a project test fails if the copies differ).
# Needs version.json (Component, Version) and reporting.json (ReportDestination, ReportKey) next to it.
#
# Public functions (all take the engine's parsed $config; none ever throws, none writes output
# except the documented return value; none shows a message):
#   Get-ReportingSettings -Config                     -> @{ Enabled; Destination; Key }
#   Send-ErrorReport -Config -Category -Message [-Step] [-ErrorRecord] [-Context] [-LogPath]
#                    [-TimeoutSeconds 10]            -> ReportId, or $null (disabled / suppressed / not written)
#   Send-ReportOutbox -Config [-TimeoutSeconds 10]    -> number delivered (disabled: clears outbox, 0)
#   Clear-ReportOutbox -Config                        -> number of files removed
#   Set-ErrorReporting -ConfigPath -Enabled           -> $true when config.json was rewritten
#   Remove-SecretText -Lines                          -> the lines that hold no secret-shaped text
#   Protect-ReportText -Text                          -> the text with secrets / names replaced (scrub v2)
#   Get-ReportPageState -Port                         -> Page block of the first Chrome tab (DevTools port), or $null
#
# Report format: schema v2 (AV Updater\Error Upload\Design.md sec. 3). Engines may pass these -Context
# keys, which become report blocks instead of Context entries:
#   Run = <run start [datetime]> or @{ Started; Trigger }   Page = Get-ReportPageState output
#   Network = "host[:port]" or a URL (probed: DNS, TCP)      ExitCode / HttpStatus / RetryCount -> Details
#
# Rules: the report is always written to the local outbox first (<StateDir>\Reports\Outbox), then
# delivered. ReportDestination http(s):// = POST to the report Worker (header X-AVU-Key; 2xx delivered,
# 400/413/415 moved to Outbox\Rejected, anything else kept for the next run); a folder path = copied to
# <ReportDestination>\<COMPUTERNAME>\ as <name>.tmp and renamed. Every touch of the destination runs in
# a separate runspace that is abandoned after the time budget; after one timeout in a process no further
# destination touch is tried. ASCII only; parses in PowerShell 7 and Windows PowerShell 5.1.
# ============================================================

$script:ReportingRoot = $PSScriptRoot
$script:ReportingHung = $false
$script:ReportingRunId = [guid]::NewGuid().ToString("N").Substring(0, 12)
$script:ReportingMaxBytes = 49152

# Strict pattern: Remove-SecretText drops lines that match.
$script:ReportingLinePattern = '(?i)(password|passwd|pwd|secret|token|cookie|credential|authorization|bearer)'

# Scrub v2 (same rules as the report Worker, tested with Error Upload\Tools\worker\test\vectors.json).
$script:ReportingSecretWords = 'password|passwd|pwd|secret|token|api[_-]?key|apikey|cookie|credential|authorization|session(?:id)?|sig|signature'
$script:ReportingRxKv       = [regex]::new('(?i)\b(' + $script:ReportingSecretWords + ')\b(["'']?)(\s*[:=]\s*)("[^"]*"|''[^'']*''|[^\s,;&"''}]+)')
$script:ReportingRxPhrase   = [regex]::new('(?i)\b(password|passwd|pwd)\s+(is|was)\s+\S+')
$script:ReportingRxBearer   = [regex]::new('(?i)\bbearer\s+[A-Za-z0-9._~+/=-]+')
$script:ReportingRxHeader   = [regex]::new('(?i)^\s*(set-cookie|cookie|authorization)\s*:')
$script:ReportingRxUrlQuery = [regex]::new('(?i)(https?://[^\s?#"''<>]+)[?#](?!\[query removed\])[^\s"''<>]*')
$script:ReportingRxEmail    = [regex]::new('[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}')
$script:ReportingRxUserPath = [regex]::new('(?i)([A-Za-z]:\\(?:Users|Documents and Settings)\\)([^\\/"''\s]+)')
$script:ReportingRxLongTok  = [regex]::new('[A-Za-z0-9+/_-]{40,}={0,2}')

function Get-ReportingProp {
    param($Object, [string]$Name)
    if ($null -eq $Object) { return $null }
    if ($Object -is [System.Collections.IDictionary]) {
        if ($Object.Contains($Name)) { return $Object[$Name] }
        return $null
    }
    $p = $Object.PSObject.Properties[$Name]
    if ($p) { return $p.Value }
    return $null
}

function Get-ReportingJsonFile {
    param([string]$Path)
    try {
        if (-not (Test-Path -LiteralPath $Path)) { return $null }
        return (Get-Content -LiteralPath $Path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop)
    } catch { return $null }
}

function Get-ReportingSettings {
    param($Config)
    $enabled = $true
    $destination = ""
    $key = ""
    try {
        $flag = Get-ReportingProp $Config "ErrorReporting"
        if ($null -ne $flag) {
            if ($flag -is [bool]) { $enabled = $flag }
            elseif ("$flag" -match '^(?i:false|0|no|off)$') { $enabled = $false }
        }
        $r = Get-ReportingJsonFile (Join-Path $script:ReportingRoot "reporting.json")
        $dest = Get-ReportingProp $Config "ReportDestination"
        if ($dest -is [string] -and $dest.Trim() -ne "") { $destination = $dest.Trim() }
        else {
            $d = Get-ReportingProp $r "ReportDestination"
            if ($d -is [string]) { $destination = $d.Trim() }
        }
        $k = Get-ReportingProp $Config "ReportKey"
        if (-not ($k -is [string] -and $k.Trim() -ne "")) { $k = Get-ReportingProp $r "ReportKey" }
        if ($k -is [string]) { $key = $k.Trim() }
    } catch { }
    return [pscustomobject]@{ Enabled = [bool]$enabled; Destination = [string]$destination; Key = [string]$key }
}

function Get-ReportingOutboxPath {
    param($Config)
    $state = Get-ReportingProp $Config "StateDir"
    if ($state -isnot [string] -or $state.Trim() -eq "") { return $null }
    return (Join-Path (Join-Path $state "Reports") "Outbox")
}

function Remove-SecretText {
    param([string[]]$Lines)
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($l in @($Lines)) {
        if ($null -eq $l) { continue }
        if ($l -match $script:ReportingLinePattern) { continue }
        $out.Add($l)
    }
    return [string[]]$out.ToArray()
}

# Scrub v2: secrets are replaced, not dropped; this PC's machine and user names become <machine> / <user>.
function Protect-ReportText {
    param([string]$Text)
    if ($null -eq $Text) { return $null }
    $names = @()
    if ($env:COMPUTERNAME -and $env:COMPUTERNAME.Length -ge 3) { $names += , @($env:COMPUTERNAME, '<machine>') }
    if ($env:USERNAME -and $env:USERNAME.Length -ge 3) { $names += , @($env:USERNAME, '<user>') }
    $out = foreach ($line in ($Text -split "\r?\n")) {
        if ($script:ReportingRxHeader.IsMatch($line)) { "[line removed]"; continue }
        $l = $script:ReportingRxBearer.Replace($line, 'Bearer [removed]')
        $l = $script:ReportingRxKv.Replace($l, { param($m) $m.Groups[1].Value + $m.Groups[2].Value + '=[removed]' })
        $l = $script:ReportingRxPhrase.Replace($l, { param($m) $m.Groups[1].Value + ' [removed]' })
        $l = $script:ReportingRxUrlQuery.Replace($l, '$1?[query removed]')
        $l = $script:ReportingRxEmail.Replace($l, '<email>')
        $l = $script:ReportingRxUserPath.Replace($l, '$1<user>')
        $l = $script:ReportingRxLongTok.Replace($l, { param($m) if ($m.Value -match '^[0-9a-fA-F]+$') { $m.Value } else { '<long-token>' } })
        foreach ($n in $names) { $l = [regex]::Replace($l, '(?i)\b' + [regex]::Escape($n[0]) + '\b', $n[1]) }
        $l
    }
    return (@($out) -join "`n")
}

# Every string inside a value (dictionaries and lists walked) goes through Protect-ReportText.
function Protect-ReportValue {
    param($Value)
    if ($null -eq $Value) { return $null }
    if ($Value -is [string]) { return (Protect-ReportText $Value) }
    if ($Value -is [datetime]) { return $Value.ToString("yyyy-MM-ddTHH:mm:ss") }
    if ($Value -is [bool] -or $Value -is [int] -or $Value -is [long] -or $Value -is [double] -or $Value -is [decimal]) { return $Value }
    if ($Value -is [System.Collections.IDictionary]) {
        $h = [ordered]@{}
        foreach ($k in @($Value.Keys)) { $h["$k"] = Protect-ReportValue $Value[$k] }
        return $h
    }
    if ($Value -is [System.Collections.IEnumerable]) {
        $a = @()
        foreach ($i in $Value) { $a += , (Protect-ReportValue $i) }
        return ,$a
    }
    if ($Value -is [System.Management.Automation.PSCustomObject]) {
        $h = [ordered]@{}
        foreach ($p in $Value.PSObject.Properties) { $h[$p.Name] = Protect-ReportValue $p.Value }
        return $h
    }
    return (Protect-ReportText ([string]$Value))
}

# Runs $Script in its own runspace and waits up to $TimeoutSeconds. On a timeout the runspace is left
# running (never Stop(): that can block on the same hung call) and the hang flag is set.
function Invoke-ReportingGuarded {
    param([string]$Script, [object[]]$Arguments, [int]$TimeoutSeconds)
    $ps = $null
    try {
        $ps = [powershell]::Create()
        [void]$ps.AddScript($Script)
        foreach ($a in $Arguments) { [void]$ps.AddArgument($a) }
        $async = $ps.BeginInvoke()
        $ms = [int][Math]::Max(1, $TimeoutSeconds) * 1000
        if ($async.AsyncWaitHandle.WaitOne($ms)) {
            try { [void]$ps.EndInvoke($async) } catch { }
            $ps.Dispose()
            return $true
        }
        $script:ReportingHung = $true
        return $false
    } catch {
        return $false
    }
}

# Delivers local report files and deletes each local file on success. Runs inside the guarded runspace,
# so it is self-contained. $Counter.Delivered counts finished files, $Counter.Rejected refused ones.
# http(s) destination: POST each file (X-AVU-Key); 2xx delivered; 400/413/415 moved to <outbox>\Rejected\;
# 401/429/5xx/no answer: kept, and the rest of this pass is skipped. Folder: <Dest>\<Machine>\ (tmp, rename).
$script:ReportingDeliverScript = @'
param($Dest, $Machine, $Files, $Counter, $Key)
if ([string]::IsNullOrWhiteSpace($Dest)) { return }
if ($Dest -match '^(?i)https?://') {
    try { [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor [System.Net.SecurityProtocolType]::Tls12 } catch { }
    foreach ($f in $Files) {
        $code = 0
        try {
            $bytes = [System.IO.File]::ReadAllBytes($f)
            $req = [System.Net.WebRequest]::Create($Dest)
            $req.Method = "POST"
            $req.ContentType = "application/json"
            $req.Timeout = 5000
            $req.ReadWriteTimeout = 5000
            try { $req.ServicePoint.Expect100Continue = $false } catch { }
            $req.Headers.Add("X-AVU-Key", [string]$Key)
            $req.ContentLength = $bytes.Length
            $s = $req.GetRequestStream()
            try { $s.Write($bytes, 0, $bytes.Length) } finally { $s.Dispose() }
            $resp = $req.GetResponse()
            $code = [int]$resp.StatusCode
            $resp.Dispose()
        } catch {
            $e = $_.Exception
            while ($e -and -not ($e -is [System.Net.WebException])) { $e = $e.InnerException }
            if ($e -and $e.Response) { try { $code = [int]$e.Response.StatusCode; $e.Response.Dispose() } catch { } }
        }
        if ($code -ge 200 -and $code -lt 300) {
            try { [System.IO.File]::Delete($f) } catch { }
            $Counter.Delivered = $Counter.Delivered + 1
        } elseif ($code -eq 400 -or $code -eq 413 -or $code -eq 415) {
            try {
                $rej = [System.IO.Path]::Combine([System.IO.Path]::GetDirectoryName($f), "Rejected")
                [void][System.IO.Directory]::CreateDirectory($rej)
                $to = [System.IO.Path]::Combine($rej, [System.IO.Path]::GetFileName($f))
                if ([System.IO.File]::Exists($to)) { [System.IO.File]::Delete($to) }
                [System.IO.File]::Move($f, $to)
                [System.IO.File]::SetLastWriteTime($to, [datetime]::Now)
            } catch { }
            $Counter.Rejected = $Counter.Rejected + 1
        } else {
            break
        }
    }
    return
}
if (-not [System.IO.Directory]::Exists($Dest)) { return }
$dir = [System.IO.Path]::Combine($Dest, $Machine)
[void][System.IO.Directory]::CreateDirectory($dir)
foreach ($f in $Files) {
    $final = [System.IO.Path]::Combine($dir, [System.IO.Path]::GetFileName($f))
    $tmp = $final + ".tmp"
    try {
        [System.IO.File]::Copy($f, $tmp, $true)
        if ([System.IO.File]::Exists($final)) { [System.IO.File]::Delete($final) }
        [System.IO.File]::Move($tmp, $final)
        [System.IO.File]::Delete($f)
        $Counter.Delivered = $Counter.Delivered + 1
    } catch {
        try { if ([System.IO.File]::Exists($tmp)) { [System.IO.File]::Delete($tmp) } } catch { }
    }
}
'@

function Get-ReportingOutboxFiles {
    param([string]$Outbox)
    try {
        if (-not (Test-Path -LiteralPath $Outbox)) { return @() }
        return @(Get-ChildItem -LiteralPath $Outbox -Filter "*.json" -File -ErrorAction Stop | Sort-Object LastWriteTime, Name)
    } catch { return @() }
}

# Drops outbox files older than 30 days, then the oldest beyond 200. Outbox\Rejected keeps 30 days.
function Limit-ReportOutbox {
    param([string]$Outbox)
    try {
        $files = @(Get-ReportingOutboxFiles $Outbox)
        $limit = (Get-Date).AddDays(-30)
        $keep = @()
        foreach ($f in $files) {
            if ($f.LastWriteTime -lt $limit) { Remove-Item -LiteralPath $f.FullName -Force -ErrorAction SilentlyContinue }
            else { $keep += $f }
        }
        $extra = $keep.Count - 200
        for ($i = 0; $i -lt $extra; $i++) { Remove-Item -LiteralPath $keep[$i].FullName -Force -ErrorAction SilentlyContinue }
        foreach ($f in @(Get-ReportingOutboxFiles (Join-Path $Outbox "Rejected"))) {
            if ($f.LastWriteTime -lt $limit) { Remove-Item -LiteralPath $f.FullName -Force -ErrorAction SilentlyContinue }
        }
    } catch { }
}

function Clear-ReportOutbox {
    param($Config)
    $n = 0
    try {
        $outbox = Get-ReportingOutboxPath $Config
        if (-not $outbox -or -not (Test-Path -LiteralPath $outbox)) { return 0 }
        foreach ($f in @(Get-ChildItem -LiteralPath $outbox -File -ErrorAction SilentlyContinue)) {
            try { Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop; if ($f.Extension -eq ".json") { $n++ } } catch { }
        }
        $rej = Join-Path $outbox "Rejected"
        if (Test-Path -LiteralPath $rej) { Remove-Item -LiteralPath $rej -Recurse -Force -ErrorAction SilentlyContinue }
    } catch { }
    return $n
}

function Send-ReportOutbox {
    param($Config, [int]$TimeoutSeconds = 10)
    try {
        $settings = Get-ReportingSettings $Config
        if (-not $settings.Enabled) { [void](Clear-ReportOutbox $Config); return 0 }
        $outbox = Get-ReportingOutboxPath $Config
        if (-not $outbox -or $script:ReportingHung -or $settings.Destination -eq "") { return 0 }
        $files = @(Get-ReportingOutboxFiles $outbox | ForEach-Object { $_.FullName })
        if ($files.Count -eq 0) { return 0 }
        $counter = [hashtable]::Synchronized(@{ Delivered = 0; Rejected = 0 })
        [void](Invoke-ReportingGuarded -Script $script:ReportingDeliverScript -Arguments @($settings.Destination, $env:COMPUTERNAME, [string[]]$files, $counter, $settings.Key) -TimeoutSeconds $TimeoutSeconds)
        return [int]$counter.Delivered
    } catch { return 0 }
}

function Get-ReportingAVUpdaterVersion {
    try {
        $exe = Join-Path (Join-Path $env:LOCALAPPDATA "AVUpdater") "AVUpdater.exe"
        if (-not (Test-Path -LiteralPath $exe)) { return $null }
        $v = (Get-Item -LiteralPath $exe).VersionInfo.FileVersion
        if ($v -match '^(\d+)\.0\.(\d+)\.0$') { return ("{0}.{1:00}" -f [int]$Matches[1], [int]$Matches[2]) }
        return $null
    } catch { return $null }
}

# Lines of a text file that may be open for writing elsewhere (the transcript); the last 1 MB at most.
function Get-ReportingFileLines {
    param([string]$Path)
    try {
        if (-not $Path -or -not (Test-Path -LiteralPath $Path)) { return @() }
        $fs = [System.IO.File]::Open($Path, 'Open', 'Read', 'ReadWrite')
        try {
            if ($fs.Length -gt 1048576) { [void]$fs.Seek(-1048576, 'End') }
            $sr = New-Object System.IO.StreamReader($fs)
            $text = $sr.ReadToEnd()
        } finally { $fs.Dispose() }
        $lines = @($text -split "\r?\n")
        if ($lines.Count -gt 0 -and $lines[$lines.Count - 1] -eq "") { $lines = @($lines[0..($lines.Count - 2)]) }
        return $lines
    } catch { return @() }
}

# The lines of THIS run: from the last transcript start, at most $Max lines of 300 characters, scrubbed.
function Get-ReportingLogExcerpt {
    param([string]$Path, [int]$Max = 120)
    try {
        $lines = @(Get-ReportingFileLines $Path)
        $start = 0
        for ($i = $lines.Count - 1; $i -ge 0; $i--) { if ($lines[$i] -match 'transcript start') { $start = $i; break } }
        if ($lines.Count -gt 0) { $lines = @($lines[$start..($lines.Count - 1)]) }
        if ($lines.Count -gt $Max) { $lines = @($lines[($lines.Count - $Max)..($lines.Count - 1)]) }
        $out = @()
        foreach ($l in $lines) {
            $t = Protect-ReportText ([string]$l)
            if ($t.Length -gt 300) { $t = $t.Substring(0, 300) }
            $out += $t
        }
        return $out
    } catch { return @() }
}

function Get-ReportingFloodState {
    param([string]$File)
    $h = @{}
    try {
        $o = Get-ReportingJsonFile $File
        if ($o) {
            foreach ($p in $o.PSObject.Properties) {
                $last = $p.Value.Last
                if ($last -is [datetime]) { $last = $last.ToUniversalTime() }
                else { $last = [datetime]::Parse([string]$last, [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::AdjustToUniversal -bor [System.Globalization.DateTimeStyles]::AssumeUniversal) }
                $s = 0
                if ($null -ne $p.Value.Suppressed) { $s = [int]$p.Value.Suppressed }
                $h[$p.Name] = @{ Last = $last; Suppressed = $s }
            }
        }
    } catch { }
    return $h
}

function Save-ReportingFloodState {
    param([string]$File, $State)
    try {
        $o = [ordered]@{}
        $cut = [datetime]::UtcNow.AddDays(-30)
        foreach ($k in $State.Keys) {
            if ($State[$k].Last -lt $cut -and $State[$k].Suppressed -eq 0) { continue }
            $o[$k] = [ordered]@{ Last = $State[$k].Last.ToString("yyyy-MM-ddTHH:mm:ssZ", [System.Globalization.CultureInfo]::InvariantCulture); Suppressed = [int]$State[$k].Suppressed }
        }
        $tmp = $File + ".tmp"
        [System.IO.File]::WriteAllText($tmp, (ConvertTo-Json -InputObject $o -Depth 4), (New-Object System.Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $tmp -Destination $File -Force -ErrorAction Stop
    } catch { }
}

function Get-ReportingSha1 {
    param([string]$Text)
    $sha = [System.Security.Cryptography.SHA1]::Create()
    try {
        $b = $sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Text))
        return (($b | ForEach-Object { $_.ToString("x2") }) -join "")
    } finally { $sha.Dispose() }
}

function Get-ReportingSha256 {
    param([byte[]]$Bytes)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { return (($sha.ComputeHash($Bytes) | ForEach-Object { $_.ToString("x2") }) -join "") }
    finally { $sha.Dispose() }
}

# Fingerprint (Design.md sec. 4), the same as the Worker's; the Worker's own value is authoritative.
function ConvertTo-ReportingNorm {
    param($Text)
    if ($null -eq $Text) { return "" }
    $t = ([string]$Text).ToLowerInvariant()
    $t = [regex]::Replace($t, 'https?://\S+', '<url>')
    $t = [regex]::Replace($t, '[a-z]:\\[^\s"''<>|]*', '<path>')
    $t = [regex]::Replace($t, '\\\\[^\s"''<>|]+', '<path>')
    $t = [regex]::Replace($t, '[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}', '<email>')
    $t = [regex]::Replace($t, '\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b', '<hex>')
    $t = [regex]::Replace($t, '\b[0-9a-f]{8,}\b', '<hex>')
    $t = [regex]::Replace($t, '[0-9]+', '<n>')
    $t = [regex]::Replace($t, '\s+', ' ').Trim()
    if ($t.Length -gt 200) { $t = $t.Substring(0, 200) }
    return $t
}

function Get-ReportingFingerprint {
    param($Report)
    $d = Get-ReportingProp $Report 'Details'
    $pos = Get-ReportingProp $d 'Position'
    $posFile = if ($pos -is [string]) { $pos.Split(':')[0] } else { "" }
    $msg = Get-ReportingProp $Report 'Message'
    $first = if ($msg -is [string]) { ($msg -split "\r?\n")[0] } else { "" }
    $key = @([string](Get-ReportingProp $Report 'Component'), [string](Get-ReportingProp $Report 'Category'), (ConvertTo-ReportingNorm (Get-ReportingProp $d 'Step')), [string](Get-ReportingProp $d 'ExceptionType'), $posFile, (ConvertTo-ReportingNorm $first)) -join '|'
    return (Get-ReportingSha256 ([System.Text.Encoding]::UTF8.GetBytes($key))).Substring(0, 16)
}

function Get-ReportingEnvironment {
    param([string]$StateDir)
    $dotNet = [Environment]::Version.ToString()
    try { $dotNet = [System.Runtime.InteropServices.RuntimeInformation]::FrameworkDescription } catch { }
    $e = [ordered]@{ OSVersion = [Environment]::OSVersion.VersionString; OSBuild = $null; OSEdition = $null; Culture = $null; TimeZone = $null
        Is64Bit = [Environment]::Is64BitOperatingSystem; Elevated = $null; PowerShellVersion = $PSVersionTable.PSVersion.ToString()
        PowerShellEdition = [string]$PSVersionTable.PSEdition; DotNetVersion = $dotNet; ChromeVersion = $null; FreeDiskBytes = $null }
    try {
        $cv = Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction Stop
        $e.OSBuild = "{0}.{1}" -f $cv.CurrentBuild, $cv.UBR
        $e.OSEdition = [string]$cv.EditionID
    } catch { }
    try { $e.Culture = [System.Globalization.CultureInfo]::CurrentCulture.Name } catch { }
    try { $e.TimeZone = [System.TimeZoneInfo]::Local.Id } catch { }
    try { $e.Elevated = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) } catch { }
    foreach ($k in 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe', 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe') {
        try {
            $exe = (Get-ItemProperty -LiteralPath $k -ErrorAction Stop).'(default)'
            if ($exe -and (Test-Path -LiteralPath $exe)) { $e.ChromeVersion = (Get-Item -LiteralPath $exe).VersionInfo.ProductVersion; break }
        } catch { }
    }
    try { if ($StateDir) { $e.FreeDiskBytes = [long](New-Object System.IO.DriveInfo([System.IO.Path]::GetPathRoot($StateDir))).AvailableFreeSpace } } catch { }
    return $e
}

# Installed updaters (default install folders) and AV Updater: names and versions only.
function Get-ReportingInstalls {
    $list = @()
    try {
        foreach ($c in 'QSys', 'Biamp', 'Crestron', 'Extron', 'Netgear') {
            $v = Get-ReportingProp (Get-ReportingJsonFile (Join-Path (Join-Path $env:LOCALAPPDATA ($c + "Updater")) "version.json")) "Version"
            if ($v) { $list += [ordered]@{ Component = $c; Version = [string]$v } }
        }
        $av = Get-ReportingAVUpdaterVersion
        if ($av) { $list += [ordered]@{ Component = "AVUpdater"; Version = $av } }
    } catch { }
    return ,$list
}

# The catalog files next to this module: 12-hex SHA256 and entry count.
function Get-ReportingCatalog {
    $list = @()
    foreach ($name in 'products.json', 'firmware-catalog.json', 'devices.json') {
        try {
            $path = Join-Path $script:ReportingRoot $name
            if (-not (Test-Path -LiteralPath $path)) { continue }
            $entries = $null
            $j = Get-ReportingJsonFile $path
            if ($j -is [array]) { $entries = $j.Count }
            elseif (Get-ReportingProp $j "Products") { $entries = @(Get-ReportingProp $j "Products").Count }
            elseif (Get-ReportingProp $j "Devices") { $entries = @(Get-ReportingProp $j "Devices").Count }
            $list += [ordered]@{ File = $name; Sha256 = (Get-ReportingSha256 ([System.IO.File]::ReadAllBytes($path))).Substring(0, 12); Entries = $entries }
        } catch { }
    }
    return ,$list
}

# Allow-listed config.json keys only (never credentials).
function Get-ReportingConfigBlock {
    param($Config)
    $h = [ordered]@{}
    try {
        foreach ($p in $Config.PSObject.Properties) {
            $n = $p.Name
            if ($n -match '(?i)credential|password|secret|token|key') { continue }
            if ($n -in 'Products', 'BrowserMode', 'FirmwareDevices', 'Firmware', 'TaskName', 'ErrorReporting' -or $n -match '(Folder|Root|Dir)$') { $h[$n] = $p.Value }
        }
    } catch { }
    return $h
}

# Network block: Online, ProxyConfigured, VendorHost {Name, DnsOk, TcpOk, LatencyMs} (3 s each at most).
function Get-ReportingNetwork {
    param($Target)
    $n = [ordered]@{ Online = $null; ProxyConfigured = $null; VendorHost = $null }
    try { $n.Online = [System.Net.NetworkInformation.NetworkInterface]::GetIsNetworkAvailable() } catch { }
    try {
        $t = [string]$Target
        $port = 443
        if ($t -match '^(?i)(https?)://([^/:?#]+)(?::(\d+))?') { $hostName = $Matches[2]; if ($Matches[3]) { $port = [int]$Matches[3] } elseif ($Matches[1] -eq 'http') { $port = 80 } }
        elseif ($t -match '^([A-Za-z0-9.-]+)(?::(\d+))?$') { $hostName = $Matches[1]; if ($Matches[2]) { $port = [int]$Matches[2] } }
        else { return $n }
        try {
            $u = [Uri]("https://" + $hostName + "/")
            $px = [System.Net.WebRequest]::GetSystemWebProxy()
            $n.ProxyConfigured = (-not $px.IsBypassed($u)) -and ($px.GetProxy($u).Host -ne $u.Host)
        } catch { }
        $vh = [ordered]@{ Name = $hostName; Port = $port; DnsOk = $false; TcpOk = $false; LatencyMs = $null }
        try {
            $ar = [System.Net.Dns]::BeginGetHostAddresses($hostName, $null, $null)
            if ($ar.AsyncWaitHandle.WaitOne(3000)) { $vh.DnsOk = @([System.Net.Dns]::EndGetHostAddresses($ar)).Count -gt 0 }
        } catch { }
        if ($vh.DnsOk) {
            $client = New-Object System.Net.Sockets.TcpClient
            try {
                $sw = [System.Diagnostics.Stopwatch]::StartNew()
                $ar = $client.BeginConnect($hostName, $port, $null, $null)
                if ($ar.AsyncWaitHandle.WaitOne(3000)) { $client.EndConnect($ar); $vh.TcpOk = $true; $vh.LatencyMs = [int]$sw.ElapsedMilliseconds }
            } catch { } finally { $client.Close() }
        }
        $n.VendorHost = $vh
    } catch { }
    return $n
}

# Page block from the first page tab of a Chrome started with --remote-debugging-port: URL without query,
# title, form fields (names/ids/types, never values), visible text excerpt, tag outline. $null when unreadable.
$script:ReportingPageScript = @'
(() => {
  const inputs = [...document.querySelectorAll('input,select,textarea,button')].slice(0, 40)
    .map(e => ({ name: e.name || '', id: e.id || '', type: (e.type || e.tagName || '').toLowerCase() }));
  const text = (document.body ? document.body.innerText : '').replace(/\s+/g, ' ').slice(0, 1000);
  const out = []; let size = 0;
  const walk = (n, d) => { for (const c of n.children) { if (size > 4000 || d > 10) return;
    let t = c.tagName.toLowerCase(); if (c.id) t += '#' + c.id; if (c.classList.length) t += '.' + [...c.classList].slice(0, 3).join('.');
    const line = ' '.repeat(d) + t; out.push(line); size += line.length + 1; walk(c, d + 1); } };
  if (document.body) walk(document.body, 0);
  return JSON.stringify({ Url: location.origin + location.pathname, Title: document.title, ReadyState: document.readyState,
    Inputs: inputs, TextExcerpt: text, DomOutline: out.join('\n').slice(0, 4000) });
})()
'@

function Get-ReportPageState {
    param([int]$Port, [int]$TimeoutSeconds = 5)
    $ws = $null; $cts = $null
    try {
        if ($Port -le 0) { return $null }
        $tabs = @((Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json" -TimeoutSec 3 -UseBasicParsing -ErrorAction Stop) | Where-Object { $_.type -eq "page" })
        $tab = @($tabs | Sort-Object { if ($_.url -like "about:*") { 1 } else { 0 } })[0]
        if (-not $tab) { return $null }
        $ws = New-Object System.Net.WebSockets.ClientWebSocket
        $cts = New-Object System.Threading.CancellationTokenSource([TimeSpan]::FromSeconds($TimeoutSeconds))
        [void]$ws.ConnectAsync([Uri]$tab.webSocketDebuggerUrl, $cts.Token).GetAwaiter().GetResult()
        $msg = @{ id = 1; method = "Runtime.evaluate"; params = @{ expression = $script:ReportingPageScript; returnByValue = $true } } | ConvertTo-Json -Depth 5 -Compress
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($msg)
        [void]$ws.SendAsync((New-Object System.ArraySegment[byte] -ArgumentList @(, $bytes)), [System.Net.WebSockets.WebSocketMessageType]::Text, $true, $cts.Token).GetAwaiter().GetResult()
        while ($true) {
            $memory = New-Object System.IO.MemoryStream
            do {
                $buffer = New-Object byte[] 65536
                $got = $ws.ReceiveAsync((New-Object System.ArraySegment[byte] -ArgumentList @(, $buffer)), $cts.Token).GetAwaiter().GetResult()
                if ($got.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) { return $null }
                $memory.Write($buffer, 0, $got.Count)
            } while (-not $got.EndOfMessage)
            $response = [System.Text.Encoding]::UTF8.GetString($memory.ToArray()) | ConvertFrom-Json
            $memory.Dispose()
            if ($response.id -eq 1) { break }
        }
        $value = $response.result.result.value
        if (-not $value) { return $null }
        $p = $value | ConvertFrom-Json
        $inputs = @()
        foreach ($i in @($p.Inputs)) { $inputs += [ordered]@{ name = [string]$i.name; id = [string]$i.id; type = [string]$i.type } }
        return [ordered]@{ Url = [string]$p.Url; Title = [string]$p.Title; ReadyState = [string]$p.ReadyState; Inputs = $inputs; TextExcerpt = [string]$p.TextExcerpt; DomOutline = [string]$p.DomOutline }
    } catch { return $null }
    finally {
        if ($ws) { try { $ws.Abort() } catch { }; try { $ws.Dispose() } catch { } }
        if ($cts) { try { $cts.Dispose() } catch { } }
    }
}

function Get-ReportingJson {
    param($Report)
    return (ConvertTo-Json -InputObject $Report -Depth 10)
}

# Keeps the serialized report under 48 KB: trims Page.DomOutline, LogExcerpt, Context, Stack in that order.
function Limit-ReportingSize {
    param($Report)
    $enc = New-Object System.Text.UTF8Encoding($false)
    $json = Get-ReportingJson $Report
    $steps = @(
        { if ($Report.Page -is [System.Collections.IDictionary]) { $Report.Page.DomOutline = "" } },
        { $Report.LogExcerpt = [object[]]@(@($Report.LogExcerpt) | Select-Object -Last 30) },
        { $Report.LogExcerpt = [object[]]@() },
        { $Report.Context = [ordered]@{ Trimmed = $true } },
        { if ($Report.Details.Stack -and $Report.Details.Stack.Length -gt 1000) { $Report.Details.Stack = $Report.Details.Stack.Substring(0, 1000) } },
        { $Report.Page = $null; $Report.HistoryTail = [object[]]@(); $Report.Config = [ordered]@{} }
    )
    foreach ($s in $steps) {
        if ($enc.GetByteCount($json) -le $script:ReportingMaxBytes) { break }
        & $s
        $json = Get-ReportingJson $Report
    }
    return $json
}

function Send-ErrorReport {
    param(
        $Config,
        [string]$Category,
        [string]$Message,
        [string]$Step,
        [System.Management.Automation.ErrorRecord]$ErrorRecord,
        [hashtable]$Context,
        [string]$LogPath,
        [int]$TimeoutSeconds = 10
    )
    try {
        $settings = Get-ReportingSettings $Config
        if (-not $settings.Enabled) { return $null }
        $outbox = Get-ReportingOutboxPath $Config
        if (-not $outbox) { return $null }

        $version = Get-ReportingJsonFile (Join-Path $script:ReportingRoot "version.json")
        $component = [string](Get-ReportingProp $version "Component")
        $componentVersion = Get-ReportingProp $version "Version"
        if ($null -ne $componentVersion) { $componentVersion = [string]$componentVersion }
        if (-not $component) { $component = "Unknown" }

        # Flood limit: same Component + Category + Message at most once per 24 h.
        $reportsDir = Split-Path -Parent $outbox
        [void][System.IO.Directory]::CreateDirectory($outbox)
        $stateFile = Join-Path $reportsDir "state.json"
        $state = Get-ReportingFloodState $stateFile
        $key = Get-ReportingSha1 ($component + "|" + $Category + "|" + $Message)
        $now = [datetime]::UtcNow
        $suppressed = 0
        if ($state.ContainsKey($key)) {
            if (($now - $state[$key].Last).TotalHours -lt 24) {
                $state[$key].Suppressed = $state[$key].Suppressed + 1
                Save-ReportingFloodState $stateFile $state
                return $null
            }
            $suppressed = $state[$key].Suppressed
        }

        $stateDir = Get-ReportingProp $Config "StateDir"
        if (-not $LogPath) { $LogPath = Join-Path (Join-Path $stateDir "Logs") ($component + "-Updater.log") }

        # Context keys that are report blocks of their own.
        $ctxIn = @{}
        if ($Context) { foreach ($k in $Context.Keys) { $ctxIn[$k] = $Context[$k] } }
        $runIn = $ctxIn["Run"]; $pageIn = $ctxIn["Page"]; $netIn = $ctxIn["Network"]
        $exitCode = $ctxIn["ExitCode"]; $httpStatus = $ctxIn["HttpStatus"]; $retryCount = $ctxIn["RetryCount"]
        foreach ($k in 'Run', 'Page', 'Network', 'ExitCode', 'HttpStatus', 'RetryCount') { $ctxIn.Remove($k) }

        $details = [ordered]@{ ExceptionType = $null; ExceptionMessage = $null; InnerExceptions = [object[]]@(); Stack = $null; Step = $null; Position = $null
            ExitCode = $exitCode; HttpStatus = $httpStatus; RetryCount = $retryCount }
        if ($Step) { $details.Step = Protect-ReportText $Step }
        if ($ErrorRecord) {
            $ex = $ErrorRecord.Exception
            $details.ExceptionType = $ex.GetType().FullName
            $details.ExceptionMessage = Protect-ReportText ([string]$ex.Message)
            $stack = Protect-ReportText ([string]$ErrorRecord.ScriptStackTrace)
            if ($stack -and $stack.Length -gt 8000) { $stack = $stack.Substring(0, 8000) }
            $details.Stack = $stack
            $ii = $ErrorRecord.InvocationInfo
            if ($ii -and $ii.ScriptName) { $details.Position = ("{0}:{1}" -f (Split-Path -Leaf $ii.ScriptName), $ii.ScriptLineNumber) }
            $inner = @()
            $e = $ex.InnerException
            while ($e -and $inner.Count -lt 5) { $inner += [ordered]@{ Type = $e.GetType().FullName; Message = (Protect-ReportText ([string]$e.Message)) }; $e = $e.InnerException }
            $details.InnerExceptions = [object[]]$inner
            if ($null -eq $details.HttpStatus) {
                $e = $ex
                while ($e) { try { if ($e.Response -and $e.Response.StatusCode) { $details.HttpStatus = [int]$e.Response.StatusCode; break } } catch { }; $e = $e.InnerException }
            }
        }

        $run = [ordered]@{ RunId = $script:ReportingRunId; Trigger = $null; StartedUtc = $null; DurationMs = $null; StepReached = $details.Step }
        $started = $runIn
        if ($runIn -is [System.Collections.IDictionary]) { $started = $runIn["Started"]; $run.Trigger = $runIn["Trigger"] }
        if ($started -is [datetime]) {
            $run.StartedUtc = $started.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ", [System.Globalization.CultureInfo]::InvariantCulture)
            $run.DurationMs = [long]([datetime]::UtcNow - $started.ToUniversalTime()).TotalMilliseconds
        }

        $inv = [System.Globalization.CultureInfo]::InvariantCulture
        $local = Get-Date
        $id = [guid]::NewGuid().ToString("N").Substring(0, 8)
        $msg = Protect-ReportText $Message
        if (-not $msg) { $msg = "(no message)" }
        if ($msg.Length -gt 2000) { $msg = $msg.Substring(0, 2000) }

        $report = [ordered]@{
            SchemaVersion     = 2
            ReportId          = $id
            TimeUtc           = $now.ToString("yyyy-MM-ddTHH:mm:ssZ", $inv)
            TimeLocal         = $local.ToString("yyyy-MM-ddTHH:mm:sszzz", $inv)
            Component         = $component
            ComponentVersion  = $componentVersion
            AVUpdaterVersion  = (Get-ReportingAVUpdaterVersion)
            Category          = $Category
            Message           = $msg
            Fingerprint       = $null
            Details           = $details
            MachineId         = (Get-ReportingSha256 ([System.Text.Encoding]::UTF8.GetBytes("" + $env:COMPUTERNAME + "|" + $env:USERNAME))).Substring(0, 12)
            Run               = $run
            Environment       = (Get-ReportingEnvironment $stateDir)
            Installs          = (Get-ReportingInstalls)
            Catalog           = (Get-ReportingCatalog)
            Config            = (Protect-ReportValue (Get-ReportingConfigBlock $Config))
            Network           = $null
            Page              = $null
            LogExcerpt        = [object[]]@(Get-ReportingLogExcerpt $LogPath)
            HistoryTail       = [object[]]@(Get-ReportingLogExcerpt -Path (Join-Path (Join-Path $stateDir "Logs") "Run-History.log") -Max 10)
            SuppressedRepeats = [int]$suppressed
            Context           = (Protect-ReportValue $ctxIn)
        }
        if ($null -ne $netIn) { if ($netIn -is [string]) { $report.Network = Get-ReportingNetwork $netIn } else { $report.Network = Protect-ReportValue $netIn } }
        if ($null -ne $pageIn) { $report.Page = Protect-ReportValue $pageIn }
        $report.Fingerprint = Get-ReportingFingerprint $report

        $user = $env:USERNAME
        foreach ($c in [System.IO.Path]::GetInvalidFileNameChars()) { $user = $user.Replace([string]$c, "-") }
        $name = "{0}_{1}_{2}_{3}_{4}.json" -f $local.ToString("yyyyMMdd-HHmmss", $inv), $component, $user, $Category, $id
        $file = Join-Path $outbox $name
        $tmp = $file + ".tmp"
        [System.IO.File]::WriteAllText($tmp, (Limit-ReportingSize $report), (New-Object System.Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $tmp -Destination $file -Force -ErrorAction Stop

        $state[$key] = @{ Last = $now; Suppressed = 0 }
        Save-ReportingFloodState $stateFile $state
        Limit-ReportOutbox $outbox

        if (-not $script:ReportingHung -and $settings.Destination -ne "") {
            [void](Invoke-ReportingGuarded -Script $script:ReportingDeliverScript -Arguments @($settings.Destination, $env:COMPUTERNAME, [string[]]@($file), ([hashtable]::Synchronized(@{ Delivered = 0; Rejected = 0 })), $settings.Key) -TimeoutSeconds $TimeoutSeconds)
        }
        return $id
    } catch { return $null }
}

function Set-ErrorReporting {
    param([string]$ConfigPath, [bool]$Enabled)
    try {
        $cfg = Get-Content -LiteralPath $ConfigPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        if ($cfg.PSObject.Properties["ErrorReporting"]) { $cfg.ErrorReporting = $Enabled }
        else { Add-Member -InputObject $cfg -NotePropertyName "ErrorReporting" -NotePropertyValue $Enabled }
        $tmp = $ConfigPath + ".tmp"
        $cfg | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $tmp -Encoding UTF8 -ErrorAction Stop
        Move-Item -LiteralPath $tmp -Destination $ConfigPath -Force -ErrorAction Stop
        if (-not $Enabled) { [void](Clear-ReportOutbox $cfg) }
        return $true
    } catch { return $false }
}
