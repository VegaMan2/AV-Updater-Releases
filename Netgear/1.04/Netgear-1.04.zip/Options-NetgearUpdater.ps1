# ============================================================
# Netgear Updater -- Options
#
# Installed to %LOCALAPPDATA%\NetgearUpdater by Install-NetgearUpdater.ps1 and
# started by the "Netgear Updater Options" icon (Desktop and Start menu).
#
#   (no switch)       Opens the Options window: status, stop or resume the updater,
#                     check now, choose which firmware groups to keep, choose Wi-Fi
#                     networks to avoid, open the run history or the firmware folder,
#                     turn error reports on or off (window only), or remove the updater.
#                     Opening it changes nothing by itself.
#                     (-NoGui, or redirected input, gives a one-key console menu instead.)
#   -Uninstall        Removes the scheduled tasks, the icons, and the updater's own
#                     folder (logs, run history). Downloaded firmware is always kept.
#
# There is no undo: older firmware is deleted when a newer version is downloaded.
# ============================================================
# WINDOW CONTROL IDS (UI Automation id = control Name; window tests use these, keep them in step; <key> = a group key in firmware-catalog.json):
#   Options window: StatusUpdater StatusLastCheck StatusFolder StatusGroups StatusNetworks CheckNow StopResume ChooseGroups
#                   ChooseNetworks OpenHistory OpenFolder RemoveUpdater ToggleErrorReports Close
#   Groups dialog:  Group_<key> ModelList GroupsSave GroupsCancel
#   Wi-Fi dialog:   NetworkList AddNetworkBox AddNetworkButton NetworksOk NetworksCancel
#   Remove dialog:  ConfirmRemove CancelRemove
[CmdletBinding()]
param (
    [string]$InstallDir = (Join-Path $env:LOCALAPPDATA "NetgearUpdater"),
    [string]$TaskName = "Netgear Updater",
    [switch]$Uninstall,
    [switch]$NoGui,   # keep the console menu (also used automatically when input is redirected)
    [switch]$Yes      # with -Uninstall: the confirmation was already given (by the window)
)

$ErrorActionPreference = "Stop"

$configFile      = Join-Path $InstallDir "config.json"
$optionsLinkName = "Netgear Updater Options.lnk"
$historyFile     = Join-Path $InstallDir "Logs\Run-History.log"

$firmwareFolder = $null
$noticeTaskName = $null

if (Test-Path $configFile) {

    $savedConfig = Get-Content $configFile -Raw | ConvertFrom-Json

    $firmwareFolder = $savedConfig.FirmwareFolder

    # Use the task name this install was set up with, so a test install with its
    # own task name never touches a different install's task.
    if ($savedConfig.TaskName -and -not $PSBoundParameters.ContainsKey("TaskName")) {
        $TaskName = $savedConfig.TaskName
    }

    $noticeTaskName = $savedConfig.NoticeTaskName
}

if (-not $noticeTaskName) {
    $noticeTaskName = "$TaskName Notice"
}

$task       = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
$noticeTask = Get-ScheduledTask -TaskName $noticeTaskName -ErrorAction SilentlyContinue

# Error reports on/off (Set-ErrorReporting). Without the module (or with a damaged one) the
# window simply has no Error reports button.
$reportingScript = Join-Path $PSScriptRoot "Reporting.ps1"
if (Test-Path -LiteralPath $reportingScript) { try { . $reportingScript } catch { } }

# What the updater can keep current: the ONE list is firmware-catalog.json next to this script (engine, Setup and Options all read it
# through the same loader, Netgear-Catalog.ps1).
. (Join-Path $PSScriptRoot "Netgear-Catalog.ps1")
$catalog = Get-NetgearCatalog -Path (Join-Path $PSScriptRoot "firmware-catalog.json")
$groupChoices = @($catalog.groups | ForEach-Object {
    [pscustomobject]@{ Key = [string]$_.key; Name = [string]$_.folder; Models = @($_.models) }
})

# Settings as saved in config.json (read fresh each time: the dialogs change them).
function Get-EnabledProducts {

    $keys = @()

    if (Test-Path $configFile) {
        try { $keys = @((Get-Content $configFile -Raw | ConvertFrom-Json).EnabledProducts | Where-Object { $_ }) }
        catch { }
    }

    $keys
}

function Get-BlockedNetworks {

    $names = @()

    if (Test-Path $configFile) {
        try { $names = @((Get-Content $configFile -Raw | ConvertFrom-Json).BlockedSSIDs | Where-Object { $_ }) }
        catch { }
    }

    $names
}

function Get-GroupsStatusText {

    $keys  = @(Get-EnabledProducts)
    $names = @($groupChoices | Where-Object { $_.Key -in $keys } | ForEach-Object { $_.Name })

    if ($names.Count -eq 0) { return "None chosen (use Choose firmware groups...)" }
    $names -join ", "
}

function Get-NetworksStatusText {

    $names = @(Get-BlockedNetworks)

    if ($names.Count -eq 0) { return "None chosen (it checks on any network)" }
    $names -join ", "
}

# Writes one setting into config.json (temp file, then move, so a crash never leaves half a file).
function Save-ConfigValue {

    param ([string]$Name, $Value)

    $cfg = Get-Content $configFile -Raw | ConvertFrom-Json
    $cfg | Add-Member -NotePropertyName $Name -NotePropertyValue $Value -Force

    $tmp = "$configFile.tmp"
    $cfg | ConvertTo-Json -Depth 8 | Set-Content -Path $tmp -Encoding UTF8
    Move-Item -LiteralPath $tmp -Destination $configFile -Force
}

function Get-WifiProfileNames {

    $names = foreach ($line in (netsh wlan show profiles 2>$null)) {
        if ($line -match '^\s*(All User Profile|User Profile)\s*:\s*(.+)$') {
            $Matches[2].Trim()
        }
    }

    @($names | Sort-Object -Unique)
}

function Get-CurrentSsid {

    $info = netsh wlan show interfaces 2>$null | Out-String

    if ($info -match '(?m)^\s*SSID\s*:\s*(.+)$') {
        return $Matches[1].Trim()
    }

    return $null
}

function Get-ModelListText {

    $lines = @()

    foreach ($g in $groupChoices) {
        $lines += ("{0}  ({1} models)" -f $g.Name, @($g.Models).Count)
        foreach ($m in @($g.Models)) { $lines += ("    {0}  [{1}, {2} ports]" -f $m.model, $m.code, $m.ports) }
        $lines += ""
    }

    $lines -join "`r`n"
}


function Invoke-TaskChange {

    # Runs one scheduled-task change. If Windows refuses, say why in plain words
    # and what to do, instead of showing a raw error. Returns $true on success.
    param (
        [scriptblock]$Change,
        [string]$Action,
        [switch]$Quiet   # window: keep the explanation in $global:NOptTaskMessage instead of printing it
    )

    try {
        & $Change
        return $true
    }
    catch {

        $text = @("Could not $Action the scheduled task. Windows said: $($_.Exception.Message)")

        if ($_.Exception.Message -match 'denied') {
            $text += ""
            $text += "This happens when the task was created from a PowerShell window opened with"
            $text += "'Run as administrator': Windows then lets only an administrator window change it."
            $text += "Either run Install-NetgearUpdater.ps1 again (setup now gives your account control"
            $text += "of its own tasks), or run this same command from an administrator window."
        }

        if ($Quiet) {
            $global:NOptTaskMessage = $text -join "`r`n"
        }
        else {
            Write-Host ""
            foreach ($line in $text) { Write-Host $line }
        }

        return $false
    }
}

function Stop-RunningUpdater {

    # Ends only this updater's own process. Nothing else is touched.
    $processes = Get-CimInstance Win32_Process |
        Where-Object {
            $_.Name -eq "pwsh.exe" -and
            $_.CommandLine -like "*$InstallDir*Netgear-Updater.ps1*"
        }

    foreach ($process in $processes) {
        Stop-Process -Id $process.ProcessId -Force -ErrorAction SilentlyContinue
    }
}

function Stop-OpenNotice {

    Get-CimInstance Win32_Process |
        Where-Object {
            $_.Name -eq "pwsh.exe" -and
            $_.CommandLine -like "*$InstallDir*Show-NetgearNotice.ps1*"
        } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

function Get-UpdaterTask {

    Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
}

function Test-UpdaterRunning {

    @(
        Get-CimInstance Win32_Process |
            Where-Object {
                $_.Name -eq "pwsh.exe" -and
                $_.CommandLine -like "*$InstallDir*Netgear-Updater.ps1*"
            }
    ).Count -gt 0
}


# ------------------------------------------------------------
# Uninstall
# ------------------------------------------------------------

if ($Uninstall) {

    Write-Host "This removes the Netgear Updater from this PC:"
    Write-Host "  - the scheduled tasks '$TaskName' and '$noticeTaskName'"
    Write-Host "  - the Netgear Updater Options icons on the Desktop and in the Start menu"
    Write-Host "  - $InstallDir (logs, run history)"
    Write-Host ""
    Write-Host "Downloaded firmware is NOT deleted."
    Write-Host ""

    if (-not $Yes) {

        $answer = Read-Host "Remove the updater now? [y/N]"

        if ($answer -notmatch '^(y|yes)$') {
            Write-Host "Nothing was removed."
            return
        }
    }

    Stop-RunningUpdater
    Stop-OpenNotice

    # If Windows will not let the tasks be removed, stop here and remove nothing
    # else: deleting the files while the tasks remain would leave broken tasks.
    if ($task) {

        if (-not (Invoke-TaskChange -Action "remove" -Change { Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction Stop })) {
            Write-Host ""
            Write-Host "Nothing else was removed."
            return
        }

        Write-Host "Removed the scheduled task."
    }

    if ($noticeTask) {

        if (-not (Invoke-TaskChange -Action "remove" -Change { Unregister-ScheduledTask -TaskName $noticeTaskName -Confirm:$false -ErrorAction Stop })) {
            Write-Host ""
            Write-Host "The main task was removed but the notice task was not, and nothing else was removed."
            return
        }
    }

    $desktop     = [Environment]::GetFolderPath("Desktop")
    $startFolder = Join-Path ([Environment]::GetFolderPath("Programs")) "Netgear Updater"

    Remove-Item (Join-Path $desktop $optionsLinkName) -Force -ErrorAction SilentlyContinue
    Remove-Item $startFolder -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Removed the icons."

    # Windows will not delete a folder a program is standing in, and this window
    # may have been started inside the install folder. Step out of it first.
    # (Set-Location only moves PowerShell's own location; the process's working
    # folder, the one Windows checks, has to be moved as well.)
    try {
        Set-Location $env:TEMP
        [System.IO.Directory]::SetCurrentDirectory($env:TEMP)
    }
    catch { }

    try {
        Remove-Item $InstallDir -Recurse -Force
        Write-Host "Removed $InstallDir."
    }
    catch {
        Write-Warning "Could not remove $InstallDir ($($_.Exception.Message)). Close any window that is open in that folder and delete it yourself."
    }

    Write-Host ""
    Write-Host "Still on this PC (remove yourself if you want):"

    if ($firmwareFolder) {
        Write-Host "  - Your Netgear firmware folder: $firmwareFolder"
    }

    Write-Host "  - PowerShell 7 (Settings > Apps > Installed apps)"
    return
}


# ------------------------------------------------------------
# Options window (no switch): shows the status, then one-key choices
# ------------------------------------------------------------

try { $Host.UI.RawUI.WindowTitle = "Netgear Updater Options" } catch { }

# One key, no Enter, no copying of commands. If there is no real console (for
# example when input is redirected) it falls back to typing a letter and Enter.
function Read-MenuKey {

    try {

        $pressed = [Console]::ReadKey($true)

        if ($pressed.Key -eq "Enter") {
            return ""
        }

        return $pressed.KeyChar.ToString().ToUpper()
    }
    catch {

        $typed = Read-Host "Choose"

        if ($null -eq $typed) {
            return ""
        }

        return $typed.Trim().ToUpper()
    }
}

function Show-Status {

    $current = Get-UpdaterTask

    Write-Host ""
    Write-Host "============================================================"
    Write-Host " Netgear Updater"
    Write-Host "============================================================"

    if (-not $current) {
        Write-Host " Updater:   its scheduled task '$TaskName' was not found"
    }
    elseif ($current.State -eq "Disabled") {
        Write-Host " Updater:   STOPPED (it will not check at logon or after sleep)"
    }
    elseif (Test-UpdaterRunning) {
        Write-Host " Updater:   checking for an update right now"
    }
    else {
        Write-Host " Updater:   ON (checks at logon and after sleep)"
    }

    if (Test-Path $historyFile) {

        $last = (Get-Content $historyFile -Tail 1)

        if ($last.Length -gt 100) {
            $last = $last.Substring(0, 97) + "..."
        }

        Write-Host " Last check: $last"
    }
    else {
        Write-Host " Last check: none yet"
    }

    if ($firmwareFolder) { Write-Host " Firmware:   $firmwareFolder" }
    Write-Host " Keeping:    $(Get-GroupsStatusText)"
    Write-Host " Avoiding:   $(Get-NetworksStatusText)"

    Write-Host "------------------------------------------------------------"
}

function Show-Menu {

    $current = Get-UpdaterTask

    Write-Host "Press one key:"
    Write-Host ""

    if ($current -and $current.State -eq "Disabled") {
        Write-Host "   R       Resume the updater"
    }
    else {
        Write-Host "   S       Stop the updater (nothing is deleted)"
    }

    Write-Host "   H       Open the run history (one dated line per attempt)"

    if ($firmwareFolder) {
        Write-Host "   F       Open the firmware folder"
    }

    Write-Host "   C       Check for updates now"
    Write-Host "   X       Remove the updater from this PC (asks you to confirm first)"
    Write-Host "   Enter   Close this window"
    Write-Host ""
}

# ------------------------------------------------------------
# The window (default when a person opens it; the console menu below is used
# with -NoGui or when input is redirected, as in the automated tests)
# ------------------------------------------------------------

function Get-OptionsStatus {

    # The same facts the console status block shows, as data.
    $current = Get-UpdaterTask

    $status = @{
        TaskFound = [bool]$current
        Stopped   = [bool]($current -and $current.State -eq "Disabled")
    }

    if (-not $current) {
        $status.Updater = "Its scheduled task '$TaskName' was not found"
    }
    elseif ($current.State -eq "Disabled") {
        $status.Updater = "STOPPED (it will not check at logon or after sleep)"
    }
    elseif (Test-UpdaterRunning) {
        $status.Updater = "Checking for an update right now"
    }
    else {
        $status.Updater = "ON (checks at logon and after sleep)"
    }

    $status.LastCheck = if (Test-Path $historyFile) { (Get-Content $historyFile -Tail 1) } else { "None yet" }
    $status.Folder    = if ($firmwareFolder) { $firmwareFolder } else { "Not set" }
    $status.Groups    = Get-GroupsStatusText
    $status.Networks  = Get-NetworksStatusText

    $status
}

function Show-NetworkPicker {

    # Checklist of the PC's saved Wi-Fi networks, plus a box to add a name by hand.
    # Returns the ticked names, or $null if cancelled.
    param ([string[]]$Current = @())

    $profiles    = @(Get-WifiProfileNames)
    $connectedTo = Get-CurrentSsid

    $global:NNet = @{ Names = New-Object System.Collections.ArrayList }

    $form = New-Object System.Windows.Forms.Form
    $global:NNet.Form = $form
    $form.Text = "Wi-Fi networks to avoid"
    $form.ClientSize = New-Object System.Drawing.Size(520, 480)
    $form.StartPosition = "CenterParent"; $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false; $form.MinimizeBox = $false; $form.ShowInTaskbar = $false
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    $info = New-Object System.Windows.Forms.Label
    $info.Location = New-Object System.Drawing.Point(16, 12); $info.Size = New-Object System.Drawing.Size(488, 66)
    $info.Text = "The updater skips the check whenever this PC is connected to a network ticked here, such as a phone hotspot."
    $form.Controls.Add($info)

    $list = New-Object System.Windows.Forms.CheckedListBox
    $list.Name = "NetworkList"; $list.CheckOnClick = $true
    $list.Location = New-Object System.Drawing.Point(16, 84); $list.Size = New-Object System.Drawing.Size(488, 280)
    $form.Controls.Add($list)
    $global:NNet.List = $list

    function Add-NetworkItem ($name, $checked) {
        for ($i = 0; $i -lt $global:NNet.Names.Count; $i++) {
            if ($global:NNet.Names[$i] -eq $name) { $global:NNet.List.SetItemChecked($i, $checked); return }
        }
        [void]$global:NNet.Names.Add($name)
        $text = if ($name -eq $global:NNet.Connected) { "$name   (connected now)" } else { $name }
        [void]$global:NNet.List.Items.Add($text, $checked)
    }

    $global:NNet.Connected = $connectedTo

    foreach ($name in $profiles) { Add-NetworkItem $name ($name -in $Current) }
    foreach ($name in $Current)  { if ($name) { Add-NetworkItem $name $true } }

    $addLabel = New-Object System.Windows.Forms.Label
    $addLabel.Text = "Not listed? Type its name:"
    $addLabel.Location = New-Object System.Drawing.Point(16, 376); $addLabel.Size = New-Object System.Drawing.Size(488, 22)
    $form.Controls.Add($addLabel)

    $box = New-Object System.Windows.Forms.TextBox
    $box.Name = "AddNetworkBox"
    $box.Location = New-Object System.Drawing.Point(16, 400); $box.Size = New-Object System.Drawing.Size(370, 26)
    $form.Controls.Add($box)
    $global:NNet.Box = $box

    $add = New-Object System.Windows.Forms.Button
    $add.Name = "AddNetworkButton"; $add.Text = "Add"
    $add.Location = New-Object System.Drawing.Point(396, 398); $add.Size = New-Object System.Drawing.Size(108, 30)
    $add.Add_Click({
        try {
            $typed = $global:NNet.Box.Text.Trim()
            if ($typed) { Add-NetworkItem $typed $true; $global:NNet.Box.Text = "" }
        } catch { }
    })
    $form.Controls.Add($add)

    $ok = New-Object System.Windows.Forms.Button
    $ok.Name = "NetworksOk"; $ok.Text = "OK"; $ok.DialogResult = "OK"
    $ok.Location = New-Object System.Drawing.Point(290, 440); $ok.Size = New-Object System.Drawing.Size(100, 32)
    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Name = "NetworksCancel"; $cancel.Text = "Cancel"; $cancel.DialogResult = "Cancel"
    $cancel.Location = New-Object System.Drawing.Point(404, 440); $cancel.Size = New-Object System.Drawing.Size(100, 32)
    $form.Controls.AddRange(@($ok, $cancel))
    $form.AcceptButton = $ok; $form.CancelButton = $cancel

    $answer = $form.ShowDialog($global:NOptForm)

    $picked = $null

    if ($answer -eq "OK") {
        $picked = @()
        for ($i = 0; $i -lt $global:NNet.Names.Count; $i++) {
            if ($list.GetItemChecked($i)) { $picked += $global:NNet.Names[$i] }
        }
    }

    $form.Dispose()
    return $picked
}

function Show-OptionsWindow {

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    # Windows will not delete a folder a program is standing in, and this window
    # may have been started inside the install folder.
    try {
        Set-Location $env:TEMP
        [System.IO.Directory]::SetCurrentDirectory($env:TEMP)
    }
    catch { }

    # Hide the console this script was started in, but only if it is ours alone
    # (not a terminal the person opened and is still using).
    try {
        Add-Type -Namespace NetgearOpt -Name Native -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern System.IntPtr GetConsoleWindow();
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern uint GetConsoleProcessList(uint[] list, uint count);
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool ShowWindow(System.IntPtr hWnd, int cmd);
'@
        $consoleWindow = [NetgearOpt.Native]::GetConsoleWindow()
        $ids = New-Object 'uint32[]' 4
        if ($consoleWindow -ne [IntPtr]::Zero -and [NetgearOpt.Native]::GetConsoleProcessList($ids, 4) -le 1) {
            [void][NetgearOpt.Native]::ShowWindow($consoleWindow, 0)
        }
    }
    catch { }

    $global:NOptForm = New-Object System.Windows.Forms.Form
    $form = $global:NOptForm
    $form.Text = "Netgear Updater Options"
    $form.ClientSize = New-Object System.Drawing.Size(600, 576)
    $form.StartPosition = "CenterScreen"
    $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false
    $form.MinimizeBox = $true
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    function Add-Label ($text, $x, $y, $w, $h, $bold) {
        $l = New-Object System.Windows.Forms.Label
        $l.Text = $text; $l.Location = New-Object System.Drawing.Point($x, $y); $l.Size = New-Object System.Drawing.Size($w, $h)
        if ($bold) { $l.Font = New-Object System.Drawing.Font("Segoe UI", 9.5, [System.Drawing.FontStyle]::Bold) }
        $form.Controls.Add($l); $l
    }

    $title = Add-Label "Netgear Updater" 20 14 560 28 $true
    $title.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)

    $rows = @(
        @{ Key = "Updater";   Caption = "Updater";    Height = 22 },
        @{ Key = "LastCheck"; Caption = "Last check"; Height = 40 },
        @{ Key = "Folder";    Caption = "Firmware";   Height = 40 },
        @{ Key = "Groups";    Caption = "Keeping";    Height = 44 },
        @{ Key = "Networks";  Caption = "Avoiding";   Height = 40 }
    )
    $global:NOptValues = @{}
    $y = 54
    foreach ($row in $rows) {
        [void](Add-Label $row.Caption 20 $y 100 $row.Height $true)
        $value = Add-Label "" 125 $y 455 $row.Height $false
        $value.Name = "Status" + $row.Key
        $global:NOptValues[$row.Key] = $value
        $y += $row.Height + 4
    }

    $line = New-Object System.Windows.Forms.Label
    $line.BorderStyle = "Fixed3D"; $line.Location = New-Object System.Drawing.Point(20, 272); $line.Size = New-Object System.Drawing.Size(560, 2)
    $form.Controls.Add($line)

    function Add-Button ($name, $text, $x, $y) {
        $b = New-Object System.Windows.Forms.Button
        $b.Name = $name; $b.Text = $text
        $b.Location = New-Object System.Drawing.Point($x, $y); $b.Size = New-Object System.Drawing.Size(275, 36)
        $form.Controls.Add($b); $b
    }

    $btnCheck    = Add-Button "CheckNow"       "Check for updates now"             20  286
    $global:NOptStopResume = Add-Button "StopResume" "Stop updater"               305 286
    $btnGroups   = Add-Button "ChooseGroups"   "Choose firmware groups..."         20  330
    $btnNetworks = Add-Button "ChooseNetworks" "Wi-Fi networks to avoid..."       305 330
    $btnFolder   = Add-Button "OpenFolder"     "Open firmware folder"              20  374
    $btnHistory  = Add-Button "OpenHistory"    "Open run history"                 305 374
    $btnRemove   = Add-Button "RemoveUpdater"  "Remove updater..."                 20  418
    $global:NOptErrorReports = Add-Button "ToggleErrorReports" "Error reports: on (click to turn off)" 305 418
    $btnClose    = Add-Button "Close"          "Close"                            305 462

    $note = Add-Label "Opening this window changes nothing by itself. Stopping the updater deletes nothing. Older firmware is deleted when a newer version arrives. Firmware is only downloaded; loading it into the switches is still done by hand." 20 508 560 56 $false
    $note.ForeColor = [System.Drawing.Color]::DimGray

    function Show-Box ($text, $buttons = "OK", $icon = "Information") {
        [System.Windows.Forms.MessageBox]::Show($global:NOptForm, $text, "Netgear Updater Options", $buttons, $icon)
    }

    function Update-OptionsStatus {
        $st = Get-OptionsStatus
        $global:NOptValues["Updater"].Text   = $st.Updater
        $global:NOptValues["LastCheck"].Text = $st.LastCheck
        $global:NOptValues["Folder"].Text    = $st.Folder
        $global:NOptValues["Groups"].Text    = $st.Groups
        $global:NOptValues["Networks"].Text  = $st.Networks
        $global:NOptStopResume.Text = if ($st.Stopped) { "Resume updater" } else { "Stop updater" }
        $global:NOptStopResume.Enabled = $st.TaskFound
    }

    # Every handler is wrapped so an error can never escape into Windows Forms'
    # "unhandled exception" box (a timer would repeat it every tick).
    function Invoke-Safely ($body) {
        try { & $body }
        catch {
            try { [void](Show-Box "Something went wrong and nothing further was changed.`r`n`r`n$($_.Exception.Message)" "OK" "Warning") } catch { }
        }
    }

    $global:NOptStopResume.Add_Click({ Invoke-Safely {
        $current = Get-UpdaterTask
        if (-not $current) {
            [void](Show-Box "The scheduled task '$TaskName' was not found, so there is nothing to stop or resume." "OK" "Warning")
        }
        elseif ($current.State -eq "Disabled") {
            if (Invoke-TaskChange -Quiet -Action "enable" -Change { Enable-ScheduledTask -TaskName $TaskName -ErrorAction Stop | Out-Null }) {
                [void](Show-Box "Resumed. The updater will run at the next logon or after the PC wakes from sleep.")
            }
            else { [void](Show-Box $global:NOptTaskMessage "OK" "Warning") }
        }
        else {
            $stopped = Invoke-TaskChange -Quiet -Action "disable" -Change {
                Disable-ScheduledTask -TaskName $TaskName -ErrorAction Stop | Out-Null
                Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
            }
            Stop-RunningUpdater
            if ($stopped) {
                [void](Show-Box "Stopped. It will not check for updates at logon or after sleep. Nothing was deleted.")
            }
            else {
                [void](Show-Box ("NOT fully stopped: any run in progress was ended, but its scheduled task could not be disabled, so it WILL run again at the next logon or wake.`r`n`r`n" + $global:NOptTaskMessage) "OK" "Warning")
            }
        }
        Update-OptionsStatus
    } })

    $btnCheck.Add_Click({ Invoke-Safely {
        $current = Get-UpdaterTask
        if (-not $current) {
            [void](Show-Box "The scheduled task '$TaskName' was not found, so the updater cannot be started." "OK" "Warning")
        }
        elseif ($current.State -eq "Disabled") {
            [void](Show-Box "The updater is stopped. Click 'Resume updater' first, then check for updates." "OK" "Warning")
        }
        elseif (Test-UpdaterRunning) {
            [void](Show-Box "The updater is already checking for updates right now.")
        }
        elseif (Invoke-TaskChange -Quiet -Action "start" -Change { Start-ScheduledTask -TaskName $TaskName -ErrorAction Stop }) {
            [void](Show-Box "The check has started in the background. If something new is found you will get a notice. The Last check line above shows the result when it finishes.")
        }
        else { [void](Show-Box $global:NOptTaskMessage "OK" "Warning") }
        Update-OptionsStatus
    } })

    $btnHistory.Add_Click({ Invoke-Safely {
        if (Test-Path $historyFile) { Start-Process -FilePath "notepad.exe" -ArgumentList "`"$historyFile`"" }
        else { [void](Show-Box "There is no run history yet.") }
    } })

    $btnFolder.Add_Click({ Invoke-Safely {
        if ($firmwareFolder -and (Test-Path $firmwareFolder)) { Start-Process -FilePath "explorer.exe" -ArgumentList "`"$firmwareFolder`"" }
        elseif ($firmwareFolder) { [void](Show-Box "The firmware folder does not exist yet:`r`n$firmwareFolder") }
        else { [void](Show-Box "No firmware folder is set.") }
    } })

    $btnNetworks.Add_Click({ Invoke-Safely {
        $picked = Show-NetworkPicker -Current @(Get-BlockedNetworks)
        if ($null -ne $picked) {
            Save-ConfigValue -Name "BlockedSSIDs" -Value @($picked)
            [void](Show-Box "Saved. Networks to avoid:`r`n`r`n$(Get-NetworksStatusText)")
        }
        Update-OptionsStatus
    } })

    $btnGroups.Add_Click({ Invoke-Safely {

        $now = @(Get-EnabledProducts)

        $d = New-Object System.Windows.Forms.Form
        $d.Text = "Choose firmware groups"
        $d.StartPosition = "CenterParent"; $d.FormBorderStyle = "FixedDialog"
        $d.MaximizeBox = $false; $d.MinimizeBox = $false; $d.ShowInTaskbar = $false
        $d.Font = $global:NOptForm.Font

        $global:NProd = @{ Form = $d; Checks = @{}; Saved = $false }

        $y = 18
        foreach ($p in $groupChoices) {
            $c = New-Object System.Windows.Forms.CheckBox
            $c.Name = "Group_" + $p.Key; $c.Text = ("{0}  ({1} models)" -f $p.Name, @($p.Models).Count)
            $c.Location = New-Object System.Drawing.Point(24, $y); $c.Size = New-Object System.Drawing.Size(560, 24)
            $c.Checked = ($now -contains $p.Key)
            $d.Controls.Add($c)
            $global:NProd.Checks[$p.Key] = $c
            $y += 28
        }

        $list = New-Object System.Windows.Forms.TextBox
        $list.Name = "ModelList"; $list.Multiline = $true; $list.ReadOnly = $true; $list.ScrollBars = "Vertical"
        $list.Location = New-Object System.Drawing.Point(24, ($y + 4)); $list.Size = New-Object System.Drawing.Size(572, 160)
        $list.Text = Get-ModelListText
        $d.Controls.Add($list)
        $y += 172

        $hint = New-Object System.Windows.Forms.Label
        $hint.Location = New-Object System.Drawing.Point(24, $y); $hint.Size = New-Object System.Drawing.Size(572, 40)
        $hint.Text = "Changes apply from the next check. Older firmware is deleted when a newer version arrives."
        $hint.ForeColor = [System.Drawing.Color]::DimGray
        $d.Controls.Add($hint)
        $y += 46

        $save = New-Object System.Windows.Forms.Button
        $save.Name = "GroupsSave"; $save.Text = "Save"
        $save.Location = New-Object System.Drawing.Point(400, $y); $save.Size = New-Object System.Drawing.Size(100, 34)
        $cancel = New-Object System.Windows.Forms.Button
        $cancel.Name = "GroupsCancel"; $cancel.Text = "Cancel"; $cancel.DialogResult = "Cancel"
        $cancel.Location = New-Object System.Drawing.Point(510, $y); $cancel.Size = New-Object System.Drawing.Size(90, 34)
        $d.Controls.AddRange(@($save, $cancel)); $d.CancelButton = $cancel
        $d.ClientSize = New-Object System.Drawing.Size(620, ($y + 50))

        $save.Add_Click({ try {

            $ticked = @($global:NProd.Checks.Keys | Where-Object { $global:NProd.Checks[$_].Checked })

            if ($ticked.Count -eq 0) {
                [void][System.Windows.Forms.MessageBox]::Show($global:NProd.Form, "Tick at least one firmware group. To stop the updater completely, use Stop updater instead.", "Choose firmware groups", "OK", "Information")
                return
            }

            Save-ConfigValue -Name "EnabledProducts" -Value @($ticked)

            $global:NProd.Saved = $true
            $global:NProd.Form.DialogResult = "OK"
        } catch {
            [void][System.Windows.Forms.MessageBox]::Show($global:NProd.Form, "The settings could not be saved. Nothing was changed.`r`n`r`n$($_.Exception.Message)", "Choose firmware groups", "OK", "Warning")
        } })

        [void]$d.ShowDialog($global:NOptForm)
        $d.Dispose()

        if ($global:NProd.Saved) {
            [void](Show-Box "Saved. This will be kept up to date from the next check (or click Check for updates now):`r`n`r`n$(Get-GroupsStatusText)")
        }
        Update-OptionsStatus
    } })

    $btnRemove.Add_Click({ Invoke-Safely {
        $dialog = New-Object System.Windows.Forms.Form
        $dialog.Text = "Remove the Netgear Updater"
        $dialog.ClientSize = New-Object System.Drawing.Size(560, 250)
        $dialog.StartPosition = "CenterParent"; $dialog.FormBorderStyle = "FixedDialog"
        $dialog.MaximizeBox = $false; $dialog.MinimizeBox = $false; $dialog.ShowInTaskbar = $false
        $dialog.Font = $global:NOptForm.Font

        $info = New-Object System.Windows.Forms.Label
        $info.Location = New-Object System.Drawing.Point(20, 16); $info.Size = New-Object System.Drawing.Size(520, 170)
        $info.Text = "This removes the Netgear Updater from this PC:`r`n`r`n" +
            "  - the scheduled tasks '$TaskName' and '$noticeTaskName'`r`n" +
            "  - the Netgear Updater Options icons on the Desktop and in the Start menu`r`n" +
            "  - $InstallDir (logs, run history)`r`n`r`n" +
            "The Netgear firmware you already downloaded is NOT deleted."
        $dialog.Controls.Add($info)

        $ok = New-Object System.Windows.Forms.Button
        $ok.Name = "ConfirmRemove"; $ok.Text = "Remove updater"; $ok.DialogResult = "OK"
        $ok.Location = New-Object System.Drawing.Point(250, 196); $ok.Size = New-Object System.Drawing.Size(150, 36)
        $cancel = New-Object System.Windows.Forms.Button
        $cancel.Name = "CancelRemove"; $cancel.Text = "Cancel"; $cancel.DialogResult = "Cancel"
        $cancel.Location = New-Object System.Drawing.Point(410, 196); $cancel.Size = New-Object System.Drawing.Size(130, 36)
        $dialog.Controls.AddRange(@($ok, $cancel)); $dialog.CancelButton = $cancel

        $answer = $dialog.ShowDialog($global:NOptForm)
        $dialog.Dispose()

        if ($answer -eq "OK") {

            $global:NOptTimer.Stop()

            # The removal runs in its own hidden process started outside the install
            # folder (so the folder can be deleted); its report is read back here.
            $report = Join-Path $env:TEMP ("netgear-remove-" + [guid]::NewGuid().ToString("N").Substring(0, 8) + ".txt")
            $argList = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`"", "-Uninstall", "-Yes", "-NoGui", "-InstallDir", "`"$InstallDir`"", "-TaskName", "`"$TaskName`"")

            $pwshPath = (Get-Process -Id $PID).Path
            $child = Start-Process -FilePath $pwshPath -WorkingDirectory $env:TEMP -WindowStyle Hidden -PassThru -ArgumentList $argList -RedirectStandardOutput $report

            $global:NOptForm.Text = "Netgear Updater Options - removing..."
            $global:NOptForm.Enabled = $false
            while (-not $child.HasExited) {
                [System.Windows.Forms.Application]::DoEvents()
                Start-Sleep -Milliseconds 100
            }
            $global:NOptForm.Enabled = $true

            $result = if (Test-Path $report) { (Get-Content $report -Raw) } else { "" }
            Remove-Item $report -Force -ErrorAction SilentlyContinue
            [void](Show-Box ("Removal finished.`r`n`r`n" + "$result".Trim()))
            $global:NOptForm.Close()
        }
    } })

    # Error reports on/off: saved to the settings file at once (a missing setting means on).
    # Turning them off also deletes reports still waiting to be sent.
    function Update-ErrorReportsButton {
        $on = $true
        try { if ((Get-Content $configFile -Raw | ConvertFrom-Json).ErrorReporting -eq $false) { $on = $false } } catch { }
        $global:NOptErrorReports.Text = if ($on) { "Error reports: on (click to turn off)" } else { "Error reports: off (click to turn on)" }
        $on
    }

    $global:NOptErrorReports.Visible = [bool](Get-Command Set-ErrorReporting -CommandType Function -ErrorAction SilentlyContinue)
    [void](Update-ErrorReportsButton)

    $global:NOptErrorReports.Add_Click({ Invoke-Safely {
        $on = Update-ErrorReportsButton
        if (-not (Set-ErrorReporting -ConfigPath $configFile -Enabled (-not $on))) {
            [void](Show-Box "The error reports setting could not be saved:`r`n$configFile" "OK" "Warning")
        }
        [void](Update-ErrorReportsButton)
    } })

    $btnClose.Add_Click({ $global:NOptForm.Close() })
    $form.CancelButton = $btnClose

    $global:NOptTimer = New-Object System.Windows.Forms.Timer
    $global:NOptTimer.Interval = 5000
    $global:NOptTimer.Add_Tick({ try { Update-OptionsStatus } catch { } })

    $form.Add_Shown({ try { Update-OptionsStatus } catch { }; try { $global:NOptTimer.Start() } catch { } })

    [void]$form.ShowDialog()
    $global:NOptTimer.Stop()
}

$useGui = -not $NoGui
try { if ([Console]::IsInputRedirected) { $useGui = $false } } catch { }

if ($useGui) {
    Show-OptionsWindow
    return
}


while ($true) {

    Show-Status
    Show-Menu

    $choice = Read-MenuKey

    if ($choice -eq "") {
        return
    }

    if ($choice -eq "S") {

        $current = Get-UpdaterTask

        if (-not $current) {
            Write-Host "The scheduled task '$TaskName' was not found, so there is nothing to stop."
            continue
        }

        if ($current.State -eq "Disabled") {
            Write-Host "The updater is already stopped."
            continue
        }

        $stopped = Invoke-TaskChange -Action "disable" -Change {
            Disable-ScheduledTask -TaskName $TaskName -ErrorAction Stop | Out-Null
            Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
        }

        Stop-RunningUpdater

        if ($stopped) {
            Write-Host "Stopped. It will not check for updates at logon or after sleep. Nothing was deleted."
        }
        else {
            Write-Host "NOT fully stopped: any run in progress was ended, but its scheduled task could"
            Write-Host "not be disabled, so it WILL run again at the next logon or wake."
        }

        continue
    }

    if ($choice -eq "R") {

        $current = Get-UpdaterTask

        if (-not $current) {
            Write-Host "The scheduled task '$TaskName' was not found, so there is nothing to resume."
            continue
        }

        if ($current.State -ne "Disabled") {
            Write-Host "The updater is already on."
            continue
        }

        if (Invoke-TaskChange -Action "enable" -Change { Enable-ScheduledTask -TaskName $TaskName -ErrorAction Stop | Out-Null }) {
            Write-Host "Resumed. The updater will run at the next logon or after the PC wakes from sleep."
        }

        continue
    }

    if ($choice -eq "H") {

        if (Test-Path $historyFile) {
            Start-Process -FilePath "notepad.exe" -ArgumentList "`"$historyFile`""
        }
        else {
            Write-Host "There is no run history yet: $historyFile"
        }

        continue
    }

    if ($choice -eq "F" -and $firmwareFolder) {

        if (Test-Path $firmwareFolder) {
            Start-Process -FilePath "explorer.exe" -ArgumentList "`"$firmwareFolder`""
        }
        else {
            Write-Host "That folder does not exist yet: $firmwareFolder"
        }

        continue
    }

    if ($choice -eq "C") {

        $current = Get-UpdaterTask

        if (-not $current) {
            Write-Host "The scheduled task '$TaskName' was not found, so the updater cannot be started."
        }
        elseif ($current.State -eq "Disabled") {
            Write-Host "The updater is stopped. Resume it first (R), then check."
        }
        elseif (Test-UpdaterRunning) {
            Write-Host "The updater is already checking for updates right now."
        }
        elseif (Invoke-TaskChange -Action "start" -Change { Start-ScheduledTask -TaskName $TaskName -ErrorAction Stop }) {
            Write-Host "The check has started in the background. See the run history (H) for the result."
        }

        continue
    }

    if ($choice -eq "X") {

        # Open the removal in its own window (it asks before it removes anything),
        # then close this one.
        $pwshPath = (Get-Process -Id $PID).Path

        # (Started in the temp folder, not in the install folder, so the install
        # folder can be deleted.)
        Start-Process -FilePath $pwshPath -WorkingDirectory $env:TEMP -ArgumentList @(
            "-NoProfile",
            "-ExecutionPolicy", "Bypass",
            "-File", "`"$PSCommandPath`"",
            "-Uninstall",
            "-InstallDir", "`"$InstallDir`""
        )

        return
    }

    Write-Host "That key is not one of the choices above."
}
