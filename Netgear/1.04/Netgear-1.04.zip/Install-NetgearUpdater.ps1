# ============================================================
# Netgear Updater -- setup (run once per machine and user)
#
# Asks for:
#   - the folder to keep Netgear switch firmware in
#   - which firmware groups to keep up to date (the list comes from firmware-catalog.json)
#   - Wi-Fi networks to avoid (for example a phone hotspot)
# There is no sign-in: Netgear's firmware downloads are public. Setup makes ONE
# request to the Netgear support site to prove it can be reached. Then it installs the
# updater to %LOCALAPPDATA%\NetgearUpdater, registers a scheduled task that runs
# at logon and on wake from sleep (only when a network is available), and adds a
# "Netgear Updater Options" icon (Desktop and Start menu).
#
# Cancelling (or a failure) before setup finishes removes everything this
# run created. After setup completes nothing is removed automatically.
#
# Usage:
#   Double-click Setup.cmd, or from any PowerShell:
#   powershell -ExecutionPolicy Bypass -File Install-NetgearUpdater.ps1
#   (can start in Windows PowerShell 5.1; if PowerShell 7 is missing, setup offers to
#   install it, then continues in PowerShell 7)
#
#   ...Install-NetgearUpdater.ps1 -InstallPrerequisites   (install PowerShell 7 without asking)
#   pwsh -File Install-NetgearUpdater.ps1 -DestinationRoot "D:\For Install\Netgear" -NoGui
#   pwsh -File Install-NetgearUpdater.ps1 -Uninstall
#
#   Error reports (a short report when the updater hits an error, never passwords) are on
#   unless this PC turned them off before. -NoErrorReports turns them off, -ErrorReports
#   turns them back on; the setup window has a tick box for it.
# ============================================================

# WINDOW CONTROL IDS (UI Automation id = control Name; window tests use these, keep them in step; <key> = a group key in firmware-catalog.json):
#   Setup window:  FolderBox BrowseButton FolderPreview GroupsAll GroupsNone Group_<key> ModelList
#                  ChooseNetworks NetworksSummary AdvancedToggle ErrorReportsCheck TaskNameBox InstallButton CancelButton
#   Wi-Fi window:  NetworkList AddNetworkBox AddNetworkButton NetworksOk NetworksCancel
#   Finish window: DoneTitle OpenOptions DoneClose
[CmdletBinding()]
param (
    [string]$InstallDir = (Join-Path $env:LOCALAPPDATA "NetgearUpdater"),
    [string]$DestinationRoot,
    [string[]]$BlockedSSIDs = @(),
    [string]$TaskName = "Netgear Updater",
    [string[]]$Products,                 # firmware group keys to keep up to date (default: all groups in the catalog)
    [string]$PageUrl,                    # default: source.pageUrl in firmware-catalog.json
    [switch]$InstallPrerequisites,
    [switch]$ReplaceExistingTask,
    [switch]$ConfigureNetworks,
    [switch]$SkipServerCheck,            # tests only: do not contact Netgear
    [switch]$SkipTask,
    [switch]$RunNow,
    [switch]$NoGui,                      # no windows (also used automatically when input is redirected)
    [switch]$NoErrorReports,             # turn error reports off
    [switch]$ErrorReports,               # turn error reports back on after an earlier opt-out
    [switch]$Uninstall
)

$ErrorActionPreference = "Stop"

# -File runs pass arrays as one comma-separated string.
$BlockedSSIDs = @($BlockedSSIDs | ForEach-Object { $_ -split "," } | ForEach-Object { $_.Trim() } | Where-Object { $_ })
$Products     = @($Products     | ForEach-Object { $_ -split "," } | ForEach-Object { $_.Trim().ToLower() } | Where-Object { $_ })

$configFile        = Join-Path $InstallDir "config.json"
$updaterName       = "Netgear-Updater.ps1"
$launcherName      = "Run-Hidden.vbs"
$optionsScriptName = "Options-NetgearUpdater.ps1"
$optionsLinkName   = "Netgear Updater Options.lnk"
$noticeName        = "Show-NetgearNotice.ps1"
$noticeLauncher    = "Run-Notice.vbs"
$noticeTaskName    = "$TaskName Notice"
$catalogName       = "firmware-catalog.json"
$catalogLoaderName = "Netgear-Catalog.ps1"
$reportingFileNames = @("Reporting.ps1", "reporting.json", "version.json")
$ownFiles          = @($updaterName, $optionsScriptName, $noticeName, $catalogName, $catalogLoaderName) + $reportingFileNames

# What the updater can keep current: the ONE list is firmware-catalog.json next to this script (engine, Setup and Options all read it
# through the same loader, Netgear-Catalog.ps1).
. (Join-Path $PSScriptRoot $catalogLoaderName)
$catalog = Get-NetgearCatalog -Path (Join-Path $PSScriptRoot $catalogName)
if (-not $PageUrl) { $PageUrl = [string]$catalog.source.pageUrl }
$groupChoices = @($catalog.groups | ForEach-Object {
    [pscustomobject]@{ Key = [string]$_.key; Name = [string]$_.folder; Models = @($_.models) }
})
$groupKeys = @($groupChoices | ForEach-Object { $_.Key })

# Windows instead of console prompts, unless -NoGui or input is redirected (automated tests).
$useGui = -not $NoGui

try { if ([Console]::IsInputRedirected) { $useGui = $false } } catch { }

$wizardDone = $false


# ------------------------------------------------------------
# Uninstall
# ------------------------------------------------------------

if ($Uninstall) {

    # Same removal as the Remove updater button in the Netgear Updater Options window.
    & (Join-Path $PSScriptRoot $optionsScriptName) -Uninstall -InstallDir $InstallDir -TaskName $TaskName
    return
}


# ------------------------------------------------------------
# The one contact with Netgear during setup
# ------------------------------------------------------------

# Proves the Netgear support site can be reached. Throws a plain-wording message on any problem.
function Test-NetgearPage {

    param ([string]$Url)

    if ($SkipServerCheck) { return $true }

    try {
        [void](Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 60 -UserAgent "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36")
    }
    catch {
        throw "Could not reach the Netgear support site ($Url): $($_.Exception.Message) Check the internet connection and try again."
    }

    $true
}

function Get-WifiProfileNames {

    $names = foreach ($line in (netsh wlan show profiles 2>$null)) {
        if ($line -match '^\s*(All User Profile|User Profile)\s*:\s*(.+)$') {
            $Matches[2].Trim()
        }
    }

    @($names | Sort-Object -Unique)
}

function Get-CurrentSsid {

    $info = netsh wlan show interfaces 2>$null | Out-String

    if ($info -match '(?m)^\s*SSID\s*:\s*(.+)$') {
        return $Matches[1].Trim()
    }

    return $null
}

# Plain-words list of the switches in each group, for the setup window.
function Get-ModelListText {

    param ($Groups)

    $lines = @()

    foreach ($g in $Groups) {
        $lines += ("{0}  ({1} models)" -f $g.Name, @($g.Models).Count)
        foreach ($m in @($g.Models)) { $lines += ("    {0}  [{1}, {2} ports]" -f $m.model, $m.code, $m.ports) }
        $lines += ""
    }

    $lines -join "`r`n"
}


# ------------------------------------------------------------
# Setup windows (used when a person runs setup; -NoGui and any value given on the
# command line keep the console route)
# ------------------------------------------------------------

function Show-NetworkPicker {

    # Checklist of the PC's saved Wi-Fi networks, plus a box to add a name by hand.
    # Returns the ticked names, or $null if cancelled.
    param ([string[]]$Current = @())

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $profiles    = @(Get-WifiProfileNames)
    $connectedTo = Get-CurrentSsid

    $global:QNet = @{ Names = New-Object System.Collections.ArrayList }

    $form = New-Object System.Windows.Forms.Form
    $global:QNet.Form = $form
    $form.Text = "Wi-Fi networks to avoid"
    $form.ClientSize = New-Object System.Drawing.Size(520, 480)
    $form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false; $form.MinimizeBox = $false
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    $info = New-Object System.Windows.Forms.Label
    $info.Location = New-Object System.Drawing.Point(16, 12); $info.Size = New-Object System.Drawing.Size(488, 66)
    $info.Text = "The updater skips the check whenever this PC is connected to a network ticked here, such as a phone hotspot."
    $form.Controls.Add($info)

    $list = New-Object System.Windows.Forms.CheckedListBox
    $list.Name = "NetworkList"; $list.CheckOnClick = $true
    $list.Location = New-Object System.Drawing.Point(16, 84); $list.Size = New-Object System.Drawing.Size(488, 280)
    $form.Controls.Add($list)
    $global:QNet.List = $list

    function Add-NetworkItem ($name, $checked) {
        for ($i = 0; $i -lt $global:QNet.Names.Count; $i++) {
            if ($global:QNet.Names[$i] -eq $name) { $global:QNet.List.SetItemChecked($i, $checked); return }
        }
        [void]$global:QNet.Names.Add($name)
        $text = if ($name -eq $global:QNet.Connected) { "$name   (connected now)" } else { $name }
        [void]$global:QNet.List.Items.Add($text, $checked)
    }

    $global:QNet.Connected = $connectedTo

    foreach ($name in $profiles) { Add-NetworkItem $name ($name -in $Current) }
    foreach ($name in $Current)  { if ($name) { Add-NetworkItem $name $true } }

    $addLabel = New-Object System.Windows.Forms.Label
    $addLabel.Text = "Not listed? Type its name:"
    $addLabel.Location = New-Object System.Drawing.Point(16, 376); $addLabel.Size = New-Object System.Drawing.Size(488, 22)
    $form.Controls.Add($addLabel)

    $box = New-Object System.Windows.Forms.TextBox
    $box.Name = "AddNetworkBox"
    $box.Location = New-Object System.Drawing.Point(16, 400); $box.Size = New-Object System.Drawing.Size(370, 26)
    $form.Controls.Add($box)
    $global:QNet.Box = $box

    $add = New-Object System.Windows.Forms.Button
    $add.Name = "AddNetworkButton"; $add.Text = "Add"
    $add.Location = New-Object System.Drawing.Point(396, 398); $add.Size = New-Object System.Drawing.Size(108, 30)
    $add.Add_Click({
        try {
            $typed = $global:QNet.Box.Text.Trim()
            if ($typed) { Add-NetworkItem $typed $true; $global:QNet.Box.Text = "" }
        } catch { }
    })
    $form.Controls.Add($add)

    $ok = New-Object System.Windows.Forms.Button
    $ok.Name = "NetworksOk"; $ok.Text = "OK"; $ok.DialogResult = "OK"
    $ok.Location = New-Object System.Drawing.Point(290, 440); $ok.Size = New-Object System.Drawing.Size(100, 32)
    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Name = "NetworksCancel"; $cancel.Text = "Cancel"; $cancel.DialogResult = "Cancel"
    $cancel.Location = New-Object System.Drawing.Point(404, 440); $cancel.Size = New-Object System.Drawing.Size(100, 32)
    $form.Controls.AddRange(@($ok, $cancel))
    $form.AcceptButton = $ok; $form.CancelButton = $cancel

    $answer = $form.ShowDialog()

    $picked = $null

    if ($answer -eq "OK") {
        $picked = @()
        for ($i = 0; $i -lt $global:QNet.Names.Count; $i++) {
            if ($list.GetItemChecked($i)) { $picked += $global:QNet.Names[$i] }
        }
    }

    $form.Dispose()
    return $picked
}

function Show-SetupWizard {

    # The one setup window. Returns $null if cancelled; otherwise the chosen values.
    # The Install button checks the Netgear site once and stays in the window if that fails.
    param (
        [string]$StartFolder,
        [string[]]$BlockedNow = @(),
        [string]$Task,
        $GroupList,
        [string[]]$Selected,
        [string]$Url,
        [bool]$ErrorReports = $true
    )

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    $global:NS = @{ Blocked = @($BlockedNow); Advanced = $false; Checks = @{}; Url = $Url }

    $form = New-Object System.Windows.Forms.Form
    $global:NS.Form = $form
    $form.Text = "Netgear Updater Setup"
    $form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false; $form.MinimizeBox = $true
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    function Add-Ctl ($control, $name, $x, $y, $w, $h, $text) {
        $c = New-Object $control
        if ($name) { $c.Name = $name }
        $c.Location = New-Object System.Drawing.Point($x, $y); $c.Size = New-Object System.Drawing.Size($w, $h)
        if ($text) { $c.Text = $text }
        $global:NS.Form.Controls.Add($c)
        $c
    }
    function Add-Heading ($text, $y) {
        $l = Add-Ctl System.Windows.Forms.Label $null 20 $y 600 24 $text
        $l.Font = New-Object System.Drawing.Font("Segoe UI", 10.5, [System.Drawing.FontStyle]::Bold)
    }

    $title = Add-Ctl System.Windows.Forms.Label $null 20 12 600 30 "Set up the Netgear Updater"
    $title.Font = New-Object System.Drawing.Font("Segoe UI", 15, [System.Drawing.FontStyle]::Bold)
    [void](Add-Ctl System.Windows.Forms.Label $null 20 46 600 40 "It keeps the newest Netgear switch firmware in a folder of your choice. No sign-in is needed. Nothing is changed on this PC until you click Install.")

    # 1. Folder
    Add-Heading "1. Where should Netgear firmware be saved?" 92
    $global:NS.Folder = Add-Ctl System.Windows.Forms.TextBox "FolderBox" 20 120 480 26 $StartFolder
    $browse = Add-Ctl System.Windows.Forms.Button "BrowseButton" 510 118 110 30 "Browse..."
    $global:NS.Preview = Add-Ctl System.Windows.Forms.Label "FolderPreview" 20 150 600 22 ""
    $global:NS.Preview.ForeColor = [System.Drawing.Color]::DimGray

    function Update-FolderPreview {
        $text = $global:NS.Folder.Text.Trim()
        $global:NS.Preview.Text = if ($text) { "Firmware will go in: " + (Join-Path $text "Firmware") } else { "" }
    }
    $global:NS.Folder.Add_TextChanged({ try { Update-FolderPreview } catch { } })
    $browse.Add_Click({
        try {
            $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
            $dialog.Description = "Choose the folder to keep Netgear firmware in. A Firmware folder is made inside it."
            $dialog.ShowNewFolderButton = $true
            if ($global:NS.Folder.Text.Trim() -and (Test-Path $global:NS.Folder.Text.Trim())) { $dialog.SelectedPath = $global:NS.Folder.Text.Trim() }
            if ($dialog.ShowDialog($global:NS.Form) -eq "OK") { $global:NS.Folder.Text = $dialog.SelectedPath }
        } catch { }
    })

    # 2. Firmware groups (from the catalog)
    Add-Heading "2. Firmware to keep up to date" 182
    $y = 210
    foreach ($group in $GroupList) {
        $label = "{0}  ({1} models)" -f $group.Name, @($group.Models).Count
        $box = Add-Ctl System.Windows.Forms.CheckBox ("Group_" + $group.Key) 36 $y 560 24 $label
        $box.Checked = ($Selected -contains $group.Key)
        $global:NS.Checks[$group.Key] = $box
        $y += 26
    }
    foreach ($mode in @(@{ Name = "GroupsAll"; Text = "All"; Value = $true; X = 470 }, @{ Name = "GroupsNone"; Text = "None"; Value = $false; X = 550 })) {
        $toggleButton = Add-Ctl System.Windows.Forms.Button $mode.Name $mode.X 180 70 26 $mode.Text
        $toggleButton.Tag = $mode.Value
        $toggleButton.Add_Click({
            param ($sender, $e)
            try { foreach ($box in $global:NS.Checks.Values) { if ($box.Enabled) { $box.Checked = [bool]$sender.Tag } } } catch { }
        })
    }
    $y += 4
    $models = Add-Ctl System.Windows.Forms.TextBox "ModelList" 36 $y 584 130 (Get-ModelListText $GroupList)
    $models.Multiline = $true; $models.ReadOnly = $true; $models.ScrollBars = "Vertical"
    $y += 136
    [void](Add-Ctl System.Windows.Forms.Label $null 20 $y 600 56 "Each group gets its own folder. The firmware file (.stk) is saved ready to upload to the switch. When a newer version arrives the older one is deleted. Loading firmware into the switches is still done by hand.")
    $y += 62

    # 3. Wi-Fi
    Add-Heading "3. Wi-Fi networks to avoid" $y
    $y += 26
    [void](Add-Ctl System.Windows.Forms.Label $null 20 $y 600 40 "The updater skips the check on any network you choose here, such as a phone hotspot.")
    $y += 42
    $global:NS.Networks = Add-Ctl System.Windows.Forms.Label "NetworksSummary" 20 ($y + 4) 480 24 ""
    $choose = Add-Ctl System.Windows.Forms.Button "ChooseNetworks" 510 $y 110 30 "Choose..."

    function Update-NetworksSummary {
        $global:NS.Networks.Text = if ($global:NS.Blocked.Count) { "Avoiding: " + ($global:NS.Blocked -join ", ") } else { "None chosen (it will download on any network)" }
    }
    $choose.Add_Click({
        try {
            $picked = Show-NetworkPicker -Current @($global:NS.Blocked)
            if ($null -ne $picked) { $global:NS.Blocked = @($picked); Update-NetworksSummary }
        } catch { }
    })
    $y += 44

    # Advanced (collapsed)
    $toggle = Add-Ctl System.Windows.Forms.Button "AdvancedToggle" 20 $y 150 28 "Advanced  >"
    $global:NS.ErrorReports = Add-Ctl System.Windows.Forms.CheckBox "ErrorReportsCheck" 190 ($y + 2) 420 24 "Send error reports to help fix bugs"
    $global:NS.ErrorReports.Checked = $ErrorReports
    $global:NS.AdvancedPanel = New-Object System.Windows.Forms.Panel
    $panel = $global:NS.AdvancedPanel
    $panel.Location = New-Object System.Drawing.Point(20, ($y + 32)); $panel.Size = New-Object System.Drawing.Size(600, 58); $panel.Visible = $false
    $form.Controls.Add($panel)
    $taskLabel = New-Object System.Windows.Forms.Label
    $taskLabel.Text = "Task name (change it for a test install next to a working one):"
    $taskLabel.Location = New-Object System.Drawing.Point(0, 0); $taskLabel.Size = New-Object System.Drawing.Size(600, 22)
    $global:NS.TaskBox = New-Object System.Windows.Forms.TextBox
    $global:NS.TaskBox.Name = "TaskNameBox"; $global:NS.TaskBox.Text = $Task
    $global:NS.TaskBox.Location = New-Object System.Drawing.Point(0, 26); $global:NS.TaskBox.Size = New-Object System.Drawing.Size(400, 26)
    $panel.Controls.AddRange(@($taskLabel, $global:NS.TaskBox))
    $y += 94

    $install = Add-Ctl System.Windows.Forms.Button "InstallButton" 400 $y 110 34 "Install"
    $cancel  = Add-Ctl System.Windows.Forms.Button "CancelButton" 520 $y 100 34 "Cancel"
    $cancel.DialogResult = "Cancel"; $form.CancelButton = $cancel
    $fullHeight = $y + 48
    $form.ClientSize = New-Object System.Drawing.Size(640, $fullHeight)

    $toggle.Add_Click({
        try {
            $global:NS.Advanced = -not $global:NS.Advanced
            $global:NS.AdvancedPanel.Visible = $global:NS.Advanced
        } catch { }
    })

    $install.Add_Click({
        try {
            $form = $global:NS.Form
            $folder = $global:NS.Folder.Text.Trim()
            if (-not $folder) {
                [void][System.Windows.Forms.MessageBox]::Show($form, "Choose the folder to save Netgear firmware in first.", "Netgear Updater Setup", "OK", "Information")
                return
            }
            if (-not (Test-Path $folder)) {
                [void][System.Windows.Forms.MessageBox]::Show($form, "That folder does not exist:`r`n$folder`r`n`r`nChoose an existing folder (Browse... can make a new one).", "Netgear Updater Setup", "OK", "Information")
                return
            }
            $ticked = @($global:NS.Checks.Keys | Where-Object { $global:NS.Checks[$_].Checked })
            if ($ticked.Count -eq 0) {
                [void][System.Windows.Forms.MessageBox]::Show($form, "Tick at least one firmware group (section 2).", "Netgear Updater Setup", "OK", "Information")
                return
            }

            # The one contact with Netgear: stay in this window if it fails.
            $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
            try {
                [void](Test-NetgearPage -Url $global:NS.Url)
            }
            catch {
                $form.Cursor = [System.Windows.Forms.Cursors]::Default
                [void][System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, "Netgear Updater Setup", "OK", "Warning")
                return
            }
            finally { $form.Cursor = [System.Windows.Forms.Cursors]::Default }

            $form.DialogResult = "OK"
        } catch { }
    })
    $form.AcceptButton = $null

    Update-FolderPreview
    Update-NetworksSummary

    # A screen shorter than the window: let the window scroll instead of cutting off the buttons.
    $workHeight = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Height
    if ($workHeight -lt ($fullHeight + 60)) {
        $form.AutoScroll = $true
        $form.AutoScrollMinSize = New-Object System.Drawing.Size(620, $fullHeight)
        $form.ClientSize = New-Object System.Drawing.Size(660, [math]::Max(400, $workHeight - 90))
    }

    $answer = $form.ShowDialog()

    $result = $null

    if ($answer -eq "OK") {

        $taskText = $global:NS.TaskBox.Text.Trim()

        $result = [pscustomobject]@{
            DestinationRoot = $global:NS.Folder.Text.Trim()
            BlockedSSIDs    = @($global:NS.Blocked)
            Products        = @($global:NS.Checks.Keys | Where-Object { $global:NS.Checks[$_].Checked })
            TaskName        = $(if ($taskText) { $taskText } else { $Task })
            ErrorReports    = $global:NS.ErrorReports.Checked
        }
    }

    $form.Dispose()
    return $result
}

function Show-SetupDone {

    # Finish window. Returns $true if the person asked to open the Options window.
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Netgear Updater Setup"
    $form.ClientSize = New-Object System.Drawing.Size(520, 250)
    $form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false; $form.MinimizeBox = $false; $form.TopMost = $true
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    $title = New-Object System.Windows.Forms.Label
    $title.Name = "DoneTitle"; $title.Text = "Setup complete"
    $title.Font = New-Object System.Drawing.Font("Segoe UI", 15, [System.Drawing.FontStyle]::Bold)
    $title.Location = New-Object System.Drawing.Point(20, 16); $title.Size = New-Object System.Drawing.Size(480, 32)

    $text = New-Object System.Windows.Forms.Label
    $text.Location = New-Object System.Drawing.Point(20, 60); $text.Size = New-Object System.Drawing.Size(480, 120)
    $text.Text = "The updater will check for new Netgear firmware at logon and after the PC wakes from sleep.`r`n`r`nTo stop or resume it, check now, change the firmware groups or remove it, open `"Netgear Updater Options`" on your Desktop or in the Start menu."

    $open = New-Object System.Windows.Forms.Button
    $open.Name = "OpenOptions"; $open.Text = "Open Netgear Updater Options"; $open.DialogResult = "Yes"
    $open.Location = New-Object System.Drawing.Point(100, 196); $open.Size = New-Object System.Drawing.Size(260, 36)
    $close = New-Object System.Windows.Forms.Button
    $close.Name = "DoneClose"; $close.Text = "Close"; $close.DialogResult = "Cancel"
    $close.Location = New-Object System.Drawing.Point(376, 196); $close.Size = New-Object System.Drawing.Size(124, 36)
    $form.Controls.AddRange(@($title, $text, $open, $close)); $form.CancelButton = $close

    $answer = $form.ShowDialog()
    $form.Dispose()

    return ($answer -eq "Yes")
}

function Find-Pwsh {

    $command = Get-Command pwsh.exe -ErrorAction SilentlyContinue

    if ($command) {
        return $command.Source
    }

    # A fresh install is not on PATH in this session yet.
    $default = Join-Path $env:ProgramFiles "PowerShell\7\pwsh.exe"

    if (Test-Path $default) {
        return $default
    }

    return $null
}

function Install-FromMsi {

    # Direct-download fallback when winget is not available.
    param (
        [string]$Name,
        [string]$Url,
        [string]$MsiArguments = ""
    )

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $ProgressPreference = "SilentlyContinue"

    $msi = Join-Path $env:TEMP ("NetgearUpdater-" + $Name.Replace(" ", "") + ".msi")

    Write-Host "Downloading $Name..."
    Invoke-WebRequest -Uri $Url -OutFile $msi -UseBasicParsing

    Write-Host "Installing $Name (a Windows permission prompt will appear)..."

    $process = Start-Process msiexec.exe `
        -ArgumentList "/i `"$msi`" /qn $MsiArguments" `
        -Verb RunAs `
        -Wait `
        -PassThru

    Remove-Item $msi -Force -ErrorAction SilentlyContinue

    if ($process.ExitCode -notin 0, 3010) {
        Write-Warning "$Name installer finished with exit code $($process.ExitCode)."
    }
}

function Install-Prerequisite {

    param (
        [string]$Name,
        [string]$WingetId,
        [scriptblock]$Fallback,
        [scriptblock]$IsInstalled
    )

    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue

    if ($winget) {

        Write-Host "Installing $Name with winget (a Windows permission prompt may appear)..."

        & $winget.Source install `
            --id $WingetId `
            --exact `
            --silent `
            --accept-package-agreements `
            --accept-source-agreements

        if (& $IsInstalled) {
            return
        }

        Write-Warning "winget did not complete the $Name install. Trying a direct download."
    }

    try {
        & $Fallback
    }
    catch {
        Write-Warning "Direct download of $Name failed: $($_.Exception.Message)"
    }
}

if ($ConfigureNetworks) {

    if (-not (Test-Path $configFile)) {
        throw "Setup has not been run yet ($configFile not found). Run setup first."
    }

    $existingConfig = Get-Content $configFile -Raw | ConvertFrom-Json
    $existingConfig.BlockedSSIDs = @(Show-NetworkPicker -Current @($existingConfig.BlockedSSIDs))
    $existingConfig | ConvertTo-Json -Depth 6 | Set-Content -Path $configFile -Encoding UTF8

    Write-Host "Saved. Blocked networks: $(@($existingConfig.BlockedSSIDs) -join ', ')"
    return
}


# ------------------------------------------------------------
# Prerequisites: PowerShell 7 (the only one; there is no browser)
# ------------------------------------------------------------

foreach ($required in $ownFiles) {
    if (-not (Test-Path (Join-Path $PSScriptRoot $required))) {
        throw "$required was not found next to this setup script ($PSScriptRoot)."
    }
}

$pwsh = Find-Pwsh

if (-not $pwsh) {

    $installPwsh = $InstallPrerequisites

    if (-not $installPwsh) {

        if ($useGui) {

            Add-Type -AssemblyName System.Windows.Forms

            $message = "This PC is missing PowerShell 7, which runs the updater and its scheduled task.`r`n`r`nSetup can download and install it now (a Windows permission prompt may appear). Setup cannot continue without it.`r`n`r`nInstall it now?  (Yes = install, No = cancel setup)"

            $installPwsh = ([System.Windows.Forms.MessageBox]::Show($message, "Netgear Updater Setup", "YesNo", "Question") -eq "Yes")
        }
        else {
            $answer = (Read-Host "PowerShell 7 is missing and is required. Install it now? [Y/n]").Trim()
            $installPwsh = ($answer -eq "" -or $answer -match '^y(es)?$')
        }
    }

    if (-not $installPwsh) {
        Write-Host "Setup cancelled. Nothing was installed or changed."
        exit 1
    }

    Install-Prerequisite `
        -Name "PowerShell 7" `
        -WingetId "Microsoft.PowerShell" `
        -IsInstalled { [bool](Find-Pwsh) } `
        -Fallback {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

            $release = Invoke-RestMethod `
                "https://api.github.com/repos/PowerShell/PowerShell/releases/latest" `
                -Headers @{ "User-Agent" = "NetgearUpdaterSetup" }

            $asset = $release.assets |
                Where-Object { $_.name -like "*win-x64.msi" } |
                Select-Object -First 1

            if (-not $asset) {
                throw "No Windows x64 MSI found in the latest PowerShell release."
            }

            Install-FromMsi -Name "PowerShell 7" -Url $asset.browser_download_url -MsiArguments "ADD_PATH=1"
        }

    $pwsh = Find-Pwsh

    if (-not $pwsh) {
        Write-Host ""
        Write-Host "PowerShell 7 could not be installed automatically. Install it from https://aka.ms/powershell, then run setup again."
        exit 1
    }
}

# This setup may have been started in Windows PowerShell 5.1 so it could
# install PowerShell 7. Continue the rest of setup in PowerShell 7.
if ($PSVersionTable.PSVersion.Major -lt 7) {

    Write-Host "Continuing setup in PowerShell 7..."

    $relaunchArgs = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $PSCommandPath)

    foreach ($name in $PSBoundParameters.Keys) {

        $value = $PSBoundParameters[$name]

        if ($value -is [switch]) {
            if ($value.IsPresent) { $relaunchArgs += "-$name" }
        }
        elseif ($value -is [array]) {
            $relaunchArgs += "-$name"
            $relaunchArgs += ($value -join ",")
        }
        else {
            $relaunchArgs += "-$name"
            $relaunchArgs += [string]$value
        }
    }

    & $pwsh @relaunchArgs
    exit $LASTEXITCODE
}

# Which groups to keep current: the command line, else every group in the catalog. Unknown keys are refused.
if (-not $Products) { $Products = @($groupKeys) }

$unknown = @($Products | Where-Object { $_ -notin $groupKeys })

if ($unknown.Count -gt 0) {
    Write-Host "Setup cannot continue: unknown firmware group(s) $($unknown -join ', '). Known: $($groupKeys -join ', ')."
    exit 1
}


# Error reports: where reports go (reporting.json next to this script).
$reportDestination = [string](Get-Content (Join-Path $PSScriptRoot "reporting.json") -Raw | ConvertFrom-Json).ReportDestination

# Error reports are on, unless this PC turned them off in an earlier setup or in Options
# (then they stay off unless -ErrorReports is given). The setup window's tick box starts
# from this and decides.
$errorReporting = $true

if (Test-Path $configFile) {
    try {
        if ((Get-Content $configFile -Raw | ConvertFrom-Json).ErrorReporting -eq $false) { $errorReporting = $false }
    }
    catch { }
}

if ($ErrorReports)   { $errorReporting = $true }
if ($NoErrorReports) { $errorReporting = $false }


# ------------------------------------------------------------
# Setup window (when the folder was not given on the command line)
# ------------------------------------------------------------

if ($useGui -and -not $DestinationRoot) {

    $startFolder = @($env:OneDriveCommercial, $env:OneDrive) |
        Where-Object { $_ -and (Test-Path $_) } |
        Select-Object -First 1

    if ($startFolder) {
        $netgearStart = Join-Path $startFolder "For Install\Netgear"
        $startFolder = if (Test-Path $netgearStart) { $netgearStart } else { $startFolder }
    }

    $previousBlocked = @($BlockedSSIDs)

    if (-not $PSBoundParameters.ContainsKey("BlockedSSIDs") -and (Test-Path $configFile)) {
        $previousBlocked = @((Get-Content $configFile -Raw | ConvertFrom-Json).BlockedSSIDs | Where-Object { $_ })
    }

    $choice = Show-SetupWizard -StartFolder $startFolder -BlockedNow $previousBlocked -Task $TaskName -GroupList $groupChoices -Selected $Products -Url $PageUrl -ErrorReports $errorReporting

    if (-not $choice) {
        Write-Host "Setup cancelled. Nothing was changed."
        exit 1
    }

    $DestinationRoot = $choice.DestinationRoot
    $BlockedSSIDs    = @($choice.BlockedSSIDs)
    $Products        = @($choice.Products)
    $TaskName        = $choice.TaskName
    $errorReporting  = [bool]$choice.ErrorReports    # the tick box decides, also over an earlier opt-out
    $noticeTaskName  = "$TaskName Notice"
    $wizardDone      = $true
}
else {

    # Console route: the folder must be given.
    if (-not $DestinationRoot) {
        $DestinationRoot = (Read-Host "Folder to keep Netgear firmware in").Trim()
    }

    if (-not $DestinationRoot) {
        Write-Host "No folder was given. Setup cancelled."
        exit 1
    }

    Write-Host "Checking that the Netgear support site can be reached (the one contact setup makes)..."

    try { [void](Test-NetgearPage -Url $PageUrl) }
    catch {
        Write-Host "Setup cannot continue: $($_.Exception.Message)"
        exit 1
    }
}

$FirmwareFolder = Join-Path $DestinationRoot "Firmware"


# ------------------------------------------------------------
# Rollback support
#
# If setup is cancelled or fails before it finishes, remove only
# what THIS run created. Anything that already existed (folders,
# an earlier install) is never removed. Once setup completes,
# nothing is removed automatically.
# ------------------------------------------------------------

$script:createdPaths = New-Object System.Collections.Generic.List[string]
$script:createdTask  = $false
$script:createdNoticeTask = $false

# Never silently replace a scheduled task that another install is using.
# Re-running setup over its own install is fine.
if (-not $SkipTask) {

    $taskInTheWay = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue

    if ($taskInTheWay) {

        $ownLauncher = Join-Path $InstallDir $launcherName

        $theirCommand = ($taskInTheWay.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join " | "

        if ($useGui -and $theirCommand -notlike "*$ownLauncher*" -and -not $ReplaceExistingTask) {

            Add-Type -AssemblyName System.Windows.Forms

            $replaceAnswer = [System.Windows.Forms.MessageBox]::Show(
                "A scheduled task named '$TaskName' already exists and was not created by this setup:`r`n`r`n$theirCommand`r`n`r`nReplace it? Choose No to keep it (then run setup again with a different task name under Advanced).",
                "Netgear Updater Setup", "YesNo", "Warning", "Button2")

            if ($replaceAnswer -eq "Yes") {
                $ReplaceExistingTask = $true
            }
        }

        if ($theirCommand -notlike "*$ownLauncher*" -and -not $ReplaceExistingTask) {

            Write-Host ""
            Write-Host "A scheduled task named '$TaskName' already exists and was not created by this setup:"
            Write-Host "  $theirCommand"
            Write-Host ""
            Write-Host "Setup will not replace it. Either choose a different name, for example:"
            Write-Host "  -TaskName `"$TaskName TEST`""
            Write-Host "or add -ReplaceExistingTask if you really want to replace it."
            exit 1
        }
    }
}

function New-TrackedDirectory {

    param ([string]$Path)

    if (Test-Path $Path) {
        return
    }

    # Remember the top-most folder that does not exist yet, so one
    # removal undoes the whole chain this run created.
    $top = $Path

    while ($true) {
        $parent = Split-Path $top -Parent

        if (-not $parent -or (Test-Path $parent)) {
            break
        }

        $top = $parent
    }

    New-Item -ItemType Directory -Path $Path -Force | Out-Null
    $script:createdPaths.Add($top)
}

function Register-CreatedFile {

    param ([string]$Path)

    if (-not (Test-Path $Path)) {
        $script:createdPaths.Add($Path)
    }
}

function Grant-UserTaskControl {

    # A task registered from an elevated (administrator) window can, by default,
    # only be changed from an elevated window, so the Stop icon (an ordinary
    # window) would get "Access is denied" even for the same person. Give the
    # signed-in user full control of THEIR OWN task; it already runs as them, so
    # this adds no privilege. A failure here is only a warning.
    param ([string]$Name)

    try {

        $sid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value

        $service = New-Object -ComObject Schedule.Service
        $service.Connect()

        $registered = $service.GetFolder("\").GetTask($Name)
        $registered.SetSecurityDescriptor("D:P(A;;FA;;;BA)(A;;FA;;;SY)(A;;FA;;;$sid)", 0)
    }
    catch {
        Write-Warning "Could not give your account control of the task '$Name' ($($_.Exception.Message)). The Stop icon may then need an administrator window."
    }
}

function Undo-Setup {

    if ($script:createdTask) {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
    }

    if ($script:createdNoticeTask) {
        Unregister-ScheduledTask -TaskName $noticeTaskName -Confirm:$false -ErrorAction SilentlyContinue
    }

    for ($i = $script:createdPaths.Count - 1; $i -ge 0; $i--) {
        Remove-Item $script:createdPaths[$i] -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function New-AppShortcut {

    param (
        [string]$Path,
        [string]$ScriptPath,
        [string]$Description = "Stop or resume the Netgear Updater, check now, choose firmware groups, or remove it",
        [string]$Icon = "$env:SystemRoot\System32\shell32.dll,316"   # the blue settings gear
    )

    $shell    = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($Path)

    $shortcut.TargetPath       = $pwsh
    $shortcut.Arguments        = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$ScriptPath`""
    $shortcut.WorkingDirectory = $InstallDir
    $shortcut.Description      = $Description
    $shortcut.IconLocation     = $Icon
    $shortcut.Save()
}

$setupFinished = $false

$progressForm = $null

if ($wizardDone) {

    Add-Type -AssemblyName System.Windows.Forms

    $progressForm = New-Object System.Windows.Forms.Form
    $progressForm.Text = "Netgear Updater Setup"
    $progressForm.ClientSize = New-Object System.Drawing.Size(420, 90)
    $progressForm.StartPosition = "CenterScreen"; $progressForm.FormBorderStyle = "FixedDialog"
    $progressForm.ControlBox = $false; $progressForm.TopMost = $true
    $progressForm.Font = New-Object System.Drawing.Font("Segoe UI", 10)

    $progressLabel = New-Object System.Windows.Forms.Label
    $progressLabel.Text = "Installing the Netgear Updater, please wait..."
    $progressLabel.Location = New-Object System.Drawing.Point(20, 28); $progressLabel.Size = New-Object System.Drawing.Size(380, 30)
    $progressForm.Controls.Add($progressLabel)

    $progressForm.Show()
    [System.Windows.Forms.Application]::DoEvents()
}

try {

    # --------------------------------------------------------
    # Where firmware is saved
    # --------------------------------------------------------

    New-TrackedDirectory $DestinationRoot
    New-TrackedDirectory $FirmwareFolder
    Write-Host "Firmware will be saved to: $FirmwareFolder"

    # --------------------------------------------------------
    # Install files and settings
    # --------------------------------------------------------

    New-TrackedDirectory $InstallDir

    foreach ($file in $ownFiles) {
        $target = Join-Path $InstallDir $file
        Register-CreatedFile $target
        Copy-Item (Join-Path $PSScriptRoot $file) $target -Force
    }

    $updaterPath       = Join-Path $InstallDir $updaterName
    $optionsScriptPath = Join-Path $InstallDir $optionsScriptName
    $noticePath        = Join-Path $InstallDir $noticeName

    $config = [ordered]@{
        StateDir        = $InstallDir
        NetgearFolder   = $DestinationRoot
        FirmwareFolder  = $FirmwareFolder
        BlockedSSIDs    = @($BlockedSSIDs)
        EnabledProducts = @($Products)
        NoticeTaskName  = $noticeTaskName
        TaskName        = $TaskName
        ErrorReporting    = $errorReporting
        ReportDestination = $reportDestination
    }

    Register-CreatedFile $configFile
    $config | ConvertTo-Json -Depth 6 | Set-Content -Path $configFile -Encoding UTF8

    $vbs = @"
Set shell = CreateObject("WScript.Shell")
shell.Run """$pwsh"" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File ""$updaterPath""", 0, True
"@

    $launcherPath = Join-Path $InstallDir $launcherName
    Register-CreatedFile $launcherPath
    Set-Content -Path $launcherPath -Value $vbs -Encoding ASCII

    $noticeVbs = @"
Set shell = CreateObject("WScript.Shell")
shell.Run """$pwsh"" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""$noticePath""", 0, False
"@

    $noticeLauncherPath = Join-Path $InstallDir $noticeLauncher
    Register-CreatedFile $noticeLauncherPath
    Set-Content -Path $noticeLauncherPath -Value $noticeVbs -Encoding ASCII

    Write-Host "Installed to $InstallDir"

    # --------------------------------------------------------
    # Scheduled task: at logon and on wake from sleep
    # --------------------------------------------------------

    if (-not $SkipTask) {

        $user = "$env:USERDOMAIN\$env:USERNAME"

        $action = New-ScheduledTaskAction `
            -Execute "wscript.exe" `
            -Argument ('"{0}"' -f $launcherPath)

        # 2 minute delay after logon and after resuming from sleep (Kernel-Power event 107).
        $logonTrigger = New-ScheduledTaskTrigger -AtLogOn -User $user
        $logonTrigger.Delay = "PT2M"

        $eventClass = Get-CimClass `
            -Namespace "Root/Microsoft/Windows/TaskScheduler" `
            -ClassName "MSFT_TaskEventTrigger"

        $wakeTrigger = New-CimInstance -CimClass $eventClass -ClientOnly
        $wakeTrigger.Enabled = $true
        $wakeTrigger.Delay = "PT2M"
        $wakeTrigger.Subscription = @"
<QueryList><Query Id="0" Path="System"><Select Path="System">*[System[Provider[@Name='Microsoft-Windows-Kernel-Power'] and EventID=107]]</Select></Query></QueryList>
"@

        # Network settings as in the Extron updater: run only when a network is available,
        # and retry a few times if the network was not ready.
        $settings = New-ScheduledTaskSettingsSet `
            -StartWhenAvailable `
            -AllowStartIfOnBatteries `
            -DontStopIfGoingOnBatteries `
            -MultipleInstances IgnoreNew `
            -RunOnlyIfNetworkAvailable `
            -RestartCount 3 `
            -RestartInterval (New-TimeSpan -Minutes 5) `
            -ExecutionTimeLimit (New-TimeSpan -Hours 3)

        # The signed-in user's SID, interactive, limited (no administrator rights).
        $userSid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value

        $principal = New-ScheduledTaskPrincipal `
            -UserId $userSid `
            -LogonType Interactive `
            -RunLevel Limited

        $existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue

        if ($existing) {
            Write-Host "A scheduled task named '$TaskName' already exists and will be replaced."
        }

        Register-ScheduledTask `
            -TaskName $TaskName `
            -Action $action `
            -Trigger @($logonTrigger, $wakeTrigger) `
            -Settings $settings `
            -Principal $principal `
            -Force |
            Out-Null

        Grant-UserTaskControl -Name $TaskName

        if (-not $existing) {
            $script:createdTask = $true
        }

        Write-Host "Scheduled task '$TaskName' registered (at logon)."

        # On-demand task that shows the notices. No triggers and NO time limit: a notice stays
        # open until the user clicks a button, so it must not be tied to the updater's time
        # limit. The updater starts it with Start-ScheduledTask.
        $noticeAction = New-ScheduledTaskAction `
            -Execute "wscript.exe" `
            -Argument ('"{0}"' -f $noticeLauncherPath)

        $noticeSettings = New-ScheduledTaskSettingsSet `
            -AllowStartIfOnBatteries `
            -DontStopIfGoingOnBatteries `
            -MultipleInstances IgnoreNew `
            -ExecutionTimeLimit ([TimeSpan]::Zero)

        $existingNotice = Get-ScheduledTask -TaskName $noticeTaskName -ErrorAction SilentlyContinue

        Register-ScheduledTask `
            -TaskName $noticeTaskName `
            -Action $noticeAction `
            -Settings $noticeSettings `
            -Principal $principal `
            -Force |
            Out-Null

        Grant-UserTaskControl -Name $noticeTaskName

        if (-not $existingNotice) {
            $script:createdNoticeTask = $true
        }
    }

    # --------------------------------------------------------
    # "Netgear Updater Options" icons (Desktop and Start menu)
    # --------------------------------------------------------

    $desktopLink = Join-Path ([Environment]::GetFolderPath("Desktop")) $optionsLinkName
    Register-CreatedFile $desktopLink
    New-AppShortcut -Path $desktopLink -ScriptPath $optionsScriptPath

    $startMenuFolder = Join-Path ([Environment]::GetFolderPath("Programs")) "Netgear Updater"
    New-TrackedDirectory $startMenuFolder

    $startMenuLink = Join-Path $startMenuFolder $optionsLinkName
    Register-CreatedFile $startMenuLink
    New-AppShortcut -Path $startMenuLink -ScriptPath $optionsScriptPath

    $setupFinished = $true
}
catch {

    Write-Host ""

    if ($_.Exception.Message -match "cancelled") {
        Write-Host "Setup cancelled."
    }
    else {
        Write-Host "Setup failed: $($_.Exception.Message)"
    }
}
finally {

    if ($progressForm) {
        $progressForm.Close()
        $progressForm.Dispose()
    }

    # Also runs if the window is closed with Ctrl+C.
    if (-not $setupFinished) {
        Write-Host "Removing what this setup created..."
        Undo-Setup
        Write-Host "Done. Nothing from this setup was left behind."

        if ($wizardDone) {
            [void][System.Windows.Forms.MessageBox]::Show("Setup did not finish, so everything it had created was removed. Nothing was left behind.", "Netgear Updater Setup", "OK", "Warning")
        }
    }
}

if (-not $setupFinished) {
    exit 1
}


Write-Host ""
Write-Host "Setup complete."
Write-Host "Run history (one dated line per attempt, with the reason if it failed):"
Write-Host "  $(Join-Path $InstallDir 'Logs\Run-History.log')"
Write-Host "Detailed log: $(Join-Path $InstallDir 'Logs\Netgear-Updater.log')"
Write-Host ""
Write-Host "To stop or resume the updater, check now, choose firmware groups or"
Write-Host "remove it, open 'Netgear Updater Options' on your Desktop (or in the Start menu)."

if ($RunNow -and -not $SkipTask) {
    Start-ScheduledTask -TaskName $TaskName
    Write-Host "Started the updater now."
}

if ($useGui -and $wizardDone) {

    if (Show-SetupDone) {

        # Open the Options window (outside the install folder, so it can never block removing it).
        Start-Process -FilePath $pwsh -WorkingDirectory $env:TEMP -WindowStyle Hidden -ArgumentList @(
            "-NoProfile", "-ExecutionPolicy", "Bypass",
            "-File", "`"$optionsScriptPath`"",
            "-InstallDir", "`"$InstallDir`""
        )
    }
}
