# ============================================================
# Biamp Updater -- Options
#
# Installed to %LOCALAPPDATA%\BiampUpdater by Install-BiampUpdater.ps1 and
# started by the "Biamp Updater Options" icon (Desktop and Start menu).
#
#   (no switch)       Opens the Options window: status, stop or resume the updater,
#                     check now, choose which software and firmware to keep, open
#                     the run history or the folders, undo the last software
#                     update, turn error reports on or off (window only), or remove
#                     the updater. Opening it changes nothing by itself. (-NoGui, or redirected input, gives a one-key
#                     console menu instead.)
#   -UndoLastUpdate   Undoes the last SOFTWARE update (puts the archived version
#                     back, removes the new one). Firmware cannot be undone.
#                     Asks first unless -Yes is given.
#   -Uninstall        Removes the scheduled tasks, the icons, and the updater's own
#                     folder (logs, run history). Downloaded software and firmware
#                     are always kept.
# ============================================================
# WINDOW CONTROL IDS (UI Automation id = control Name; window tests use these, keep them in step; <key> = a Key in products.json):
#   Options window: StatusUpdater StatusLastCheck StatusSoftware StatusFirmware StatusProducts CheckNow StopResume ChooseProducts
#                   OpenHistory OpenFolder OpenFirmwareFolder UndoLastUpdate RemoveUpdater ToggleErrorReports Close
#   Products dialog: Program_<key> ProductsSave ProductsCancel
#   Remove dialog:   ConfirmRemove CancelRemove
[CmdletBinding()]
param (
    [string]$InstallDir = (Join-Path $env:LOCALAPPDATA "BiampUpdater"),
    [string]$TaskName = "Biamp Updater",
    [switch]$Uninstall,
    [switch]$UndoLastUpdate,
    [switch]$NoGui,   # keep the console menu (also used automatically when input is redirected)
    [switch]$Yes      # with -Uninstall / -UndoLastUpdate: the confirmation was already given (by the window)
)

$ErrorActionPreference = "Stop"

$configFile      = Join-Path $InstallDir "config.json"
$optionsLinkName = "Biamp Updater Options.lnk"
$historyFile     = Join-Path $InstallDir "Logs\Run-History.log"
$journalFolder   = Join-Path $InstallDir "Journal"

# Error reports on/off (Set-ErrorReporting). Without the module (or with a damaged one) the
# window simply has no Error reports button.
$reportingScript = Join-Path $PSScriptRoot "Reporting.ps1"
if (Test-Path -LiteralPath $reportingScript) { try { . $reportingScript } catch { } }

$biampFolder    = $null
$firmwareFolder = $null
$noticeTaskName = $null

if (Test-Path $configFile) {

    $savedConfig = Get-Content $configFile -Raw | ConvertFrom-Json

    $biampFolder    = $savedConfig.BiampFolder
    $firmwareFolder = $savedConfig.FirmwareFolder

    # Use the task name this install was set up with, so a test install with its
    # own task name never touches a different install's task.
    if ($savedConfig.TaskName -and -not $PSBoundParameters.ContainsKey("TaskName")) {
        $TaskName = $savedConfig.TaskName
    }

    $noticeTaskName = $savedConfig.NoticeTaskName
}

if (-not $noticeTaskName) {
    $noticeTaskName = "$TaskName Notice"
}

$task       = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
$noticeTask = Get-ScheduledTask -TaskName $noticeTaskName -ErrorAction SilentlyContinue

# What the updater can keep current: the ONE list is products.json next to this script (engine, Setup and Options all read it).
$productChoices = @((Get-Content -LiteralPath (Join-Path $PSScriptRoot "products.json") -Raw | ConvertFrom-Json).Products | ForEach-Object {
    [pscustomobject]@{ Key = $_.Key; Name = $_.UiName; Kind = $_.Kind; Supported = [bool]$_.Supported }
})

# Settings as saved in config.json (read fresh each time: the products window changes them).
function Get-EnabledProducts {

    $keys = @()

    if (Test-Path $configFile) {
        try { $keys = @((Get-Content $configFile -Raw | ConvertFrom-Json).EnabledProducts | Where-Object { $_ }) }
        catch { }
    }

    $keys
}

function Get-ProductsStatusText {

    $keys  = @(Get-EnabledProducts)
    $names = @($productChoices | Where-Object { $_.Supported -and $_.Key -in $keys } | ForEach-Object { $_.Name })

    if ($names.Count -eq 0) { return "None chosen (use Choose software and firmware...)" }
    $names -join ", "
}


function Invoke-TaskChange {

    # Runs one scheduled-task change. If Windows refuses, say why in plain words
    # and what to do, instead of showing a raw error. Returns $true on success.
    param (
        [scriptblock]$Change,
        [string]$Action,
        [switch]$Quiet   # window: keep the explanation in $global:BOptTaskMessage instead of printing it
    )

    try {
        & $Change
        return $true
    }
    catch {

        $text = @("Could not $Action the scheduled task. Windows said: $($_.Exception.Message)")

        if ($_.Exception.Message -match 'denied') {
            $text += ""
            $text += "This happens when the task was created from a PowerShell window opened with"
            $text += "'Run as administrator': Windows then lets only an administrator window change it."
            $text += "Either run Install-BiampUpdater.ps1 again (setup now gives your account control"
            $text += "of its own tasks), or run this same command from an administrator window."
        }

        if ($Quiet) {
            $global:BOptTaskMessage = $text -join "`r`n"
        }
        else {
            Write-Host ""
            foreach ($line in $text) { Write-Host $line }
        }

        return $false
    }
}

function Stop-RunningUpdater {

    # Ends only this updater's own process. Nothing else is touched.
    $processes = Get-CimInstance Win32_Process |
        Where-Object {
            $_.Name -eq "pwsh.exe" -and
            $_.CommandLine -like "*$InstallDir*Biamp-Updater.ps1*"
        }

    foreach ($process in $processes) {
        Stop-Process -Id $process.ProcessId -Force -ErrorAction SilentlyContinue
    }
}

function Stop-OpenNotice {

    Get-CimInstance Win32_Process |
        Where-Object {
            $_.Name -eq "pwsh.exe" -and
            $_.CommandLine -like "*$InstallDir*Show-BiampNotice.ps1*"
        } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

function Get-UpdaterTask {

    Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
}

function Test-UpdaterRunning {

    @(
        Get-CimInstance Win32_Process |
            Where-Object {
                $_.Name -eq "pwsh.exe" -and
                $_.CommandLine -like "*$InstallDir*Biamp-Updater.ps1*"
            }
    ).Count -gt 0
}


# ------------------------------------------------------------
# Undo the last software update
# ------------------------------------------------------------

# The newest journal file the updater wrote (one per run that changed something), or $null.
function Get-LastJournal {

    if (-not (Test-Path $journalFolder)) { return $null }

    $file = Get-ChildItem -LiteralPath $journalFolder -Filter "*.json" -File -ErrorAction SilentlyContinue |
        Sort-Object Name -Descending | Select-Object -First 1

    if (-not $file) { return $null }

    try { [pscustomobject]@{ File = $file.FullName; Data = (Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json) } }
    catch { $null }
}

# What an undo would do, in plain words. Can = $false when there is nothing the undo can change.
function Get-UndoPlan {

    $journal = Get-LastJournal

    if (-not $journal) {
        return [pscustomobject]@{ Can = $false; Text = "There is no update to undo yet."; Journal = $null; Software = @(); Firmware = @() }
    }

    $software = @(@($journal.Data.Updates) | Where-Object { $_.Kind -eq "Software" })
    $firmware = @(@($journal.Data.Updates) | Where-Object { $_.Kind -eq "Firmware" })

    $when = try { ([datetime]$journal.Data.Time).ToString("MMMM d, yyyy h:mm tt") } catch { "the last run" }

    $lines = @()

    foreach ($u in $software) {
        $lines += "  - $($u.Product): remove $(Split-Path ([string]$u.Added) -Leaf)"
        foreach ($a in @($u.Archived)) { $lines += "      and put $(Split-Path ([string]$a.From) -Leaf) back from the Archive folder" }
    }

    $fwNote = ""
    if ($firmware.Count -gt 0) {
        $fwNote = "`r`n`r`nFirmware cannot be undone: the same update also changed $(($firmware | ForEach-Object { $_.Product }) -join ', '), and older firmware is deleted when a new file arrives. That firmware stays as it is."
    }

    if ($software.Count -eq 0) {
        $text = "The last update ($when) only changed firmware ($(($firmware | ForEach-Object { $_.Product }) -join ', ')). Firmware cannot be undone: older firmware is deleted when a new file arrives. If you need an older file, Biamp keeps some under 'Older firmware versions' on its Tesira Software and Firmware page."
        return [pscustomobject]@{ Can = $false; Text = $text; Journal = $journal; Software = @(); Firmware = $firmware }
    }

    $text = "Undo the software update of ${when}:`r`n`r`n" + ($lines -join "`r`n") + $fwNote +
        "`r`n`r`nThe updater will download the newer version again at its next check. To stay on the older one, stop the updater first."

    [pscustomobject]@{ Can = $true; Text = $text; Journal = $journal; Software = $software; Firmware = $firmware }
}

# Does the undo. Returns a plain-words report. Never touches firmware or files the updater did not add.
function Invoke-UndoLastUpdate {

    $plan = Get-UndoPlan

    if (-not $plan.Can) { return $plan.Text }

    if (Test-UpdaterRunning) { return "The updater is checking for updates right now. Wait for it to finish (or stop the updater), then undo." }

    $softwareRoot = if ($biampFolder) { ([string]$biampFolder).TrimEnd('\') } else { $null }
    $report = New-Object System.Collections.Generic.List[string]

    foreach ($u in $plan.Software) {

        $added = [string]$u.Added

        if ($added -and (Test-Path -LiteralPath $added)) {

            # Only a file inside the software folder is ever removed.
            if ($softwareRoot -and ((Split-Path $added -Parent).TrimEnd('\') -ieq $softwareRoot)) {
                Remove-Item -LiteralPath $added -Force
                $report.Add("Removed $(Split-Path $added -Leaf).")
            }
            else {
                $report.Add("Left $(Split-Path $added -Leaf) alone: it is not in the software folder.")
            }
        }

        foreach ($a in @($u.Archived)) {

            $from = [string]$a.From
            $to   = [string]$a.To
            $leaf = Split-Path $from -Leaf

            if (-not (Test-Path -LiteralPath $to)) { $report.Add("Could not put back ${leaf}: the archived copy is gone."); continue }
            if (Test-Path -LiteralPath $from)      { $report.Add("Left the archived copy of ${leaf} where it is: a file with that name is already in the folder."); continue }

            Move-Item -LiteralPath $to -Destination $from
            $report.Add("Put back $leaf.")
        }
    }

    # Mark the software part as done so it cannot be undone twice; keep any firmware record.
    try {
        if ($plan.Firmware.Count -gt 0) {
            [ordered]@{ Time = $plan.Journal.Data.Time; Updates = @($plan.Firmware) } | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $plan.Journal.File
        }
        else {
            Move-Item -LiteralPath $plan.Journal.File -Destination ($plan.Journal.File + ".undone") -Force
        }
    }
    catch { }

    $report.Add("")
    $report.Add("Done. The updater will download the newer version again at its next check unless you stop it.")

    $report -join "`r`n"
}


# ------------------------------------------------------------
# Uninstall
# ------------------------------------------------------------

if ($Uninstall) {

    Write-Host "This removes the Biamp Updater from this PC:"
    Write-Host "  - the scheduled tasks '$TaskName' and '$noticeTaskName'"
    Write-Host "  - the Biamp Updater Options icons on the Desktop and in the Start menu"
    Write-Host "  - $InstallDir (logs, run history, undo records)"
    Write-Host ""
    Write-Host "Downloaded software and firmware are NOT deleted."
    Write-Host ""

    if (-not $Yes) {

        $answer = Read-Host "Remove the updater now? [y/N]"

        if ($answer -notmatch '^(y|yes)$') {
            Write-Host "Nothing was removed."
            return
        }
    }

    Stop-RunningUpdater
    Stop-OpenNotice

    # If Windows will not let the tasks be removed, stop here and remove nothing
    # else: deleting the files while the tasks remain would leave broken tasks.
    if ($task) {

        if (-not (Invoke-TaskChange -Action "remove" -Change { Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction Stop })) {
            Write-Host ""
            Write-Host "Nothing else was removed."
            return
        }

        Write-Host "Removed the scheduled task."
    }

    if ($noticeTask) {

        if (-not (Invoke-TaskChange -Action "remove" -Change { Unregister-ScheduledTask -TaskName $noticeTaskName -Confirm:$false -ErrorAction Stop })) {
            Write-Host ""
            Write-Host "The main task was removed but the notice task was not, and nothing else was removed."
            return
        }
    }

    $desktop     = [Environment]::GetFolderPath("Desktop")
    $startFolder = Join-Path ([Environment]::GetFolderPath("Programs")) "Biamp Updater"

    Remove-Item (Join-Path $desktop $optionsLinkName) -Force -ErrorAction SilentlyContinue
    Remove-Item $startFolder -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Removed the icons."

    # Windows will not delete a folder a program is standing in, and this window
    # may have been started inside the install folder. Step out of it first.
    # (Set-Location only moves PowerShell's own location; the process's working
    # folder, the one Windows checks, has to be moved as well.)
    try {
        Set-Location $env:TEMP
        [System.IO.Directory]::SetCurrentDirectory($env:TEMP)
    }
    catch { }

    try {
        Remove-Item $InstallDir -Recurse -Force
        Write-Host "Removed $InstallDir."
    }
    catch {
        Write-Warning "Could not remove $InstallDir ($($_.Exception.Message)). Close any window that is open in that folder and delete it yourself."
    }

    Write-Host ""
    Write-Host "Still on this PC (remove yourself if you want):"

    if ($biampFolder) {
        Write-Host "  - Your Biamp software folder: $biampFolder"
    }

    if ($firmwareFolder) {
        Write-Host "  - Your Biamp firmware folder: $firmwareFolder"
    }

    Write-Host "  - PowerShell 7 (Settings > Apps > Installed apps)"
    return
}

if ($UndoLastUpdate) {

    $plan = Get-UndoPlan

    Write-Host $plan.Text

    if (-not $plan.Can) { return }

    if (-not $Yes) {

        Write-Host ""
        $answer = Read-Host "Undo it now? [y/N]"

        if ($answer -notmatch '^(y|yes)$') {
            Write-Host "Nothing was changed."
            return
        }
    }

    Write-Host ""
    Write-Host (Invoke-UndoLastUpdate)
    return
}


# ------------------------------------------------------------
# Options window (no switch): shows the status, then one-key choices
# ------------------------------------------------------------

try { $Host.UI.RawUI.WindowTitle = "Biamp Updater Options" } catch { }

# One key, no Enter, no copying of commands. If there is no real console (for
# example when input is redirected) it falls back to typing a letter and Enter.
function Read-MenuKey {

    try {

        $pressed = [Console]::ReadKey($true)

        if ($pressed.Key -eq "Enter") {
            return ""
        }

        return $pressed.KeyChar.ToString().ToUpper()
    }
    catch {

        $typed = Read-Host "Choose"

        if ($null -eq $typed) {
            return ""
        }

        return $typed.Trim().ToUpper()
    }
}

function Show-Status {

    $current = Get-UpdaterTask

    Write-Host ""
    Write-Host "============================================================"
    Write-Host " Biamp Updater"
    Write-Host "============================================================"

    if (-not $current) {
        Write-Host " Updater:   its scheduled task '$TaskName' was not found"
    }
    elseif ($current.State -eq "Disabled") {
        Write-Host " Updater:   STOPPED (it will not check at logon or after sleep)"
    }
    elseif (Test-UpdaterRunning) {
        Write-Host " Updater:   checking for an update right now"
    }
    else {
        Write-Host " Updater:   ON (checks at logon and after sleep)"
    }

    if (Test-Path $historyFile) {

        $last = (Get-Content $historyFile -Tail 1)

        if ($last.Length -gt 100) {
            $last = $last.Substring(0, 97) + "..."
        }

        Write-Host " Last check: $last"
    }
    else {
        Write-Host " Last check: none yet"
    }

    if ($biampFolder)    { Write-Host " Software:   $biampFolder" }
    if ($firmwareFolder) { Write-Host " Firmware:   $firmwareFolder" }
    Write-Host " Keeping:    $(Get-ProductsStatusText)"

    Write-Host "------------------------------------------------------------"
}

function Show-Menu {

    $current = Get-UpdaterTask

    Write-Host "Press one key:"
    Write-Host ""

    if ($current -and $current.State -eq "Disabled") {
        Write-Host "   R       Resume the updater"
    }
    else {
        Write-Host "   S       Stop the updater (nothing is deleted)"
    }

    Write-Host "   H       Open the run history (one dated line per attempt)"

    if ($biampFolder) {
        Write-Host "   F       Open the software folder"
    }

    Write-Host "   C       Check for updates now"
    Write-Host "   U       Undo the last software update (asks you to confirm first)"
    Write-Host "   X       Remove the updater from this PC (asks you to confirm first)"
    Write-Host "   Enter   Close this window"
    Write-Host ""
}

# ------------------------------------------------------------
# The window (default when a person opens it; the console menu below is used
# with -NoGui or when input is redirected, as in the automated tests)
# ------------------------------------------------------------

function Get-OptionsStatus {

    # The same facts the console status block shows, as data.
    $current = Get-UpdaterTask

    $status = @{
        TaskFound = [bool]$current
        Stopped   = [bool]($current -and $current.State -eq "Disabled")
    }

    if (-not $current) {
        $status.Updater = "Its scheduled task '$TaskName' was not found"
    }
    elseif ($current.State -eq "Disabled") {
        $status.Updater = "STOPPED (it will not check at logon or after sleep)"
    }
    elseif (Test-UpdaterRunning) {
        $status.Updater = "Checking for an update right now"
    }
    else {
        $status.Updater = "ON (checks at logon and after sleep)"
    }

    $status.LastCheck = if (Test-Path $historyFile) { (Get-Content $historyFile -Tail 1) } else { "None yet" }
    $status.Software  = if ($biampFolder) { $biampFolder } else { "Not set" }
    $status.Firmware  = if ($firmwareFolder) { $firmwareFolder } else { "Not set" }
    $status.Products  = Get-ProductsStatusText

    $status
}

function Show-OptionsWindow {

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    # Windows will not delete a folder a program is standing in, and this window
    # may have been started inside the install folder.
    try {
        Set-Location $env:TEMP
        [System.IO.Directory]::SetCurrentDirectory($env:TEMP)
    }
    catch { }

    # Hide the console this script was started in, but only if it is ours alone
    # (not a terminal the person opened and is still using).
    try {
        Add-Type -Namespace BiampOpt -Name Native -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern System.IntPtr GetConsoleWindow();
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern uint GetConsoleProcessList(uint[] list, uint count);
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool ShowWindow(System.IntPtr hWnd, int cmd);
'@
        $consoleWindow = [BiampOpt.Native]::GetConsoleWindow()
        $ids = New-Object 'uint32[]' 4
        if ($consoleWindow -ne [IntPtr]::Zero -and [BiampOpt.Native]::GetConsoleProcessList($ids, 4) -le 1) {
            [void][BiampOpt.Native]::ShowWindow($consoleWindow, 0)
        }
    }
    catch { }

    $global:BOptForm = New-Object System.Windows.Forms.Form
    $form = $global:BOptForm
    $form.Text = "Biamp Updater Options"
    $form.ClientSize = New-Object System.Drawing.Size(600, 580)
    $form.StartPosition = "CenterScreen"
    $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false
    $form.MinimizeBox = $true
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    function Add-Label ($text, $x, $y, $w, $h, $bold) {
        $l = New-Object System.Windows.Forms.Label
        $l.Text = $text; $l.Location = New-Object System.Drawing.Point($x, $y); $l.Size = New-Object System.Drawing.Size($w, $h)
        if ($bold) { $l.Font = New-Object System.Drawing.Font("Segoe UI", 9.5, [System.Drawing.FontStyle]::Bold) }
        $form.Controls.Add($l); $l
    }

    $title = Add-Label "Biamp Updater" 20 14 560 28 $true
    $title.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)

    $rows = @(
        @{ Key = "Updater";   Caption = "Updater";    Height = 22 },
        @{ Key = "LastCheck"; Caption = "Last check"; Height = 40 },
        @{ Key = "Software";  Caption = "Software";   Height = 40 },
        @{ Key = "Firmware";  Caption = "Firmware";   Height = 40 },
        @{ Key = "Products";  Caption = "Keeping";    Height = 44 }
    )
    $global:BOptValues = @{}
    $y = 54
    foreach ($row in $rows) {
        [void](Add-Label $row.Caption 20 $y 100 $row.Height $true)
        $value = Add-Label "" 125 $y 455 $row.Height $false
        $value.Name = "Status" + $row.Key
        $global:BOptValues[$row.Key] = $value
        $y += $row.Height + 4
    }

    $line = New-Object System.Windows.Forms.Label
    $line.BorderStyle = "Fixed3D"; $line.Location = New-Object System.Drawing.Point(20, 272); $line.Size = New-Object System.Drawing.Size(560, 2)
    $form.Controls.Add($line)

    function Add-Button ($name, $text, $x, $y) {
        $b = New-Object System.Windows.Forms.Button
        $b.Name = $name; $b.Text = $text
        $b.Location = New-Object System.Drawing.Point($x, $y); $b.Size = New-Object System.Drawing.Size(275, 36)
        $form.Controls.Add($b); $b
    }

    $btnCheck    = Add-Button "CheckNow"           "Check for updates now"                20  286
    $global:BOptStopResume = Add-Button "StopResume" "Stop updater"                       305 286
    $btnProducts = Add-Button "ChooseProducts"     "Choose software and firmware..."      20  330
    $btnHistory  = Add-Button "OpenHistory"        "Open run history"                     305 330
    $btnFolder   = Add-Button "OpenFolder"         "Open software folder"                 20  374
    $btnFwFolder = Add-Button "OpenFirmwareFolder" "Open firmware folder"                 305 374
    $btnUndo     = Add-Button "UndoLastUpdate"     "Undo last software update..."         20  418
    $btnRemove   = Add-Button "RemoveUpdater"      "Remove updater..."                    305 418
    $global:BOptErrorReports = Add-Button "ToggleErrorReports" "Error reports: on (click to turn off)" 20 462
    $btnClose    = Add-Button "Close"              "Close"                                305 462

    $note = Add-Label "Opening this window changes nothing by itself. Stopping the updater deletes nothing. Software: older versions are moved to the Archive folder. Firmware: older files are deleted when a new one arrives and cannot be undone. Firmware is only downloaded; loading it into the devices is still done by hand." 20 510 560 58 $false
    $note.ForeColor = [System.Drawing.Color]::DimGray

    function Show-Box ($text, $buttons = "OK", $icon = "Information") {
        [System.Windows.Forms.MessageBox]::Show($global:BOptForm, $text, "Biamp Updater Options", $buttons, $icon)
    }

    function Update-OptionsStatus {
        $st = Get-OptionsStatus
        $global:BOptValues["Updater"].Text   = $st.Updater
        $global:BOptValues["LastCheck"].Text = $st.LastCheck
        $global:BOptValues["Software"].Text  = $st.Software
        $global:BOptValues["Firmware"].Text  = $st.Firmware
        $global:BOptValues["Products"].Text  = $st.Products
        $global:BOptStopResume.Text = if ($st.Stopped) { "Resume updater" } else { "Stop updater" }
        $global:BOptStopResume.Enabled = $st.TaskFound
    }

    # Every handler is wrapped so an error can never escape into Windows Forms'
    # "unhandled exception" box (a timer would repeat it every tick).
    function Invoke-Safely ($body) {
        try { & $body }
        catch {
            try { [void](Show-Box "Something went wrong and nothing further was changed.`r`n`r`n$($_.Exception.Message)" "OK" "Warning") } catch { }
        }
    }

    $global:BOptStopResume.Add_Click({ Invoke-Safely {
        $current = Get-UpdaterTask
        if (-not $current) {
            [void](Show-Box "The scheduled task '$TaskName' was not found, so there is nothing to stop or resume." "OK" "Warning")
        }
        elseif ($current.State -eq "Disabled") {
            if (Invoke-TaskChange -Quiet -Action "enable" -Change { Enable-ScheduledTask -TaskName $TaskName -ErrorAction Stop | Out-Null }) {
                [void](Show-Box "Resumed. The updater will run at the next logon or after the PC wakes from sleep.")
            }
            else { [void](Show-Box $global:BOptTaskMessage "OK" "Warning") }
        }
        else {
            $stopped = Invoke-TaskChange -Quiet -Action "disable" -Change {
                Disable-ScheduledTask -TaskName $TaskName -ErrorAction Stop | Out-Null
                Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
            }
            Stop-RunningUpdater
            if ($stopped) {
                [void](Show-Box "Stopped. It will not check for updates at logon or after sleep. Nothing was deleted.")
            }
            else {
                [void](Show-Box ("NOT fully stopped: any run in progress was ended, but its scheduled task could not be disabled, so it WILL run again at the next logon or wake.`r`n`r`n" + $global:BOptTaskMessage) "OK" "Warning")
            }
        }
        Update-OptionsStatus
    } })

    $btnCheck.Add_Click({ Invoke-Safely {
        $current = Get-UpdaterTask
        if (-not $current) {
            [void](Show-Box "The scheduled task '$TaskName' was not found, so the updater cannot be started." "OK" "Warning")
        }
        elseif ($current.State -eq "Disabled") {
            [void](Show-Box "The updater is stopped. Click 'Resume updater' first, then check for updates." "OK" "Warning")
        }
        elseif (Test-UpdaterRunning) {
            [void](Show-Box "The updater is already checking for updates right now.")
        }
        elseif (Invoke-TaskChange -Quiet -Action "start" -Change { Start-ScheduledTask -TaskName $TaskName -ErrorAction Stop }) {
            [void](Show-Box "The check has started in the background. If something new is found you will get a notice. The Last check line above shows the result when it finishes.")
        }
        else { [void](Show-Box $global:BOptTaskMessage "OK" "Warning") }
        Update-OptionsStatus
    } })

    $btnHistory.Add_Click({ Invoke-Safely {
        if (Test-Path $historyFile) { Start-Process -FilePath "notepad.exe" -ArgumentList "`"$historyFile`"" }
        else { [void](Show-Box "There is no run history yet.") }
    } })

    $btnFolder.Add_Click({ Invoke-Safely {
        if ($biampFolder -and (Test-Path $biampFolder)) { Start-Process -FilePath "explorer.exe" -ArgumentList "`"$biampFolder`"" }
        else { [void](Show-Box "The software folder does not exist yet:`r`n$biampFolder") }
    } })

    $btnFwFolder.Add_Click({ Invoke-Safely {
        if ($firmwareFolder -and (Test-Path $firmwareFolder)) { Start-Process -FilePath "explorer.exe" -ArgumentList "`"$firmwareFolder`"" }
        elseif ($firmwareFolder) { [void](Show-Box "The firmware folder does not exist yet (it is created when the first firmware is downloaded):`r`n$firmwareFolder") }
        else { [void](Show-Box "No firmware folder is set.") }
    } })

    $btnProducts.Add_Click({ Invoke-Safely {

        $now = @(Get-EnabledProducts)

        $d = New-Object System.Windows.Forms.Form
        $d.Text = "Choose software and firmware"
        $d.ClientSize = New-Object System.Drawing.Size(520, 330)
        $d.StartPosition = "CenterParent"; $d.FormBorderStyle = "FixedDialog"
        $d.MaximizeBox = $false; $d.MinimizeBox = $false; $d.ShowInTaskbar = $false
        $d.Font = $global:BOptForm.Font

        $global:BProd = @{ Form = $d; Checks = @{}; Saved = $false }

        $y = 18
        foreach ($p in $productChoices) {
            $c = New-Object System.Windows.Forms.CheckBox
            $c.Name = "Program_" + $p.Key; $c.Text = $p.Name
            $c.Location = New-Object System.Drawing.Point(24, $y); $c.Size = New-Object System.Drawing.Size(470, 24)
            if ($p.Supported) { $c.Checked = ($now -contains $p.Key) } else { $c.Checked = $false; $c.Enabled = $false }
            $d.Controls.Add($c)
            $global:BProd.Checks[$p.Key] = $c
            $y += 28
        }

        $hint = New-Object System.Windows.Forms.Label
        $hint.Location = New-Object System.Drawing.Point(24, 192); $hint.Size = New-Object System.Drawing.Size(472, 70)
        $hint.Text = "Changes apply from the next check. Software: older versions go to the Archive folder. Firmware: older files are deleted when a new one arrives."
        $hint.ForeColor = [System.Drawing.Color]::DimGray
        $d.Controls.Add($hint)

        $save = New-Object System.Windows.Forms.Button
        $save.Name = "ProductsSave"; $save.Text = "Save"
        $save.Location = New-Object System.Drawing.Point(300, 278); $save.Size = New-Object System.Drawing.Size(100, 34)
        $cancel = New-Object System.Windows.Forms.Button
        $cancel.Name = "ProductsCancel"; $cancel.Text = "Cancel"; $cancel.DialogResult = "Cancel"
        $cancel.Location = New-Object System.Drawing.Point(410, 278); $cancel.Size = New-Object System.Drawing.Size(90, 34)
        $d.Controls.AddRange(@($save, $cancel)); $d.CancelButton = $cancel

        $save.Add_Click({ try {

            $ticked = @($global:BProd.Checks.Keys | Where-Object { $global:BProd.Checks[$_].Checked })

            if ($ticked.Count -eq 0) {
                [void][System.Windows.Forms.MessageBox]::Show($global:BProd.Form, "Tick at least one item. To stop the updater completely, use Stop updater instead.", "Choose software and firmware", "OK", "Information")
                return
            }

            $cfg = Get-Content $configFile -Raw | ConvertFrom-Json
            $cfg | Add-Member -NotePropertyName EnabledProducts -NotePropertyValue @($ticked) -Force

            $tmp = "$configFile.tmp"
            $cfg | ConvertTo-Json -Depth 8 | Set-Content -Path $tmp -Encoding UTF8
            Move-Item -LiteralPath $tmp -Destination $configFile -Force

            $global:BProd.Saved = $true
            $global:BProd.Form.DialogResult = "OK"
        } catch {
            [void][System.Windows.Forms.MessageBox]::Show($global:BProd.Form, "The settings could not be saved. Nothing was changed.`r`n`r`n$($_.Exception.Message)", "Choose software and firmware", "OK", "Warning")
        } })

        [void]$d.ShowDialog($global:BOptForm)
        $d.Dispose()

        if ($global:BProd.Saved) {
            [void](Show-Box "Saved. This will be kept up to date from the next check (or click Check for updates now):`r`n`r`n$(Get-ProductsStatusText)")
        }
        Update-OptionsStatus
    } })

    $btnUndo.Add_Click({ Invoke-Safely {

        $plan = Get-UndoPlan

        if (-not $plan.Can) {
            [void](Show-Box $plan.Text)
            return
        }

        $answer = Show-Box ($plan.Text + "`r`n`r`nUndo it now?") "YesNo" "Question"

        if ($answer -eq "Yes") {
            [void](Show-Box (Invoke-UndoLastUpdate))
        }
        Update-OptionsStatus
    } })

    $btnRemove.Add_Click({ Invoke-Safely {
        $dialog = New-Object System.Windows.Forms.Form
        $dialog.Text = "Remove the Biamp Updater"
        $dialog.ClientSize = New-Object System.Drawing.Size(560, 250)
        $dialog.StartPosition = "CenterParent"; $dialog.FormBorderStyle = "FixedDialog"
        $dialog.MaximizeBox = $false; $dialog.MinimizeBox = $false; $dialog.ShowInTaskbar = $false
        $dialog.Font = $global:BOptForm.Font

        $info = New-Object System.Windows.Forms.Label
        $info.Location = New-Object System.Drawing.Point(20, 16); $info.Size = New-Object System.Drawing.Size(520, 170)
        $info.Text = "This removes the Biamp Updater from this PC:`r`n`r`n" +
            "  - the scheduled tasks '$TaskName' and '$noticeTaskName'`r`n" +
            "  - the Biamp Updater Options icons on the Desktop and in the Start menu`r`n" +
            "  - $InstallDir (logs, run history, undo records)`r`n`r`n" +
            "The Biamp software and firmware you already downloaded are NOT deleted."
        $dialog.Controls.Add($info)

        $ok = New-Object System.Windows.Forms.Button
        $ok.Name = "ConfirmRemove"; $ok.Text = "Remove updater"; $ok.DialogResult = "OK"
        $ok.Location = New-Object System.Drawing.Point(250, 196); $ok.Size = New-Object System.Drawing.Size(150, 36)
        $cancel = New-Object System.Windows.Forms.Button
        $cancel.Name = "CancelRemove"; $cancel.Text = "Cancel"; $cancel.DialogResult = "Cancel"
        $cancel.Location = New-Object System.Drawing.Point(410, 196); $cancel.Size = New-Object System.Drawing.Size(130, 36)
        $dialog.Controls.AddRange(@($ok, $cancel)); $dialog.CancelButton = $cancel

        $answer = $dialog.ShowDialog($global:BOptForm)
        $dialog.Dispose()

        if ($answer -eq "OK") {

            $global:BOptTimer.Stop()

            # The removal runs in its own hidden process started outside the install
            # folder (so the folder can be deleted); its report is read back here.
            $report = Join-Path $env:TEMP ("biamp-remove-" + [guid]::NewGuid().ToString("N").Substring(0, 8) + ".txt")
            $argList = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`"", "-Uninstall", "-Yes", "-NoGui", "-InstallDir", "`"$InstallDir`"", "-TaskName", "`"$TaskName`"")

            $pwshPath = (Get-Process -Id $PID).Path
            $child = Start-Process -FilePath $pwshPath -WorkingDirectory $env:TEMP -WindowStyle Hidden -PassThru -ArgumentList $argList -RedirectStandardOutput $report

            $global:BOptForm.Text = "Biamp Updater Options - removing..."
            $global:BOptForm.Enabled = $false
            while (-not $child.HasExited) {
                [System.Windows.Forms.Application]::DoEvents()
                Start-Sleep -Milliseconds 100
            }
            $global:BOptForm.Enabled = $true

            $result = if (Test-Path $report) { (Get-Content $report -Raw) } else { "" }
            Remove-Item $report -Force -ErrorAction SilentlyContinue
            [void](Show-Box ("Removal finished.`r`n`r`n" + "$result".Trim()))
            $global:BOptForm.Close()
        }
    } })

    # Error reports on/off: saved to the settings file at once (a missing setting means on).
    # Turning them off also deletes reports still waiting to be sent.
    function Update-ErrorReportsButton {
        $on = $true
        try { if ((Get-Content $configFile -Raw | ConvertFrom-Json).ErrorReporting -eq $false) { $on = $false } } catch { }
        $global:BOptErrorReports.Text = if ($on) { "Error reports: on (click to turn off)" } else { "Error reports: off (click to turn on)" }
        $on
    }

    $global:BOptErrorReports.Visible = [bool](Get-Command Set-ErrorReporting -CommandType Function -ErrorAction SilentlyContinue)
    [void](Update-ErrorReportsButton)

    $global:BOptErrorReports.Add_Click({ Invoke-Safely {
        $on = Update-ErrorReportsButton
        if (-not (Set-ErrorReporting -ConfigPath $configFile -Enabled (-not $on))) {
            [void](Show-Box "The error reports setting could not be saved:`r`n$configFile" "OK" "Warning")
        }
        [void](Update-ErrorReportsButton)
    } })

    $btnClose.Add_Click({ $global:BOptForm.Close() })
    $form.CancelButton = $btnClose

    $global:BOptTimer = New-Object System.Windows.Forms.Timer
    $global:BOptTimer.Interval = 5000
    $global:BOptTimer.Add_Tick({ try { Update-OptionsStatus } catch { } })

    $form.Add_Shown({ try { Update-OptionsStatus } catch { }; try { $global:BOptTimer.Start() } catch { } })

    [void]$form.ShowDialog()
    $global:BOptTimer.Stop()
}

$useGui = -not $NoGui
try { if ([Console]::IsInputRedirected) { $useGui = $false } } catch { }

if ($useGui) {
    Show-OptionsWindow
    return
}


while ($true) {

    Show-Status
    Show-Menu

    $choice = Read-MenuKey

    if ($choice -eq "") {
        return
    }

    if ($choice -eq "S") {

        $current = Get-UpdaterTask

        if (-not $current) {
            Write-Host "The scheduled task '$TaskName' was not found, so there is nothing to stop."
            continue
        }

        if ($current.State -eq "Disabled") {
            Write-Host "The updater is already stopped."
            continue
        }

        $stopped = Invoke-TaskChange -Action "disable" -Change {
            Disable-ScheduledTask -TaskName $TaskName -ErrorAction Stop | Out-Null
            Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
        }

        Stop-RunningUpdater

        if ($stopped) {
            Write-Host "Stopped. It will not check for updates at logon or after sleep. Nothing was deleted."
        }
        else {
            Write-Host "NOT fully stopped: any run in progress was ended, but its scheduled task could"
            Write-Host "not be disabled, so it WILL run again at the next logon or wake."
        }

        continue
    }

    if ($choice -eq "R") {

        $current = Get-UpdaterTask

        if (-not $current) {
            Write-Host "The scheduled task '$TaskName' was not found, so there is nothing to resume."
            continue
        }

        if ($current.State -ne "Disabled") {
            Write-Host "The updater is already on."
            continue
        }

        if (Invoke-TaskChange -Action "enable" -Change { Enable-ScheduledTask -TaskName $TaskName -ErrorAction Stop | Out-Null }) {
            Write-Host "Resumed. The updater will run at the next logon or after the PC wakes from sleep."
        }

        continue
    }

    if ($choice -eq "H") {

        if (Test-Path $historyFile) {
            Start-Process -FilePath "notepad.exe" -ArgumentList "`"$historyFile`""
        }
        else {
            Write-Host "There is no run history yet: $historyFile"
        }

        continue
    }

    if ($choice -eq "F" -and $biampFolder) {

        if (Test-Path $biampFolder) {
            Start-Process -FilePath "explorer.exe" -ArgumentList "`"$biampFolder`""
        }
        else {
            Write-Host "That folder does not exist yet: $biampFolder"
        }

        continue
    }

    if ($choice -eq "C") {

        $current = Get-UpdaterTask

        if (-not $current) {
            Write-Host "The scheduled task '$TaskName' was not found, so the updater cannot be started."
        }
        elseif ($current.State -eq "Disabled") {
            Write-Host "The updater is stopped. Resume it first (R), then check."
        }
        elseif (Test-UpdaterRunning) {
            Write-Host "The updater is already checking for updates right now."
        }
        elseif (Invoke-TaskChange -Action "start" -Change { Start-ScheduledTask -TaskName $TaskName -ErrorAction Stop }) {
            Write-Host "The check has started in the background. See the run history (H) for the result."
        }

        continue
    }

    if ($choice -eq "U") {

        $plan = Get-UndoPlan

        Write-Host ""
        Write-Host $plan.Text

        if ($plan.Can) {

            Write-Host ""
            $answer = Read-Host "Undo it now? [y/N]"

            if ($answer -match '^(y|yes)$') {
                Write-Host ""
                Write-Host (Invoke-UndoLastUpdate)
            }
            else {
                Write-Host "Nothing was changed."
            }
        }

        continue
    }

    if ($choice -eq "X") {

        # Open the removal in its own window (it asks before it removes anything),
        # then close this one.
        $pwshPath = (Get-Process -Id $PID).Path

        # (Started in the temp folder, not in the install folder, so the install
        # folder can be deleted.)
        Start-Process -FilePath $pwshPath -WorkingDirectory $env:TEMP -ArgumentList @(
            "-NoProfile",
            "-ExecutionPolicy", "Bypass",
            "-File", "`"$PSCommandPath`"",
            "-Uninstall",
            "-InstallDir", "`"$InstallDir`""
        )

        return
    }

    Write-Host "That key is not one of the choices above."
}
