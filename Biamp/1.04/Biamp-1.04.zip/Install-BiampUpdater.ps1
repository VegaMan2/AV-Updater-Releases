# ============================================================
# Biamp Updater -- setup (run once per machine and user)
#
# Asks for:
#   - the folder to keep Biamp software in (firmware goes in a Firmware folder)
#   - which Biamp programs and firmware files to keep up to date
#   - Wi-Fi networks to avoid (for example a phone hotspot)
# There is no sign-in: Biamp's download page is public. Setup makes ONE
# request to the Biamp page to prove it can be reached. Then it installs the
# updater to %LOCALAPPDATA%\BiampUpdater, registers a scheduled task that runs
# at logon and on wake from sleep, and adds a "Biamp Updater Options" icon
# (Desktop and Start menu).
#
# Cancelling (or a failure) before setup finishes removes everything this
# run created. After setup completes nothing is removed automatically.
#
# Usage:
#   Double-click Setup.cmd, or from any PowerShell:
#   powershell -ExecutionPolicy Bypass -File Install-BiampUpdater.ps1
#   (can start in Windows PowerShell 5.1; if PowerShell 7 is missing, setup offers to
#   install it, then continues in PowerShell 7)
#
#   ...Install-BiampUpdater.ps1 -InstallPrerequisites   (install PowerShell 7 without asking)
#   pwsh -File Install-BiampUpdater.ps1 -DestinationRoot "D:\For Install\Biamp" -NoGui
#   pwsh -File Install-BiampUpdater.ps1 -Uninstall
#
#   Error reports (a short report when the updater hits an error, never passwords) are on
#   unless this PC turned them off before. -NoErrorReports turns them off, -ErrorReports
#   turns them back on; the setup window has a tick box for it.
# ============================================================

# WINDOW CONTROL IDS (UI Automation id = control Name; window tests use these, keep them in step; <key> = a Key in products.json):
#   Setup window:  FolderBox BrowseButton FolderPreview FirmwareFolderBox FirmwareBrowse ProgramsAll ProgramsNone
#                  Program_<key> ChooseNetworks NetworksSummary AdvancedToggle ErrorReportsCheck TaskNameBox InstallButton CancelButton
#   Wi-Fi window:  NetworkList AddNetworkBox AddNetworkButton NetworksOk NetworksCancel
#   Finish window: DoneTitle OpenOptions DoneClose
[CmdletBinding()]
param (
    [string]$InstallDir = (Join-Path $env:LOCALAPPDATA "BiampUpdater"),
    [string]$DestinationRoot,
    [string]$FirmwareFolder,             # default: a Firmware folder inside the Biamp folder
    [string[]]$BlockedSSIDs = @(),
    [string]$TaskName = "Biamp Updater",
    [string[]]$Products,                 # keys to keep up to date (default: all five)
    [string]$PageUrl,                    # default: PageUrl in products.json
    [switch]$InstallPrerequisites,
    [switch]$ReplaceExistingTask,
    [switch]$ConfigureNetworks,
    [switch]$SkipServerCheck,            # tests only: do not contact Biamp
    [switch]$SkipTask,
    [switch]$RunNow,
    [switch]$NoGui,                      # no windows (also used automatically when input is redirected)
    [switch]$NoErrorReports,             # turn error reports off
    [switch]$ErrorReports,               # turn error reports back on after an earlier opt-out
    [switch]$Uninstall
)

$ErrorActionPreference = "Stop"

# -File runs pass arrays as one comma-separated string.
$BlockedSSIDs = @($BlockedSSIDs | ForEach-Object { $_ -split "," } | ForEach-Object { $_.Trim() } | Where-Object { $_ })
$Products     = @($Products     | ForEach-Object { $_ -split "," } | ForEach-Object { $_.Trim().ToLower() } | Where-Object { $_ })

$configFile        = Join-Path $InstallDir "config.json"
$updaterName       = "Biamp-Updater.ps1"
$launcherName      = "Run-Hidden.vbs"
$optionsScriptName = "Options-BiampUpdater.ps1"
$optionsLinkName   = "Biamp Updater Options.lnk"
$noticeName        = "Show-BiampNotice.ps1"
$noticeLauncher    = "Run-Notice.vbs"
$noticeTaskName    = "$TaskName Notice"
$reportingFileNames = @("Reporting.ps1", "reporting.json", "version.json")
$ownFiles          = @($updaterName, $optionsScriptName, $noticeName, "products.json") + $reportingFileNames

# What the updater can keep current: the ONE list is products.json next to this script (engine, Setup and Options all read it).
$catalogDoc = Get-Content -LiteralPath (Join-Path $PSScriptRoot "products.json") -Raw | ConvertFrom-Json
$productChoices = @($catalogDoc.Products | ForEach-Object {
    [pscustomobject]@{ Key = $_.Key; Name = $_.UiName; Kind = $_.Kind; Supported = [bool]$_.Supported }
})
# The page address is in the same file; -PageUrl overrides it (tests, or a moved page).
if (-not $PageUrl) { $PageUrl = [string]$catalogDoc.PageUrl }
$supportedKeys = @($productChoices | Where-Object { $_.Supported } | ForEach-Object { $_.Key })
$firmwareKeys  = @($productChoices | Where-Object { $_.Kind -eq "Firmware" } | ForEach-Object { $_.Key })

# Windows instead of console prompts, unless -NoGui or input is redirected (automated tests).
$useGui = -not $NoGui

try { if ([Console]::IsInputRedirected) { $useGui = $false } } catch { }

$wizardDone = $false


# ------------------------------------------------------------
# Uninstall
# ------------------------------------------------------------

if ($Uninstall) {

    # Same removal as the Remove updater button in the Biamp Updater Options window.
    & (Join-Path $PSScriptRoot $optionsScriptName) -Uninstall -InstallDir $InstallDir -TaskName $TaskName
    return
}


# ------------------------------------------------------------
# The one contact with Biamp during setup
# ------------------------------------------------------------

# Proves the Biamp download page can be reached and still lists downloads.
# Throws a plain-wording message on any problem.
function Test-BiampPage {

    param ([string]$Url)

    if ($SkipServerCheck) { return $true }

    try {
        $response = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 60
    }
    catch {
        throw "Could not reach the Biamp download page ($Url): $($_.Exception.Message) Check the internet connection and try again."
    }

    if ($response.Content -notmatch 'downloads\.biamp\.com') {
        throw "The Biamp page was reached but it lists no downloads (the page may have changed). Setup cannot continue."
    }

    $true
}

function Get-WifiProfileNames {

    $names = foreach ($line in (netsh wlan show profiles 2>$null)) {
        if ($line -match '^\s*(All User Profile|User Profile)\s*:\s*(.+)$') {
            $Matches[2].Trim()
        }
    }

    @($names | Sort-Object -Unique)
}

function Get-CurrentSsid {

    $info = netsh wlan show interfaces 2>$null | Out-String

    if ($info -match '(?m)^\s*SSID\s*:\s*(.+)$') {
        return $Matches[1].Trim()
    }

    return $null
}

function Get-DefaultFirmwareFolder {

    param ([string]$SoftwareFolder)

    if (-not $SoftwareFolder) { return "" }
    Join-Path $SoftwareFolder "Firmware"
}


# ------------------------------------------------------------
# Setup windows (used when a person runs setup; -NoGui and any value given on the
# command line keep the console route)
# ------------------------------------------------------------

function Show-NetworkPicker {

    # Checklist of the PC's saved Wi-Fi networks, plus a box to add a name by hand.
    # Returns the ticked names, or $null if cancelled.
    param ([string[]]$Current = @())

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $profiles    = @(Get-WifiProfileNames)
    $connectedTo = Get-CurrentSsid

    $global:QNet = @{ Names = New-Object System.Collections.ArrayList }

    $form = New-Object System.Windows.Forms.Form
    $global:QNet.Form = $form
    $form.Text = "Wi-Fi networks to avoid"
    $form.ClientSize = New-Object System.Drawing.Size(520, 480)
    $form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false; $form.MinimizeBox = $false
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    $info = New-Object System.Windows.Forms.Label
    $info.Location = New-Object System.Drawing.Point(16, 12); $info.Size = New-Object System.Drawing.Size(488, 66)
    $info.Text = "Biamp downloads are large (the Tesira firmware is about 620 MB). The updater skips the check whenever this PC is connected to a network ticked here, such as a phone hotspot."
    $form.Controls.Add($info)

    $list = New-Object System.Windows.Forms.CheckedListBox
    $list.Name = "NetworkList"; $list.CheckOnClick = $true
    $list.Location = New-Object System.Drawing.Point(16, 84); $list.Size = New-Object System.Drawing.Size(488, 280)
    $form.Controls.Add($list)
    $global:QNet.List = $list

    function Add-NetworkItem ($name, $checked) {
        for ($i = 0; $i -lt $global:QNet.Names.Count; $i++) {
            if ($global:QNet.Names[$i] -eq $name) { $global:QNet.List.SetItemChecked($i, $checked); return }
        }
        [void]$global:QNet.Names.Add($name)
        $text = if ($name -eq $global:QNet.Connected) { "$name   (connected now)" } else { $name }
        [void]$global:QNet.List.Items.Add($text, $checked)
    }

    $global:QNet.Connected = $connectedTo

    foreach ($name in $profiles) { Add-NetworkItem $name ($name -in $Current) }
    foreach ($name in $Current)  { if ($name) { Add-NetworkItem $name $true } }

    $addLabel = New-Object System.Windows.Forms.Label
    $addLabel.Text = "Not listed? Type its name:"
    $addLabel.Location = New-Object System.Drawing.Point(16, 376); $addLabel.Size = New-Object System.Drawing.Size(488, 22)
    $form.Controls.Add($addLabel)

    $box = New-Object System.Windows.Forms.TextBox
    $box.Name = "AddNetworkBox"
    $box.Location = New-Object System.Drawing.Point(16, 400); $box.Size = New-Object System.Drawing.Size(370, 26)
    $form.Controls.Add($box)
    $global:QNet.Box = $box

    $add = New-Object System.Windows.Forms.Button
    $add.Name = "AddNetworkButton"; $add.Text = "Add"
    $add.Location = New-Object System.Drawing.Point(396, 398); $add.Size = New-Object System.Drawing.Size(108, 30)
    $add.Add_Click({
        try {
            $typed = $global:QNet.Box.Text.Trim()
            if ($typed) { Add-NetworkItem $typed $true; $global:QNet.Box.Text = "" }
        } catch { }
    })
    $form.Controls.Add($add)

    $ok = New-Object System.Windows.Forms.Button
    $ok.Name = "NetworksOk"; $ok.Text = "OK"; $ok.DialogResult = "OK"
    $ok.Location = New-Object System.Drawing.Point(290, 440); $ok.Size = New-Object System.Drawing.Size(100, 32)
    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Name = "NetworksCancel"; $cancel.Text = "Cancel"; $cancel.DialogResult = "Cancel"
    $cancel.Location = New-Object System.Drawing.Point(404, 440); $cancel.Size = New-Object System.Drawing.Size(100, 32)
    $form.Controls.AddRange(@($ok, $cancel))
    $form.AcceptButton = $ok; $form.CancelButton = $cancel

    $answer = $form.ShowDialog()

    $picked = $null

    if ($answer -eq "OK") {
        $picked = @()
        for ($i = 0; $i -lt $global:QNet.Names.Count; $i++) {
            if ($list.GetItemChecked($i)) { $picked += $global:QNet.Names[$i] }
        }
    }

    $form.Dispose()
    return $picked
}

function Show-SetupWizard {

    # The one setup window. Returns $null if cancelled; otherwise the chosen values.
    # The Install button checks the Biamp page once and stays in the window if that fails.
    param (
        [string]$StartFolder,
        [string]$StartFirmwareFolder,
        [string[]]$BlockedNow = @(),
        [string]$Task,
        $ProductList,
        [string[]]$Selected,
        [string]$Url,
        [bool]$ErrorReports = $true
    )

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    $global:BS = @{ Blocked = @($BlockedNow); Advanced = $false; Checks = @{}; Url = $Url; Setting = $false; FwManual = $false; FirmwareKeys = @($firmwareKeys) }

    # A firmware folder that is not the usual "<folder>\Firmware" was chosen on purpose earlier: keep it.
    if ($StartFirmwareFolder -and $StartFirmwareFolder -ne (Get-DefaultFirmwareFolder $StartFolder)) { $global:BS.FwManual = $true }

    $form = New-Object System.Windows.Forms.Form
    $global:BS.Form = $form
    $form.Text = "Biamp Updater Setup"
    $form.ClientSize = New-Object System.Drawing.Size(640, 740)
    $form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false; $form.MinimizeBox = $true
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    function Add-Ctl ($control, $name, $x, $y, $w, $h, $text) {
        $c = New-Object $control
        if ($name) { $c.Name = $name }
        $c.Location = New-Object System.Drawing.Point($x, $y); $c.Size = New-Object System.Drawing.Size($w, $h)
        if ($text) { $c.Text = $text }
        $global:BS.Form.Controls.Add($c)
        $c
    }
    function Add-Heading ($text, $y) {
        $l = Add-Ctl System.Windows.Forms.Label $null 20 $y 600 24 $text
        $l.Font = New-Object System.Drawing.Font("Segoe UI", 10.5, [System.Drawing.FontStyle]::Bold)
    }

    $title = Add-Ctl System.Windows.Forms.Label $null 20 12 600 30 "Set up the Biamp Updater"
    $title.Font = New-Object System.Drawing.Font("Segoe UI", 15, [System.Drawing.FontStyle]::Bold)
    [void](Add-Ctl System.Windows.Forms.Label $null 20 46 600 40 "It keeps the newest Biamp software and firmware in a folder of your choice. No sign-in is needed. Nothing is changed on this PC until you click Install.")

    # 1. Folder
    Add-Heading "1. Where should Biamp software be saved?" 92
    $global:BS.Folder = Add-Ctl System.Windows.Forms.TextBox "FolderBox" 20 120 480 26 $StartFolder
    $browse = Add-Ctl System.Windows.Forms.Button "BrowseButton" 510 118 110 30 "Browse..."
    $global:BS.Preview = Add-Ctl System.Windows.Forms.Label "FolderPreview" 20 150 600 22 ""
    $global:BS.Preview.ForeColor = [System.Drawing.Color]::DimGray

    $global:BS.FirmwareFolder = $null   # created below; Update-FolderPreview fills it in

    function Update-FolderPreview {
        $text = $global:BS.Folder.Text.Trim()
        $global:BS.Preview.Text = if ($text) { "Software will go in: " + $text } else { "" }

        # The firmware folder follows the software folder until the person chooses one of their own.
        if ($global:BS.FirmwareFolder -and -not $global:BS.FwManual) {
            $global:BS.Setting = $true
            $global:BS.FirmwareFolder.Text = Get-DefaultFirmwareFolder $text
            $global:BS.Setting = $false
        }
    }
    $global:BS.Folder.Add_TextChanged({ try { Update-FolderPreview } catch { } })
    $browse.Add_Click({
        try {
            $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
            $dialog.Description = "Choose the folder to keep Biamp software in. Software is saved directly in it."
            $dialog.ShowNewFolderButton = $true
            if ($global:BS.Folder.Text.Trim() -and (Test-Path $global:BS.Folder.Text.Trim())) { $dialog.SelectedPath = $global:BS.Folder.Text.Trim() }
            if ($dialog.ShowDialog($global:BS.Form) -eq "OK") { $global:BS.Folder.Text = $dialog.SelectedPath }
        } catch { }
    })

    # 2. Programs and firmware
    Add-Heading "2. Software and firmware to keep up to date" 182
    $y = 210
    foreach ($product in $ProductList) {
        $box = Add-Ctl System.Windows.Forms.CheckBox ("Program_" + $product.Key) 36 $y 420 24 $product.Name
        if ($product.Supported) { $box.Checked = ($Selected -contains $product.Key) }
        else { $box.Checked = $false; $box.Enabled = $false }
        $global:BS.Checks[$product.Key] = $box
        $y += 24
    }
    foreach ($mode in @(@{ Name = "ProgramsAll"; Text = "All"; Value = $true; X = 470 }, @{ Name = "ProgramsNone"; Text = "None"; Value = $false; X = 550 })) {
        $toggleButton = Add-Ctl System.Windows.Forms.Button $mode.Name $mode.X 180 70 26 $mode.Text
        $toggleButton.Tag = $mode.Value
        $toggleButton.Add_Click({
            param ($sender, $e)
            try { foreach ($box in $global:BS.Checks.Values) { if ($box.Enabled) { $box.Checked = [bool]$sender.Tag } } } catch { }
        })
    }
    [void](Add-Ctl System.Windows.Forms.Label $null 20 360 600 60 "Software: when a new version arrives, the old one is moved to an Archive folder. Firmware: the old file is deleted once the new one is checked. Loading firmware into devices is still done by hand.")

    # 3. Firmware folder
    Add-Heading "3. Where should firmware be saved?" 428
    $global:BS.FirmwareFolder = Add-Ctl System.Windows.Forms.TextBox "FirmwareFolderBox" 20 456 480 26 $StartFirmwareFolder
    $global:BS.FirmwareBrowse = Add-Ctl System.Windows.Forms.Button "FirmwareBrowse" 510 454 110 30 "Browse..."
    $global:BS.FirmwareFolder.Add_TextChanged({ try { if (-not $global:BS.Setting) { $global:BS.FwManual = $true } } catch { } })
    $global:BS.FirmwareBrowse.Add_Click({
        try {
            $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
            $dialog.Description = "Choose the folder to keep Biamp firmware in. Firmware is saved directly in it."
            $dialog.ShowNewFolderButton = $true
            if ($global:BS.FirmwareFolder.Text.Trim() -and (Test-Path $global:BS.FirmwareFolder.Text.Trim())) { $dialog.SelectedPath = $global:BS.FirmwareFolder.Text.Trim() }
            if ($dialog.ShowDialog($global:BS.Form) -eq "OK") { $global:BS.FirmwareFolder.Text = $dialog.SelectedPath }
        } catch { }
    })

    # 4. Wi-Fi
    Add-Heading "4. Wi-Fi networks to avoid" 500
    [void](Add-Ctl System.Windows.Forms.Label $null 20 526 600 40 "Some downloads are large (Tesira firmware is about 620 MB). The updater skips the check on any network you choose here, such as a phone hotspot.")
    $global:BS.Networks = Add-Ctl System.Windows.Forms.Label "NetworksSummary" 20 568 480 24 ""
    $choose = Add-Ctl System.Windows.Forms.Button "ChooseNetworks" 510 564 110 30 "Choose..."

    function Update-NetworksSummary {
        $global:BS.Networks.Text = if ($global:BS.Blocked.Count) { "Avoiding: " + ($global:BS.Blocked -join ", ") } else { "None chosen (it will download on any network)" }
    }
    $choose.Add_Click({
        try {
            $picked = Show-NetworkPicker -Current @($global:BS.Blocked)
            if ($null -ne $picked) { $global:BS.Blocked = @($picked); Update-NetworksSummary }
        } catch { }
    })

    # Advanced (collapsed)
    $toggle = Add-Ctl System.Windows.Forms.Button "AdvancedToggle" 20 608 150 28 "Advanced  >"
    $global:BS.ErrorReports = Add-Ctl System.Windows.Forms.CheckBox "ErrorReportsCheck" 190 610 420 24 "Send error reports to help fix bugs"
    $global:BS.ErrorReports.Checked = $ErrorReports
    $global:BS.AdvancedPanel = New-Object System.Windows.Forms.Panel
    $panel = $global:BS.AdvancedPanel
    $panel.Location = New-Object System.Drawing.Point(20, 640); $panel.Size = New-Object System.Drawing.Size(600, 58); $panel.Visible = $false
    $form.Controls.Add($panel)
    $taskLabel = New-Object System.Windows.Forms.Label
    $taskLabel.Text = "Task name (change it for a test install next to a working one):"
    $taskLabel.Location = New-Object System.Drawing.Point(0, 0); $taskLabel.Size = New-Object System.Drawing.Size(600, 22)
    $global:BS.TaskBox = New-Object System.Windows.Forms.TextBox
    $global:BS.TaskBox.Name = "TaskNameBox"; $global:BS.TaskBox.Text = $Task
    $global:BS.TaskBox.Location = New-Object System.Drawing.Point(0, 26); $global:BS.TaskBox.Size = New-Object System.Drawing.Size(400, 26)
    $panel.Controls.AddRange(@($taskLabel, $global:BS.TaskBox))

    $install = Add-Ctl System.Windows.Forms.Button "InstallButton" 400 700 110 34 "Install"
    $cancel  = Add-Ctl System.Windows.Forms.Button "CancelButton" 520 700 100 34 "Cancel"
    $cancel.DialogResult = "Cancel"; $form.CancelButton = $cancel

    $toggle.Add_Click({
        try {
            $global:BS.Advanced = -not $global:BS.Advanced
            $global:BS.AdvancedPanel.Visible = $global:BS.Advanced
        } catch { }
    })

    $install.Add_Click({
        try {
            $form = $global:BS.Form
            $folder = $global:BS.Folder.Text.Trim()
            if (-not $folder) {
                [void][System.Windows.Forms.MessageBox]::Show($form, "Choose the folder to save Biamp software in first.", "Biamp Updater Setup", "OK", "Information")
                return
            }
            if (-not (Test-Path $folder)) {
                [void][System.Windows.Forms.MessageBox]::Show($form, "That folder does not exist:`r`n$folder`r`n`r`nChoose an existing folder (Browse... can make a new one).", "Biamp Updater Setup", "OK", "Information")
                return
            }
            $ticked = @($global:BS.Checks.Keys | Where-Object { $global:BS.Checks[$_].Checked })
            if ($ticked.Count -eq 0) {
                [void][System.Windows.Forms.MessageBox]::Show($form, "Tick at least one item (section 2).", "Biamp Updater Setup", "OK", "Information")
                return
            }
            $fwFolder = $global:BS.FirmwareFolder.Text.Trim()
            if (@($ticked | Where-Object { $_ -in $global:BS.FirmwareKeys }).Count -gt 0) {
                if (-not $fwFolder) {
                    [void][System.Windows.Forms.MessageBox]::Show($form, "Choose the folder to save firmware in (section 3).", "Biamp Updater Setup", "OK", "Information")
                    return
                }
                if ($fwFolder.TrimEnd('\') -ieq $folder.TrimEnd('\')) {
                    [void][System.Windows.Forms.MessageBox]::Show($form, "The firmware folder must be different from the software folder, so firmware and software do not get mixed.", "Biamp Updater Setup", "OK", "Information")
                    return
                }
            }

            # The one contact with Biamp: stay in this window if it fails.
            $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
            try {
                [void](Test-BiampPage -Url $global:BS.Url)
            }
            catch {
                $form.Cursor = [System.Windows.Forms.Cursors]::Default
                [void][System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, "Biamp Updater Setup", "OK", "Warning")
                return
            }
            finally { $form.Cursor = [System.Windows.Forms.Cursors]::Default }

            $form.DialogResult = "OK"
        } catch { }
    })
    $form.AcceptButton = $null

    Update-FolderPreview
    Update-NetworksSummary

    # A screen shorter than the window: let the window scroll instead of cutting off the buttons.
    $workHeight = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Height
    if ($workHeight -lt 800) {
        $form.AutoScroll = $true
        $form.AutoScrollMinSize = New-Object System.Drawing.Size(620, 745)
        $form.ClientSize = New-Object System.Drawing.Size(660, [math]::Max(400, $workHeight - 90))
    }

    $answer = $form.ShowDialog()

    $result = $null

    if ($answer -eq "OK") {

        $taskText = $global:BS.TaskBox.Text.Trim()

        $result = [pscustomobject]@{
            DestinationRoot = $global:BS.Folder.Text.Trim()
            FirmwareFolder  = $global:BS.FirmwareFolder.Text.Trim()
            BlockedSSIDs    = @($global:BS.Blocked)
            Products        = @($global:BS.Checks.Keys | Where-Object { $global:BS.Checks[$_].Checked })
            TaskName        = $(if ($taskText) { $taskText } else { $Task })
            ErrorReports    = $global:BS.ErrorReports.Checked
        }
    }

    $form.Dispose()
    return $result
}

function Show-SetupDone {

    # Finish window. Returns $true if the person asked to open the Options window.
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Biamp Updater Setup"
    $form.ClientSize = New-Object System.Drawing.Size(520, 250)
    $form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false; $form.MinimizeBox = $false; $form.TopMost = $true
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    $title = New-Object System.Windows.Forms.Label
    $title.Name = "DoneTitle"; $title.Text = "Setup complete"
    $title.Font = New-Object System.Drawing.Font("Segoe UI", 15, [System.Drawing.FontStyle]::Bold)
    $title.Location = New-Object System.Drawing.Point(20, 16); $title.Size = New-Object System.Drawing.Size(480, 32)

    $text = New-Object System.Windows.Forms.Label
    $text.Location = New-Object System.Drawing.Point(20, 60); $text.Size = New-Object System.Drawing.Size(480, 120)
    $text.Text = "The updater will check for new Biamp software and firmware at logon and after the PC wakes from sleep.`r`n`r`nTo stop or resume it, check now, undo the last update or remove it, open `"Biamp Updater Options`" on your Desktop or in the Start menu."

    $open = New-Object System.Windows.Forms.Button
    $open.Name = "OpenOptions"; $open.Text = "Open Biamp Updater Options"; $open.DialogResult = "Yes"
    $open.Location = New-Object System.Drawing.Point(100, 196); $open.Size = New-Object System.Drawing.Size(260, 36)
    $close = New-Object System.Windows.Forms.Button
    $close.Name = "DoneClose"; $close.Text = "Close"; $close.DialogResult = "Cancel"
    $close.Location = New-Object System.Drawing.Point(376, 196); $close.Size = New-Object System.Drawing.Size(124, 36)
    $form.Controls.AddRange(@($title, $text, $open, $close)); $form.CancelButton = $close

    $answer = $form.ShowDialog()
    $form.Dispose()

    return ($answer -eq "Yes")
}

function Find-Pwsh {

    $command = Get-Command pwsh.exe -ErrorAction SilentlyContinue

    if ($command) {
        return $command.Source
    }

    # A fresh install is not on PATH in this session yet.
    $default = Join-Path $env:ProgramFiles "PowerShell\7\pwsh.exe"

    if (Test-Path $default) {
        return $default
    }

    return $null
}

function Install-FromMsi {

    # Direct-download fallback when winget is not available.
    param (
        [string]$Name,
        [string]$Url,
        [string]$MsiArguments = ""
    )

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $ProgressPreference = "SilentlyContinue"

    $msi = Join-Path $env:TEMP ("BiampUpdater-" + $Name.Replace(" ", "") + ".msi")

    Write-Host "Downloading $Name..."
    Invoke-WebRequest -Uri $Url -OutFile $msi -UseBasicParsing

    Write-Host "Installing $Name (a Windows permission prompt will appear)..."

    $process = Start-Process msiexec.exe `
        -ArgumentList "/i `"$msi`" /qn $MsiArguments" `
        -Verb RunAs `
        -Wait `
        -PassThru

    Remove-Item $msi -Force -ErrorAction SilentlyContinue

    if ($process.ExitCode -notin 0, 3010) {
        Write-Warning "$Name installer finished with exit code $($process.ExitCode)."
    }
}

function Install-Prerequisite {

    param (
        [string]$Name,
        [string]$WingetId,
        [scriptblock]$Fallback,
        [scriptblock]$IsInstalled
    )

    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue

    if ($winget) {

        Write-Host "Installing $Name with winget (a Windows permission prompt may appear)..."

        & $winget.Source install `
            --id $WingetId `
            --exact `
            --silent `
            --accept-package-agreements `
            --accept-source-agreements

        if (& $IsInstalled) {
            return
        }

        Write-Warning "winget did not complete the $Name install. Trying a direct download."
    }

    try {
        & $Fallback
    }
    catch {
        Write-Warning "Direct download of $Name failed: $($_.Exception.Message)"
    }
}

if ($ConfigureNetworks) {

    if (-not (Test-Path $configFile)) {
        throw "Setup has not been run yet ($configFile not found). Run setup first."
    }

    $existingConfig = Get-Content $configFile -Raw | ConvertFrom-Json
    $existingConfig.BlockedSSIDs = @(Show-NetworkPicker -Current @($existingConfig.BlockedSSIDs))
    $existingConfig | ConvertTo-Json -Depth 6 | Set-Content -Path $configFile -Encoding UTF8

    Write-Host "Saved. Blocked networks: $(@($existingConfig.BlockedSSIDs) -join ', ')"
    return
}


# ------------------------------------------------------------
# Prerequisites: PowerShell 7 (the only one; there is no browser)
# ------------------------------------------------------------

foreach ($required in $ownFiles) {
    if (-not (Test-Path (Join-Path $PSScriptRoot $required))) {
        throw "$required was not found next to this setup script ($PSScriptRoot)."
    }
}

$pwsh = Find-Pwsh

if (-not $pwsh) {

    $installPwsh = $InstallPrerequisites

    if (-not $installPwsh) {

        if ($useGui) {

            Add-Type -AssemblyName System.Windows.Forms

            $message = "This PC is missing PowerShell 7, which runs the updater and its scheduled task.`r`n`r`nSetup can download and install it now (a Windows permission prompt may appear). Setup cannot continue without it.`r`n`r`nInstall it now?  (Yes = install, No = cancel setup)"

            $installPwsh = ([System.Windows.Forms.MessageBox]::Show($message, "Biamp Updater Setup", "YesNo", "Question") -eq "Yes")
        }
        else {
            $answer = (Read-Host "PowerShell 7 is missing and is required. Install it now? [Y/n]").Trim()
            $installPwsh = ($answer -eq "" -or $answer -match '^y(es)?$')
        }
    }

    if (-not $installPwsh) {
        Write-Host "Setup cancelled. Nothing was installed or changed."
        exit 1
    }

    Install-Prerequisite `
        -Name "PowerShell 7" `
        -WingetId "Microsoft.PowerShell" `
        -IsInstalled { [bool](Find-Pwsh) } `
        -Fallback {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

            $release = Invoke-RestMethod `
                "https://api.github.com/repos/PowerShell/PowerShell/releases/latest" `
                -Headers @{ "User-Agent" = "BiampUpdaterSetup" }

            $asset = $release.assets |
                Where-Object { $_.name -like "*win-x64.msi" } |
                Select-Object -First 1

            if (-not $asset) {
                throw "No Windows x64 MSI found in the latest PowerShell release."
            }

            Install-FromMsi -Name "PowerShell 7" -Url $asset.browser_download_url -MsiArguments "ADD_PATH=1"
        }

    $pwsh = Find-Pwsh

    if (-not $pwsh) {
        Write-Host ""
        Write-Host "PowerShell 7 could not be installed automatically. Install it from https://aka.ms/powershell, then run setup again."
        exit 1
    }
}

# This setup may have been started in Windows PowerShell 5.1 so it could
# install PowerShell 7. Continue the rest of setup in PowerShell 7.
if ($PSVersionTable.PSVersion.Major -lt 7) {

    Write-Host "Continuing setup in PowerShell 7..."

    $relaunchArgs = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $PSCommandPath)

    foreach ($name in $PSBoundParameters.Keys) {

        $value = $PSBoundParameters[$name]

        if ($value -is [switch]) {
            if ($value.IsPresent) { $relaunchArgs += "-$name" }
        }
        elseif ($value -is [array]) {
            $relaunchArgs += "-$name"
            $relaunchArgs += ($value -join ",")
        }
        else {
            $relaunchArgs += "-$name"
            $relaunchArgs += [string]$value
        }
    }

    & $pwsh @relaunchArgs
    exit $LASTEXITCODE
}

# Which items to keep current: the command line, else all supported ones. Unknown keys are refused.
if (-not $Products) { $Products = @($supportedKeys) }

$knownKeys = @($productChoices | ForEach-Object { $_.Key })
$unknown   = @($Products | Where-Object { $_ -notin $knownKeys })

if ($unknown.Count -gt 0) {
    Write-Host "Setup cannot continue: unknown product(s) $($unknown -join ', '). Known: $($knownKeys -join ', ')."
    exit 1
}

# Error reports: where reports go (reporting.json next to this script).
$reportDestination = [string](Get-Content (Join-Path $PSScriptRoot "reporting.json") -Raw | ConvertFrom-Json).ReportDestination

# Error reports are on, unless this PC turned them off in an earlier setup or in Options
# (then they stay off unless -ErrorReports is given). The setup window's tick box starts
# from this and decides.
$errorReporting = $true

if (Test-Path $configFile) {
    try {
        if ((Get-Content $configFile -Raw | ConvertFrom-Json).ErrorReporting -eq $false) { $errorReporting = $false }
    }
    catch { }
}

if ($ErrorReports)   { $errorReporting = $true }
if ($NoErrorReports) { $errorReporting = $false }

# What an earlier setup chose (shown again when setup is re-run).
$previousFirmwareFolder = ""

if (Test-Path $configFile) {
    try {
        $previousConfig = Get-Content $configFile -Raw | ConvertFrom-Json
        if ($previousConfig.FirmwareFolder) { $previousFirmwareFolder = [string]$previousConfig.FirmwareFolder }
    }
    catch { }
}


# ------------------------------------------------------------
# Setup window (when the folder was not given on the command line)
# ------------------------------------------------------------

if ($useGui -and -not $DestinationRoot) {

    $startFolder = @($env:OneDriveCommercial, $env:OneDrive) |
        Where-Object { $_ -and (Test-Path $_) } |
        Select-Object -First 1

    if ($startFolder) {
        $biampStart = Join-Path $startFolder "For Install\Biamp"
        $startFolder = if (Test-Path $biampStart) { $biampStart } else { $startFolder }
    }

    $previousBlocked = @($BlockedSSIDs)

    if (-not $PSBoundParameters.ContainsKey("BlockedSSIDs") -and (Test-Path $configFile)) {
        $previousBlocked = @((Get-Content $configFile -Raw | ConvertFrom-Json).BlockedSSIDs | Where-Object { $_ })
    }

    $firmwareStart = if ($previousFirmwareFolder) { $previousFirmwareFolder } else { Get-DefaultFirmwareFolder $startFolder }

    $choice = Show-SetupWizard -StartFolder $startFolder -StartFirmwareFolder $firmwareStart -BlockedNow $previousBlocked -Task $TaskName -ProductList $productChoices -Selected $Products -Url $PageUrl -ErrorReports $errorReporting

    if (-not $choice) {
        Write-Host "Setup cancelled. Nothing was changed."
        exit 1
    }

    $DestinationRoot = $choice.DestinationRoot
    $FirmwareFolder  = $choice.FirmwareFolder
    $BlockedSSIDs    = @($choice.BlockedSSIDs)
    $Products        = @($choice.Products)
    $TaskName        = $choice.TaskName
    $noticeTaskName  = "$TaskName Notice"
    $errorReporting  = [bool]$choice.ErrorReports    # the tick box decides, also over an earlier opt-out
    $wizardDone      = $true
}
else {

    # Console route: the folder must be given.
    if (-not $DestinationRoot) {
        $DestinationRoot = (Read-Host "Folder to keep Biamp software in").Trim()
    }

    if (-not $DestinationRoot) {
        Write-Host "No folder was given. Setup cancelled."
        exit 1
    }

    if (-not $FirmwareFolder) { $FirmwareFolder = Get-DefaultFirmwareFolder $DestinationRoot }

    if ($FirmwareFolder.TrimEnd('\') -ieq $DestinationRoot.TrimEnd('\')) {
        Write-Host "Setup cannot continue: the firmware folder must be different from the software folder."
        exit 1
    }

    Write-Host "Checking that the Biamp download page can be reached (the one contact setup makes)..."

    try { [void](Test-BiampPage -Url $PageUrl) }
    catch {
        Write-Host "Setup cannot continue: $($_.Exception.Message)"
        exit 1
    }
}

if (-not $FirmwareFolder) { $FirmwareFolder = Get-DefaultFirmwareFolder $DestinationRoot }


# ------------------------------------------------------------
# Rollback support
#
# If setup is cancelled or fails before it finishes, remove only
# what THIS run created. Anything that already existed (folders,
# an earlier install) is never removed. Once setup completes,
# nothing is removed automatically.
# ------------------------------------------------------------

$script:createdPaths = New-Object System.Collections.Generic.List[string]
$script:createdTask  = $false
$script:createdNoticeTask = $false

# Never silently replace a scheduled task that another install is using.
# Re-running setup over its own install is fine.
if (-not $SkipTask) {

    $taskInTheWay = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue

    if ($taskInTheWay) {

        $ownLauncher = Join-Path $InstallDir $launcherName

        $theirCommand = ($taskInTheWay.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join " | "

        if ($useGui -and $theirCommand -notlike "*$ownLauncher*" -and -not $ReplaceExistingTask) {

            Add-Type -AssemblyName System.Windows.Forms

            $replaceAnswer = [System.Windows.Forms.MessageBox]::Show(
                "A scheduled task named '$TaskName' already exists and was not created by this setup:`r`n`r`n$theirCommand`r`n`r`nReplace it? Choose No to keep it (then run setup again with a different task name under Advanced).",
                "Biamp Updater Setup", "YesNo", "Warning", "Button2")

            if ($replaceAnswer -eq "Yes") {
                $ReplaceExistingTask = $true
            }
        }

        if ($theirCommand -notlike "*$ownLauncher*" -and -not $ReplaceExistingTask) {

            Write-Host ""
            Write-Host "A scheduled task named '$TaskName' already exists and was not created by this setup:"
            Write-Host "  $theirCommand"
            Write-Host ""
            Write-Host "Setup will not replace it. Either choose a different name, for example:"
            Write-Host "  -TaskName `"$TaskName TEST`""
            Write-Host "or add -ReplaceExistingTask if you really want to replace it."
            exit 1
        }
    }
}

function New-TrackedDirectory {

    param ([string]$Path)

    if (Test-Path $Path) {
        return
    }

    # Remember the top-most folder that does not exist yet, so one
    # removal undoes the whole chain this run created.
    $top = $Path

    while ($true) {
        $parent = Split-Path $top -Parent

        if (-not $parent -or (Test-Path $parent)) {
            break
        }

        $top = $parent
    }

    New-Item -ItemType Directory -Path $Path -Force | Out-Null
    $script:createdPaths.Add($top)
}

function Register-CreatedFile {

    param ([string]$Path)

    if (-not (Test-Path $Path)) {
        $script:createdPaths.Add($Path)
    }
}

function Grant-UserTaskControl {

    # A task registered from an elevated (administrator) window can, by default,
    # only be changed from an elevated window, so the Stop icon (an ordinary
    # window) would get "Access is denied" even for the same person. Give the
    # signed-in user full control of THEIR OWN task; it already runs as them, so
    # this adds no privilege. A failure here is only a warning.
    param ([string]$Name)

    try {

        $sid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value

        $service = New-Object -ComObject Schedule.Service
        $service.Connect()

        $registered = $service.GetFolder("\").GetTask($Name)
        $registered.SetSecurityDescriptor("D:P(A;;FA;;;BA)(A;;FA;;;SY)(A;;FA;;;$sid)", 0)
    }
    catch {
        Write-Warning "Could not give your account control of the task '$Name' ($($_.Exception.Message)). The Stop icon may then need an administrator window."
    }
}

function Undo-Setup {

    if ($script:createdTask) {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
    }

    if ($script:createdNoticeTask) {
        Unregister-ScheduledTask -TaskName $noticeTaskName -Confirm:$false -ErrorAction SilentlyContinue
    }

    for ($i = $script:createdPaths.Count - 1; $i -ge 0; $i--) {
        Remove-Item $script:createdPaths[$i] -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function New-AppShortcut {

    param (
        [string]$Path,
        [string]$ScriptPath,
        [string]$Description = "Stop or resume the Biamp Updater, check now, undo the last update, or remove it",
        [string]$Icon = "$env:SystemRoot\System32\shell32.dll,316"   # the blue settings gear
    )

    $shell    = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($Path)

    $shortcut.TargetPath       = $pwsh
    $shortcut.Arguments        = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$ScriptPath`""
    $shortcut.WorkingDirectory = $InstallDir
    $shortcut.Description      = $Description
    $shortcut.IconLocation     = $Icon
    $shortcut.Save()
}

$setupFinished = $false

$progressForm = $null

if ($wizardDone) {

    Add-Type -AssemblyName System.Windows.Forms

    $progressForm = New-Object System.Windows.Forms.Form
    $progressForm.Text = "Biamp Updater Setup"
    $progressForm.ClientSize = New-Object System.Drawing.Size(420, 90)
    $progressForm.StartPosition = "CenterScreen"; $progressForm.FormBorderStyle = "FixedDialog"
    $progressForm.ControlBox = $false; $progressForm.TopMost = $true
    $progressForm.Font = New-Object System.Drawing.Font("Segoe UI", 10)

    $progressLabel = New-Object System.Windows.Forms.Label
    $progressLabel.Text = "Installing the Biamp Updater, please wait..."
    $progressLabel.Location = New-Object System.Drawing.Point(20, 28); $progressLabel.Size = New-Object System.Drawing.Size(380, 30)
    $progressForm.Controls.Add($progressLabel)

    $progressForm.Show()
    [System.Windows.Forms.Application]::DoEvents()
}

try {

    # --------------------------------------------------------
    # Where software and firmware are saved
    # --------------------------------------------------------

    New-TrackedDirectory $DestinationRoot
    Write-Host "Software will be saved to: $DestinationRoot"

    $firmwareOn = (@($Products | Where-Object { $_ -in $firmwareKeys }).Count -gt 0)

    if ($firmwareOn) {
        New-TrackedDirectory $FirmwareFolder
        Write-Host "Firmware will be saved to: $FirmwareFolder"
    }

    # --------------------------------------------------------
    # Install files and settings
    # --------------------------------------------------------

    New-TrackedDirectory $InstallDir

    foreach ($file in $ownFiles) {
        $target = Join-Path $InstallDir $file
        Register-CreatedFile $target
        Copy-Item (Join-Path $PSScriptRoot $file) $target -Force
    }

    $updaterPath       = Join-Path $InstallDir $updaterName
    $optionsScriptPath = Join-Path $InstallDir $optionsScriptName
    $noticePath        = Join-Path $InstallDir $noticeName

    $config = [ordered]@{
        StateDir        = $InstallDir
        BiampFolder     = $DestinationRoot
        FirmwareFolder  = $FirmwareFolder
        PageUrl         = $PageUrl
        BlockedSSIDs    = @($BlockedSSIDs)
        EnabledProducts = @($Products)
        NoticeTaskName  = $noticeTaskName
        TaskName        = $TaskName
        ErrorReporting    = $errorReporting
        ReportDestination = $reportDestination
    }

    Register-CreatedFile $configFile
    $config | ConvertTo-Json -Depth 6 | Set-Content -Path $configFile -Encoding UTF8

    $vbs = @"
Set shell = CreateObject("WScript.Shell")
shell.Run """$pwsh"" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File ""$updaterPath""", 0, True
"@

    $launcherPath = Join-Path $InstallDir $launcherName
    Register-CreatedFile $launcherPath
    Set-Content -Path $launcherPath -Value $vbs -Encoding ASCII

    $noticeVbs = @"
Set shell = CreateObject("WScript.Shell")
shell.Run """$pwsh"" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""$noticePath""", 0, False
"@

    $noticeLauncherPath = Join-Path $InstallDir $noticeLauncher
    Register-CreatedFile $noticeLauncherPath
    Set-Content -Path $noticeLauncherPath -Value $noticeVbs -Encoding ASCII

    Write-Host "Installed to $InstallDir"

    # --------------------------------------------------------
    # Scheduled task: at logon and on wake from sleep
    # --------------------------------------------------------

    if (-not $SkipTask) {

        $user = "$env:USERDOMAIN\$env:USERNAME"

        $action = New-ScheduledTaskAction `
            -Execute "wscript.exe" `
            -Argument ('"{0}"' -f $launcherPath)

        # 2 minute delay after logon and after resuming from sleep (Kernel-Power event 107).
        $logonTrigger = New-ScheduledTaskTrigger -AtLogOn -User $user
        $logonTrigger.Delay = "PT2M"

        $eventClass = Get-CimClass `
            -Namespace "Root/Microsoft/Windows/TaskScheduler" `
            -ClassName "MSFT_TaskEventTrigger"

        $wakeTrigger = New-CimInstance -CimClass $eventClass -ClientOnly
        $wakeTrigger.Enabled = $true
        $wakeTrigger.Delay = "PT2M"
        $wakeTrigger.Subscription = @"
<QueryList><Query Id="0" Path="System"><Select Path="System">*[System[Provider[@Name='Microsoft-Windows-Kernel-Power'] and EventID=107]]</Select></Query></QueryList>
"@

        # Firmware files are large (about 620 MB), so allow a long run.
        $settings = New-ScheduledTaskSettingsSet `
            -StartWhenAvailable `
            -AllowStartIfOnBatteries `
            -DontStopIfGoingOnBatteries `
            -MultipleInstances IgnoreNew `
            -ExecutionTimeLimit (New-TimeSpan -Hours 3)

        # The signed-in user's SID, interactive, limited (no administrator rights).
        $userSid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value

        $principal = New-ScheduledTaskPrincipal `
            -UserId $userSid `
            -LogonType Interactive `
            -RunLevel Limited

        $existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue

        if ($existing) {
            Write-Host "A scheduled task named '$TaskName' already exists and will be replaced."
        }

        Register-ScheduledTask `
            -TaskName $TaskName `
            -Action $action `
            -Trigger @($logonTrigger, $wakeTrigger) `
            -Settings $settings `
            -Principal $principal `
            -Force |
            Out-Null

        Grant-UserTaskControl -Name $TaskName

        if (-not $existing) {
            $script:createdTask = $true
        }

        Write-Host "Scheduled task '$TaskName' registered (at logon)."

        # On-demand task that shows the notices. No triggers and NO time limit: a notice stays
        # open until the user clicks a button, so it must not be tied to the updater's time
        # limit. The updater starts it with Start-ScheduledTask.
        $noticeAction = New-ScheduledTaskAction `
            -Execute "wscript.exe" `
            -Argument ('"{0}"' -f $noticeLauncherPath)

        $noticeSettings = New-ScheduledTaskSettingsSet `
            -AllowStartIfOnBatteries `
            -DontStopIfGoingOnBatteries `
            -MultipleInstances IgnoreNew `
            -ExecutionTimeLimit ([TimeSpan]::Zero)

        $existingNotice = Get-ScheduledTask -TaskName $noticeTaskName -ErrorAction SilentlyContinue

        Register-ScheduledTask `
            -TaskName $noticeTaskName `
            -Action $noticeAction `
            -Settings $noticeSettings `
            -Principal $principal `
            -Force |
            Out-Null

        Grant-UserTaskControl -Name $noticeTaskName

        if (-not $existingNotice) {
            $script:createdNoticeTask = $true
        }
    }

    # --------------------------------------------------------
    # "Biamp Updater Options" icons (Desktop and Start menu)
    # --------------------------------------------------------

    $desktopLink = Join-Path ([Environment]::GetFolderPath("Desktop")) $optionsLinkName
    Register-CreatedFile $desktopLink
    New-AppShortcut -Path $desktopLink -ScriptPath $optionsScriptPath

    $startMenuFolder = Join-Path ([Environment]::GetFolderPath("Programs")) "Biamp Updater"
    New-TrackedDirectory $startMenuFolder

    $startMenuLink = Join-Path $startMenuFolder $optionsLinkName
    Register-CreatedFile $startMenuLink
    New-AppShortcut -Path $startMenuLink -ScriptPath $optionsScriptPath

    $setupFinished = $true
}
catch {

    Write-Host ""

    if ($_.Exception.Message -match "cancelled") {
        Write-Host "Setup cancelled."
    }
    else {
        Write-Host "Setup failed: $($_.Exception.Message)"
    }
}
finally {

    if ($progressForm) {
        $progressForm.Close()
        $progressForm.Dispose()
    }

    # Also runs if the window is closed with Ctrl+C.
    if (-not $setupFinished) {
        Write-Host "Removing what this setup created..."
        Undo-Setup
        Write-Host "Done. Nothing from this setup was left behind."

        if ($wizardDone) {
            [void][System.Windows.Forms.MessageBox]::Show("Setup did not finish, so everything it had created was removed. Nothing was left behind.", "Biamp Updater Setup", "OK", "Warning")
        }
    }
}

if (-not $setupFinished) {
    exit 1
}


Write-Host ""
Write-Host "Setup complete."
Write-Host "Run history (one dated line per attempt, with the reason if it failed):"
Write-Host "  $(Join-Path $InstallDir 'Logs\Run-History.log')"
Write-Host "Detailed log: $(Join-Path $InstallDir 'Logs\Biamp-Updater.log')"
Write-Host ""
Write-Host "To stop or resume the updater, check now, undo the last update or"
Write-Host "remove it, open 'Biamp Updater Options' on your Desktop (or in the Start menu)."

if ($RunNow -and -not $SkipTask) {
    Start-ScheduledTask -TaskName $TaskName
    Write-Host "Started the updater now."
}

if ($useGui -and $wizardDone) {

    if (Show-SetupDone) {

        # Open the Options window (outside the install folder, so it can never block removing it).
        Start-Process -FilePath $pwsh -WorkingDirectory $env:TEMP -WindowStyle Hidden -ArgumentList @(
            "-NoProfile", "-ExecutionPolicy", "Bypass",
            "-File", "`"$optionsScriptPath`"",
            "-InstallDir", "`"$InstallDir`""
        )
    }
}
