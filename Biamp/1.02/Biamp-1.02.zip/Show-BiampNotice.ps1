# ============================================================
# Biamp Updater -- notices
#
# Started by the updater (through the on-demand scheduled task
# "<TaskName> Notice", which has NO time limit) when a notice is waiting.
# If several are waiting they are shown one after another in this order:
#
#   pending-error.json          A run failed. Shows the step and the error.
#                               Buttons: Open Log Folder | OK
#   pending-notice.json         New versions were downloaded (one or several products).
#                               Software and firmware are separate windows.
#                               Buttons: Go to Folder | OK
#
# A notice never closes by itself. It stays on screen until the user clicks
# one of its buttons. The X button is removed and Alt+F4 is blocked. If the
# PC is restarted or the user logs off first, the notice stays pending and
# appears again at the next updater run. Only after the user clicks a button
# is it cleared, so each one is acknowledged exactly once.
# ============================================================

# WINDOW CONTROL IDS (UI Automation id = control Name; window tests use these, keep them in step):
#   BiampNoticeForm NoticeText ActionButton OkButton
[CmdletBinding()]
param (
    [string]$StateDir = $PSScriptRoot
)

$ErrorActionPreference = "Stop"

$errorPending  = Join-Path $StateDir "pending-error.json"
$updatePending = Join-Path $StateDir "pending-notice.json"

if (
    -not (Test-Path $errorPending) -and
    -not (Test-Path $updatePending)
) {
    return
}

# Only one notice window at a time.
$mutex = New-Object System.Threading.Mutex($false, "Global\BiampUpdater-Notice")

try {
    $mutexAcquired = $mutex.WaitOne(0, $false)
}
catch [System.Threading.AbandonedMutexException] {
    $mutexAcquired = $true
}

if (-not $mutexAcquired) {
    return
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()


# Shows one notice. Returns $true when the user clicked a button.
# Buttons: an action and OK.
function Show-Notice {

    param (
        [string]$Text,
        [string]$ActionText,
        [scriptblock]$Action
    )

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Biamp Updater"
    $form.Name = "BiampNoticeForm"
    $form.StartPosition = "CenterScreen"
    $form.FormBorderStyle = "FixedDialog"
    $form.ControlBox = $false
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $form.TopMost = $true
    $form.ClientSize = New-Object System.Drawing.Size(580, 440)

    # Only the buttons can close the window (Tag = "ack").
    # Windows shutdown or logoff is still allowed to end it.
    $form.Add_FormClosing({
        param($sender, $e)

        if (
            $sender.Tag -ne "ack" -and
            $e.CloseReason -ne [System.Windows.Forms.CloseReason]::WindowsShutDown
        ) {
            $e.Cancel = $true
        }
    })

    $label = New-Object System.Windows.Forms.Label
    $label.Name = "NoticeText"
    $label.Location = New-Object System.Drawing.Point(20, 16)
    $label.Size = New-Object System.Drawing.Size(540, 360)
    $label.Text = $Text

    $okButton = New-Object System.Windows.Forms.Button
    $okButton.Name = "OkButton"
    $okButton.Text = "OK"
    $okButton.Location = New-Object System.Drawing.Point(470, 392)
    $okButton.Size = New-Object System.Drawing.Size(90, 30)
    $okButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $okButton.Add_Click({
        $this.FindForm().Tag = "ack"
    })

    $first = New-Object System.Windows.Forms.Button
    $first.Name = "ActionButton"
    $first.Text = $ActionText
    $first.Location = New-Object System.Drawing.Point(320, 392)
    $first.Size = New-Object System.Drawing.Size(140, 30)
    $first.Tag = $Action
    $first.Add_Click({
        $this.FindForm().Tag = "ack"
        & $this.Tag
        $this.FindForm().Close()
    })

    $form.AcceptButton = $okButton

    $form.Controls.AddRange(@($label, $okButton, $first))

    $null = $form.ShowDialog()

    $acknowledged = ($form.Tag -eq "ack")
    $form.Dispose()

    return $acknowledged
}


try {

    # --------------------------------------------------------
    # 1. A run failed: show the error so it can be investigated
    # --------------------------------------------------------

    if (Test-Path $errorPending) {

        $notice = Get-Content $errorPending -Raw | ConvertFrom-Json

        $when = ([datetime]$notice.Time).ToString("MMMM d, yyyy h:mm tt")

        $text =
            "The Biamp Updater could not finish its last check.`r`n`r`n" +
            "When:  $when`r`n" +
            "While: $($notice.Step)`r`n" +
            "Error: $($notice.Message)`r`n`r`n" +
            "It will try again at the next logon. The same error is " +
            "not shown again for 24 hours, but every attempt is written to the logs:`r`n`r`n" +
            "Run history (one line per attempt):`r`n    $($notice.HistoryFile)`r`n`r`n" +
            "Detailed log (steps, error location, call stack):`r`n    $($notice.LogFile)`r`n`r`n" +
            "If it keeps failing, send both files to whoever maintains this updater."

        $logTarget = $notice.HistoryFile

        $acknowledged = Show-Notice `
            -Text $text `
            -ActionText "Open Log Folder" `
            -Action {
                Start-Process explorer.exe -ArgumentList "/select,`"$logTarget`""
            }.GetNewClosure()

        if ($acknowledged) {
            Remove-Item $errorPending -Force
        }
    }

    # --------------------------------------------------------
    # 2. New versions were downloaded: software and firmware are
    #    SEPARATE windows (different jobs, different folders), shown one
    #    after the other, software first. Each is acknowledged on its own.
    # --------------------------------------------------------

    if (Test-Path $updatePending) {

        $notice = Get-Content $updatePending -Raw | ConvertFrom-Json

        foreach ($kind in "Software", "Firmware") {

            $mine = @(@($notice.Items) | Where-Object { $(if ($_.Kind) { $_.Kind } else { "Software" }) -eq $kind })

            if ($mine.Count -eq 0) { continue }

            $lines = foreach ($item in ($mine | Select-Object -First 14)) {

                $replaced =
                    if ($item.PreviousVersion) { " (replaces $($item.PreviousVersion))" }
                    else { "" }

                "    $($item.Name)  $($item.Version)$replaced"
            }

            if ($mine.Count -gt 14) { $lines += "    ... and $($mine.Count - 14) more" }

            if ($kind -eq "Software") {

                $headline = "$(if ($mine.Count -eq 1) { 'A new Biamp software version has' } else { "$($mine.Count) new Biamp software versions have" }) been downloaded."
                $text =
                    "$headline`r`n`r`n" +
                    ($lines -join "`r`n") + "`r`n`r`n" +
                    "Older versions were moved to the Archive folder.`r`n" +
                    "Saved to: $($notice.Folder)"
            }
            else {

                $headline = if ($mine.Count -eq 1) { "A new Biamp firmware file has been downloaded." } else { "$($mine.Count) new Biamp firmware files have been downloaded." }
                $text =
                    "$headline`r`n`r`n" +
                    ($lines -join "`r`n") + "`r`n`r`n" +
                    "Older firmware was deleted.`r`n" +
                    "Loading firmware into the devices is still done by hand.`r`n" +
                    "Saved to: $($notice.FirmwareFolder)"
            }

            $target = $mine[0].FilePath

            $acknowledged = Show-Notice `
                -Text $text `
                -ActionText "Go to Folder" `
                -Action {
                    Start-Process explorer.exe -ArgumentList "/select,`"$target`""
                }.GetNewClosure()

            if (-not $acknowledged) { break }

            # Acknowledged: clear only this kind; keep the other kind pending.
            $rest = @(@($notice.Items) | Where-Object { $(if ($_.Kind) { $_.Kind } else { "Software" }) -ne $kind })

            if ($rest.Count -eq 0) {
                Remove-Item $updatePending -Force
            }
            else {
                $notice.Items = $rest
                $notice | ConvertTo-Json -Depth 4 | Set-Content -Path $updatePending
            }
        }
    }
}
finally {

    try {
        $mutex.ReleaseMutex()
    }
    catch {
    }

    $mutex.Dispose()
}
