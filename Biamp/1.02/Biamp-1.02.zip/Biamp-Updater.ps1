# ============================================================
# Biamp Updater
#
# Keeps the newest Biamp software and firmware from
# the Biamp download page (PageUrl in products.json) in the destination folder.
# Plain HTTPS: no sign-in, no browser. Versions come from the download link
# file names on the page (the page text itself can lag behind).
#
#   Software (Tesira Software, Discovery tool, USB driver): newest in the Biamp
#     folder; the superseded file is moved to Archive\ (journal records it).
#   Firmware (Tesira .tfa2, TesiraFORTE X .tfa): newest in Biamp\Firmware;
#     the superseded file is deleted AFTER the new one is downloaded and checked.
#   Only files matching a product's own file-name pattern are ever touched.
#
# All settings come from config.json (written by Install-BiampUpdater.ps1).
# Dot-sourcing this file (. .\Biamp-Updater.ps1) only defines the functions;
# that is how the tests use it. Needs PowerShell 7.
# ============================================================

param (
    [string]$ConfigPath = (Join-Path $PSScriptRoot "config.json"),

    # Tests only: a local folder holding page.html and the "downloadable" files
    # instead of support.biamp.com / downloads.biamp.com. No network.
    [string]$TestBackendRoot
)

$ErrorActionPreference = "Stop"

# Error reports (Reporting.ps1 next to this script; never passwords). A missing or damaged
# module never changes a run: the two functions the run calls then do nothing.
$reportingScript = Join-Path $PSScriptRoot "Reporting.ps1"
if (Test-Path -LiteralPath $reportingScript) { try { . $reportingScript } catch { } }
if (-not (Get-Command Send-ErrorReport -CommandType Function -ErrorAction SilentlyContinue) -or
    -not (Get-Command Send-ReportOutbox -CommandType Function -ErrorAction SilentlyContinue)) {
    function Send-ErrorReport { $null }
    function Send-ReportOutbox { 0 }
}

# The one catalog (products.json, next to this script): PageUrl plus the Products list. Setup and Options read the same file.
function Start-DownloadStatus {
    $statusPath = $null
    try {
        $state = $script:config.StateDir
        if ($state -and (Test-Path -LiteralPath $state)) {
            $statusPath = Join-Path $state 'download-status.json'
            $process = [Diagnostics.Process]::GetCurrentProcess()
            $json = @{ Pid = $PID; StartTicks = $process.StartTime.ToUniversalTime().Ticks.ToString(); Status = 'Downloading' } | ConvertTo-Json -Compress
            [IO.File]::WriteAllText($statusPath, $json)
        }
    } catch { $statusPath = $null }
    return $statusPath
}

function Invoke-TrackedDownload {
    param([scriptblock]$Transfer)
    $statusPath = Start-DownloadStatus
    try { & $Transfer }
    finally { if ($statusPath) { try { [IO.File]::Delete($statusPath) } catch { } } }
}

function Read-BiampCatalog {

    $file = Join-Path $PSScriptRoot "products.json"
    if (-not (Test-Path -LiteralPath $file)) { throw "products.json is missing next to Biamp-Updater.ps1." }

    $catalog = Get-Content -LiteralPath $file -Raw | ConvertFrom-Json
    if (-not $catalog.PageUrl -or @($catalog.Products).Count -eq 0) { throw "products.json has no PageUrl or no Products (the file may be damaged)." }

    foreach ($p in @($catalog.Products)) {
        if ($p.RetainOld -notin "archive", "delete" -or $p.Folder -notin "root", "firmware") {
            throw "products.json: product '$($p.Key)' needs RetainOld (archive or delete) and Folder (root or firmware)."
        }
    }

    $catalog
}

$script:DefaultPageUrl = (Read-BiampCatalog).PageUrl


# ------------------------------------------------------------
# Product list (what the updater knows how to keep current)
# Pattern: regex on the file name; group 1 = version with dashes (5-7-1).
# Versioned = $false: the name never changes (Discovery tool); a change is
# detected by a different file size.
# ------------------------------------------------------------

function Get-BiampProducts {

    # The one product list (products.json, next to this script). Only the products found by their link on the
    # page are returned here; the USB driver (Handler "usb") has its own function.
    @((Read-BiampCatalog).Products | Where-Object { $_.Handler -eq "link" })
}

# The USB driver's catalog entry (Handler "usb"): file-name pattern, link text, name and old-version rule.
function Get-BiampUsbProduct {

    $p = @((Read-BiampCatalog).Products | Where-Object { $_.Handler -eq "usb" })
    if ($p.Count -ne 1) { throw "products.json must hold exactly one product with Handler usb." }

    $p[0]
}


# ------------------------------------------------------------
# Versions and page parsing (pure functions, no I/O)
# ------------------------------------------------------------

# "5-7-1" or "5.7.1" -> @(5,7,1); $null when not whole numbers.
function ConvertTo-VersionParts {
    param ([string]$Text)
    if ($Text -notmatch '^\d+([-.]\d+)*$') { return $null }
    , @($Text -split '[-.]' | ForEach-Object { [int]$_ })
}

function Compare-VersionParts {
    param ($A, $B)
    $len = [math]::Max(@($A).Count, @($B).Count)
    for ($i = 0; $i -lt $len; $i++) {
        $x = if ($i -lt @($A).Count) { $A[$i] } else { 0 }
        $y = if ($i -lt @($B).Count) { $B[$i] } else { 0 }
        if ($x -lt $y) { return -1 }
        if ($x -gt $y) { return 1 }
    }
    0
}

# Text that sorts like the version (5.10 after 5.9): each part padded to 6 digits.
function Get-VersionSortKey {
    param ($Parts)
    (@($Parts) | ForEach-Object { '{0:D6}' -f [int]$_ }) -join '.'
}

# Every download link on the page: Url, Name (file name without query), Position (offset in the page).
function Get-PageLinks {

    param ([string]$Html, [string]$BaseUrl = $script:DefaultPageUrl)

    $links = New-Object System.Collections.Generic.List[object]

    foreach ($m in [regex]::Matches($Html, '(?is)href\s*=\s*"([^"]+)"')) {

        $href = [System.Net.WebUtility]::HtmlDecode($m.Groups[1].Value)

        try { $uri = New-Object System.Uri((New-Object System.Uri($BaseUrl)), $href) } catch { continue }

        if ($uri.Host -notmatch '(^|\.)downloads\.biamp\.com$') { continue }

        $name = [System.IO.Path]::GetFileName([System.Uri]::UnescapeDataString($uri.AbsolutePath))
        if (-not $name) { continue }

        $links.Add([pscustomobject]@{ Url = $uri.AbsoluteUri; Name = $name; Position = $m.Index })
    }

    , $links.ToArray()
}

# Where the "Older Firmware" part starts (links after it are never candidates for current firmware). Page order otherwise.
function Get-OlderFirmwareStart {
    param ([string]$Html)
    # The heading itself, not the table-of-contents entry that links to it.
    $m = [regex]::Match($Html, '(?is)<h[1-6][^>]*>(?:(?!</h[1-6]>).)*Older\s+firmware(?:(?!</h[1-6]>).)*</h[1-6]>')
    if ($m.Success) { $m.Index } else { [int]::MaxValue }
}

# Candidate links for one product, newest version first. Duplicates (same file name) collapse to one.
function Find-ProductLinks {

    param ($Product, $Links, [int]$OlderStart = [int]::MaxValue)

    $found = foreach ($l in @($Links)) {

        if ($Product.Section -eq "current-firmware" -and $l.Position -ge $OlderStart) { continue }

        $m = [regex]::Match($l.Name, $Product.Pattern, 'IgnoreCase')
        if (-not $m.Success) { continue }

        $parts = $null; $text = $null
        if ($Product.Versioned) {
            $parts = ConvertTo-VersionParts $m.Groups[1].Value
            if (-not $parts) { continue }
            $text = ($parts -join '.')
        }

        [pscustomobject]@{ Url = $l.Url; Name = $l.Name; Parts = $parts; Text = $text }
    }

    $seen = @{}
    $unique = foreach ($f in @($found | Where-Object { $_ })) { if (-not $seen.ContainsKey($f.Name)) { $seen[$f.Name] = $true; $f } }

    if ($Product.Versioned) {
        # Highest version first; a stable sort keeps page order for equal versions.
        $sorted = @($unique | Where-Object { $_ }) | Sort-Object -Stable -Descending -Property { Get-VersionSortKey $_.Parts }
        return @($sorted)
    }

    @($unique)
}

# Files already in a folder that belong to this product, newest version first.
function Get-LocalProductFiles {

    param ($Product, [string]$Folder)

    if (-not (Test-Path -LiteralPath $Folder)) { return @() }

    $items = foreach ($f in Get-ChildItem -LiteralPath $Folder -File -ErrorAction SilentlyContinue) {

        $m = [regex]::Match($f.Name, $Product.Pattern, 'IgnoreCase')
        if (-not $m.Success) { continue }

        $parts = $null; $text = $null
        if ($Product.Versioned) {
            $parts = ConvertTo-VersionParts $m.Groups[1].Value
            if (-not $parts) { continue }
            $text = ($parts -join '.')
        }

        [pscustomobject]@{ Name = $f.Name; Parts = $parts; Text = $text; Item = $f }
    }

    if ($Product.Versioned) {
        $sorted = @($items | Where-Object { $_ }) | Sort-Object -Descending -Property { Get-VersionSortKey $_.Parts }
        return @($sorted)
    }

    @($items | Where-Object { $_ })
}


# ------------------------------------------------------------
# Network (or the test backend)
# ------------------------------------------------------------

# Runs a web call, retrying connection drops (reset, SSL, timeout) a few times. HTTP errors are not retried.
function Invoke-WebRetry {

    param ([scriptblock]$Call, [int]$Tries = 3)

    for ($i = 1; $i -le $Tries; $i++) {
        try { return & $Call }
        catch {
            if ($_.Exception.Response -or $i -eq $Tries) { throw }
            Start-Sleep -Seconds (5 * $i)
        }
    }
}

function Get-PageHtml {

    param ([string]$PageUrl)

    if ($script:TestBackendRoot) {
        return [System.IO.File]::ReadAllText((Join-Path $script:TestBackendRoot "page.html"))
    }

    (Invoke-WebRetry { Invoke-WebRequest -Uri $PageUrl -UseBasicParsing -TimeoutSec 60 }).Content
}

# Does the link answer, and how big is it? Returns $null for a dead link (404 and so on).
function Get-RemoteInfo {

    param ([string]$Url)

    if ($script:TestBackendRoot) {
        $name = [System.IO.Path]::GetFileName(([System.Uri]$Url).AbsolutePath)
        $path = Join-Path $script:TestBackendRoot $name
        if (-not (Test-Path -LiteralPath $path)) { return $null }
        return [pscustomobject]@{ Length = (Get-Item -LiteralPath $path).Length; LastModified = (Get-Item -LiteralPath $path).LastWriteTimeUtc }
    }

    try {
        $r = Invoke-WebRetry { Invoke-WebRequest -Uri $Url -Method Head -UseBasicParsing -TimeoutSec 60 }
        $len = $r.Headers['Content-Length'] | Select-Object -First 1
        if (-not $len) { return $null }
        $lm = $null
        $lmText = $r.Headers['Last-Modified'] | Select-Object -First 1
        if ($lmText) { try { $lm = [datetime]::Parse($lmText).ToUniversalTime() } catch { } }
        [pscustomobject]@{ Length = [int64]$len; LastModified = $lm }
    }
    catch {
        $resp = $_.Exception.Response
        if ($resp -and [int]$resp.StatusCode -ge 400 -and [int]$resp.StatusCode -lt 500) { return $null }
        throw
    }
}

function Get-RemoteFile {

    param ([string]$Url, [string]$Destination)

    if ($script:TestBackendRoot) {
        $name = [System.IO.Path]::GetFileName(([System.Uri]$Url).AbsolutePath)
        [System.IO.File]::Copy((Join-Path $script:TestBackendRoot $name), $Destination, $true)
        return
    }

    $client = New-Object System.Net.Http.HttpClient
    $client.Timeout = [System.Threading.Timeout]::InfiniteTimeSpan

    try {
        $response = $client.GetAsync($Url, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
        $response.EnsureSuccessStatusCode() | Out-Null

        $in  = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
        $out = [System.IO.File]::Create($Destination)
        try { $in.CopyTo($out, 1MB) } finally { $out.Dispose(); $in.Dispose() }
    }
    finally { $client.Dispose() }
}

# Throws a plain-wording message when the downloaded file is not what the page promised.
function Test-DownloadedFile {

    param ([string]$Path, [int64]$ExpectedSize, [string]$Validate = "size")

    if (-not (Test-Path -LiteralPath $Path)) { throw "The download did not create a file." }

    $size = (Get-Item -LiteralPath $Path).Length

    if ($size -le 0) { throw "The downloaded file is empty." }
    if ($ExpectedSize -gt 0 -and $size -ne $ExpectedSize) {
        throw "The download was cut off or incomplete ($size bytes received, $ExpectedSize expected)."
    }

    if ($Validate -eq "mz") {
        $fs = [System.IO.File]::OpenRead($Path)
        try { $b1 = $fs.ReadByte(); $b2 = $fs.ReadByte() } finally { $fs.Dispose() }
        if ($b1 -ne 0x4D -or $b2 -ne 0x5A) { throw "The downloaded file is not a Windows program (it may be an error page)." }
    }
}


# ------------------------------------------------------------
# One product
# ------------------------------------------------------------

function Update-Product {

    param ($Product, $PageLinks, [int]$OlderStart, [string]$Destination, [string]$TempFolder, [string]$ArchiveFolder)

    $result = [pscustomobject]@{
        Key = $Product.Key; Name = $Product.Name; Kind = $Product.Kind; Status = "Failed"; Detail = ""
        Previous = $null; New = $null; FilePath = $null; Removed = @(); Archived = @()
    }

    $downloaded = $null

    try {

        $candidates = @(Find-ProductLinks -Product $Product -Links $PageLinks -OlderStart $OlderStart)

        if ($candidates.Count -eq 0) {
            $result.Status = "NotFound"
            throw "No download link for $($Product.Name) was found on the Biamp page (the page may have changed)."
        }

        # The newest link that actually answers (the page keeps some dead links).
        $latest = $null; $info = $null; $dead = @()
        foreach ($c in $candidates) {
            $i = Get-RemoteInfo -Url $c.Url
            if ($i) { $latest = $c; $info = $i; break }
            $dead += $c.Name
        }

        if (-not $latest) { throw "The download link(s) for $($Product.Name) on the Biamp page do not work ($($dead -join ', '))." }

        New-Item -ItemType Directory -Path $Destination -Force | Out-Null
        $local = @(Get-LocalProductFiles -Product $Product -Folder $Destination)

        if ($local.Count -gt 0) { $result.Previous = if ($Product.Versioned) { $local[0].Text } else { $local[0].Name } }

        if ($Product.Versioned) {

            if ($local.Count -gt 0 -and (Compare-VersionParts $local[0].Parts $latest.Parts) -ge 0) {
                $result.Status = "Current"; $result.Detail = "$($local[0].Text) is the newest."
                return $result
            }
        }
        else {
            if ($local.Count -gt 0 -and $local[0].Item.Length -eq $info.Length) {
                $result.Status = "Current"; $result.Detail = "$($local[0].Name) is unchanged."
                return $result
            }
        }

        # Room for the download in the temp folder and the destination, plus a margin.
        $needed = $info.Length + 100MB
        foreach ($folder in $TempFolder, $Destination) {
            $root = [System.IO.Path]::GetPathRoot((Resolve-Path -LiteralPath $folder).Path)
            $free = (New-Object System.IO.DriveInfo $root).AvailableFreeSpace
            if ($free -lt $needed) {
                throw "Not enough free disk space on $root ($([math]::Round($free / 1MB)) MB free, about $([math]::Round($needed / 1MB)) MB needed)."
            }
        }

        $downloaded = Join-Path $TempFolder $latest.Name
        Write-Host "  Downloading $($latest.Name) ($([math]::Round($info.Length / 1MB, 1)) MB)..."
        Invoke-TrackedDownload { Get-RemoteFile -Url $latest.Url -Destination $downloaded }

        Test-DownloadedFile -Path $downloaded -ExpectedSize $info.Length -Validate $Product.Validate

        # Software: the superseded file goes to Archive\ BEFORE the new one is moved in (an unversioned name would collide).
        $archived = @()
        if ($Product.RetainOld -eq "archive") {
            foreach ($old in $local) {
                if ($Product.Versioned -and (Compare-VersionParts $old.Parts $latest.Parts) -ge 0) { continue }

                New-Item -ItemType Directory -Path $ArchiveFolder -Force | Out-Null
                $archiveName = $old.Name
                if (-not $Product.Versioned -or (Test-Path -LiteralPath (Join-Path $ArchiveFolder $archiveName))) {
                    $stamp = $old.Item.LastWriteTime.ToString("yyyy-MM-dd")
                    $archiveName = "{0} ({1}){2}" -f [System.IO.Path]::GetFileNameWithoutExtension($old.Name), $stamp, [System.IO.Path]::GetExtension($old.Name)
                    $n = 2
                    while (Test-Path -LiteralPath (Join-Path $ArchiveFolder $archiveName)) {
                        $archiveName = "{0} ({1}-{2}){3}" -f [System.IO.Path]::GetFileNameWithoutExtension($old.Name), $stamp, $n, [System.IO.Path]::GetExtension($old.Name); $n++
                    }
                }
                $to = Join-Path $ArchiveFolder $archiveName
                Move-Item -LiteralPath $old.Item.FullName -Destination $to
                $archived += [ordered]@{ From = $old.Item.FullName; To = $to }
            }
        }

        $target = Join-Path $Destination $latest.Name
        Move-Item -LiteralPath $downloaded -Destination $target -Force
        $downloaded = $null

        # Firmware: only now, with the new file in place, delete the older firmware of THIS product.
        $removed = @()
        if ($Product.RetainOld -eq "delete") {
            foreach ($old in $local) {
                if ($Product.Versioned -and (Compare-VersionParts $old.Parts $latest.Parts) -ge 0) { continue }
                Remove-Item -LiteralPath $old.Item.FullName -Force
                $removed += $old.Name
            }
        }

        $newText = if ($Product.Versioned) { $latest.Text } else { $latest.Name }
        $result.Status   = "Updated"
        $result.New      = $newText
        $result.FilePath = $target
        $result.Removed  = $removed
        $result.Archived = $archived
        $result.Detail   = "$(if ($result.Previous) { "$($result.Previous) -> " })$newText$(if ($dead.Count) { " (skipped dead link: $($dead -join ', '))" })"
    }
    catch {
        if ($result.Status -ne "NotFound") { $result.Status = "Failed" }
        $result.Detail = $_.Exception.Message
    }
    finally {
        if ($downloaded) { Remove-Item -LiteralPath $downloaded -Force -ErrorAction SilentlyContinue }
    }

    $result
}


# ------------------------------------------------------------
# USB driver (on ShareFile, behind a bot check that only a real browser passes).
# A hidden, throwaway Chrome opens the public share page and clicks Download, the way a person would.
# No sign-in, no saved profile. Change detection needs no Chrome: the driver's line on the Biamp page
# (version, date, link) is remembered in usb-driver-state.json; Chrome only starts when that line changes
# or the file is missing. If Chrome cannot do it, the run asks the user to download it by hand (a notice).
# ------------------------------------------------------------

# The driver's file-name pattern and the link text that finds its line come from products.json (Handler "usb").

# The driver's line on the page: share link, share id and the visible text (version and date) used to notice a change.
function Get-UsbDriverLink {

    param ([string]$Html, $Product = (Get-BiampUsbProduct))

    foreach ($li in [regex]::Matches($Html, '(?is)<li\b[^>]*>.*?</li>')) {

        if ($li.Value -notmatch ('(?i)' + $Product.LinkText)) { continue }

        $m = [regex]::Match($li.Value, '(?i)href\s*=\s*"(https://[^"]*sharefile\.com/public/share/web-(s[0-9a-f]+))"')
        if (-not $m.Success) { continue }

        $text = [System.Net.WebUtility]::HtmlDecode([regex]::Replace($li.Value, '<[^>]+>', ' '))
        $text = ([regex]::Replace($text, '\s+', ' ')).Trim()

        return [pscustomobject]@{ Url = $m.Groups[1].Value; ShareId = $m.Groups[2].Value; Text = $text }
    }

    $null
}

# Driver installers already in the folder, newest version first.
function Get-LocalUsbDrivers {

    param ([string]$Folder, $Product = (Get-BiampUsbProduct))

    if (-not (Test-Path -LiteralPath $Folder)) { return @() }

    $items = foreach ($f in Get-ChildItem -LiteralPath $Folder -File -ErrorAction SilentlyContinue) {

        $m = [regex]::Match($f.Name, $Product.Pattern, 'IgnoreCase')
        if (-not $m.Success) { continue }

        $parts = ConvertTo-VersionParts $m.Groups[1].Value
        if (-not $parts) { continue }

        [pscustomobject]@{ Name = $f.Name; Parts = $parts; Text = ($parts -join '.'); Item = $f }
    }

    @(@($items | Where-Object { $_ }) | Sort-Object -Descending -Property { Get-VersionSortKey $_.Parts })
}

function Find-ChromeExe {

    foreach ($p in @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")) {
        if ($p -and (Test-Path -LiteralPath $p)) { return $p }
    }

    $null
}

# Starts a hidden Chrome with a throwaway profile inside $TempFolder, drives it over its DevTools port to click
# Download on the share page, and returns the path of the finished file (inside $TempFolder). Always closes Chrome
# and deletes the profile. Throws a plain-wording message on any failure.
function Get-UsbDriverViaChrome {

    param ([string]$ShareUrl, [string]$ShareId, [string]$TempFolder)

    $chrome = Find-ChromeExe
    if (-not $chrome) { throw "Google Chrome is not installed on this PC." }

    $unique = "biampusb-" + [guid]::NewGuid().ToString("N").Substring(0, 8)
    $work   = Join-Path $TempFolder $unique
    $prof   = Join-Path $work "profile"
    $dl     = Join-Path $work "dl"
    [void][System.IO.Directory]::CreateDirectory($dl)

    $listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, 0)
    $listener.Start(); $port = $listener.LocalEndpoint.Port; $listener.Stop()

    $origin = ([uri]$ShareUrl).GetLeftPart([System.UriPartial]::Authority)
    $st     = @{ Id = 0; Pending = $null; Sb = (New-Object System.Text.StringBuilder); Buf = (New-Object byte[] 1048576); Begin = $null; Progress = $null }
    $proc   = $null
    $sock   = $null

    try {
        $proc = Start-Process -FilePath $chrome -PassThru -ArgumentList @(
            "--headless=new", "--remote-debugging-port=$port", "--remote-allow-origins=*",
            "--user-data-dir=`"$prof`"", "--no-first-run", "--disable-gpu", "--disable-extensions", "about:blank")

        $wsUrl = $null
        for ($i = 0; $i -lt 40 -and -not $wsUrl; $i++) {
            try {
                $targets = Invoke-RestMethod -Uri "http://127.0.0.1:$port/json" -TimeoutSec 3
                $page = @($targets | Where-Object { $_.type -eq "page" })[0]
                if ($page) { $wsUrl = $page.webSocketDebuggerUrl }
            }
            catch { }
            if (-not $wsUrl) { Start-Sleep -Milliseconds 500 }
        }
        if (-not $wsUrl) { throw "Chrome did not open its remote-control port." }

        $sock = New-Object System.Net.WebSockets.ClientWebSocket
        [void]$sock.ConnectAsync([uri]$wsUrl, [System.Threading.CancellationToken]::None).GetAwaiter().GetResult()

        function Send-Cdp([string]$Method, $Params) {
            $st.Id++
            $json  = ConvertTo-Json -InputObject @{ id = $st.Id; method = $Method; params = $Params } -Depth 8 -Compress
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
            $seg   = New-Object 'System.ArraySegment[byte]' -ArgumentList (, $bytes)
            [void]$sock.SendAsync($seg, [System.Net.WebSockets.WebSocketMessageType]::Text, $true, [System.Threading.CancellationToken]::None).GetAwaiter().GetResult()
            $st.Id
        }

        # One receive stays pending between calls: cancelling a pending receive aborts the whole socket.
        function Read-Cdp([int]$Milliseconds) {
            $deadline = (Get-Date).AddMilliseconds($Milliseconds)
            while ((Get-Date) -lt $deadline) {
                if (-not $st.Pending) {
                    $seg = New-Object 'System.ArraySegment[byte]' -ArgumentList (, $st.Buf)
                    $st.Pending = $sock.ReceiveAsync($seg, [System.Threading.CancellationToken]::None)
                }
                if (-not $st.Pending.Wait(300)) { continue }
                $r = $st.Pending.Result; $st.Pending = $null
                if ($r.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) { throw "Chrome closed the remote-control connection." }
                [void]$st.Sb.Append([System.Text.Encoding]::UTF8.GetString($st.Buf, 0, $r.Count))
                if (-not $r.EndOfMessage) { continue }
                $text = $st.Sb.ToString(); [void]$st.Sb.Clear()
                $m = $null
                try { $m = $text | ConvertFrom-Json } catch { continue }
                if ($m.method -eq "Browser.downloadWillBegin") { $st.Begin = $m.params }
                elseif ($m.method -eq "Browser.downloadProgress") { $st.Progress = $m.params }
                return $m
            }
            $null
        }

        function Invoke-Cdp([string]$Method, $Params, [int]$TimeoutSeconds = 20) {
            $id = Send-Cdp $Method $Params
            $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
            while ((Get-Date) -lt $deadline) {
                $m = Read-Cdp 500
                if ($m -and $m.id -eq $id) { return $m }
            }
            throw "Chrome did not answer ($Method) in time."
        }

        [void](Invoke-Cdp "Browser.setDownloadBehavior" @{ behavior = "allowAndName"; downloadPath = $dl; eventsEnabled = $true })
        [void](Invoke-Cdp "Page.navigate" @{ url = ($origin + "/share/view/" + $ShareId) } 30)

        $js = "(function(){var b=[].slice.call(document.querySelectorAll('button,a,[role=button]')).filter(function(e){return /download/i.test((e.innerText||'')+(e.getAttribute('aria-label')||''));})[0]; if(!b){return 'none';} b.click(); return 'clicked';})()"
        $clicked = $false
        $until = (Get-Date).AddSeconds(60)
        while (-not $clicked -and (Get-Date) -lt $until) {
            $res = Invoke-Cdp "Runtime.evaluate" @{ expression = $js; returnByValue = $true }
            if ($res.result.result.value -eq "clicked") { $clicked = $true } else { Start-Sleep -Milliseconds 1000 }
        }
        if (-not $clicked) { throw "The Download button did not appear on the ShareFile page." }

        $until = (Get-Date).AddSeconds(180)
        while ((Get-Date) -lt $until) {
            [void](Read-Cdp 500)
            if ($st.Progress -and $st.Progress.state -eq "completed") { break }
            if ($st.Progress -and $st.Progress.state -eq "canceled") { throw "The browser download was cancelled." }
        }
        if (-not ($st.Progress -and $st.Progress.state -eq "completed")) { throw "The download did not finish within 3 minutes." }

        $name = if ($st.Begin) { [System.IO.Path]::GetFileName([string]$st.Begin.suggestedFilename) } else { "" }
        if (-not $name) { throw "ShareFile did not name the downloaded file." }

        $got = Join-Path $dl ([string]$st.Progress.guid)
        if (-not (Test-Path -LiteralPath $got)) { throw "The browser reported a finished download but the file is missing." }

        $target = Join-Path $TempFolder $name
        Move-Item -LiteralPath $got -Destination $target -Force

        if ((Get-Item -LiteralPath $target).Length -ne [int64]$st.Progress.totalBytes) {
            Remove-Item -LiteralPath $target -Force -ErrorAction SilentlyContinue
            throw "The driver download was cut off or incomplete."
        }

        $target
    }
    finally {
        try { if ($sock) { $sock.Dispose() } } catch { }
        try { if ($proc -and -not $proc.HasExited) { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue } } catch { }
        try {
            Get-CimInstance Win32_Process -Filter "Name = 'chrome.exe'" -ErrorAction SilentlyContinue |
                Where-Object { $_.CommandLine -and $_.CommandLine.Contains($unique) } |
                ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
        }
        catch { }
        Start-Sleep -Milliseconds 1500
        Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# Keeps the newest USB driver installer in the Biamp folder (older ones are archived or deleted as RetainOld in products.json says; shipped value: archive).
# Status: Current, Updated, Manual (could not be downloaded automatically: the user is asked to do it), NotFound.
function Update-UsbDriver {

    param ([string]$Html, [string]$Destination, [string]$TempFolder, [string]$ArchiveFolder, [string]$StateDir)

    $product = Get-BiampUsbProduct

    $result = [pscustomobject]@{
        Key = $product.Key; Name = $product.Name; Kind = $product.Kind; Status = "Failed"; Detail = ""
        Previous = $null; New = $null; FilePath = $null; Removed = @(); Archived = @(); Link = $null; Reason = $null
    }

    $downloaded = $null

    try {

        $link = Get-UsbDriverLink -Html $Html -Product $product

        if (-not $link) {
            $result.Status = "NotFound"
            throw "No USB driver link was found on the Biamp page (the page may have changed)."
        }

        $result.Link = $link.Url
        New-Item -ItemType Directory -Path $Destination -Force | Out-Null

        $local = @(Get-LocalUsbDrivers -Folder $Destination -Product $product)
        if ($local.Count -gt 0) { $result.Previous = $local[0].Text }

        $stateFile = Join-Path $StateDir "usb-driver-state.json"
        $state = $null
        if (Test-Path -LiteralPath $stateFile) { try { $state = Get-Content -LiteralPath $stateFile -Raw | ConvertFrom-Json } catch { } }

        # Nothing changed on the page and the file is there: no Chrome.
        if ($state -and $state.ShareUrl -eq $link.Url -and $state.PageText -eq $link.Text -and @($local | Where-Object { $_.Name -eq $state.FileName }).Count -gt 0) {
            $result.Status = "Current"
            $result.Detail = "$($local[0].Text) is the newest (the Biamp page line is unchanged)."
            return $result
        }

        try {
            if ($script:TestBackendRoot) {

                if (Test-Path -LiteralPath (Join-Path $script:TestBackendRoot "usb-driver-fail.flag")) { throw "simulated failure (test)" }

                $fake = Join-Path $script:TestBackendRoot "usb-driver-fake.exe"
                if (-not (Test-Path -LiteralPath $fake)) { throw "no fake driver in the test backend" }

                $nameFile = Join-Path $script:TestBackendRoot "usb-driver-fake.name.txt"
                $fakeName = "Biamp_Tesira_TUSBAudio_v5.50.0_2022-09-08_setup.exe"
                if (Test-Path -LiteralPath $nameFile) { $fakeName = ([System.IO.File]::ReadAllText($nameFile)).Trim() }

                $downloaded = Join-Path $TempFolder $fakeName
                Copy-Item -LiteralPath $fake -Destination $downloaded -Force
            }
            else {
                $downloaded = Invoke-TrackedDownload { Get-UsbDriverViaChrome -ShareUrl $link.Url -ShareId $link.ShareId -TempFolder $TempFolder }
            }

            $nameMatch = [regex]::Match([System.IO.Path]::GetFileName($downloaded), $product.Pattern, 'IgnoreCase')
            if (-not $nameMatch.Success) { throw "The downloaded file '$([System.IO.Path]::GetFileName($downloaded))' is not a Biamp USB driver installer." }

            Test-DownloadedFile -Path $downloaded -ExpectedSize 0 -Validate $product.Validate
        }
        catch {
            $result.Status = "Manual"
            $result.Reason = $_.Exception.Message
            $result.Detail = "The Biamp USB driver changed on the Biamp page but could not be downloaded automatically. Download it from $($link.Url)."
            return $result
        }

        $newParts = ConvertTo-VersionParts $nameMatch.Groups[1].Value
        $newName  = [System.IO.Path]::GetFileName($downloaded)
        $newText  = ($newParts -join '.')

        # Already have this version (only the page line changed): remember the new line, nothing moves.
        if ($local.Count -gt 0 -and (Compare-VersionParts $local[0].Parts $newParts) -ge 0) {
            [ordered]@{ ShareUrl = $link.Url; PageText = $link.Text; FileName = $local[0].Name; Time = (Get-Date).ToString("o") } | ConvertTo-Json | Set-Content -LiteralPath $stateFile
            $result.Status = "Current"
            $result.Detail = "$($local[0].Text) is the newest."
            return $result
        }

        # RetainOld "archive": older drivers go to Archive\ BEFORE the new one is moved in.
        # RetainOld "delete": older drivers are deleted AFTER the new one is in place (same rule as the link products).
        $archived = @()
        foreach ($old in @($local | Where-Object { $product.RetainOld -eq "archive" })) {

            if ((Compare-VersionParts $old.Parts $newParts) -ge 0) { continue }

            New-Item -ItemType Directory -Path $ArchiveFolder -Force | Out-Null
            $archiveName = $old.Name

            if (Test-Path -LiteralPath (Join-Path $ArchiveFolder $archiveName)) {
                $stamp = $old.Item.LastWriteTime.ToString("yyyy-MM-dd")
                $archiveName = "{0} ({1}){2}" -f [System.IO.Path]::GetFileNameWithoutExtension($old.Name), $stamp, [System.IO.Path]::GetExtension($old.Name)
                $n = 2
                while (Test-Path -LiteralPath (Join-Path $ArchiveFolder $archiveName)) {
                    $archiveName = "{0} ({1}-{2}){3}" -f [System.IO.Path]::GetFileNameWithoutExtension($old.Name), $stamp, $n, [System.IO.Path]::GetExtension($old.Name); $n++
                }
            }

            $to = Join-Path $ArchiveFolder $archiveName
            Move-Item -LiteralPath $old.Item.FullName -Destination $to
            $archived += [ordered]@{ From = $old.Item.FullName; To = $to }
        }

        $target = Join-Path $Destination $newName
        Move-Item -LiteralPath $downloaded -Destination $target -Force
        $downloaded = $null

        $removed = @()
        if ($product.RetainOld -eq "delete") {
            foreach ($old in $local) {
                if ((Compare-VersionParts $old.Parts $newParts) -ge 0) { continue }
                Remove-Item -LiteralPath $old.Item.FullName -Force
                $removed += $old.Name
            }
        }

        [ordered]@{ ShareUrl = $link.Url; PageText = $link.Text; FileName = $newName; Time = (Get-Date).ToString("o") } | ConvertTo-Json | Set-Content -LiteralPath $stateFile

        $result.Status   = "Updated"
        $result.New      = $newText
        $result.FilePath = $target
        $result.Removed  = $removed
        $result.Archived = $archived
        $result.Detail   = "$(if ($result.Previous) { "$($result.Previous) -> " })$newText"
    }
    catch {
        if ($result.Status -ne "NotFound") { $result.Status = "Failed" }
        $result.Detail = $_.Exception.Message
    }
    finally {
        if ($downloaded) { Remove-Item -LiteralPath $downloaded -Force -ErrorAction SilentlyContinue }
    }

    $result
}


# ------------------------------------------------------------
# Notices, history, journal (same behaviour as the other updaters)
# ------------------------------------------------------------

function Start-PendingNotice {

    $state = $script:config.StateDir

    if (-not ((Test-Path (Join-Path $state "pending-notice.json")) -or (Test-Path (Join-Path $state "pending-error.json")))) { return }

    $noticeTask = if ($script:config.NoticeTaskName) { $script:config.NoticeTaskName } else { "Biamp Updater Notice" }

    try {
        if (Get-ScheduledTask -TaskName $noticeTask -ErrorAction SilentlyContinue) {
            Start-ScheduledTask -TaskName $noticeTask
            return
        }
    }
    catch { }

    if (-not (Test-Path (Join-Path $state "Show-BiampNotice.ps1"))) { return }

    Start-Process -FilePath (Get-Process -Id $PID).Path -WindowStyle Hidden -ArgumentList @(
        "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", (Join-Path $state "Show-BiampNotice.ps1")
    )
}

# One dated line per attempt, even if more than one code path calls this.
function Write-RunHistory {

    param ([string]$Outcome = $script:runOutcome, [string]$Detail = $script:runDetail)

    if ($script:runHistoryWritten) { return }
    $script:runHistoryWritten = $true

    if (-not $Outcome) {
        $Outcome = "UNKNOWN"
        $Detail  = "The run ended without recording a result. See Biamp-Updater.log."
    }

    $took = (Get-Date) - $script:runStarted
    $tookText = if ($took.TotalMinutes -ge 1) { "{0}m {1}s" -f [int][math]::Floor($took.TotalMinutes), $took.Seconds } else { "{0}s" -f [int][math]::Round($took.TotalSeconds) }

    $line = "{0}  {1,-10} {2} (took {3})" -f $script:runStarted.ToString("yyyy-MM-dd HH:mm:ss"), $Outcome, (($Detail -replace '\s+', ' ').Trim()), $tookText

    try {
        $historyFile = Join-Path (Join-Path $script:config.StateDir "Logs") "Run-History.log"
        New-Item -ItemType Directory -Path (Split-Path $historyFile) -Force | Out-Null

        if ((Test-Path $historyFile) -and (Get-Item $historyFile).Length -gt 1MB) {
            Move-Item $historyFile ($historyFile + ".old") -Force
        }

        Add-Content -Path $historyFile -Value $line -Encoding UTF8
    }
    catch { }
}

# Error notice for a failed run. The same error again within 24 hours is logged but not shown again.
function New-ErrorNotice {

    param ([string]$Step, [string]$Message)

    $state     = $script:config.StateDir
    $seenFile  = Join-Path $state "last-error-notice.json"
    $signature = "$Step|$Message"

    try {
        if (Test-Path $seenFile) {
            $seen = Get-Content $seenFile -Raw | ConvertFrom-Json
            if ($seen.Signature -eq $signature -and ((Get-Date) - [datetime]$seen.Time).TotalHours -lt 24) {
                return "not repeated: same error within 24 hours"
            }
        }

        [ordered]@{
            Time        = $script:runStarted.ToString("o")
            Step        = $Step
            Message     = $Message
            HistoryFile = (Join-Path (Join-Path $state "Logs") "Run-History.log")
            LogFile     = (Join-Path (Join-Path $state "Logs") "Biamp-Updater.log")
        } | ConvertTo-Json | Set-Content -Path (Join-Path $state "pending-error.json")

        [ordered]@{ Signature = $signature; Time = (Get-Date).ToString("o") } | ConvertTo-Json | Set-Content -Path $seenFile

        "shown to the user"
    }
    catch { "could not be created" }
}

# "new version downloaded" notice: one pending file listing every product updated since the user last acknowledged it.
function Add-UpdateNotice {

    param ($Updated)

    $file  = Join-Path $script:config.StateDir "pending-notice.json"
    $items = @()

    if (Test-Path $file) {
        try { $items = @((Get-Content $file -Raw | ConvertFrom-Json).Items) } catch { }
    }

    foreach ($u in $Updated) {
        $items = @($items | Where-Object { $_.Key -ne $u.Key })
        $items += [ordered]@{ Key = $u.Key; Kind = $u.Kind; Name = $u.Name; Version = $u.New; PreviousVersion = $u.Previous; FilePath = $u.FilePath }
    }

    [ordered]@{ Folder = $script:config.BiampFolder; FirmwareFolder = $script:config.FirmwareFolder; Items = $items } | ConvertTo-Json -Depth 4 | Set-Content -Path $file
}

# Journal: what this run added, archived and deleted. Undo (Options) reads Archived to put software back.
function Write-Journal {

    param ($Results)

    try {
        $folder = Join-Path $script:config.StateDir "Journal"
        New-Item -ItemType Directory -Path $folder -Force | Out-Null

        $updates = @($Results | Where-Object { $_.Status -eq "Updated" })
        if ($updates.Count -eq 0) { return }

        [ordered]@{
            Time    = $script:runStarted.ToString("o")
            Updates = @($updates | ForEach-Object {
                [ordered]@{ Kind = $_.Kind; Key = $_.Key; Product = $_.Name; Added = $_.FilePath; Archived = @($_.Archived); Removed = @($_.Removed) }
            })
        } | ConvertTo-Json -Depth 5 | Set-Content -Path (Join-Path $folder ($script:runStarted.ToString("yyyyMMdd-HHmmss") + ".json"))
    }
    catch { }
}


# ------------------------------------------------------------
# Main run
# ------------------------------------------------------------

# Dot-sourced (by the tests): functions only.
if ($MyInvocation.InvocationName -eq '.') { return }

$script:TestBackendRoot = $TestBackendRoot
$script:config     = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$script:runStarted = Get-Date
$script:runOutcome = $null
$script:runDetail  = $null

$stateDir   = $script:config.StateDir
$logFolder  = Join-Path $stateDir "Logs"
$tempFolder = Join-Path $stateDir "Temp"

New-Item -ItemType Directory -Path $logFolder -Force | Out-Null
Start-Transcript -Path (Join-Path $logFolder "Biamp-Updater.log") -Append | Out-Null

Write-Host ""
Write-Host "============================================================"
Write-Host "Biamp updater started: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Write-Host "============================================================"

# Never two runs at once.
$mutex = New-Object System.Threading.Mutex($false, "Global\AVSoftwareUpdater-BIAMP")

try { $mutexAcquired = $mutex.WaitOne(0, $false) }
catch [System.Threading.AbandonedMutexException] { $mutexAcquired = $true }

if (-not $mutexAcquired) {
    Write-Host "Biamp updater is already running. This instance will exit."
    $script:runOutcome = "SKIPPED"
    $script:runDetail  = "Another update check was already running."
    Write-RunHistory
    try { Stop-Transcript | Out-Null } catch { }
    exit 0
}

try {

    # A notice the user has not acknowledged yet appears again.
    try { Start-PendingNotice } catch { }

    # Error reports that could not be sent earlier (share offline) are sent now.
    try { [void](Send-ReportOutbox -Config $script:config) } catch { }

    # --- Blocked Wi-Fi (phone hotspots) ---
    if (-not $TestBackendRoot) {

        $wifiInfo = netsh wlan show interfaces | Out-String
        $ssid = if ($wifiInfo -match '(?m)^\s*SSID\s*:\s*(.+)$') { $Matches[1].Trim() } else { $null }

        if ($ssid -and $ssid -in @($script:config.BlockedSSIDs)) {
            Write-Host "Connected to blocked Wi-Fi: $ssid. Update check skipped."
            $script:runOutcome = "SKIPPED"
            $script:runDetail  = "Connected to blocked Wi-Fi network '$ssid'."
            return
        }
    }

    $step = "preparing the update check"

    $destination    = $script:config.BiampFolder
    $firmwareFolder = if ($script:config.FirmwareFolder) { $script:config.FirmwareFolder } else { Join-Path $destination "Firmware" }
    $archiveFolder  = Join-Path $destination "Archive"
    New-Item -ItemType Directory -Path $destination -Force | Out-Null

    if (Test-Path $tempFolder) { Remove-Item $tempFolder -Recurse -Force -ErrorAction SilentlyContinue }
    New-Item -ItemType Directory -Path $tempFolder -Force | Out-Null

    # --- Read the Biamp page ---
    $step = "reading the Biamp download page"
    $pageUrl = if ($script:config.PageUrl) { $script:config.PageUrl } else { $script:DefaultPageUrl }

    try { $html = Get-PageHtml -PageUrl $pageUrl }
    catch {
        # No internet or site down is expected now and then: not an error notice.
        $status = $null
        try { $status = [int]$_.Exception.Response.StatusCode } catch { }
        if (-not $status -or $status -ge 500 -or $_.Exception -is [System.Net.Http.HttpRequestException] -or $_.Exception.InnerException -is [System.Net.Sockets.SocketException]) {
            Write-Host "Could not reach the Biamp page: $($_.Exception.Message)"
            $script:runOutcome = "SKIPPED"
            $script:runDetail  = "Could not reach the Biamp download page (no internet, or the site is down): $($_.Exception.Message)"
            return
        }
        throw
    }

    $pageLinks = Get-PageLinks -Html $html -BaseUrl $pageUrl
    if (@($pageLinks).Count -eq 0) { throw "The Biamp page was read but holds no download links (the page may have changed)." }
    $olderStart = Get-OlderFirmwareStart -Html $html

    # --- Each enabled product ---
    $results = @()
    $enabled = @($script:config.EnabledProducts)

    foreach ($product in Get-BiampProducts) {

        if ($product.Key -notin $enabled) { continue }

        $step = "checking $($product.Name)"
        Write-Host "$($product.Name)..."

        $dest = if ($product.Folder -eq "firmware") { $firmwareFolder } else { $destination }

        $r = Update-Product -Product $product -PageLinks $pageLinks -OlderStart $olderStart -Destination $dest -TempFolder $tempFolder -ArchiveFolder $archiveFolder
        Write-Host "  $($r.Status): $($r.Detail)"
        $results += $r
    }

    if ($enabled -contains "usb-driver") {

        $step = "checking the Biamp USB driver"
        Write-Host "$((Get-BiampUsbProduct).Name)..."

        $r = Update-UsbDriver -Html $html -Destination $destination -TempFolder $tempFolder -ArchiveFolder $archiveFolder -StateDir $stateDir
        Write-Host "  $($r.Status): $($r.Detail)"
        if ($r.Reason) { Write-Host "  (reason: $($r.Reason))" }
        $results += $r
    }

    Write-Journal $results

    $updated = @($results | Where-Object { $_.Status -eq "Updated" })
    $failed  = @($results | Where-Object { $_.Status -in "Failed", "NotFound" })
    $manual  = @($results | Where-Object { $_.Status -eq "Manual" })

    if ($updated.Count -gt 0) {
        try { Add-UpdateNotice $updated; Start-PendingNotice } catch { }
    }

    $summary = ($results | ForEach-Object { "$($_.Name): $($_.Status.ToLower())$(if ($_.Status -ne 'Current') { " ($($_.Detail))" })" }) -join "; "

    # One error notice for everything that needs the user (failures and the by-hand USB driver), once per 24 hours.
    $noticeLines = @()
    $noticeLines += @($failed | ForEach-Object { "$($_.Name): $($_.Detail)" })
    $noticeLines += @($manual | ForEach-Object { $_.Detail })
    $noticeNote = $null

    if ($noticeLines.Count -gt 0) {
        $noticeNote = New-ErrorNotice -Step "updating" -Message ($noticeLines -join "`n")
        try { Start-PendingNotice } catch { }
    }

    # Error report for failed downloads only. The by-hand USB driver step ($manual) is not an error and is not reported.
    if ($failed.Count -gt 0) {
        try { [void](Send-ErrorReport -Config $script:config -Category DownloadFailed -Message (@($failed | ForEach-Object { "$($_.Name): $($_.Detail)" }) -join "`n") -Step "updating" -Context @{ Products = @($failed | ForEach-Object { $_.Key }); Notice = $noticeNote }) } catch { }
    }

    if ($failed.Count -gt 0) {
        $script:runOutcome = "FAILED"
        $script:runDetail  = "$summary [error notice $noticeNote]"
    }
    elseif ($updated.Count -gt 0) {
        $script:runOutcome = "UPDATED"
        $script:runDetail  = "$summary$(if ($manual.Count -gt 0) { " [error notice $noticeNote]" })"
    }
    else {
        $script:runOutcome = "CURRENT"
        $script:runDetail  = "All enabled Biamp products are up to date.$(if ($manual.Count -gt 0) { " Needs you: $($manual[0].Detail) [error notice $noticeNote]" })"
    }
}
catch {

    $message = $_.Exception.Message
    Write-Host "ERROR while $step`: $message"
    Write-Host $_.ScriptStackTrace

    $noticeNote = New-ErrorNotice -Step $step -Message $message
    try { Start-PendingNotice } catch { }

    try { [void](Send-ErrorReport -Config $script:config -Category RunFailed -Message $message -Step $step -ErrorRecord $_ -Context @{ Notice = $noticeNote }) } catch { }

    $script:runOutcome = "FAILED"
    $script:runDetail  = "Failed while $step`: $message [error notice $noticeNote]"
}
finally {

    Remove-Item $tempFolder -Recurse -Force -ErrorAction SilentlyContinue

    Write-RunHistory

    try { $mutex.ReleaseMutex() } catch { }
    try { Stop-Transcript | Out-Null } catch { }
}
