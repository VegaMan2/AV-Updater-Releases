# ============================================================
# Q-Sys Updater -- notices
#
# Started by the updater (through the on-demand scheduled task
# "<TaskName> Notice", which has NO time limit) when a notice is waiting.
# If several are waiting they are shown one after another in this order:
#
#   pending-signin-failed.json  The updater is paused because the saved Q-SYS
#                               sign-in does not work. Three kinds:
#                                 failed       Q-SYS rejected the password
#                                 unconfirmed  repeated sign-ins could not be
#                                              confirmed (safety cap)
#                                 reminder     weekly reminder while paused
#                               Buttons: Update Password | OK
#                               (the weekly reminder also has Remove Updater)
#   pending-error.json          A run failed. Shows the step and the error.
#                               Buttons: Open Log Folder | OK
#   pending-notice.json         A new version was downloaded.
#                               Buttons: Go to Folder | OK
#
# A notice never closes by itself. It stays on screen until the user clicks
# one of its buttons. The X button is removed and Alt+F4 is blocked. If the
# PC is restarted or the user logs off first, the notice stays pending and
# appears again at the next updater run. Only after the user clicks a button
# is it cleared, so each one is acknowledged exactly once.
# ============================================================

[CmdletBinding()]
param (
    [string]$StateDir = $PSScriptRoot
)

$ErrorActionPreference = "Stop"

$signInPending  = Join-Path $StateDir "pending-signin-failed.json"
$errorPending   = Join-Path $StateDir "pending-error.json"
$updatePending  = Join-Path $StateDir "pending-notice.json"
$notifiedFile   = Join-Path $StateDir "last-notified-version.txt"
$passwordScript = Join-Path $StateDir "Update-QSysPassword.ps1"
$optionsScript  = Join-Path $StateDir "Options-QSysUpdater.ps1"

if (
    -not (Test-Path $signInPending) -and
    -not (Test-Path $errorPending) -and
    -not (Test-Path $updatePending)
) {
    return
}

# Only one notice window at a time.
$mutex = New-Object System.Threading.Mutex($false, "Global\QSysUpdater-Notice")

try {
    $mutexAcquired = $mutex.WaitOne(0, $false)
}
catch [System.Threading.AbandonedMutexException] {
    $mutexAcquired = $true
}

if (-not $mutexAcquired) {
    return
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()


# Shows one notice. Returns $true when the user clicked a button.
# Buttons: an action, an optional second action, and OK.
# The text decides the window height (user 2026-11-14): at 125% display scaling or with a long error message the
# fixed box cut the text off. Grows the label and the window to fit the text in the label's own font; when that
# would be taller than the screen, the text goes in a scrolling read-only box instead. Buttons move down with it.
function Set-NoticeFit {
    param ($Form, $Label, [int]$MinHeight)
    $width = $Label.Width
    $flags = [System.Windows.Forms.TextFormatFlags]::WordBreak -bor [System.Windows.Forms.TextFormatFlags]::TextBoxControl
    $need = [System.Windows.Forms.TextRenderer]::MeasureText([string]$Label.Text, $Label.Font, (New-Object System.Drawing.Size($width, 100000)), $flags).Height + 8
    $screenMax = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Height - 160
    $height = [math]::Max($MinHeight, $need)
    $textControl = $Label
    if ($height -gt $screenMax) {
        $height = [math]::Max($MinHeight, $screenMax)
        $box = New-Object System.Windows.Forms.TextBox
        $box.Multiline = $true; $box.ReadOnly = $true; $box.ScrollBars = "Vertical"; $box.BorderStyle = "None"
        $box.BackColor = $Form.BackColor; $box.TabStop = $false; $box.Font = $Label.Font
        $box.Text = ([string]$Label.Text) -replace "(?<!`r)`n", "`r`n"
        $box.Location = $Label.Location
        $Form.Controls.Remove($Label); $Form.Controls.Add($box)
        $textControl = $box
    }
    $textControl.Size = New-Object System.Drawing.Size($width, $height)
    $delta = $height - $MinHeight
    if ($delta -gt 0) {
        foreach ($c in @($Form.Controls)) { if ($c -is [System.Windows.Forms.Button]) { $c.Top += $delta } }
        $Form.ClientSize = New-Object System.Drawing.Size($Form.ClientSize.Width, ($Form.ClientSize.Height + $delta))
    }
}

function Show-Notice {

    param (
        [string]$Text,
        [string]$ActionText,
        [scriptblock]$Action,
        [string]$SecondText,
        [scriptblock]$SecondAction
    )

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Q-Sys Updater"
    $form.StartPosition = "CenterScreen"
    $form.FormBorderStyle = "FixedDialog"
    $form.ControlBox = $false
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $form.TopMost = $true
    $form.ClientSize = New-Object System.Drawing.Size(580, 420)

    # Only the buttons can close the window (Tag = "ack").
    # Windows shutdown or logoff is still allowed to end it.
    $form.Add_FormClosing({
        param($sender, $e)

        if (
            $sender.Tag -ne "ack" -and
            $e.CloseReason -ne [System.Windows.Forms.CloseReason]::WindowsShutDown
        ) {
            $e.Cancel = $true
        }
    })

    $label = New-Object System.Windows.Forms.Label
    $label.Location = New-Object System.Drawing.Point(20, 16)
    $label.Size = New-Object System.Drawing.Size(540, 340)
    $label.Text = $Text

    # Buttons are placed from the right: OK, then the second action, then the first.
    $okButton = New-Object System.Windows.Forms.Button
    $okButton.Text = "OK"
    $okButton.Location = New-Object System.Drawing.Point(470, 372)
    $okButton.Size = New-Object System.Drawing.Size(90, 30)
    $okButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $okButton.Add_Click({
        $this.FindForm().Tag = "ack"
    })

    $controls = @($label, $okButton)
    $nextX = 470

    if ($SecondText) {

        $nextX -= 150

        $second = New-Object System.Windows.Forms.Button
        $second.Text = $SecondText
        $second.Location = New-Object System.Drawing.Point($nextX, 372)
        $second.Size = New-Object System.Drawing.Size(140, 30)
        $second.Tag = $SecondAction
        $second.Add_Click({
            $this.FindForm().Tag = "ack"
            & $this.Tag
            $this.FindForm().Close()
        })

        $controls += $second
    }

    $nextX -= 150

    $first = New-Object System.Windows.Forms.Button
    $first.Text = $ActionText
    $first.Location = New-Object System.Drawing.Point($nextX, 372)
    $first.Size = New-Object System.Drawing.Size(140, 30)
    $first.Tag = $Action
    $first.Add_Click({
        $this.FindForm().Tag = "ack"
        & $this.Tag
        $this.FindForm().Close()
    })

    $controls += $first

    $form.AcceptButton = $okButton

    $form.Controls.AddRange($controls)

    Set-NoticeFit -Form $form -Label $label -MinHeight 340

    $null = $form.ShowDialog()

    $acknowledged = ($form.Tag -eq "ack")
    $form.Dispose()

    return $acknowledged
}


try {

    $pwshPath = (Get-Process -Id $PID).Path

    # Wording shared by the sign-in notices.
    $tipText =
        "Recommended first: sign in to your Q-SYS account at qsys.com in your normal " +
        "browser with the correct password. A successful sign-in may reset the count " +
        "of failed attempts on your account."

    $howToUpdateText =
        "To update the saved password at any time, open AV Updater, go to the " +
        "Q-Sys tab and click 'Update password...'. " +
        "If you cannot find it, run this in PowerShell:`r`n" +
        "    pwsh -File `"$passwordScript`""

    # --------------------------------------------------------
    # 1. The updater is paused: the saved Q-SYS sign-in does not work
    # --------------------------------------------------------

    if (Test-Path $signInPending) {

        $notice = Get-Content $signInPending -Raw | ConvertFrom-Json

        $kind = if ($notice.Kind) { $notice.Kind } else { "failed" }

        $updatePasswordAction = {
            Start-Process -FilePath $pwshPath -ArgumentList @(
                "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $passwordScript
            )
        }.GetNewClosure()

        if ($kind -eq "reminder") {

            $since =
                if ($notice.PausedSince) { ([datetime]$notice.PausedSince).ToString("MMMM d, yyyy") }
                else { "a while" }

            $text =
                "Reminder: the Q-Sys Updater has been paused since $since because " +
                "the saved Q-SYS sign-in did not work ($($notice.Message)). No new Q-SYS " +
                "versions are being downloaded.`r`n`r`n" +
                "Choose Update Password to fix it, or Remove Updater if you no longer " +
                "want it on this PC. You will be reminded again in a week.`r`n`r`n" +
                "$tipText`r`n`r`n$howToUpdateText"

            $removeAction = {
                Start-Process -FilePath $pwshPath -WorkingDirectory $env:TEMP -ArgumentList @(
                    "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $optionsScript,
                    "-Uninstall", "-InstallDir", $StateDir
                )
            }.GetNewClosure()

            $acknowledged = Show-Notice `
                -Text $text `
                -ActionText "Update Password" `
                -Action $updatePasswordAction `
                -SecondText "Remove Updater" `
                -SecondAction $removeAction
        }
        else {

            $intro =
                if ($kind -eq "unconfirmed") {
                    "The updater has signed in more than once without being able to confirm " +
                    "that it worked, so it has paused to protect your Q-SYS account from " +
                    "repeated failed attempts. No update was downloaded.`r`n`r`n" +
                    "Details: $($notice.Message)"
                }
                else {
                    "Q-SYS did not accept the saved sign-in, so no update was downloaded.`r`n`r`n" +
                    "Q-SYS said: $($notice.Message)"
                }

            $text =
                "$intro`r`n`r`n" +
                "The updater will not try again until the saved password is updated, so " +
                "your account is not hit with more failed attempts. You will get a " +
                "reminder once a week while it is paused.`r`n`r`n" +
                "$tipText`r`n`r`n$howToUpdateText"

            $acknowledged = Show-Notice `
                -Text $text `
                -ActionText "Update Password" `
                -Action $updatePasswordAction
        }

        if ($acknowledged) {
            Remove-Item $signInPending -Force
        }
    }

    # --------------------------------------------------------
    # 2. A run failed: show the error so it can be investigated
    # --------------------------------------------------------

    if (Test-Path $errorPending) {

        $notice = Get-Content $errorPending -Raw | ConvertFrom-Json

        $when = ([datetime]$notice.Time).ToString("MMMM d, yyyy h:mm tt")

        $text =
            "The Q-Sys Updater could not finish its last check.`r`n`r`n" +
            "When:  $when`r`n" +
            "While: $($notice.Step)`r`n" +
            "Error: $($notice.Message)`r`n`r`n" +
            "It will try again at the next logon. The same error is " +
            "not shown again for 24 hours, but every attempt is written to the logs:`r`n`r`n" +
            "Run history (one line per attempt):`r`n    $($notice.HistoryFile)`r`n`r`n" +
            "Detailed log (steps, error location, call stack):`r`n    $($notice.LogFile)`r`n`r`n" +
            "If it keeps failing, send both files to whoever maintains this updater."

        $logTarget = $notice.HistoryFile

        $acknowledged = Show-Notice `
            -Text $text `
            -ActionText "Open Log Folder" `
            -Action {
                Start-Process explorer.exe -ArgumentList "/select,`"$logTarget`""
            }.GetNewClosure()

        if ($acknowledged) {
            Remove-Item $errorPending -Force
        }
    }

    # --------------------------------------------------------
    # 3. A new version was downloaded
    # --------------------------------------------------------

    if (Test-Path $updatePending) {

        $notice = Get-Content $updatePending -Raw | ConvertFrom-Json

        $replaced =
            if ($notice.PreviousVersion -and $notice.PreviousVersion -ne "0.0.0") {
                " (replaces $($notice.PreviousVersion))"
            }
            else {
                ""
            }

        $text =
            "A new version of Q-SYS Designer has been downloaded.`r`n`r`n" +
            "Version $($notice.Version)$replaced`r`n" +
            "Saved to: $($notice.Folder)"

        $target = $notice.FilePath

        $acknowledged = Show-Notice `
            -Text $text `
            -ActionText "Go to Folder" `
            -Action {
                Start-Process explorer.exe -ArgumentList "/select,`"$target`""
            }.GetNewClosure()

        # Acknowledged: record the version and clear the pending notice.
        if ($acknowledged) {
            Set-Content -Path $notifiedFile -Value $notice.Version
            Remove-Item $updatePending -Force
        }
    }
}
finally {

    try {
        $mutex.ReleaseMutex()
    }
    catch {
    }

    $mutex.Dispose()
}
