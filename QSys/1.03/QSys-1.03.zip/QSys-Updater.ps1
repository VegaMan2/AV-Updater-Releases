# ============================================================
# Q-SYS Designer Automatic Updater
# ============================================================

$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.IO.Compression.FileSystem

# Portable settings written by Install-QSysUpdater.ps1 (no credentials in here)
$config = Get-Content (Join-Path $PSScriptRoot "config.json") -Raw | ConvertFrom-Json

# Error reports (Reporting.ps1 next to this script; never passwords). A missing or damaged
# module never changes a run: the two functions the run calls then do nothing.
$reportingScript = Join-Path $PSScriptRoot "Reporting.ps1"
if (Test-Path -LiteralPath $reportingScript) { try { . $reportingScript } catch { } }
if (-not (Get-Command Send-ErrorReport -CommandType Function -ErrorAction SilentlyContinue) -or
    -not (Get-Command Send-ReportOutbox -CommandType Function -ErrorAction SilentlyContinue)) {
    function Send-ErrorReport { $null }
    function Send-ReportOutbox { 0 }
}

# The one product list (products.json, next to this script): page URL, sign-in host, file-name filter,
# version pattern, output name and old-version rule. Same shape as the other updaters: { Vendor, PageUrl, Products[] }.
function Start-DownloadStatus {
    $statusPath = $null
    try {
        $state = $script:config.StateDir
        if ($state -and (Test-Path -LiteralPath $state)) {
            $statusPath = Join-Path $state 'download-status.json'
            $process = [Diagnostics.Process]::GetCurrentProcess()
            $json = @{ Pid = $PID; StartTicks = $process.StartTime.ToUniversalTime().Ticks.ToString(); Status = 'Downloading' } | ConvertTo-Json -Compress
            [IO.File]::WriteAllText($statusPath, $json)
        }
    } catch { $statusPath = $null }
    return $statusPath
}

function Invoke-TrackedDownload {
    param([scriptblock]$Transfer)
    $statusPath = Start-DownloadStatus
    try { & $Transfer }
    finally { if ($statusPath) { try { [IO.File]::Delete($statusPath) } catch { } } }
}

# An old version that is being installed right now (an installer running from it, or a file in it held open by
# another program) is never moved or deleted: the caller skips that product this run and tries again next run
# (user 2026-11-14). Returns a plain-words reason, or $null when nothing is in use. Missing paths are ignored.
function Get-InUseReason {
    param ([string[]]$Paths)
    $items = @()
    foreach ($p in $Paths) {
        if (-not $p) { continue }
        try { $items += Get-Item -LiteralPath $p -Force -ErrorAction Stop } catch { }
    }
    if ($items.Count -eq 0) { return $null }
    $roots = @($items | ForEach-Object { $_.FullName.TrimEnd('\') })
    foreach ($proc in @(Get-Process -ErrorAction SilentlyContinue)) {
        $exe = $null
        try { $exe = $proc.Path } catch { }
        if (-not $exe) { continue }
        foreach ($r in $roots) {
            if ($exe.Equals($r, [StringComparison]::OrdinalIgnoreCase) -or $exe.StartsWith($r + '\', [StringComparison]::OrdinalIgnoreCase)) {
                return "$(Split-Path -Leaf $r) is in use ($($proc.ProcessName) is running from it)"
            }
        }
    }
    # Offline / RecallOnDataAccess: a cloud-only copy is not held by anything here, and opening it would download it.
    $cloudOnly = [int][IO.FileAttributes]::Offline -bor 0x400000
    foreach ($it in $items) {
        $files = if ($it.PSIsContainer) { @(Get-ChildItem -LiteralPath $it.FullName -Recurse -File -Force -ErrorAction SilentlyContinue) } else { @($it) }
        foreach ($f in $files) {
            if (([int]$f.Attributes -band $cloudOnly) -ne 0) { continue }
            $stream = $null
            try { $stream = [IO.File]::Open($f.FullName, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::None) }
            catch [System.IO.FileNotFoundException] { }
            catch [System.IO.DirectoryNotFoundException] { }
            catch [System.UnauthorizedAccessException] { }
            catch { return "$($f.Name) is in use (open in another program)" }
            finally { if ($stream) { $stream.Dispose() } }
        }
    }
    return $null
}

function Read-QSysCatalog {

    $file = Join-Path $PSScriptRoot "products.json"
    if (-not (Test-Path -LiteralPath $file)) { throw "products.json is missing next to QSys-Updater.ps1." }

    $catalog = Get-Content -LiteralPath $file -Raw | ConvertFrom-Json
    if (-not $catalog.PageUrl -or @($catalog.Products).Count -eq 0) { throw "products.json has no PageUrl or no Products (the file may be damaged)." }

    foreach ($p in @($catalog.Products)) {
        if ($p.RetainOld -notin "archive", "delete" -or $p.Folder -notin "root", "firmware") {
            throw "products.json: product '$($p.Key)' needs RetainOld (archive or delete) and Folder (root or firmware)."
        }
        if (-not $p.FileFilter -or -not $p.OutputName -or -not $p.VersionPattern -or -not $p.AuthHost -or -not $p.LocalNameMatch) {
            throw "products.json: product '$($p.Key)' needs AuthHost, VersionPattern, LocalNameMatch, FileFilter and OutputName."
        }
    }

    $catalog
}

$qsysCatalog = Read-QSysCatalog
$qsysProduct = @($qsysCatalog.Products | Where-Object { $_.Handler -eq "browser" -and $_.Supported })[0]
if (-not $qsysProduct) { throw "products.json has no supported browser product." }

# Starts the "new version downloaded" notice if one is waiting for the user.
# Uses the on-demand notice task (no time limit, independent of this run).
function Start-PendingNotice {

    if (
        -not (Test-Path (Join-Path $config.StateDir "pending-notice.json")) -and
        -not (Test-Path (Join-Path $config.StateDir "pending-signin-failed.json")) -and
        -not (Test-Path (Join-Path $config.StateDir "pending-error.json"))
    ) {
        return
    }

    $noticeTask =
        if ($config.NoticeTaskName) { $config.NoticeTaskName }
        else { "Q-Sys Updater Notice" }

    try {
        if (Get-ScheduledTask -TaskName $noticeTask -ErrorAction SilentlyContinue) {
            Start-ScheduledTask -TaskName $noticeTask
            return
        }
    }
    catch {
    }

    # Fallback if the notice task is not installed.
    $pwshPath = (Get-Process -Id $PID).Path

    # (Hidden only hides the console; the notice window itself still appears.)
    Start-Process `
        -FilePath $pwshPath `
        -WindowStyle Hidden `
        -ArgumentList @(
            "-NoProfile"
            "-ExecutionPolicy", "Bypass"
            "-File", (Join-Path $config.StateDir "Show-QSysNotice.ps1")
        )
}

# Reads the sign-in page AFTER the sign-in code has clicked Sign in and says what
# it sees: Failed, LeftSignIn (signed in), or Waiting. Read only: never types or
# clicks. The red message box is visible on EVERY fresh sign-in page with the text
# "You need to sign in or sign up before continuing", so that exact text is
# normal; any other visible text in it means Q-SYS rejected the sign-in.
# (Prototype and tests: Tools\Prototype\Test-SignInDetection.ps1)
function Resolve-SignInState {

    param ($Snapshot)

    if ($Snapshot.url -notlike "https://ciam.qsc.com/*") {
        return "LeftSignIn"
    }

    $message = ([string]$Snapshot.errorMsgText).Trim()

    if (
        $Snapshot.errorBoxVisible -and
        $message -and
        $message -notlike "*You need to sign in or sign up before continuing*"
    ) {
        return "Failed"
    }

    return "Waiting"
}

# ------------------------------------------------------------
# Run history: ONE dated line per attempt, whatever happened
#
#   2026-10-25 20:15:03  UPDATED    Q-SYS Designer 10.5.0 -> 10.6.0 ... (took 4m 12s)
#   2026-10-25 20:20:11  UP TO DATE Q-SYS Designer 10.6.0 is current ... (took 3s)
#   2026-10-25 20:21:00  SKIPPED    Connected to blocked Wi-Fi network 'MyPhone'. (took 0s)
#   2026-10-25 20:22:10  FAILED     Download timed out after 1800 seconds. (took 31m 2s)
#
# File: Logs\Run-History.log (kept to about 1 MB; the previous file becomes
# Run-History.log.old). The detailed step-by-step log is QSys-Updater.log.
# ------------------------------------------------------------

$runStarted        = Get-Date
$runOutcome        = $null
$runDetail         = ""
$runStep           = ""
$runHistoryWritten = $false

function Write-RunHistory {

    param (
        [string]$Outcome = $script:runOutcome,
        [string]$Detail  = $script:runDetail
    )

    # One line per attempt, even if more than one code path calls this.
    if ($script:runHistoryWritten) {
        return
    }

    $script:runHistoryWritten = $true

    if (-not $Outcome) {
        $Outcome = "UNKNOWN"
        $Detail  = "The run ended without recording a result. See QSys-Updater.log."
    }

    $took = (Get-Date) - $script:runStarted

    $tookText =
        if ($took.TotalMinutes -ge 1) {
            "{0}m {1}s" -f [int][math]::Floor($took.TotalMinutes), $took.Seconds
        }
        else {
            "{0}s" -f [int][math]::Round($took.TotalSeconds)
        }

    $detailText = ($Detail -replace '\s+', ' ').Trim()

    $line = "{0}  {1,-10} {2} (took {3})" -f $script:runStarted.ToString("yyyy-MM-dd HH:mm:ss"), $Outcome, $detailText, $tookText

    try {
        $historyFile = Join-Path (Join-Path $config.StateDir "Logs") "Run-History.log"

        New-Item -ItemType Directory -Path (Split-Path $historyFile) -Force | Out-Null

        if ((Test-Path $historyFile) -and (Get-Item $historyFile).Length -gt 1MB) {
            Move-Item $historyFile ($historyFile + ".old") -Force
        }

        Add-Content -Path $historyFile -Value $line -Encoding UTF8
    }
    catch {
        # The history must never be the reason a run fails.
    }
}

# ------------------------------------------------------------
# Safety cap on password submissions
#
# This does NOT depend on recognising an error message. Every time the updater
# submits the saved password it counts one "unconfirmed" attempt; the count goes
# back to 0 when a sign-in is confirmed (the page leaves the sign-in site, a
# download starts, or the download completes). If $maxUnconfirmedSubmissions
# attempts in a row are never confirmed, the next run pauses instead of trying
# again. A new saved password (a newer credential file) starts the count over.
# ------------------------------------------------------------

$maxUnconfirmedSubmissions = 2
$signInStateFile = Join-Path $config.StateDir "signin-state.json"

function Get-CredentialStamp {

    $path = Join-Path $config.StateDir "QSys-Credential.xml"

    if (Test-Path $path) { (Get-Item $path).LastWriteTimeUtc.Ticks.ToString() } else { "none" }
}

function Get-SignInState {

    $state = [pscustomobject]@{
        CredentialStamp = (Get-CredentialStamp)
        Unconfirmed     = 0
        LastSubmission  = $null
    }

    try {
        if (Test-Path $signInStateFile) {

            $saved = Get-Content $signInStateFile -Raw | ConvertFrom-Json

            # A different saved password starts the count over.
            if ($saved.CredentialStamp -eq $state.CredentialStamp) {
                $state.Unconfirmed    = [int]$saved.Unconfirmed
                $state.LastSubmission = $saved.LastSubmission
            }
        }
    }
    catch { }

    $state
}

function Save-SignInState {

    param ($State)

    try { $State | ConvertTo-Json | Set-Content -Path $signInStateFile } catch { }
}

function Register-PasswordSubmission {

    $state = Get-SignInState
    $state.Unconfirmed++
    $state.LastSubmission = (Get-Date).ToString("o")
    Save-SignInState $state
}

function Reset-SignInCounter {

    $state = Get-SignInState
    $state.Unconfirmed = 0
    Save-SignInState $state
}

# ------------------------------------------------------------
# Error notice for a FAILED run
#
# A failed run is shown to the user (pending-error.json, shown by
# Show-QSysNotice.ps1; it never closes by itself) so it can be investigated.
# Not used for expected skips (offline, blocked Wi-Fi) or for a rejected
# sign-in, which has its own notice. The same error again within 24 hours is
# still written to both logs but does not pop up again. Returns a short phrase
# for the history line.
# ------------------------------------------------------------

$errorNoticeFile    = Join-Path $config.StateDir "pending-error.json"
$errorSeenFile      = Join-Path $config.StateDir "last-error-notice.json"
$errorNoticeCreated = $false
$failureMessage     = ""

function New-ErrorNotice {

    param (
        [string]$Step,
        [string]$Message
    )

    $signature = "$Step|$Message"

    try {

        if (Test-Path $errorSeenFile) {

            $seen = Get-Content $errorSeenFile -Raw | ConvertFrom-Json

            if (
                $seen.Signature -eq $signature -and
                ((Get-Date) - [datetime]$seen.Time).TotalHours -lt 24
            ) {
                return "not repeated: same error within 24 hours"
            }
        }

        [ordered]@{
            Time        = $script:runStarted.ToString("o")
            Step        = $Step
            Message     = $Message
            HistoryFile = (Join-Path (Join-Path $config.StateDir "Logs") "Run-History.log")
            LogFile     = (Join-Path (Join-Path $config.StateDir "Logs") "QSys-Updater.log")
        } |
            ConvertTo-Json |
            Set-Content -Path $errorNoticeFile

        [ordered]@{
            Signature = $signature
            Time      = (Get-Date).ToString("o")
        } |
            ConvertTo-Json |
            Set-Content -Path $errorSeenFile

        $script:errorNoticeCreated = $true

        return "shown to the user"
    }
    catch {
        return "could not be created"
    }
}

# ------------------------------------------------------------
# Logging
# ------------------------------------------------------------

$logFolder = Join-Path $config.StateDir "Logs"
$logFile = Join-Path $logFolder "QSys-Updater.log"

New-Item -ItemType Directory -Path $logFolder -Force | Out-Null

Start-Transcript `
    -Path $logFile `
    -Append |
    Out-Null

Write-Host ""
Write-Host "============================================================"
Write-Host "Q-SYS updater started: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Write-Host "============================================================"


# ------------------------------------------------------------
# Prevent multiple updater instances from running at once
# ------------------------------------------------------------

$mutexName = "Global\AVSoftwareUpdater-QSYS"

$mutex = New-Object System.Threading.Mutex($false, $mutexName)

try {
    $mutexAcquired = $mutex.WaitOne(0, $false)
}
catch [System.Threading.AbandonedMutexException] {
    # Previous updater ended without releasing the mutex.
    # An abandoned mutex is now owned by this process, so continue.
    $mutexAcquired = $true
}

if (-not $mutexAcquired) {
    Write-Host "Q-SYS updater is already running."
    Write-Host "This instance will exit."

    $runOutcome = "SKIPPED"
    $runDetail  = "Another update check was already running."
    Write-RunHistory

    exit 0
}


# A notice the user has not acknowledged yet (for example the PC was restarted
# while it was open) appears again on the next run.
try { Start-PendingNotice } catch { }

# Error reports that could not be sent earlier (share offline) are sent now.
try { [void](Send-ReportOutbox -Config $config) } catch { }


# ------------------------------------------------------------
# After a failed sign-in, wait for the saved password to be updated
#
# Without this the updater would try the wrong password again at every
# logon and wake, and could get the Q-SYS account locked.
# ------------------------------------------------------------

$loginFailedFile  = Join-Path $config.StateDir "login-failed.json"
$credentialPath   = Join-Path $config.StateDir "QSys-Credential.xml"
$signInNoticeFile = Join-Path $config.StateDir "pending-signin-failed.json"

# Safety cap: too many password submissions in a row that were never confirmed
# (whether or not an error message was recognised) pause the updater.
if (-not (Test-Path $loginFailedFile)) {

    $capState = Get-SignInState

    if ($capState.Unconfirmed -ge $maxUnconfirmedSubmissions) {

        $capMessage = "The last $($capState.Unconfirmed) sign-ins with this saved password could not be confirmed as successful."

        Write-Host $capMessage

        [ordered]@{
            Time         = (Get-Date).ToString("o")
            Message      = $capMessage
            Kind         = "unconfirmed"
            LastReminder = (Get-Date).ToString("o")
        } |
            ConvertTo-Json |
            Set-Content -Path $loginFailedFile

        [ordered]@{
            Kind    = "unconfirmed"
            Message = $capMessage
        } |
            ConvertTo-Json |
            Set-Content -Path $signInNoticeFile

        try { Start-PendingNotice } catch { }

        try { [void](Send-ErrorReport -Config $config -Category SignInFailed -Message $capMessage -Context @{ Kind = "unconfirmed" }) } catch { }
    }
}

if (Test-Path $loginFailedFile) {

    $failedInfo = Get-Content $loginFailedFile -Raw | ConvertFrom-Json
    $failedAt   = [datetime]$failedInfo.Time

    if ((Test-Path $credentialPath) -and (Get-Item $credentialPath).LastWriteTime -gt $failedAt) {

        Write-Host "The saved Q-SYS password was updated after the last failed sign-in. Trying again."

        Remove-Item $loginFailedFile -Force
        Remove-Item $signInNoticeFile -Force -ErrorAction SilentlyContinue
    }
    else {

        Write-Host "The last Q-SYS sign-in failed and the saved password has not been updated since."
        Write-Host "Not trying again until it is. Open AV Updater and click 'Update password...' on the Q-Sys tab to enter the new password."

        $earlierMessage = $failedInfo.Message

        # Weekly reminder while paused (no sign-in attempt is made). The notice
        # at the moment of the failure counts as the first reminder.
        $lastReminder =
            if ($failedInfo.LastReminder) { [datetime]$failedInfo.LastReminder }
            else { $failedAt }

        $reminderShown = $false

        if (
            ((Get-Date) - $lastReminder).TotalDays -ge 7 -and
            -not (Test-Path $signInNoticeFile)
        ) {

            [ordered]@{
                Kind        = "reminder"
                Message     = $earlierMessage
                PausedSince = $failedAt.ToString("o")
            } |
                ConvertTo-Json |
                Set-Content -Path $signInNoticeFile

            if ($failedInfo.PSObject.Properties.Name -contains "LastReminder") {
                $failedInfo.LastReminder = (Get-Date).ToString("o")
            }
            else {
                $failedInfo | Add-Member -NotePropertyName LastReminder -NotePropertyValue (Get-Date).ToString("o")
            }

            $failedInfo | ConvertTo-Json | Set-Content -Path $loginFailedFile

            $reminderShown = $true

            Write-Host "Showing the weekly reminder."

            try { Start-PendingNotice } catch { }
        }

        $runOutcome = "SKIPPED"
        $runDetail  = "Paused: the last Q-SYS sign-in failed ('$earlierMessage') and the saved password has not been updated since. Open AV Updater and click 'Update password...' on the Q-Sys tab.$(if ($reminderShown) { ' Weekly reminder shown.' })"
        Write-RunHistory

        try { $mutex.ReleaseMutex() } catch { }
        try { Stop-Transcript | Out-Null } catch { }

        exit 0
    }
}


# ------------------------------------------------------------
# Network helpers (added 2026-10-30 after a Biamp run died on one dropped
# connection): wait for the network at logon/wake, retry connection drops.
# ------------------------------------------------------------

$scriptStartTime = Get-Date

# Can we open a TCP connection to the host? (No data is sent.)
function Test-TcpPort {

    param ([string]$HostName, [int]$Port = 443, [int]$TimeoutMs = 5000)

    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $task = $client.ConnectAsync($HostName, $Port)
        return ($task.Wait($TimeoutMs) -and $client.Connected)
    }
    catch { return $false }
    finally { $client.Close() }
}

# At logon or wake the network is often not up yet. Poll until the host
# answers or the time runs out. Returns $true when it is reachable.
function Wait-ForNetwork {

    param ([string]$HostName, [int]$Port = 443, [int]$MaxSeconds = 180, [int]$PollSeconds = 10)

    $waited = 0
    while ($true) {
        if (Test-TcpPort -HostName $HostName -Port $Port) { return $true }
        if ($waited -ge $MaxSeconds) { return $false }
        if ($waited -eq 0) { Write-Host "Waiting for the network (up to $MaxSeconds seconds)..." }
        Start-Sleep -Seconds $PollSeconds
        $waited += $PollSeconds
    }
}

# Runs a web call, retrying connection drops (reset, SSL, timeout) a few
# times. An HTTP error answer (404 and so on) is not retried.
function Invoke-WebRetry {

    param ([scriptblock]$Call, [int]$Tries = 3)

    for ($i = 1; $i -le $Tries; $i++) {
        try { return & $Call }
        catch {
            if ($_.Exception.Response -or $i -eq $Tries) { throw }
            Write-Host "Connection problem ($($_.Exception.Message)). Retrying ($i of $($Tries - 1))..."
            Start-Sleep -Seconds (5 * $i)
        }
    }
}


# Used later for cleanup.
$signInFailed = $false
$qsysChromeProfile = $null
$chromeProcess = $null
$loginWebSocket = $null


try {

    # ------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------

    $qsysPage = $qsysCatalog.PageUrl

    $runStep = "preparing the installers folder"
    $qsysFolder = $config.QSysFolder

    New-Item -ItemType Directory -Path $qsysFolder -Force | Out-Null

    $archiveFolder = Join-Path $qsysFolder "Archive"

    $downloadsFolder = (New-Object -ComObject Shell.Application).NameSpace("shell:Downloads").Self.Path

    if (-not $downloadsFolder) {
        $downloadsFolder = Join-Path $env:USERPROFILE "Downloads"
    }

    $chrome = @(
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe"
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe"
        "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
    ) | Where-Object { Test-Path $_ } | Select-Object -First 1

    $qsysCredentialFile = Join-Path $config.StateDir "QSys-Credential.xml"

    $qsysChromeProfile = Join-Path $config.StateDir "QSys-Chrome-Profile"

    $chromeDebugPort = 9223

    $downloadTimeoutSeconds = 1800   # 30 minutes

    if (-not (Test-Path $qsysChromeProfile)) {
        New-Item -ItemType Directory -Path $qsysChromeProfile -Force | Out-Null
    }


    # ------------------------------------------------------------
    # Chrome DevTools Protocol helper
    #
    # Sends a command to a Chrome tab and waits specifically for
    # the response belonging to that command. Chrome may send
    # unrelated events while pages are loading, so those are ignored.
    # ------------------------------------------------------------

    function Invoke-CdpCommand {

        param (
            [System.Net.WebSockets.ClientWebSocket]$WebSocket,
            [int]$Id,
            [string]$Method,
            [hashtable]$Params = @{}
        )

        $command = @{
            id     = $Id
            method = $Method
            params = $Params
        } | ConvertTo-Json -Depth 10 -Compress

        $sendBytes = [System.Text.Encoding]::UTF8.GetBytes($command)
        $sendBuffer = [ArraySegment[byte]]::new($sendBytes)

        $WebSocket.SendAsync(
            $sendBuffer,
            [System.Net.WebSockets.WebSocketMessageType]::Text,
            $true,
            [Threading.CancellationToken]::None
        ).GetAwaiter().GetResult()

        while ($true) {

            $memory = New-Object System.IO.MemoryStream

            do {
                $receiveBytes = New-Object byte[] 65536
                $receiveBuffer = [ArraySegment[byte]]::new($receiveBytes)

                $result = $WebSocket.ReceiveAsync(
                    $receiveBuffer,
                    [Threading.CancellationToken]::None
                ).GetAwaiter().GetResult()

                if (
                    $result.MessageType -eq
                    [System.Net.WebSockets.WebSocketMessageType]::Close
                ) {
                    $memory.Dispose()
                    throw "Chrome DevTools connection closed unexpectedly."
                }

                $memory.Write($receiveBytes, 0, $result.Count)

            } while (-not $result.EndOfMessage)

            $responseText =
                [System.Text.Encoding]::UTF8.GetString(
                    $memory.ToArray()
                )

            $memory.Dispose()

            $response = $responseText | ConvertFrom-Json

            if ($response.id -eq $Id) {
                return $response
            }
        }
    }


    function Connect-CdpTab {

        param (
            [string]$WebSocketDebuggerUrl
        )

        $webSocket =
            [System.Net.WebSockets.ClientWebSocket]::new()

        $null = $webSocket.ConnectAsync(
            [Uri]$WebSocketDebuggerUrl,
            [Threading.CancellationToken]::None
        ).GetAwaiter().GetResult()

        if (
            $webSocket.State -ne
            [System.Net.WebSockets.WebSocketState]::Open
        ) {
            throw "Could not connect to Chrome DevTools tab."
        }

        return $webSocket
    }


    # ------------------------------------------------------------
    # Do not update while connected to blocked Wi-Fi
    # ------------------------------------------------------------

    $blockedSSIDs = @($config.BlockedSSIDs)

    $wifiInfo = netsh wlan show interfaces | Out-String

    $currentSSID = if (
        $wifiInfo -match '(?m)^\s*SSID\s*:\s*(.+)$'
    ) {
        $Matches[1].Trim()
    }
    else {
        $null
    }

    if (
        $currentSSID -and
        $currentSSID -in $blockedSSIDs
    ) {
        Write-Host "Connected to blocked Wi-Fi: $currentSSID"
        Write-Host "Q-SYS update check skipped."

        $runOutcome = "SKIPPED"
        $runDetail  = "Connected to blocked Wi-Fi network '$currentSSID'."

        exit 0
    }


    # ------------------------------------------------------------
    # Get latest Q-SYS version from Q-SYS website
    # ------------------------------------------------------------

    $runStep = "checking the Q-SYS website"
    Write-Host "Checking internet connection and Q-SYS website..."

    $qsysHost = ([System.Uri]$qsysPage).Host

    if (-not (Wait-ForNetwork -HostName $qsysHost)) {
        Write-Host "Internet unavailable or Q-SYS website could not be reached."
        Write-Host "Q-SYS update check skipped."

        $runOutcome = "SKIPPED"
        $runDetail  = "Offline: could not reach $qsysHost after waiting 3 minutes. Will retry next run (logon or wake)."

        exit 0
    }

    try {
        $page = Invoke-WebRetry {
            Invoke-WebRequest `
                $qsysPage `
                -TimeoutSec 15
        }
    }
    catch {
        Write-Host "Internet unavailable or Q-SYS website could not be reached."
        Write-Host "Q-SYS update check skipped."

        $runOutcome = "SKIPPED"
        $runDetail  = "Could not reach the Q-SYS website (no internet, or the site is down); will retry next run: $($_.Exception.Message)"

        exit 0
    }

    $latestLink = [regex]::Match(
        $page.Content,
        'href="([^"]+)"[^>]*>Download Latest Version</a>'
    ).Groups[1].Value

    $latestLink =
        [System.Net.WebUtility]::HtmlDecode(
            $latestLink
        )

    if ([string]::IsNullOrWhiteSpace($latestLink)) {
        throw "Could not find the Q-SYS 'Download Latest Version' link."
    }

    $latestVersion = [regex]::Match(
        $latestLink,
        'QDS:version([0-9.]+)'
    ).Groups[1].Value

    if ([string]::IsNullOrWhiteSpace($latestVersion)) {
        throw "Could not determine the latest Q-SYS Designer version."
    }

    Write-Host "Latest Q-SYS version: $latestVersion"
    $qsysFilter = $qsysProduct.FileFilter.Replace("{version}", $latestVersion)


    # ------------------------------------------------------------
    # Find current local version
    #
    # Only checks files directly in Q-Sys Designer.
    # Archive and Staged Update Versions are NOT searched.
    # ------------------------------------------------------------

    $runStep = "finding the installed version in the installers folder"
    $currentFile =
        Get-ChildItem $qsysFolder -File -Filter "*.zip" |
        Where-Object {
            $_.Name -match $qsysProduct.LocalNameMatch -and
            $_.Name -match $qsysProduct.VersionPattern
        } |
        Sort-Object {
            [version](
                [regex]::Match(
                    $_.Name,
                    $qsysProduct.VersionPattern
                ).Value
            )
        } -Descending |
        Select-Object -First 1

    if (-not $currentFile) {
        Write-Host "No Q-SYS Designer ZIP found in $qsysFolder. Treating this as a first-time download."
    }

    $currentVersion =
        if ($currentFile) {
            [regex]::Match($currentFile.Name, $qsysProduct.VersionPattern).Value
        }
        else {
            "0.0.0"
        }

    Write-Host "Current local version: $currentVersion"


    # ------------------------------------------------------------
    # Determine whether an update is required
    # ------------------------------------------------------------

    if (
        [version]$latestVersion -le
        [version]$currentVersion
    ) {
        Write-Host "Q-SYS Designer is current. No update needed."

        $runOutcome = "UP TO DATE"
        $runDetail  = "Q-SYS Designer $currentVersion is current (latest on the Q-SYS site: $latestVersion)."

        exit 0
    }

    Write-Host "UPDATE AVAILABLE: $currentVersion -> $latestVersion"


    # ------------------------------------------------------------
    # The current version is being installed (its installer is running
    # or a file in it is open): never archive it now. Skip this run,
    # before signing in or downloading, and try again next run.
    # ------------------------------------------------------------

    if ($currentFile) {

        $runStep = "checking whether the current version is in use"

        $busy = Get-InUseReason @($currentFile.FullName, (Join-Path $qsysFolder $currentFile.BaseName))

        if ($busy) {
            Write-Host "Q-SYS update skipped: $busy."

            $runOutcome = "SKIPPED"
            $runDetail  = "Q-SYS Designer $latestVersion is available, but $busy. Nothing was moved; will retry next run."

            exit 0
        }
    }


    # ------------------------------------------------------------
    # Determine expected download filename
    # ------------------------------------------------------------

    $expectedFileName =
        $qsysProduct.OutputName.Replace("{version}", $latestVersion)

    $expectedDownload =
        Join-Path $downloadsFolder $expectedFileName


    # ------------------------------------------------------------
    # Snapshot matching Q-SYS files already in Downloads
    #
    # Anything in this snapshot existed before the updater's
    # download attempt and must never be deleted by the updater.
    # ------------------------------------------------------------

    $runStep = "checking your Downloads folder"
    $downloadsBefore = @(
        Get-ChildItem $downloadsFolder -File |
        Where-Object {
            $_.Name -like "$qsysFilter.zip"
        } |
        Select-Object -ExpandProperty FullName
    )


    # ------------------------------------------------------------
    # Check whether required version already exists in Downloads
    #
    # This also recognizes Chrome-style names such as:
    #
    # Q-SYS Designer Installer 10.5.0 (1).zip
    #
    # Files that existed before this updater run are user-owned.
    # They are NEVER deleted or overwritten by the updater.
    # ------------------------------------------------------------

    $existingDownload =
        Get-ChildItem $downloadsFolder -File |
        Where-Object {
            $_.Name -like "$qsysFilter.zip"
        } |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1

    if ($existingDownload) {

        Write-Host "Q-SYS Designer $latestVersion already exists in Downloads:"
        Write-Host $existingDownload.Name
        Write-Host "Validating existing Downloads copy..."

        try {
            $zip =
                [System.IO.Compression.ZipFile]::OpenRead(
                    $existingDownload.FullName
                )

            $zip.Dispose()

            Write-Host "Existing Downloads copy is valid."
            Write-Host "No download is required."
        }
        catch {
            throw "Existing Downloads copy is not a valid ZIP. It will NOT be deleted or overwritten."
        }
    }


    # ------------------------------------------------------------
    # Launch dedicated Chrome session if download is required
    # ------------------------------------------------------------

    if ($existingDownload) {

        Write-Host "Using existing Downloads copy: $($existingDownload.Name)"
    }
    else {

        # Credential file is only required if we actually need
        # to download and Q-SYS asks us to authenticate.

        # Chrome is only needed when a download is actually required.
        if (-not $chrome) {
            throw "Google Chrome was not found. Install Chrome and run again."
        }

        # Hidden (no window at all) is the default. Setup's -BrowserMode Visible
        # shows the window for testing and troubleshooting.
        $browserArguments =
            if ($config.BrowserMode -eq "Visible") {
                @()
            }
            else {
                @("--headless=new", "--window-size=1280,900")
            }

        $runStep = "starting Chrome"
        Write-Host "Launching dedicated Chrome session for Q-SYS Designer $latestVersion ($(if ($config.BrowserMode -eq 'Visible') { 'visible' } else { 'hidden' }))..."

        $chromeProcess = Start-Process `
            -FilePath $chrome `
            -ArgumentList @(
                "--remote-debugging-port=$chromeDebugPort"
                "--user-data-dir=$qsysChromeProfile"
                "--no-first-run"
                "--no-default-browser-check"
                "--disable-background-mode"
                $browserArguments
                $latestLink
            ) `
            -PassThru

        $runStep = "connecting to Chrome"
        Write-Host "Waiting for Chrome DevTools interface..."

        $cdpReady = $false

        for ($i = 0; $i -lt 30; $i++) {

            try {
                $null = Invoke-RestMethod `
                    "http://127.0.0.1:$chromeDebugPort/json/version" `
                    -TimeoutSec 2

                $cdpReady = $true
                break
            }
            catch {
                Start-Sleep -Seconds 1
            }
        }

        if (-not $cdpReady) {
            throw "Chrome DevTools interface did not become available."
        }

        Write-Host "Chrome DevTools interface is ready."


        # --------------------------------------------------------
        # Check whether Q-SYS requires authentication
        # --------------------------------------------------------

        $runStep = "signing in to Q-SYS"
        Write-Host "Checking Q-SYS authentication state..."

        $loginTab = $null
        $downloadStarted = $null

        for ($i = 0; $i -lt 60; $i++) {

            try {
                $tabs = Invoke-RestMethod `
                    "http://127.0.0.1:$chromeDebugPort/json" `
                    -TimeoutSec 2
            }
            catch {
                Start-Sleep -Seconds 1
                continue
            }

            $loginTab =
                $tabs |
                Where-Object {
                    $_.type -eq "page" -and
                    $_.url -like "https://$($qsysProduct.AuthHost)/*"
                } |
                Select-Object -First 1

            if ($loginTab) {
                Write-Host "Q-SYS login page detected."
                break
            }

            # If a new ZIP or partial download appeared,
            # authentication was not required.

            $downloadStarted =
                Get-ChildItem $downloadsFolder -File |
                Where-Object {
                    $_.Name -like $qsysFilter -and
                    $_.FullName -notin $downloadsBefore
                } |
                Select-Object -First 1

            if ($downloadStarted) {
                Write-Host "Q-SYS session is already authenticated."
                break
            }

            Start-Sleep -Seconds 1
        }


        # --------------------------------------------------------
        # Authenticate if Q-SYS redirected to CIAM
        # --------------------------------------------------------

        if ($loginTab) {

            if (-not (Test-Path $qsysCredentialFile)) {
                throw "Q-SYS credential file was not found: $qsysCredentialFile"
            }

            Write-Host "Loading stored Q-SYS credentials..."

            try {
                $qsysCredential =
                    Import-Clixml $qsysCredentialFile

                $qsysEmail =
                    $qsysCredential.UserName

                $qsysPassword =
                    $qsysCredential.GetNetworkCredential().Password
            }
            catch {
                throw "Stored Q-SYS credentials could not be loaded."
            }

            if (
                [string]::IsNullOrWhiteSpace($qsysEmail) -or
                [string]::IsNullOrWhiteSpace($qsysPassword)
            ) {
                throw "Stored Q-SYS credentials are incomplete."
            }

            Write-Host "Stored Q-SYS credentials loaded."

            Write-Host "Connecting to Q-SYS login page..."

            $loginWebSocket =
                Connect-CdpTab `
                    $loginTab.webSocketDebuggerUrl

            Write-Host "Connected to Q-SYS login page."


            # ----------------------------------------------------
            # Enter email and click Continue
            # ----------------------------------------------------

            Write-Host "Entering Q-SYS email address..."

            $emailJson =
                $qsysEmail |
                ConvertTo-Json -Compress

            $emailScript = @"
(() => {
    const field = document.querySelector('input[name="email"]');
    if (!field) return "EMAIL_FIELD_NOT_FOUND";

    const nativeSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    nativeSetter.call(field, $emailJson);
    field.dispatchEvent(new Event('input', { bubbles: true }));
    field.dispatchEvent(new Event('change', { bubbles: true }));


    return field.value.length;
})()
"@

            $emailResult =
                Invoke-CdpCommand `
                    -WebSocket $loginWebSocket `
                    -Id 1 `
                    -Method "Runtime.evaluate" `
                    -Params @{
                        expression    = $emailScript
                        returnByValue = $true
                    }

            $emailStatus =
            $emailLength =
                $emailResult.result.result.value

            if ($emailLength -le 0) {
                throw "Q-SYS email field did not accept the email address."
            }

            Write-Host "Email entered. Verifying it remains populated..."

            Start-Sleep -Seconds 2

            $emailCheckScript = 'document.querySelector(''input[name="email"]'')?.value.length ?? 0'

            $emailCheck =
                Invoke-CdpCommand `
                    -WebSocket $loginWebSocket `
                    -Id 2 `
                    -Method "Runtime.evaluate" `
                    -Params @{
                        expression    = $emailCheckScript
                        returnByValue = $true
                    }

            $emailRetainedLength =
                $emailCheck.result.result.value

            if ($emailRetainedLength -le 0) {
                throw "Q-SYS email field was cleared before Continue."
            }


            Write-Host "Email field verified. Waiting for Q-SYS login page to finish initializing..."
            Start-Sleep -Seconds 2
            Write-Host "Submitting Continue..."

            $continuePositionScript = @"
(() => {
    const field = document.querySelector('input[name="email"]');
    if (!field || field.value.length === 0) return null;

    const button = document.querySelector('#handleSignIn');
    if (!button) return null;

    button.scrollIntoView({ behavior: "instant", block: "center", inline: "center" });
    const rect = button.getBoundingClientRect();

    return {
        x: rect.left + (rect.width / 2),
        y: rect.top + (rect.height / 2)
    };
})()
"@

            Write-Host "Submitting Q-SYS Continue..."

            $continuePosition =
                Invoke-CdpCommand `
                    -WebSocket $loginWebSocket `
                    -Id 3 `
                    -Method "Runtime.evaluate" `
                    -Params @{
                        expression    = $continuePositionScript
                        returnByValue = $true
                    }

            $continueX = $continuePosition.result.result.value.x
            $continueY = $continuePosition.result.result.value.y

            if ($null -eq $continueX -or $null -eq $continueY) {
                throw "Could not determine Q-SYS Continue button position."
            }

            $null =
                Invoke-CdpCommand `
                    -WebSocket $loginWebSocket `
                    -Id 4 `
                    -Method "Input.dispatchMouseEvent" `
                    -Params @{
                        type       = "mousePressed"
                        x          = $continueX
                        y          = $continueY
                        button     = "left"
                        clickCount = 1
                    }

            $null =
                Invoke-CdpCommand `
                    -WebSocket $loginWebSocket `
                    -Id 5 `
                    -Method "Input.dispatchMouseEvent" `
                    -Params @{
                        type       = "mouseReleased"
                        x          = $continueX
                        y          = $continueY
                        button     = "left"
                        clickCount = 1
                    }
            Write-Host "Q-SYS email submitted."


            # ----------------------------------------------------
            # Wait for password field
            # ----------------------------------------------------

            Write-Host "Waiting for Q-SYS password page..."

            $passwordFieldReady = $false

            for ($i = 0; $i -lt 30; $i++) {

                Start-Sleep -Seconds 1

                $passwordCheck =
                    Invoke-CdpCommand `
                        -WebSocket $loginWebSocket `
                        -Id (2 + $i) `
                        -Method "Runtime.evaluate" `
                        -Params @{
                            expression =
                                '(() => { const f = document.querySelector(''input[name="password"]''); if (!f) return false; const r = f.getBoundingClientRect(); const s = getComputedStyle(f); return r.width > 0 && r.height > 0 && s.display !== "none" && s.visibility !== "hidden"; })()'

                            returnByValue = $true
                        }

                if (
                    $passwordCheck.result.result.value -eq
                    $true
                ) {
                    $passwordFieldReady = $true
                    break
                }
            }

            if (-not $passwordFieldReady) {
                throw "Q-SYS password page did not appear."
            }

            Write-Host "Q-SYS password page is ready."


            # ----------------------------------------------------
            # Enter password and sign in
            # ----------------------------------------------------

            Write-Host "Entering Q-SYS password..."

            $passwordJson =
                $qsysPassword |
                ConvertTo-Json -Compress

            $passwordVerified = $false

            for ($passwordAttempt = 1; $passwordAttempt -le 3; $passwordAttempt++) {

                $passwordScript = @"
(() => {
    const field = document.querySelector('input[name="password"]');
    if (!field) return 0;

    const nativeSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    nativeSetter.call(field, $passwordJson);
    field.dispatchEvent(new Event('input', { bubbles: true }));
    field.dispatchEvent(new Event('change', { bubbles: true }));

    return field.value.length;
})()
"@

                $passwordResult =
                    Invoke-CdpCommand `
                        -WebSocket $loginWebSocket `
                        -Id (100 + ($passwordAttempt * 10)) `
                        -Method "Runtime.evaluate" `
                        -Params @{
                            expression    = $passwordScript
                            returnByValue = $true
                        }

                $enteredPasswordLength =
                    $passwordResult.result.result.value

                if ($enteredPasswordLength -le 0) {

                    Write-Host "Password was not accepted on attempt $passwordAttempt. Retrying..."
                    Start-Sleep -Seconds 2
                    continue
                }

                Write-Host "Password entered. Verifying it remains populated..."

                Start-Sleep -Seconds 2

                $passwordCheckScript =
                    'document.querySelector(''input[name="password"]'')?.value.length ?? 0'

                $passwordCheck =
                    Invoke-CdpCommand `
                        -WebSocket $loginWebSocket `
                        -Id (101 + ($passwordAttempt * 10)) `
                        -Method "Runtime.evaluate" `
                        -Params @{
                            expression    = $passwordCheckScript
                            returnByValue = $true
                        }

                $passwordRetainedLength =
                    $passwordCheck.result.result.value

                if ($passwordRetainedLength -gt 0) {
                    $passwordVerified = $true
                    break
                }

                Write-Host "Q-SYS cleared the password field. Retrying..."
                Start-Sleep -Seconds 2
            }

            if (-not $passwordVerified) {
                throw "Q-SYS password field could not be populated after 3 attempts."
            }
            Write-Host "Password field verified. Submitting Q-SYS sign-in..."

            $submitPositionScript = @"
(() => {
    const field = document.querySelector('input[name="password"]');
    if (!field || field.value.length === 0) return null;

    const button = document.querySelector('#handleSignIn');
    if (!button) return null;

    button.scrollIntoView({ behavior: "instant", block: "center", inline: "center" });

    const rect = button.getBoundingClientRect();

    return {
        x: rect.left + (rect.width / 2),
        y: rect.top + (rect.height / 2)
    };
})()
"@

            $submitPosition =
                Invoke-CdpCommand `
                    -WebSocket $loginWebSocket `
                    -Id 102 `
                    -Method "Runtime.evaluate" `
                    -Params @{
                        expression    = $submitPositionScript
                        returnByValue = $true
                    }

            $submitX = $submitPosition.result.result.value.x
            $submitY = $submitPosition.result.result.value.y

            if ($null -eq $submitX -or $null -eq $submitY) {
                throw "Could not determine Q-SYS sign-in button position."
            }

            $null =
                Invoke-CdpCommand `
                    -WebSocket $loginWebSocket `
                    -Id 103 `
                    -Method "Input.dispatchMouseEvent" `
                    -Params @{
                        type       = "mousePressed"
                        x          = $submitX
                        y          = $submitY
                        button     = "left"
                        clickCount = 1
                    }

            Start-Sleep -Milliseconds 100

            $null =
                Invoke-CdpCommand `
                    -WebSocket $loginWebSocket `
                    -Id 104 `
                    -Method "Input.dispatchMouseEvent" `
                    -Params @{
                        type       = "mouseReleased"
                        x          = $submitX
                        y          = $submitY
                        button     = "left"
                        clickCount = 1
                    }
            Write-Host "Q-SYS sign-in submitted."

            # Remove plaintext password variables as soon as
            # they are no longer needed.

            $qsysPassword = $null
            $passwordJson = $null
            $qsysCredential = $null
        }
        elseif (-not $downloadStarted) {

            throw "Could not determine Q-SYS authentication state."
        }


        # --------------------------------------------------------
        # Check that Q-SYS accepted the sign-in (read only)
        #
        # Runs after the sign-in code above, which is not changed by this.
        # Watches the page for up to 25 seconds: leaving the sign-in site
        # or a download starting means success; Q-SYS showing an error in
        # its red message box (confirmed twice in a row) means the saved
        # password was rejected, so stop now instead of waiting 30 minutes.
        # --------------------------------------------------------

        if ($loginWebSocket) {

            $runStep = "checking that Q-SYS accepted the sign-in"
            Write-Host "Checking that the sign-in was accepted..."

            # The password has just been submitted: count it until a sign-in is confirmed.
            Register-PasswordSubmission

            $signInSnapshotScript = @'
(() => {
  const wrap = document.querySelector('#errorMsg-wrapper');
  const msg  = document.querySelector('#errorMsg');
  return JSON.stringify({
    url: location.href.split('?')[0],
    errorBoxVisible: !!(wrap && wrap.offsetWidth),
    errorMsgText: msg ? msg.innerText.trim() : ''
  });
})()
'@

            $signInOutcome = "Waiting"
            $signInMessage = ""
            $failedInARow = 0
            $signInCheckId = 5000

            for ($i = 0; $i -lt 25; $i++) {

                Start-Sleep -Seconds 1

                $downloadAlreadyStarted =
                    Get-ChildItem $downloadsFolder -File -ErrorAction SilentlyContinue |
                    Where-Object {
                        $_.Name -like "*Q-SYS*Designer*$latestVersion*" -and
                        $_.FullName -notin $downloadsBefore
                    } |
                    Select-Object -First 1

                if ($downloadAlreadyStarted) {
                    $signInOutcome = "LeftSignIn"
                    break
                }

                $signInCheckId++

                try {
                    $snapshotText =
                        (Invoke-CdpCommand `
                            -WebSocket $loginWebSocket `
                            -Id $signInCheckId `
                            -Method "Runtime.evaluate" `
                            -Params @{
                                expression    = $signInSnapshotScript
                                returnByValue = $true
                            }).result.result.value
                }
                catch {
                    # The page is moving to the next step; look again.
                    continue
                }

                if (-not $snapshotText) {
                    continue
                }

                $signInState = Resolve-SignInState ($snapshotText | ConvertFrom-Json)

                if ($signInState -eq "LeftSignIn") {
                    $signInOutcome = "LeftSignIn"
                    break
                }

                if ($signInState -eq "Failed") {

                    $failedInARow++
                    $signInMessage = ($snapshotText | ConvertFrom-Json).errorMsgText

                    if ($failedInARow -ge 2) {
                        $signInOutcome = "Failed"
                        break
                    }
                }
                else {
                    $failedInARow = 0
                }
            }

            if ($signInOutcome -eq "Failed") {

                $signInFailed = $true

                [ordered]@{
                    Time         = (Get-Date).ToString("o")
                    Message      = $signInMessage
                    Kind         = "failed"
                    LastReminder = (Get-Date).ToString("o")
                } |
                    ConvertTo-Json |
                    Set-Content -Path $loginFailedFile

                [ordered]@{
                    Kind    = "failed"
                    Message = $signInMessage
                } |
                    ConvertTo-Json |
                    Set-Content -Path $signInNoticeFile

                throw "Q-SYS did not accept the saved sign-in ('$signInMessage'). The updater will not try again until the saved password is updated."
            }

            if ($signInOutcome -eq "LeftSignIn") {
                Write-Host "Q-SYS accepted the sign-in."

                Reset-SignInCounter
            }
            else {
                Write-Host "No sign-in error seen. Continuing."
            }
        }
    }


    # ------------------------------------------------------------
    # Wait for download to complete
    # Skip this if a valid copy already existed in Downloads.
    # ------------------------------------------------------------

    if ($existingDownload) {

        $downloadFile =
            $existingDownload

        $downloadCreatedByUpdater =
            $false
    }
    else {

        $downloadStatusPath = Start-DownloadStatus
        try {
        $runStep = "waiting for the download"
        Write-Host "Waiting for download to complete..."

        $elapsed = 0
        $newDownload = $null
        $offlineChecks = 0

        while ($elapsed -lt $downloadTimeoutSeconds) {

            $newDownload =
                Get-ChildItem $downloadsFolder -File |
                Where-Object {
                    $_.Name -like "$qsysFilter.zip" -and
                    $_.FullName -notin $downloadsBefore
                } |
                Sort-Object LastWriteTime -Descending |
                Select-Object -First 1

            $partialDownloads =
                Get-ChildItem `
                    $downloadsFolder `
                    -File `
                    -Filter "*.crdownload" |
                Where-Object {
                    $_.Name -like $qsysFilter
                }

            if (
                $newDownload -and
                -not $partialDownloads
            ) {
                break
            }

            Start-Sleep -Seconds 5
            $elapsed += 5

            # A dropped connection stalls Chrome's download silently. Check the
            # network every minute; after 3 minutes offline in a row, give up.
            if ($elapsed % 60 -eq 0) {
                if (Test-TcpPort -HostName $qsysHost) { $offlineChecks = 0 }
                else { $offlineChecks++ }

                if ($offlineChecks -ge 3) { break }
            }
        }

        if (-not $newDownload -and $offlineChecks -ge 3) {
            # Close the updater's own Chrome so it lets go of the partial file,
            # then delete only partial downloads this run started.
            if ($qsysChromeProfile) {
                Get-CimInstance Win32_Process |
                    Where-Object { $_.Name -eq "chrome.exe" -and $_.CommandLine -like "*$qsysChromeProfile*" } |
                    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
                Start-Sleep -Seconds 2
            }

            Get-ChildItem $downloadsFolder -File -Filter "*.crdownload" -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -like $qsysFilter -and $_.CreationTime -ge $scriptStartTime } |
                Remove-Item -Force -ErrorAction SilentlyContinue

            Write-Host "The connection dropped during the download. Q-SYS update skipped."

            $runOutcome = "SKIPPED"
            $runDetail  = "Offline: the connection dropped while downloading Q-SYS Designer $latestVersion. The partial download was removed; will retry next run."

            exit 0
        }

        if (-not $newDownload) {
            throw "Download timed out after $downloadTimeoutSeconds seconds."
        }

        $downloadFile =
            $newDownload

        $downloadCreatedByUpdater =
            $true

        Write-Host "Download completed: $($downloadFile.Name)"
        } finally { if ($downloadStatusPath) { try { [IO.File]::Delete($downloadStatusPath) } catch { } } }
    }


    # ------------------------------------------------------------
    # Validate downloaded ZIP
    # ------------------------------------------------------------

    $runStep = "validating the downloaded ZIP"
    Write-Host "Validating downloaded ZIP..."

    try {
        $zip =
            [System.IO.Compression.ZipFile]::OpenRead(
                $downloadFile.FullName
            )

        $zip.Dispose()
    }
    catch {
        throw "Downloaded file is not a valid ZIP. Existing Q-SYS installer was NOT changed."
    }

    Write-Host "Downloaded ZIP is valid."


    # ------------------------------------------------------------
    # COPY new version into Q-SYS folder FIRST
    #
    # The old installer remains untouched until the new installer
    # has been successfully copied, validated and extracted.
    # ------------------------------------------------------------

    $destinationFile =
        Join-Path $qsysFolder $expectedFileName

    if (Test-Path $destinationFile) {
        throw "Q-SYS Designer $latestVersion already exists in the destination folder."
    }

    # The extracted installers live in a folder named like the ZIP
    # without ".zip", for example "Q-SYS Designer Installer 10.5.0".
    $extractedName   = [System.IO.Path]::GetFileNameWithoutExtension($expectedFileName)
    $extractedFolder = Join-Path $qsysFolder $extractedName


    # ------------------------------------------------------------
    # Check everything that could block the archive step BEFORE
    # changing anything, so a problem never leaves a half-finished
    # update behind.
    #
    # The old ZIP and, if it exists, its extracted folder (same
    # name without ".zip") both move to Archive.
    # ------------------------------------------------------------

    $oldExtractedFolder = $null
    $archiveZipTarget = $null
    $archiveFolderTarget = $null

    if ($currentFile) {

        $archiveZipTarget =
            Join-Path $archiveFolder $currentFile.Name

        if (Test-Path $archiveZipTarget) {
            throw "Archive already contains $($currentFile.Name). Nothing was changed."
        }

        $candidate =
            Join-Path $qsysFolder $currentFile.BaseName

        if (Test-Path $candidate -PathType Container) {

            $oldExtractedFolder = $candidate

            $archiveFolderTarget =
                Join-Path $archiveFolder $currentFile.BaseName

            if (Test-Path $archiveFolderTarget) {
                throw "Archive already contains the folder $($currentFile.BaseName). Nothing was changed."
            }
        }

        # Checked again: the user may have started the old installer while this run downloaded.
        $busy = Get-InUseReason @($currentFile.FullName, $oldExtractedFolder)

        if ($busy) {
            Write-Host "Q-SYS update skipped: $busy."

            if ($downloadCreatedByUpdater) {
                Remove-Item -LiteralPath $downloadFile.FullName -Force -ErrorAction SilentlyContinue
            }

            $runOutcome = "SKIPPED"
            $runDetail  = "Q-SYS Designer $latestVersion was downloaded, but $busy. Nothing was moved and the download was removed; will retry next run."

            exit 0
        }
    }


    # ------------------------------------------------------------
    # Make sure there is room for the copy plus the extracted files
    # ------------------------------------------------------------

    try {
        $sizeZip =
            [System.IO.Compression.ZipFile]::OpenRead(
                $downloadFile.FullName
            )

        try {
            $uncompressedBytes =
                ($sizeZip.Entries | Measure-Object -Property Length -Sum).Sum
        }
        finally {
            $sizeZip.Dispose()
        }

        $neededBytes =
            $downloadFile.Length + $uncompressedBytes + 500MB

        $driveRoot =
            [System.IO.Path]::GetPathRoot($qsysFolder)

        $freeBytes =
            (New-Object System.IO.DriveInfo($driveRoot)).AvailableFreeSpace
    }
    catch {
        # Free space could not be determined (for example a network path).
        $freeBytes = $null
    }

    if ($null -ne $freeBytes -and $freeBytes -lt $neededBytes) {
        throw (
            "Not enough free space on $driveRoot. Need about " +
            "$([math]::Round($neededBytes / 1GB, 1)) GB, only " +
            "$([math]::Round($freeBytes / 1GB, 1)) GB free. Nothing was changed."
        )
    }


    $runStep = "copying the new version into the installers folder"
    Write-Host "Copying new version into Q-SYS folder..."

    Copy-Item `
        $downloadFile.FullName `
        $destinationFile


    # ------------------------------------------------------------
    # Validate the COPY in the Q-SYS folder
    # ------------------------------------------------------------

    $runStep = "validating the copied ZIP"
    Write-Host "Validating copied ZIP..."

    try {
        $zip =
            [System.IO.Compression.ZipFile]::OpenRead(
                $destinationFile
            )

        $zip.Dispose()
    }
    catch {

        # Remove only the bad/incomplete new copy.
        Remove-Item `
            $destinationFile `
            -Force `
            -ErrorAction SilentlyContinue

        throw "Copied ZIP failed validation. Existing Q-SYS installer was NOT archived."
    }

    Write-Host "Copied ZIP is valid."


    # ------------------------------------------------------------
    # Extract the new version next to the ZIP
    #
    # Extracts into a temporary folder first, so a half-extracted
    # folder can never be mistaken for a finished one. If this fails,
    # the new ZIP is removed again so the next run starts the update
    # over, and the old version stays exactly as it was.
    # ------------------------------------------------------------

    $extractedCreated = $false

    if (Test-Path $extractedFolder) {

        Write-Host "Extracted folder already exists and was left as it is: $extractedName"
    }
    else {

        $runStep = "extracting the installers"
        Write-Host "Extracting installers..."

        $extractTemp =
            Join-Path $qsysFolder "$extractedName.extracting"

        try {

            if (Test-Path $extractTemp) {
                Remove-Item $extractTemp -Recurse -Force
            }

            [System.IO.Compression.ZipFile]::ExtractToDirectory(
                $destinationFile,
                $extractTemp
            )

            # If the ZIP wraps everything in one folder, use that folder's
            # contents so the result is not nested one level too deep.
            $topLevel = @(Get-ChildItem $extractTemp -Force)

            if ($topLevel.Count -eq 1 -and $topLevel[0].PSIsContainer) {

                Move-Item $topLevel[0].FullName $extractedFolder
                Remove-Item $extractTemp -Force
            }
            else {

                Move-Item $extractTemp $extractedFolder
            }
        }
        catch {

            $extractError = $_.Exception.Message

            Remove-Item $extractTemp -Recurse -Force -ErrorAction SilentlyContinue
            Remove-Item $extractedFolder -Recurse -Force -ErrorAction SilentlyContinue
            Remove-Item $destinationFile -Force -ErrorAction SilentlyContinue

            throw "Extraction failed: $extractError. The new ZIP was removed so the next run can try again. Existing Q-SYS installer was NOT changed."
        }

        $extractedCreated = $true

        Write-Host "Extracted to: $extractedName"
    }


    # ------------------------------------------------------------
    # Archive old current version (ZIP and extracted folder)
    #
    # Staged Update Versions is never searched or modified.
    # ------------------------------------------------------------

    # Journal of what this run changed, so it can be undone later
    # (Options-QSysUpdater.ps1 -UndoLastUpdate). Written before the archive step
    # and updated after every move.
    $journalFolder = Join-Path $config.StateDir "Journal"
    New-Item -ItemType Directory -Path $journalFolder -Force | Out-Null

    $journalFile =
        Join-Path $journalFolder (
            "update-{0}-{1}.json" -f (Get-Date -Format "yyyyMMdd-HHmmss"), $latestVersion
        )

    $journal = [ordered]@{
        Time                 = (Get-Date).ToString("o")
        FromVersion          = $currentVersion
        ToVersion            = $latestVersion
        QSysFolder           = $qsysFolder
        NewZip               = $destinationFile
        ExtractedFolder      = $(if ($extractedCreated) { $extractedFolder } else { $null })
        ArchiveFolder        = $archiveFolder
        ArchiveFolderCreated = $false
        Moves                = @()
        Status               = "in-progress"
    }

    $journal | ConvertTo-Json -Depth 5 | Set-Content -Path $journalFile

    if ($currentFile) {

        if (-not (Test-Path $archiveFolder)) {

            New-Item `
                -ItemType Directory `
                -Path $archiveFolder `
                -Force |
                Out-Null

            $journal.ArchiveFolderCreated = $true
            $journal | ConvertTo-Json -Depth 5 | Set-Content -Path $journalFile
        }

        $runStep = "archiving the old version"
        Write-Host "Archiving Q-SYS Designer $currentVersion..."

        $originalZipPath = $currentFile.FullName

        Move-Item `
            $currentFile.FullName `
            $archiveZipTarget

        $journal.Moves = @($journal.Moves) + [ordered]@{ From = $originalZipPath; To = $archiveZipTarget }
        $journal | ConvertTo-Json -Depth 5 | Set-Content -Path $journalFile

        if ($oldExtractedFolder) {

            Write-Host "Archiving extracted folder $($currentFile.BaseName)..."

            $originalFolderPath = $oldExtractedFolder

            Move-Item `
                $oldExtractedFolder `
                $archiveFolderTarget

            $journal.Moves = @($journal.Moves) + [ordered]@{ From = $originalFolderPath; To = $archiveFolderTarget }
            $journal | ConvertTo-Json -Depth 5 | Set-Content -Path $journalFile
        }
    }

    $journal.Status = "complete"
    $journal | ConvertTo-Json -Depth 5 | Set-Content -Path $journalFile



    # ------------------------------------------------------------
    # Remove Downloads copy ONLY if this updater created it
    # ------------------------------------------------------------

    if ($downloadCreatedByUpdater) {

        Write-Host "Removing Downloads copy created by updater..."

        Remove-Item `
            $downloadFile.FullName `
            -Force
    }
    else {

        Write-Host "Pre-existing Downloads copy left untouched."
    }


    # ------------------------------------------------------------
    # Finished
    # ------------------------------------------------------------

    Write-Host ""
    Write-Host "Q-SYS Designer update completed successfully."
    Write-Host "$currentVersion -> $latestVersion"

    # Tells the code after the finally block to show the notice.
    $updateDownloaded = $true

    # A completed download proves the sign-in worked, even if it was not seen earlier.
    Reset-SignInCounter

    $runOutcome = "UPDATED"
    $runDetail =
        if ($currentVersion -eq "0.0.0") {
            "Q-SYS Designer $latestVersion downloaded and extracted (first download)."
        }
        else {
            "Q-SYS Designer $currentVersion -> $latestVersion downloaded, extracted and the old version archived."
        }
}
catch {

    # Remember why the run failed (the history line is written in finally),
    # then let the error continue exactly as it did before.
    $runOutcome = "FAILED"
    $runDetail  =
        if ($runStep) { "While ${runStep}: $($_.Exception.Message)" }
        else { $_.Exception.Message }

    $failureMessage = ($_.Exception.Message -replace '\s+', ' ').Trim()
    $failureRecord  = $_

    # Everything needed to investigate goes into the detailed log
    # (QSys-Updater.log): the step, the error, where in the script it
    # happened, and the call stack.
    Write-Host ""
    Write-Host "RUN FAILED$(if ($runStep) { " while $runStep" })."
    Write-Host "Error: $($_.Exception.Message)"

    if ($_.InvocationInfo -and $_.InvocationInfo.PositionMessage) {
        Write-Host $_.InvocationInfo.PositionMessage
    }

    if ($_.ScriptStackTrace) {
        Write-Host "Call stack:"
        Write-Host $_.ScriptStackTrace
    }

    throw
}
finally {

    # ------------------------------------------------------------
    # Close CDP WebSocket if one was opened
    # ------------------------------------------------------------

    if ($loginWebSocket) {

        try {
            if (
                $loginWebSocket.State -eq
                [System.Net.WebSockets.WebSocketState]::Open
            ) {
                $loginWebSocket.CloseAsync(
                    [System.Net.WebSockets.WebSocketCloseStatus]::NormalClosure,
                    "Updater finished",
                    [Threading.CancellationToken]::None
                ).GetAwaiter().GetResult()
            }
        }
        catch {
        }

        try {
            $loginWebSocket.Dispose()
        }
        catch {
        }
    }


    # ------------------------------------------------------------
    # Close ONLY Chrome processes using the dedicated Q-SYS profile
    #
    # This does not touch the user's normal Chrome session.
    # ------------------------------------------------------------

    if ($qsysChromeProfile) {

        try {
            $qsysChromeProcesses =
                Get-CimInstance Win32_Process |
                Where-Object {
                    $_.Name -eq "chrome.exe" -and
                    $_.CommandLine -like "*$qsysChromeProfile*"
                }

            foreach ($process in $qsysChromeProcesses) {

                Stop-Process `
                    -Id $process.ProcessId `
                    -Force `
                    -ErrorAction SilentlyContinue
            }
        }
        catch {
        }
    }


    # ------------------------------------------------------------
    # Finish logging
    # ------------------------------------------------------------

    try {
        Stop-Transcript | Out-Null
    }
    catch {
    }


    # ------------------------------------------------------------
    # Release updater mutex
    # ------------------------------------------------------------

    try {
        $mutex.ReleaseMutex()
    }
    catch {
    }

    try {
        $mutex.Dispose()
    }
    catch {
    }


    # ------------------------------------------------------------
    # A failed run: queue the error notice (not for a rejected sign-in,
    # which has its own notice) and say so in the history line.
    # Either way an error report is sent (it never changes the run).
    # ------------------------------------------------------------

    if ($runOutcome -eq "FAILED" -and -not $signInFailed) {

        $noticeResult = New-ErrorNotice `
            -Step $(if ($runStep) { $runStep } else { "(unknown step)" }) `
            -Message $failureMessage

        $runDetail = "$runDetail [error notice $noticeResult]"

        try { [void](Send-ErrorReport -Config $config -Category RunFailed -Message $failureMessage -Step $runStep -ErrorRecord $failureRecord -Context @{ Notice = $noticeResult }) } catch { }
    }
    elseif ($signInFailed) {

        # The rejected sign-in is detected after the sign-in code and reported here, not inside it.
        try { [void](Send-ErrorReport -Config $config -Category SignInFailed -Message $failureMessage -ErrorRecord $failureRecord -Context @{ Kind = "failed" }) } catch { }
    }


    # ------------------------------------------------------------
    # Run history: the one line for this attempt
    # ------------------------------------------------------------

    Write-RunHistory


    # ------------------------------------------------------------
    # A rejected sign-in: show the notice (OK / Update Password) now,
    # after Chrome is closed and the lock is released.
    # ------------------------------------------------------------

    if ($signInFailed -or $errorNoticeCreated) {

        try { Start-PendingNotice } catch { }
    }
}


# ------------------------------------------------------------
# Tell the user a new version was downloaded
#
# Writes pending-notice.json and starts the notice. The notice runs
# in its own process (on-demand scheduled task, no time limit) and
# never closes by itself, so it is not tied to this run ending. The
# notice clears pending-notice.json only when the user clicks OK or
# Go to Folder. Skipped if this version was already acknowledged.
# ------------------------------------------------------------

if ($updateDownloaded) {

    try {

        $notifiedFile = Join-Path $config.StateDir "last-notified-version.txt"

        $alreadyAcknowledged =
            (Test-Path $notifiedFile) -and
            ((Get-Content $notifiedFile -Raw).Trim() -eq $latestVersion)

        if (-not $alreadyAcknowledged) {

            [ordered]@{
                Version         = $latestVersion
                PreviousVersion = $currentVersion
                FilePath        = $(if (Test-Path $extractedFolder) { $extractedFolder } else { $destinationFile })
                Folder          = $qsysFolder
            } |
                ConvertTo-Json |
                Set-Content -Path (Join-Path $config.StateDir "pending-notice.json")

            Start-PendingNotice
        }
    }
    catch {
        # The download already succeeded; a notice problem must not fail the run.
    }
}
