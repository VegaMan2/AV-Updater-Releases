# ============================================================
# Q-Sys Updater -- setup (run once per machine and user)
#
# Asks for:
#   - the folder to keep installers in (folder browser)
#   - the Q-SYS (qsys.com) email and password (Windows credential
#     dialog; stored encrypted for THIS Windows user on THIS PC only)
# Then installs the updater to %LOCALAPPDATA%\QSysUpdater, registers a
# scheduled task that runs at logon and on wake from sleep, and adds a
# "Q-Sys Updater Options" icon (Desktop and Start menu).
#
# Cancelling (or a failure) before setup finishes removes everything this
# run created. After setup completes nothing is removed automatically.
#
# Usage:
#   Right-click > Run with PowerShell, or from any PowerShell:
#   powershell -ExecutionPolicy Bypass -File Install-QSysUpdater.ps1
#   (works from Windows PowerShell 5.1; if PowerShell 7 or Chrome is
#   missing, setup offers to download and install them, then continues
#   in PowerShell 7)
#
#   ...Install-QSysUpdater.ps1 -InstallPrerequisites   (install missing software without asking)
#   ...Install-QSysUpdater.ps1 -UpdateCredentialOnly
#   pwsh -File Install-QSysUpdater.ps1 -DestinationRoot "D:\For Install"
#   pwsh -File Install-QSysUpdater.ps1 -Uninstall
#
#   Error reports (a short report when the updater hits an error, never passwords) are on
#   unless this PC turned them off before. -NoErrorReports turns them off, -ErrorReports
#   turns them back on; the setup window has a tick box for it.
# ============================================================

[CmdletBinding()]
param (
    [string]$InstallDir = (Join-Path $env:LOCALAPPDATA "QSysUpdater"),
    [string]$DestinationRoot,
    [string[]]$BlockedSSIDs = @(),
    [string]$TaskName = "Q-Sys Updater",
    [switch]$InstallPrerequisites,
    [switch]$ReplaceExistingTask,
    [ValidateSet("Hidden", "Visible")]
    [string]$BrowserMode = "Hidden",
    [switch]$ConfigureBrowser,
    [switch]$UndoUpdates,
    [switch]$ConfigureNetworks,
    [switch]$UpdateCredentialOnly,
    [switch]$SkipTask,
    [switch]$RunNow,
    [switch]$NoGui,   # keep the console prompts (also used automatically when input is redirected)
    [switch]$NoErrorReports,   # turn error reports off
    [switch]$ErrorReports,     # turn error reports back on after an earlier opt-out
    [switch]$Uninstall
)

$ErrorActionPreference = "Stop"

# -File runs pass arrays as one comma-separated string.
$BlockedSSIDs = @($BlockedSSIDs | ForEach-Object { $_ -split "," } | ForEach-Object { $_.Trim() } | Where-Object { $_ })

$credentialFile = Join-Path $InstallDir "QSys-Credential.xml"
$configFile     = Join-Path $InstallDir "config.json"
$updaterName    = "QSys-Updater.ps1"
$launcherName   = "Run-Hidden.vbs"
$optionsScriptName = "Options-QSysUpdater.ps1"
$optionsLinkName = "Q-Sys Updater Options.lnk"
$noticeName     = "Show-QSysNotice.ps1"
$noticeLauncher = "Run-Notice.vbs"
$noticeTaskName = "$TaskName Notice"
$passwordName   = "Update-QSysPassword.ps1"
$legacyStopLink = "Stop Q-Sys Updater.lnk"            # icons made by earlier versions of setup
$legacyPassLink = "Update Q-SYS Password.lnk"

# The Windows sign-in window. If its file is missing, fall back to the text prompt.
$credentialPromptName   = "CredentialPrompt.ps1"
$credentialPromptSource = Join-Path $PSScriptRoot $credentialPromptName

if (Test-Path $credentialPromptSource) {
    . $credentialPromptSource
}
else {
    function Get-QSysCredentialPrompt {
        param ([string]$Message)
        Get-Credential -Message $Message
    }
}


# Windows instead of console prompts, unless -NoGui or input is redirected (automated tests).
$useGui = -not $NoGui

try { if ([Console]::IsInputRedirected) { $useGui = $false } } catch { }

$wizardDone = $false


# ------------------------------------------------------------
# Uninstall
# ------------------------------------------------------------

if ($Uninstall) {

    # Same removal as the 'X' choice in the Q-Sys Updater Options window.
    & (Join-Path $PSScriptRoot "Options-QSysUpdater.ps1") -Uninstall -UndoUpdates:$UndoUpdates -InstallDir $InstallDir -TaskName $TaskName
    return
}


# ------------------------------------------------------------
# Save credential (encrypted for this Windows user on this PC)
# ------------------------------------------------------------

function Save-QSysCredential {

    param ([string]$Path)

    # The setup window may already have asked for it (held in memory until now).
    $credential = $global:QSetupCredential

    if (-not $credential) {
        $credential = Get-QSysCredentialPrompt -Message "Enter your Q-SYS (qsys.com) account email and password"
    }

    if (
        -not $credential -or
        [string]::IsNullOrWhiteSpace($credential.UserName) -or
        $credential.Password.Length -eq 0
    ) {
        throw "No credential was entered. Setup cancelled."
    }

    $credential | Export-Clixml -Path $Path

    # Limit the file to the current user only.
    $currentUser = "$env:USERDOMAIN\$env:USERNAME"
    & icacls.exe $Path /inheritance:r /grant:r "${currentUser}:(F)" | Out-Null

    Write-Host "Credential saved for $($credential.UserName)."
    Write-Host "It is encrypted and can only be read by $currentUser on this PC."
}

function Get-WifiProfileNames {

    $names = foreach ($line in (netsh wlan show profiles 2>$null)) {
        if ($line -match '^\s*(All User Profile|User Profile)\s*:\s*(.+)$') {
            $Matches[2].Trim()
        }
    }

    @($names | Sort-Object -Unique)
}

function Get-CurrentSsid {

    $info = netsh wlan show interfaces 2>$null | Out-String

    if ($info -match '(?m)^\s*SSID\s*:\s*(.+)$') {
        return $Matches[1].Trim()
    }

    return $null
}

function Select-BlockedSSIDs {

    # Lets the user pick Wi-Fi networks the updater must NOT download on
    # (for example a phone hotspot), so a 2 GB download never uses it.
    param ([string[]]$Current = @())

    if ($useGui) {

        $picked = Show-NetworkPicker -Current $Current

        if ($null -eq $picked) {
            throw "Setup cancelled."
        }

        return @($picked)
    }

    $profiles    = @(Get-WifiProfileNames)
    $connectedTo = Get-CurrentSsid

    Write-Host ""
    Write-Host "Networks to avoid"
    Write-Host "The updater downloads installers of about 2 GB. It will skip the check"
    Write-Host "whenever this PC is connected to a network you block here, such as a"
    Write-Host "phone hotspot."
    Write-Host ""

    for ($i = 0; $i -lt $profiles.Count; $i++) {

        $tags = @()
        if ($profiles[$i] -in $Current)     { $tags += "blocked" }
        if ($profiles[$i] -eq $connectedTo) { $tags += "connected now" }

        $suffix = if ($tags) { "  [" + ($tags -join ", ") + "]" } else { "" }
        Write-Host ("  {0,2}. {1}{2}" -f ($i + 1), $profiles[$i], $suffix)
    }

    if (-not $profiles) {
        Write-Host "  (no saved Wi-Fi networks were found; you can type names)"
    }

    $currentText = if ($Current) { $Current -join ", " } else { "none" }

    Write-Host ""
    Write-Host "Currently blocked: $currentText"
    $answer = Read-Host "Enter numbers and/or network names separated by commas, 'none' to clear, 'cancel' to quit setup, or press Enter to keep"

    if ($answer.Trim() -eq "cancel") {
        throw "Setup cancelled."
    }

    if ([string]::IsNullOrWhiteSpace($answer)) {
        return @($Current)
    }

    if ($answer.Trim() -eq "none") {
        return @()
    }

    $selected = @()

    foreach ($token in ($answer -split ",")) {

        $token = $token.Trim()

        if (-not $token) { continue }

        if ($token -match '^\d+$' -and [int]$token -ge 1 -and [int]$token -le $profiles.Count) {
            $selected += $profiles[[int]$token - 1]
        }
        else {
            $selected += $token
        }
    }

    return @($selected | Select-Object -Unique)
}


# ------------------------------------------------------------
# Setup windows (used when a person runs setup; the console prompts remain
# for -NoGui, redirected input, and for any value given on the command line)
# ------------------------------------------------------------

function Show-NetworkPicker {

    # Checklist of the PC's saved Wi-Fi networks, plus a box to add a name by hand.
    # Returns the ticked names, or $null if cancelled.
    param ([string[]]$Current = @())

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $profiles    = @(Get-WifiProfileNames)
    $connectedTo = Get-CurrentSsid

    $global:QNet = @{ Names = New-Object System.Collections.ArrayList }

    $form = New-Object System.Windows.Forms.Form
    $global:QNet.Form = $form
    $form.Text = "Wi-Fi networks to avoid"
    $form.ClientSize = New-Object System.Drawing.Size(520, 480)
    $form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false; $form.MinimizeBox = $false
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    $info = New-Object System.Windows.Forms.Label
    $info.Location = New-Object System.Drawing.Point(16, 12); $info.Size = New-Object System.Drawing.Size(488, 66)
    $info.Text = "The updater downloads installers of about 2 GB. It skips the check whenever this PC is connected to a network ticked here, such as a phone hotspot."
    $form.Controls.Add($info)

    $list = New-Object System.Windows.Forms.CheckedListBox
    $list.Name = "NetworkList"; $list.CheckOnClick = $true
    $list.Location = New-Object System.Drawing.Point(16, 84); $list.Size = New-Object System.Drawing.Size(488, 280)
    $form.Controls.Add($list)
    $global:QNet.List = $list

    function Add-NetworkItem ($name, $checked) {
        for ($i = 0; $i -lt $global:QNet.Names.Count; $i++) {
            if ($global:QNet.Names[$i] -eq $name) { $global:QNet.List.SetItemChecked($i, $checked); return }
        }
        [void]$global:QNet.Names.Add($name)
        $text = if ($name -eq $global:QNet.Connected) { "$name   (connected now)" } else { $name }
        [void]$global:QNet.List.Items.Add($text, $checked)
    }

    $global:QNet.Connected = $connectedTo

    foreach ($name in $profiles) { Add-NetworkItem $name ($name -in $Current) }
    foreach ($name in $Current)  { if ($name) { Add-NetworkItem $name $true } }

    $addLabel = New-Object System.Windows.Forms.Label
    $addLabel.Text = "Not listed? Type its name:"
    $addLabel.Location = New-Object System.Drawing.Point(16, 376); $addLabel.Size = New-Object System.Drawing.Size(488, 22)
    $form.Controls.Add($addLabel)

    $box = New-Object System.Windows.Forms.TextBox
    $box.Name = "AddNetworkBox"
    $box.Location = New-Object System.Drawing.Point(16, 400); $box.Size = New-Object System.Drawing.Size(370, 26)
    $form.Controls.Add($box)
    $global:QNet.Box = $box

    $add = New-Object System.Windows.Forms.Button
    $add.Name = "AddNetworkButton"; $add.Text = "Add"
    $add.Location = New-Object System.Drawing.Point(396, 398); $add.Size = New-Object System.Drawing.Size(108, 30)
    $add.Add_Click({
        try {
            $typed = $global:QNet.Box.Text.Trim()
            if ($typed) { Add-NetworkItem $typed $true; $global:QNet.Box.Text = "" }
        } catch { }
    })
    $form.Controls.Add($add)

    $ok = New-Object System.Windows.Forms.Button
    $ok.Name = "NetworksOk"; $ok.Text = "OK"; $ok.DialogResult = "OK"
    $ok.Location = New-Object System.Drawing.Point(290, 440); $ok.Size = New-Object System.Drawing.Size(100, 32)
    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Name = "NetworksCancel"; $cancel.Text = "Cancel"; $cancel.DialogResult = "Cancel"
    $cancel.Location = New-Object System.Drawing.Point(404, 440); $cancel.Size = New-Object System.Drawing.Size(100, 32)
    $form.Controls.AddRange(@($ok, $cancel))
    $form.AcceptButton = $ok; $form.CancelButton = $cancel

    $answer = $form.ShowDialog()

    $picked = $null

    if ($answer -eq "OK") {
        $picked = @()
        for ($i = 0; $i -lt $global:QNet.Names.Count; $i++) {
            if ($list.GetItemChecked($i)) { $picked += $global:QNet.Names[$i] }
        }
    }

    $form.Dispose()
    return $picked
}

function Show-SetupWizard {

    # The one setup window. Returns $null if cancelled; otherwise the chosen values.
    # The Q-SYS credential is held in memory only (it is written at Install).
    param (
        [string]$StartFolder,
        [string[]]$BlockedNow = @(),
        [string]$Mode,
        [string]$Task,
        [bool]$ErrorReports = $true
    )

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    $global:QS = @{ Blocked = @($BlockedNow); Credential = $null; Advanced = $false }

    $form = New-Object System.Windows.Forms.Form
    $global:QS.Form = $form
    $form.Text = "Q-Sys Updater Setup"
    $form.ClientSize = New-Object System.Drawing.Size(640, 650)
    $form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false; $form.MinimizeBox = $true
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    function Add-Ctl ($control, $name, $x, $y, $w, $h, $text) {
        $c = New-Object $control
        if ($name) { $c.Name = $name }
        $c.Location = New-Object System.Drawing.Point($x, $y); $c.Size = New-Object System.Drawing.Size($w, $h)
        if ($text) { $c.Text = $text }
        $global:QS.Form.Controls.Add($c)
        $c
    }
    function Add-Heading ($text, $y) {
        $l = Add-Ctl System.Windows.Forms.Label $null 20 $y 600 24 $text
        $l.Font = New-Object System.Drawing.Font("Segoe UI", 10.5, [System.Drawing.FontStyle]::Bold)
    }

    $title = Add-Ctl System.Windows.Forms.Label $null 20 12 600 30 "Set up the Q-Sys Updater"
    $title.Font = New-Object System.Drawing.Font("Segoe UI", 15, [System.Drawing.FontStyle]::Bold)
    [void](Add-Ctl System.Windows.Forms.Label $null 20 46 600 40 "It keeps the newest Q-SYS Designer installer in a folder of your choice. Nothing is changed on this PC until you click Install.")

    # 1. Folder
    Add-Heading "1. Where should installers be saved?" 92
    $global:QS.Folder = Add-Ctl System.Windows.Forms.TextBox "FolderBox" 20 120 480 26 $StartFolder
    $browse = Add-Ctl System.Windows.Forms.Button "BrowseButton" 510 118 110 30 "Browse..."
    $global:QS.Preview = Add-Ctl System.Windows.Forms.Label "FolderPreview" 20 150 600 22 ""
    $global:QS.Preview.ForeColor = [System.Drawing.Color]::DimGray

    function Update-FolderPreview {
        $text = $global:QS.Folder.Text.Trim()
        $global:QS.Preview.Text = if ($text) { "Installers will go in: " + $text } else { "" }
    }
    $global:QS.Folder.Add_TextChanged({ try { Update-FolderPreview } catch { } })
    $browse.Add_Click({
        try {
            $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
            $dialog.Description = "Choose the folder to keep installers in (for example, your Q-Sys Designer folder). Installers are saved directly in it."
            $dialog.ShowNewFolderButton = $true
            if ($global:QS.Folder.Text.Trim() -and (Test-Path $global:QS.Folder.Text.Trim())) { $dialog.SelectedPath = $global:QS.Folder.Text.Trim() }
            if ($dialog.ShowDialog($global:QS.Form) -eq "OK") { $global:QS.Folder.Text = $dialog.SelectedPath }
        } catch { }
    })

    # 2. Wi-Fi
    Add-Heading "2. Wi-Fi networks to avoid" 182
    [void](Add-Ctl System.Windows.Forms.Label $null 20 208 600 40 "The updater downloads about 2 GB. It skips the check on any network you choose here, such as a phone hotspot.")
    $global:QS.Networks = Add-Ctl System.Windows.Forms.Label "NetworksSummary" 20 250 480 24 ""
    $choose = Add-Ctl System.Windows.Forms.Button "ChooseNetworks" 510 246 110 30 "Choose..."

    function Update-NetworksSummary {
        $global:QS.Networks.Text = if ($global:QS.Blocked.Count) { "Avoiding: " + ($global:QS.Blocked -join ", ") } else { "None chosen (it will download on any network)" }
    }
    $choose.Add_Click({
        try {
            $picked = Show-NetworkPicker -Current @($global:QS.Blocked)
            if ($null -ne $picked) { $global:QS.Blocked = @($picked); Update-NetworksSummary }
        } catch { }
    })

    # 3. Sign-in
    Add-Heading "3. Q-SYS sign-in" 290
    $enter = Add-Ctl System.Windows.Forms.Button "EnterCredential" 20 318 300 32 "Enter Q-SYS email and password..."
    $global:QS.CredentialStatus = Add-Ctl System.Windows.Forms.Label "CredentialStatus" 330 324 290 24 "Not entered yet"
    [void](Add-Ctl System.Windows.Forms.Label $null 20 354 600 40 "Stored encrypted, readable only by your Windows account on this PC. The password is never shown or logged.")

    $enter.Add_Click({
        try {
            $credential = Get-QSysCredentialPrompt -Message "Enter your Q-SYS (qsys.com) account email and password"
            if ($credential -and -not [string]::IsNullOrWhiteSpace($credential.UserName) -and $credential.Password.Length -gt 0) {
                $global:QS.Credential = $credential
                $global:QS.CredentialStatus.Text = "Entered for " + $credential.UserName
            }
        } catch { }
    })

    # 4. Chrome window
    Add-Heading "4. Chrome window" 400
    $hidden = Add-Ctl System.Windows.Forms.RadioButton "ChromeHidden" 20 428 600 24 "Hidden (recommended): Chrome runs with no window"
    $visible = Add-Ctl System.Windows.Forms.RadioButton "ChromeVisible" 20 452 600 24 "Visible: for testing and troubleshooting"
    $hidden.Checked = ($Mode -ne "Visible"); $visible.Checked = ($Mode -eq "Visible")
    $global:QS.Visible = $visible

    # Advanced (collapsed)
    $toggle = Add-Ctl System.Windows.Forms.Button "AdvancedToggle" 20 488 150 28 "Advanced  >"
    $global:QS.ErrorReports = Add-Ctl System.Windows.Forms.CheckBox "ErrorReportsCheck" 190 490 420 24 "Send error reports to help fix bugs"
    $global:QS.ErrorReports.Checked = $ErrorReports
    $global:QS.AdvancedPanel = New-Object System.Windows.Forms.Panel
    $panel = $global:QS.AdvancedPanel
    $panel.Location = New-Object System.Drawing.Point(20, 520); $panel.Size = New-Object System.Drawing.Size(600, 62); $panel.Visible = $false
    $form.Controls.Add($panel)
    $taskLabel = New-Object System.Windows.Forms.Label
    $taskLabel.Text = "Task name (change it for a test install next to a working one):"
    $taskLabel.Location = New-Object System.Drawing.Point(0, 0); $taskLabel.Size = New-Object System.Drawing.Size(600, 22)
    $global:QS.TaskBox = New-Object System.Windows.Forms.TextBox
    $global:QS.TaskBox.Name = "TaskNameBox"; $global:QS.TaskBox.Text = $Task
    $global:QS.TaskBox.Location = New-Object System.Drawing.Point(0, 26); $global:QS.TaskBox.Size = New-Object System.Drawing.Size(400, 26)
    $panel.Controls.AddRange(@($taskLabel, $global:QS.TaskBox))

    $install = Add-Ctl System.Windows.Forms.Button "InstallButton" 400 604 110 34 "Install"
    $cancel  = Add-Ctl System.Windows.Forms.Button "CancelButton" 520 604 100 34 "Cancel"
    $install.Anchor = "Bottom,Right"; $cancel.Anchor = "Bottom,Right"
    $cancel.DialogResult = "Cancel"; $form.CancelButton = $cancel

    $toggle.Add_Click({
        try {
            $global:QS.Advanced = -not $global:QS.Advanced
            $global:QS.AdvancedPanel.Visible = $global:QS.Advanced
        } catch { }
    })

    $install.Add_Click({
        try {
            $folder = $global:QS.Folder.Text.Trim()
            if (-not $folder) {
                [void][System.Windows.Forms.MessageBox]::Show($global:QS.Form, "Choose the folder to save installers in first.", "Q-Sys Updater Setup", "OK", "Information")
                return
            }
            if (-not (Test-Path $folder)) {
                [void][System.Windows.Forms.MessageBox]::Show($global:QS.Form, "That folder does not exist:`r`n$folder`r`n`r`nChoose an existing folder (Browse... can make a new one).", "Q-Sys Updater Setup", "OK", "Information")
                return
            }
            if (-not $global:QS.Credential) {
                [void][System.Windows.Forms.MessageBox]::Show($global:QS.Form, "Enter your Q-SYS email and password first (section 3).", "Q-Sys Updater Setup", "OK", "Information")
                return
            }
            $global:QS.Form.DialogResult = "OK"
        } catch { }
    })
    $form.AcceptButton = $null

    Update-FolderPreview
    Update-NetworksSummary

    $answer = $form.ShowDialog()

    $result = $null

    if ($answer -eq "OK") {

        $taskText = $global:QS.TaskBox.Text.Trim()

        $result = [pscustomobject]@{
            DestinationRoot = $global:QS.Folder.Text.Trim()
            BlockedSSIDs    = @($global:QS.Blocked)
            BrowserMode     = $(if ($global:QS.Visible.Checked) { "Visible" } else { "Hidden" })
            TaskName        = $(if ($taskText) { $taskText } else { $Task })
            Credential      = $global:QS.Credential
            ErrorReports    = $global:QS.ErrorReports.Checked
        }
    }

    $form.Dispose()
    return $result
}

function Show-SetupDone {

    # Finish window. Returns $true if the person asked to open the Options window.
    param ([string]$LogFolder)

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Q-Sys Updater Setup"
    $form.ClientSize = New-Object System.Drawing.Size(520, 250)
    $form.StartPosition = "CenterScreen"; $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false; $form.MinimizeBox = $false; $form.TopMost = $true
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    $title = New-Object System.Windows.Forms.Label
    $title.Name = "DoneTitle"; $title.Text = "Setup complete"
    $title.Font = New-Object System.Drawing.Font("Segoe UI", 15, [System.Drawing.FontStyle]::Bold)
    $title.Location = New-Object System.Drawing.Point(20, 16); $title.Size = New-Object System.Drawing.Size(480, 32)

    $text = New-Object System.Windows.Forms.Label
    $text.Location = New-Object System.Drawing.Point(20, 60); $text.Size = New-Object System.Drawing.Size(480, 120)
    $text.Text = "The updater will check for a new Q-SYS Designer at logon.`r`n`r`nTo stop or resume it, change your Q-SYS password, undo an update or remove it, open `"Q-Sys Updater Options`" on your Desktop or in the Start menu."

    $open = New-Object System.Windows.Forms.Button
    $open.Name = "OpenOptions"; $open.Text = "Open Q-Sys Updater Options"; $open.DialogResult = "Yes"
    $open.Location = New-Object System.Drawing.Point(120, 196); $open.Size = New-Object System.Drawing.Size(240, 36)
    $close = New-Object System.Windows.Forms.Button
    $close.Name = "DoneClose"; $close.Text = "Close"; $close.DialogResult = "Cancel"
    $close.Location = New-Object System.Drawing.Point(376, 196); $close.Size = New-Object System.Drawing.Size(124, 36)
    $form.Controls.AddRange(@($title, $text, $open, $close)); $form.CancelButton = $close

    $answer = $form.ShowDialog()
    $form.Dispose()

    return ($answer -eq "Yes")
}

if ($UpdateCredentialOnly) {

    if (-not (Test-Path $InstallDir)) {
        throw "Setup has not been run yet ($InstallDir not found). Run setup first."
    }

    Save-QSysCredential -Path $credentialFile
    return
}

if ($ConfigureNetworks) {

    if (-not (Test-Path $configFile)) {
        throw "Setup has not been run yet ($configFile not found). Run setup first."
    }

    $existingConfig = Get-Content $configFile -Raw | ConvertFrom-Json
    $existingConfig.BlockedSSIDs = @(Select-BlockedSSIDs -Current @($existingConfig.BlockedSSIDs))
    $existingConfig | ConvertTo-Json | Set-Content -Path $configFile -Encoding UTF8

    Write-Host "Saved. Blocked networks: $(@($existingConfig.BlockedSSIDs) -join ', ')"
    return
}

if ($ConfigureBrowser) {

    if (-not (Test-Path $configFile)) {
        throw "Setup has not been run yet ($configFile not found). Run setup first."
    }

    $existingConfig = Get-Content $configFile -Raw | ConvertFrom-Json

    if ($existingConfig.PSObject.Properties.Name -contains "BrowserMode") {
        $existingConfig.BrowserMode = $BrowserMode
    }
    else {
        $existingConfig | Add-Member -NotePropertyName BrowserMode -NotePropertyValue $BrowserMode
    }

    $existingConfig | ConvertTo-Json | Set-Content -Path $configFile -Encoding UTF8

    Write-Host "Saved. Chrome will run $(if ($BrowserMode -eq 'Visible') { 'with a visible window (for testing)' } else { 'hidden, with no window' })."
    return
}


# ------------------------------------------------------------
# Prerequisites
# ------------------------------------------------------------

$updaterSource = Join-Path $PSScriptRoot $updaterName

if (-not (Test-Path $updaterSource)) {
    throw "$updaterName was not found next to this setup script ($PSScriptRoot)."
}

$optionsScriptSource = Join-Path $PSScriptRoot $optionsScriptName

if (-not (Test-Path $optionsScriptSource)) {
    throw "$optionsScriptName was not found next to this setup script ($PSScriptRoot)."
}

$noticeSource = Join-Path $PSScriptRoot $noticeName

if (-not (Test-Path $noticeSource)) {
    throw "$noticeName was not found next to this setup script ($PSScriptRoot)."
}

$passwordSource = Join-Path $PSScriptRoot $passwordName

if (-not (Test-Path $passwordSource)) {
    throw "$passwordName was not found next to this setup script ($PSScriptRoot)."
}

# The product list (page URL, sign-in host, file names, old-version rule) the updater reads.
$catalogName   = "products.json"
$catalogSource = Join-Path $PSScriptRoot $catalogName

if (-not (Test-Path $catalogSource)) {
    throw "$catalogName was not found next to this setup script ($PSScriptRoot)."
}

# Error reports: the module, where reports go, and this updater's name and version.
$reportingFileNames = @("Reporting.ps1", "reporting.json", "version.json")

foreach ($name in $reportingFileNames) {
    if (-not (Test-Path (Join-Path $PSScriptRoot $name))) {
        throw "$name was not found next to this setup script ($PSScriptRoot)."
    }
}

$reportDestination = [string](Get-Content (Join-Path $PSScriptRoot "reporting.json") -Raw | ConvertFrom-Json).ReportDestination

function Find-Pwsh {

    $command = Get-Command pwsh.exe -ErrorAction SilentlyContinue

    if ($command) {
        return $command.Source
    }

    # A fresh install is not on PATH in this session yet.
    $default = Join-Path $env:ProgramFiles "PowerShell\7\pwsh.exe"

    if (Test-Path $default) {
        return $default
    }

    return $null
}

function Find-Chrome {

    @(
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe"
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe"
        "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
    ) | Where-Object { Test-Path $_ } | Select-Object -First 1
}

function Install-FromMsi {

    # Direct-download fallback when winget is not available.
    param (
        [string]$Name,
        [string]$Url,
        [string]$MsiArguments = ""
    )

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $ProgressPreference = "SilentlyContinue"

    $msi = Join-Path $env:TEMP ("QSysUpdater-" + $Name.Replace(" ", "") + ".msi")

    Write-Host "Downloading $Name..."
    Invoke-WebRequest -Uri $Url -OutFile $msi -UseBasicParsing

    Write-Host "Installing $Name (a Windows permission prompt will appear)..."

    $process = Start-Process msiexec.exe `
        -ArgumentList "/i `"$msi`" /qn $MsiArguments" `
        -Verb RunAs `
        -Wait `
        -PassThru

    Remove-Item $msi -Force -ErrorAction SilentlyContinue

    if ($process.ExitCode -notin 0, 3010) {
        Write-Warning "$Name installer finished with exit code $($process.ExitCode)."
    }
}

function Install-Prerequisite {

    param (
        [string]$Name,
        [string]$WingetId,
        [scriptblock]$Fallback,
        [scriptblock]$IsInstalled
    )

    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue

    if ($winget) {

        Write-Host "Installing $Name with winget (a Windows permission prompt may appear)..."

        & $winget.Source install `
            --id $WingetId `
            --exact `
            --silent `
            --accept-package-agreements `
            --accept-source-agreements

        if (& $IsInstalled) {
            return
        }

        Write-Warning "winget did not complete the $Name install. Trying a direct download."
    }

    try {
        & $Fallback
    }
    catch {
        Write-Warning "Direct download of $Name failed: $($_.Exception.Message)"
    }
}

$pwsh   = Find-Pwsh
$chrome = Find-Chrome

$missing = @()

if (-not $pwsh) {
    $missing += "PowerShell 7 (runs the updater and the scheduled task)"
}

if (-not $chrome) {
    $missing += "Google Chrome (the updater uses it to sign in to qsys.com and download)"
}

if ($missing) {

    Write-Host ""
    Write-Host "This PC is missing required software:"
    $missing | ForEach-Object { Write-Host "  - $_" }
    Write-Host ""

    function Read-InstallChoice {

        param ([string]$Name)

        while ($true) {

            $answer = (Read-Host "Install $Name now? [Y] Yes  [N] No  [C] Cancel setup (Enter = Yes)").Trim()

            if ($answer -eq "" -or $answer -match '^y(es)?$') { return "install" }
            if ($answer -match '^n(o)?$')                     { return "skip" }
            if ($answer -match '^c(ancel)?$')                 { return "cancel" }

            Write-Host "Please enter Y, N or C."
        }
    }

    $installPwsh   = $false
    $installChrome = $false

    if ($InstallPrerequisites) {
        $installPwsh   = -not $pwsh
        $installChrome = -not $chrome
    }
    elseif ($useGui) {

        Add-Type -AssemblyName System.Windows.Forms

        $message = "This PC is missing software the Q-Sys Updater needs:`r`n`r`n" +
            (($missing | ForEach-Object { "  - $_" }) -join "`r`n") +
            "`r`n`r`nSetup can download and install it now (a Windows permission prompt may appear). Setup cannot continue without it.`r`n`r`nInstall it now?  (Yes = install, No = cancel setup)"

        $answer = [System.Windows.Forms.MessageBox]::Show($message, "Q-Sys Updater Setup", "YesNo", "Question")

        if ($answer -ne "Yes") {
            Write-Host "Setup cancelled. Nothing was installed or changed."
            exit 1
        }

        $installPwsh   = -not $pwsh
        $installChrome = -not $chrome
    }
    else {

        if (-not $pwsh) {

            $choice = Read-InstallChoice -Name "PowerShell 7"

            if ($choice -eq "cancel") {
                Write-Host "Setup cancelled. Nothing was installed or changed."
                exit 1
            }

            if ($choice -eq "skip") {
                Write-Host ""
                Write-Host "PowerShell 7 is required to run the updater, so setup cannot continue."
                Write-Host "Install it from https://aka.ms/powershell, then run setup again."
                exit 1
            }

            $installPwsh = $true
        }

        if (-not $chrome) {

            $choice = Read-InstallChoice -Name "Google Chrome"

            if ($choice -eq "cancel") {
                Write-Host "Setup cancelled. Nothing was installed or changed."
                exit 1
            }

            if ($choice -eq "skip") {
                Write-Host ""
                Write-Host "Google Chrome is required to sign in and download installers, so setup cannot continue."
                Write-Host "Install it from https://www.google.com/chrome, then run setup again."
                exit 1
            }

            $installChrome = $true
        }
    }

    if ($installPwsh) {

        Install-Prerequisite `
            -Name "PowerShell 7" `
            -WingetId "Microsoft.PowerShell" `
            -IsInstalled { [bool](Find-Pwsh) } `
            -Fallback {
                [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

                $release = Invoke-RestMethod `
                    "https://api.github.com/repos/PowerShell/PowerShell/releases/latest" `
                    -Headers @{ "User-Agent" = "QSysUpdaterSetup" }

                $asset = $release.assets |
                    Where-Object { $_.name -like "*win-x64.msi" } |
                    Select-Object -First 1

                if (-not $asset) {
                    throw "No Windows x64 MSI found in the latest PowerShell release."
                }

                Install-FromMsi `
                    -Name "PowerShell 7" `
                    -Url $asset.browser_download_url `
                    -MsiArguments "ADD_PATH=1"
            }

        $pwsh = Find-Pwsh
    }

    if ($installChrome) {

        Install-Prerequisite `
            -Name "Google Chrome" `
            -WingetId "Google.Chrome" `
            -IsInstalled { [bool](Find-Chrome) } `
            -Fallback {
                Install-FromMsi `
                    -Name "Google Chrome" `
                    -Url "https://dl.google.com/dl/chrome/install/googlechromestandaloneenterprise64.msi"
            }

        $chrome = Find-Chrome
    }

    if (-not $pwsh -or -not $chrome) {

        Write-Host ""
        Write-Host "Some software could not be installed automatically:"
        if (-not $pwsh)   { Write-Host "  PowerShell 7: https://aka.ms/powershell" }
        if (-not $chrome) { Write-Host "  Google Chrome: https://www.google.com/chrome" }
        Write-Host "Install it, then run setup again."
        exit 1
    }

    Write-Host "Required software is installed."
}

# This setup may have been started in Windows PowerShell 5.1 so it could
# install PowerShell 7. Continue the rest of setup in PowerShell 7.
if ($PSVersionTable.PSVersion.Major -lt 7) {

    Write-Host "Continuing setup in PowerShell 7..."

    $relaunchArgs = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $PSCommandPath)

    foreach ($name in $PSBoundParameters.Keys) {

        $value = $PSBoundParameters[$name]

        if ($value -is [switch]) {
            if ($value.IsPresent) { $relaunchArgs += "-$name" }
        }
        elseif ($value -is [array]) {
            $relaunchArgs += "-$name"
            $relaunchArgs += ($value -join ",")
        }
        else {
            $relaunchArgs += "-$name"
            $relaunchArgs += [string]$value
        }
    }

    & $pwsh @relaunchArgs
    exit $LASTEXITCODE
}


# ------------------------------------------------------------
# Error reports: on, unless this PC turned them off in an earlier setup
# or in Options (then they stay off unless -ErrorReports is given).
# The setup window's tick box starts from this and decides.
# ------------------------------------------------------------

$errorReporting = $true

if (Test-Path $configFile) {
    try {
        if ((Get-Content $configFile -Raw | ConvertFrom-Json).ErrorReporting -eq $false) { $errorReporting = $false }
    }
    catch { }
}

if ($ErrorReports)   { $errorReporting = $true }
if ($NoErrorReports) { $errorReporting = $false }


# ------------------------------------------------------------
# Setup window (when the folder was not given on the command line)
# ------------------------------------------------------------

if ($useGui -and -not $DestinationRoot) {

    $startFolder = @($env:OneDriveCommercial, $env:OneDrive) |
        Where-Object { $_ -and (Test-Path $_) } |
        Select-Object -First 1

    $previousBlocked = @($BlockedSSIDs)

    if (-not $PSBoundParameters.ContainsKey("BlockedSSIDs") -and (Test-Path $configFile)) {
        $previousBlocked = @((Get-Content $configFile -Raw | ConvertFrom-Json).BlockedSSIDs | Where-Object { $_ })
    }

    $choice = Show-SetupWizard -StartFolder $startFolder -BlockedNow $previousBlocked -Mode $BrowserMode -Task $TaskName -ErrorReports $errorReporting

    if (-not $choice) {
        Write-Host "Setup cancelled. Nothing was changed."
        exit 1
    }

    $DestinationRoot = $choice.DestinationRoot
    $BlockedSSIDs    = @($choice.BlockedSSIDs)
    $BrowserMode     = $choice.BrowserMode
    $TaskName        = $choice.TaskName
    $noticeTaskName  = "$TaskName Notice"
    $errorReporting  = [bool]$choice.ErrorReports    # the tick box decides, also over an earlier opt-out
    $NoErrorReports  = -not $errorReporting

    $global:QSetupCredential = $choice.Credential
    $wizardDone = $true
}


# ------------------------------------------------------------
# Rollback support
#
# If setup is cancelled or fails before it finishes, remove only
# what THIS run created. Anything that already existed (folders,
# an earlier install) is never removed. Once setup completes,
# nothing is removed automatically.
# ------------------------------------------------------------

$script:createdPaths = New-Object System.Collections.Generic.List[string]
$script:createdTask  = $false
$script:createdNoticeTask = $false

# Never silently replace a scheduled task that another install (for example the
# original script) is using. Re-running setup over its own install is fine.
if (-not $SkipTask) {

    $taskInTheWay = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue

    if ($taskInTheWay) {

        $ownLauncher = Join-Path $InstallDir $launcherName

        $theirCommand = ($taskInTheWay.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join " | "

        if ($useGui -and $theirCommand -notlike "*$ownLauncher*" -and -not $ReplaceExistingTask) {

            Add-Type -AssemblyName System.Windows.Forms

            $replaceAnswer = [System.Windows.Forms.MessageBox]::Show(
                "A scheduled task named '$TaskName' already exists and was not created by this setup:`r`n`r`n$theirCommand`r`n`r`nReplace it? Choose No to keep it (then run setup again with a different task name under Advanced).",
                "Q-Sys Updater Setup", "YesNo", "Warning", "Button2")

            if ($replaceAnswer -eq "Yes") {
                $ReplaceExistingTask = $true
            }
        }

        if ($theirCommand -notlike "*$ownLauncher*" -and -not $ReplaceExistingTask) {

            Write-Host ""
            Write-Host "A scheduled task named '$TaskName' already exists and was not created by this setup:"
            Write-Host "  $theirCommand"
            Write-Host ""
            Write-Host "Setup will not replace it. Either choose a different name, for example:"
            Write-Host "  -TaskName `"$TaskName TEST`""
            Write-Host "or add -ReplaceExistingTask if you really want to replace it."
            exit 1
        }
    }
}

function New-TrackedDirectory {

    param ([string]$Path)

    if (Test-Path $Path) {
        return
    }

    # Remember the top-most folder that does not exist yet, so one
    # removal undoes the whole chain this run created.
    $top = $Path

    while ($true) {
        $parent = Split-Path $top -Parent

        if (-not $parent -or (Test-Path $parent)) {
            break
        }

        $top = $parent
    }

    New-Item -ItemType Directory -Path $Path -Force | Out-Null
    $script:createdPaths.Add($top)
}

function Register-CreatedFile {

    param ([string]$Path)

    if (-not (Test-Path $Path)) {
        $script:createdPaths.Add($Path)
    }
}

function Grant-UserTaskControl {

    # A task registered from an elevated (administrator) window can, by default,
    # only be changed from an elevated window, so the Stop icon (an ordinary
    # window) would get "Access is denied" even for the same person. Give the
    # signed-in user full control of THEIR OWN task; it already runs as them, so
    # this adds no privilege. A failure here is only a warning.
    param ([string]$Name)

    try {

        $sid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value

        $service = New-Object -ComObject Schedule.Service
        $service.Connect()

        $registered = $service.GetFolder("\").GetTask($Name)
        $registered.SetSecurityDescriptor("D:P(A;;FA;;;BA)(A;;FA;;;SY)(A;;FA;;;$sid)", 0)
    }
    catch {
        Write-Warning "Could not give your account control of the task '$Name' ($($_.Exception.Message)). The Stop icon may then need an administrator window."
    }
}

function Undo-Setup {

    if ($script:createdTask) {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
    }

    if ($script:createdNoticeTask) {
        Unregister-ScheduledTask -TaskName $noticeTaskName -Confirm:$false -ErrorAction SilentlyContinue
    }

    for ($i = $script:createdPaths.Count - 1; $i -ge 0; $i--) {
        Remove-Item $script:createdPaths[$i] -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function New-AppShortcut {

    param (
        [string]$Path,
        [string]$ScriptPath,
        [string]$Description = "Stop or resume the Q-Sys Updater, change the saved Q-SYS password, undo the last update, or remove it",
        [string]$Icon = "$env:SystemRoot\System32\shell32.dll,316"   # the blue settings gear
    )

    $shell    = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($Path)

    $shortcut.TargetPath       = $pwsh
    $shortcut.Arguments        = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$ScriptPath`""
    $shortcut.WorkingDirectory = $InstallDir
    $shortcut.Description      = $Description
    $shortcut.IconLocation     = $Icon
    $shortcut.Save()
}

$setupFinished = $false

$progressForm = $null

if ($wizardDone) {

    Add-Type -AssemblyName System.Windows.Forms

    $progressForm = New-Object System.Windows.Forms.Form
    $progressForm.Text = "Q-Sys Updater Setup"
    $progressForm.ClientSize = New-Object System.Drawing.Size(420, 90)
    $progressForm.StartPosition = "CenterScreen"; $progressForm.FormBorderStyle = "FixedDialog"
    $progressForm.ControlBox = $false; $progressForm.TopMost = $true
    $progressForm.Font = New-Object System.Drawing.Font("Segoe UI", 10)

    $progressLabel = New-Object System.Windows.Forms.Label
    $progressLabel.Text = "Installing the Q-Sys Updater, please wait..."
    $progressLabel.Location = New-Object System.Drawing.Point(20, 28); $progressLabel.Size = New-Object System.Drawing.Size(380, 30)
    $progressForm.Controls.Add($progressLabel)

    $progressForm.Show()
    [System.Windows.Forms.Application]::DoEvents()
}

try {

    # --------------------------------------------------------
    # Choose where installers are saved
    # --------------------------------------------------------

    if (-not $DestinationRoot) {

        Add-Type -AssemblyName System.Windows.Forms

        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = "Choose the folder to keep installers in (for example, your Q-Sys Designer folder). Installers are saved directly in it."
        $dialog.ShowNewFolderButton = $true

        $startFolder = @($env:OneDriveCommercial, $env:OneDrive) |
            Where-Object { $_ -and (Test-Path $_) } |
            Select-Object -First 1

        if ($startFolder) {
            $dialog.SelectedPath = $startFolder
        }

        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
            throw "No folder was chosen. Setup cancelled."
        }

        $DestinationRoot = $dialog.SelectedPath
    }

    # The chosen folder is used as is; only an Archive folder is added later, when an update needs one.
    $qsysFolder = $DestinationRoot
    New-TrackedDirectory $qsysFolder

    Write-Host "Installers will be saved to: $qsysFolder"


    # --------------------------------------------------------
    # Choose Wi-Fi networks to avoid (skipped if -BlockedSSIDs was given)
    # --------------------------------------------------------

    if (-not $PSBoundParameters.ContainsKey("BlockedSSIDs") -and -not $wizardDone) {

        $previousBlocked = @()

        if (Test-Path $configFile) {
            $previousBlocked = @((Get-Content $configFile -Raw | ConvertFrom-Json).BlockedSSIDs)
        }

        $BlockedSSIDs = @(Select-BlockedSSIDs -Current $previousBlocked)
    }


    # --------------------------------------------------------
    # Credential
    # --------------------------------------------------------

    New-TrackedDirectory $InstallDir

    Register-CreatedFile $credentialFile
    Save-QSysCredential -Path $credentialFile


    # --------------------------------------------------------
    # Install files and settings
    # --------------------------------------------------------

    $updaterPath = Join-Path $InstallDir $updaterName
    Register-CreatedFile $updaterPath
    Copy-Item $updaterSource $updaterPath -Force

    $optionsScriptPath = Join-Path $InstallDir $optionsScriptName
    Register-CreatedFile $optionsScriptPath
    Copy-Item $optionsScriptSource $optionsScriptPath -Force

    # The Options script replaces the old Stop script of earlier versions of setup.
    Remove-Item (Join-Path $InstallDir "Stop-QSysUpdater.ps1") -Force -ErrorAction SilentlyContinue

    $noticePath = Join-Path $InstallDir $noticeName
    Register-CreatedFile $noticePath
    Copy-Item $noticeSource $noticePath -Force

    $passwordPath = Join-Path $InstallDir $passwordName
    Register-CreatedFile $passwordPath
    Copy-Item $passwordSource $passwordPath -Force

    $catalogPath = Join-Path $InstallDir $catalogName
    Register-CreatedFile $catalogPath
    Copy-Item $catalogSource $catalogPath -Force

    if (Test-Path $credentialPromptSource) {
        $credentialPromptPath = Join-Path $InstallDir $credentialPromptName
        Register-CreatedFile $credentialPromptPath
        Copy-Item $credentialPromptSource $credentialPromptPath -Force
    }

    foreach ($name in $reportingFileNames) {
        $reportingFilePath = Join-Path $InstallDir $name
        Register-CreatedFile $reportingFilePath
        Copy-Item (Join-Path $PSScriptRoot $name) $reportingFilePath -Force
    }

    $config = [ordered]@{
        StateDir          = $InstallDir
        DestRoot          = $DestinationRoot
        QSysFolder        = $qsysFolder
        BlockedSSIDs      = @($BlockedSSIDs)
        NoticeTaskName    = $noticeTaskName
        TaskName          = $TaskName
        BrowserMode       = $BrowserMode
        ErrorReporting    = $errorReporting
        ReportDestination = $reportDestination
    }

    Register-CreatedFile $configFile
    $config | ConvertTo-Json | Set-Content -Path $configFile -Encoding UTF8

    $vbs = @"
Set shell = CreateObject("WScript.Shell")
shell.Run """$pwsh"" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File ""$updaterPath""", 0, True
"@

    $launcherPath = Join-Path $InstallDir $launcherName
    Register-CreatedFile $launcherPath
    Set-Content -Path $launcherPath -Value $vbs -Encoding ASCII

    $noticeVbs = @"
Set shell = CreateObject("WScript.Shell")
shell.Run """$pwsh"" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""$noticePath""", 0, False
"@

    $noticeLauncherPath = Join-Path $InstallDir $noticeLauncher
    Register-CreatedFile $noticeLauncherPath
    Set-Content -Path $noticeLauncherPath -Value $noticeVbs -Encoding ASCII

    Write-Host "Installed to $InstallDir"


    # --------------------------------------------------------
    # Scheduled task: at logon and on wake from sleep
    # --------------------------------------------------------

    if (-not $SkipTask) {

        $user = "$env:USERDOMAIN\$env:USERNAME"

        $action = New-ScheduledTaskAction `
            -Execute "wscript.exe" `
            -Argument ('"{0}"' -f $launcherPath)

        # Matches the original working task: 2 minute delay after logon and
        # after resuming from sleep (Kernel-Power event 107).
        $logonTrigger = New-ScheduledTaskTrigger -AtLogOn -User $user
        $logonTrigger.Delay = "PT2M"

        $eventClass = Get-CimClass `
            -Namespace "Root/Microsoft/Windows/TaskScheduler" `
            -ClassName "MSFT_TaskEventTrigger"

        $wakeTrigger = New-CimInstance -CimClass $eventClass -ClientOnly
        $wakeTrigger.Enabled = $true
        $wakeTrigger.Delay = "PT2M"
        $wakeTrigger.Subscription = @"
<QueryList><Query Id="0" Path="System"><Select Path="System">*[System[Provider[@Name='Microsoft-Windows-Kernel-Power'] and EventID=107]]</Select></Query></QueryList>
"@

        $settings = New-ScheduledTaskSettingsSet `
            -StartWhenAvailable `
            -AllowStartIfOnBatteries `
            -DontStopIfGoingOnBatteries `
            -MultipleInstances IgnoreNew `
            -RunOnlyIfNetworkAvailable `
            -RestartCount 3 `
            -RestartInterval (New-TimeSpan -Minutes 5) `
            -ExecutionTimeLimit (New-TimeSpan -Hours 1)

        # Same account type as the original task: the signed-in user's SID, interactive.
        $userSid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value

        $principal = New-ScheduledTaskPrincipal `
            -UserId $userSid `
            -LogonType Interactive `
            -RunLevel Limited

        $existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue

        if ($existing) {
            Write-Host "A scheduled task named '$TaskName' already exists and will be replaced."
        }

        Register-ScheduledTask `
            -TaskName $TaskName `
            -Action $action `
            -Trigger @($logonTrigger, $wakeTrigger) `
            -Settings $settings `
            -Principal $principal `
            -Force |
            Out-Null

        Grant-UserTaskControl -Name $TaskName

        if (-not $existing) {
            $script:createdTask = $true
        }

        Write-Host "Scheduled task '$TaskName' registered (at logon)."

        # On-demand task that shows the "new version downloaded" notice.
        # No triggers and NO time limit: the notice stays open until the
        # user clicks a button, so it must not be tied to the updater's
        # 1 hour limit. The updater starts it with Start-ScheduledTask.
        $noticeAction = New-ScheduledTaskAction `
            -Execute "wscript.exe" `
            -Argument ('"{0}"' -f $noticeLauncherPath)

        $noticeSettings = New-ScheduledTaskSettingsSet `
            -AllowStartIfOnBatteries `
            -DontStopIfGoingOnBatteries `
            -MultipleInstances IgnoreNew `
            -ExecutionTimeLimit ([TimeSpan]::Zero)

        $existingNotice = Get-ScheduledTask -TaskName $noticeTaskName -ErrorAction SilentlyContinue

        Register-ScheduledTask `
            -TaskName $noticeTaskName `
            -Action $noticeAction `
            -Settings $noticeSettings `
            -Principal $principal `
            -Force |
            Out-Null

        Grant-UserTaskControl -Name $noticeTaskName

        if (-not $existingNotice) {
            $script:createdNoticeTask = $true
        }
    }


    # --------------------------------------------------------
    # "Q-Sys Updater Options" icons (Desktop and Start menu)
    # --------------------------------------------------------

    $desktopLink = Join-Path ([Environment]::GetFolderPath("Desktop")) $optionsLinkName
    Register-CreatedFile $desktopLink
    New-AppShortcut -Path $desktopLink -ScriptPath $optionsScriptPath

    $startMenuFolder = Join-Path ([Environment]::GetFolderPath("Programs")) "Q-Sys Updater"
    New-TrackedDirectory $startMenuFolder

    $startMenuLink = Join-Path $startMenuFolder $optionsLinkName
    Register-CreatedFile $startMenuLink
    New-AppShortcut -Path $startMenuLink -ScriptPath $optionsScriptPath

    # Earlier versions of setup made separate "Stop Q-Sys Updater" and
    # "Update Q-SYS Password" icons. Remove those two (only when they point into
    # THIS install) so no stale icons are left behind.
    $shell = New-Object -ComObject WScript.Shell

    foreach ($folder in @([Environment]::GetFolderPath("Desktop"), $startMenuFolder)) {

        foreach ($legacy in $legacyStopLink, $legacyPassLink) {

            $legacyPath = Join-Path $folder $legacy

            if (Test-Path $legacyPath) {

                $points = $shell.CreateShortcut($legacyPath).Arguments

                if ($points -like "*$InstallDir*") {
                    Remove-Item $legacyPath -Force -ErrorAction SilentlyContinue
                }
            }
        }
    }
    $setupFinished = $true
}
catch {

    Write-Host ""

    if ($_.Exception.Message -match "cancelled") {
        Write-Host "Setup cancelled."
    }
    else {
        Write-Host "Setup failed: $($_.Exception.Message)"
    }
}
finally {

    if ($progressForm) {
        $progressForm.Close()
        $progressForm.Dispose()
    }

    # Also runs if the window is closed with Ctrl+C.
    if (-not $setupFinished) {
        Write-Host "Removing what this setup created..."
        Undo-Setup
        Write-Host "Done. Nothing from this setup was left behind."

        if ($wizardDone) {
            [void][System.Windows.Forms.MessageBox]::Show("Setup did not finish, so everything it had created was removed. Nothing was left behind.`r`n`r`nDetails are in the setup window's text.", "Q-Sys Updater Setup", "OK", "Warning")
        }
    }
}

if (-not $setupFinished) {
    exit 1
}


Write-Host ""
Write-Host "Setup complete."
Write-Host "Run history (one dated line per attempt, with the reason if it failed):"
Write-Host "  $(Join-Path $InstallDir 'Logs\Run-History.log')"
Write-Host "Detailed log: $(Join-Path $InstallDir 'Logs\QSys-Updater.log')"
Write-Host ""
Write-Host "Chrome runs $(if ($BrowserMode -eq 'Visible') { 'with a visible window (testing mode)' } else { 'hidden (no window)' })."
Write-Host ""
Write-Host "To stop or resume the updater, change your Q-SYS password, undo the last"
Write-Host "update or remove everything, open 'Q-Sys Updater Options' on your Desktop"
Write-Host "(or in the Start menu) and press one key."

if ($RunNow -and -not $SkipTask) {
    Start-ScheduledTask -TaskName $TaskName
    Write-Host "Started the updater now."
}

if ($useGui -and $wizardDone) {

    if (Show-SetupDone) {

        # Open the Options window (outside the install folder, so it can never block removing it).
        Start-Process -FilePath $pwsh -WorkingDirectory $env:TEMP -WindowStyle Hidden -ArgumentList @(
            "-NoProfile", "-ExecutionPolicy", "Bypass",
            "-File", "`"$optionsScriptPath`"",
            "-InstallDir", "`"$InstallDir`""
        )
    }
}
