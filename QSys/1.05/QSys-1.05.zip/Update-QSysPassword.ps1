# ============================================================
# Q-Sys Updater -- update the saved Q-SYS password
#
# Behind the P choice in the "Q-Sys Updater Options" window and the "Update Password"
# button on the sign-in notice. Asks for the Q-SYS email and password
# in the standard Windows credential prompt and saves them, encrypted
# for THIS Windows user on THIS PC only (never stored in plain text).
# Saving also lifts the pause that follows a rejected sign-in, so the
# updater tries again.
# ============================================================

[CmdletBinding()]
param (
    [string]$StateDir = $PSScriptRoot,
    [switch]$Gui   # answer in message boxes instead of the console (used by the Options window)
)

$ErrorActionPreference = "Stop"

$configFile     = Join-Path $StateDir "config.json"
$credentialFile = Join-Path $StateDir "QSys-Credential.xml"

# The Windows sign-in window. If its file is missing, fall back to the text prompt.
$credentialPromptFile = Join-Path $PSScriptRoot "CredentialPrompt.ps1"

if (Test-Path $credentialPromptFile) {
    . $credentialPromptFile
}
else {
    function Get-QSysCredentialPrompt {
        param ([string]$Message)
        Get-Credential -Message $Message
    }
}

$taskName = "Q-Sys Updater"

if (Test-Path $configFile) {

    $config = Get-Content $configFile -Raw | ConvertFrom-Json

    if ($config.TaskName) {
        $taskName = $config.TaskName
    }
}

function Show-Message ($text, $icon = "Information", $buttons = "OK") {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show($text, "Q-Sys Updater", $buttons, $icon)
}

if (-not $Gui) {
    Write-Host "Update the saved Q-SYS (qsys.com) sign-in."
    Write-Host ""
}

$credential = Get-QSysCredentialPrompt -Message "Enter your Q-SYS (qsys.com) account email and password"

if (
    -not $credential -or
    [string]::IsNullOrWhiteSpace($credential.UserName) -or
    $credential.Password.Length -eq 0
) {
    if ($Gui) { [void](Show-Message "No credential was entered. Nothing was changed.") }
    else { Write-Host "No credential was entered. Nothing was changed." }
    return
}

$credential | Export-Clixml -Path $credentialFile

# Limit the file to the current user only.
$currentUser = "$env:USERDOMAIN\$env:USERNAME"
& icacls.exe $credentialFile /inheritance:r /grant:r "${currentUser}:(F)" | Out-Null

# Lift the pause that follows a rejected sign-in.
Remove-Item (Join-Path $StateDir "login-failed.json") -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $StateDir "pending-signin-failed.json") -Force -ErrorAction SilentlyContinue

$savedText = "Saved for $($credential.UserName). It is encrypted and can only be read by $currentUser on this PC."

if ($Gui) {

    if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {

        $answer = Show-Message "$savedText`r`n`r`nCheck for the update now?" "Question" "YesNo"

        if ($answer -eq "Yes") {
            Start-ScheduledTask -TaskName $taskName
            [void](Show-Message "Started. The result is in the run history.")
        }
    }
    else {
        [void](Show-Message $savedText)
    }

    return
}

Write-Host ""
Write-Host $savedText
Write-Host ""

if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {

    $answer = Read-Host "Check for the update now? [Y/n]"

    if ($answer -eq "" -or $answer -match '^(y|yes)$') {
        Start-ScheduledTask -TaskName $taskName
        Write-Host "Started. The result is in the log."
    }
    else {
        Write-Host "OK. It will check at the next logon."
    }
}
