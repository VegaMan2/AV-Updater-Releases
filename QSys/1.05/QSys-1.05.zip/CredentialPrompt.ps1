# ============================================================
# Q-Sys Updater -- the Windows sign-in window
#
# Defines Get-QSysCredentialPrompt, which shows the standard Windows
# credential window ("Windows Security" style, with a User name box and a
# masked Password box) and returns a PSCredential, or $null if the user
# cancels. Used by Install-QSysUpdater.ps1 and Update-QSysPassword.ps1.
#
# Why not just Get-Credential: in PowerShell 7 that prints a text prompt in
# the console instead of showing a window.
#
# If the window cannot be shown for any reason, it falls back to the text
# prompt (Get-Credential), so the caller always gets a credential or $null.
# Works in Windows PowerShell 5.1 and PowerShell 7.
# ============================================================

$script:QSysCredentialUiSource = @'
using System;
using System.Runtime.InteropServices;
using System.Text;

public static class QSysCredUI
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct CREDUI_INFO
    {
        public int cbSize;
        public IntPtr hwndParent;
        public string pszMessageText;
        public string pszCaptionText;
        public IntPtr hbmBanner;
    }

    [DllImport("credui.dll", CharSet = CharSet.Unicode)]
    public static extern int CredUIPromptForWindowsCredentials(
        ref CREDUI_INFO pUiInfo,
        int dwAuthError,
        ref uint pulAuthPackage,
        IntPtr pvInAuthBuffer,
        uint ulInAuthBufferSize,
        out IntPtr ppvOutAuthBuffer,
        out uint pulOutAuthBufferSize,
        ref bool pfSave,
        int dwFlags);

    [DllImport("credui.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern bool CredUnPackAuthenticationBuffer(
        int dwFlags,
        IntPtr pAuthBuffer,
        uint cbAuthBuffer,
        StringBuilder pszUserName,
        ref int pcchMaxUserName,
        StringBuilder pszDomainName,
        ref int pcchMaxDomainName,
        StringBuilder pszPassword,
        ref int pcchMaxPassword);

    [DllImport("ole32.dll")]
    public static extern void CoTaskMemFree(IntPtr ptr);
}
'@

function Get-QSysCredentialPrompt {

    param (
        [string]$Message = "Enter your Q-SYS (qsys.com) account email and password",
        [string]$Caption = "Q-Sys Updater"
    )

    try {

        if (-not ([System.Management.Automation.PSTypeName]'QSysCredUI').Type) {
            Add-Type -TypeDefinition $script:QSysCredentialUiSource
        }

        $info = New-Object QSysCredUI+CREDUI_INFO
        $info.cbSize         = [System.Runtime.InteropServices.Marshal]::SizeOf($info)
        $info.pszMessageText = $Message
        $info.pszCaptionText = $Caption

        [uint32]$authPackage = 0
        [IntPtr]$outBuffer   = [IntPtr]::Zero
        [uint32]$outSize     = 0
        [bool]$save          = $false

        # CREDUIWIN_GENERIC (1): any user name, such as an email address.
        $result = [QSysCredUI]::CredUIPromptForWindowsCredentials(
            [ref]$info, 0, [ref]$authPackage, [IntPtr]::Zero, 0,
            [ref]$outBuffer, [ref]$outSize, [ref]$save, 1
        )

        # 1223 = the user cancelled.
        if ($result -eq 1223) {
            return $null
        }

        if ($result -ne 0) {
            throw "Windows credential window error $result"
        }

        $user   = New-Object System.Text.StringBuilder 512
        $domain = New-Object System.Text.StringBuilder 512
        $pass   = New-Object System.Text.StringBuilder 512

        try {

            [int]$userLength   = 512
            [int]$domainLength = 512
            [int]$passLength   = 512

            $unpacked = [QSysCredUI]::CredUnPackAuthenticationBuffer(
                0, $outBuffer, $outSize,
                $user, [ref]$userLength,
                $domain, [ref]$domainLength,
                $pass, [ref]$passLength
            )

            if (-not $unpacked) {
                throw "Could not read what was typed into the Windows credential window"
            }

            $secure = New-Object System.Security.SecureString

            foreach ($character in $pass.ToString().ToCharArray()) {
                $secure.AppendChar($character)
            }

            $secure.MakeReadOnly()

            $userName = $user.ToString()

            if ($domain.Length -gt 0) {
                $userName = $domain.ToString() + "\" + $userName
            }

            return New-Object System.Management.Automation.PSCredential($userName, $secure)
        }
        finally {

            # Wipe what was typed from memory as soon as it has been copied.
            [void]$pass.Clear()

            if ($outBuffer -ne [IntPtr]::Zero) {
                [QSysCredUI]::CoTaskMemFree($outBuffer)
            }
        }
    }
    catch {

        Write-Warning "The Windows sign-in window could not be shown ($($_.Exception.Message)). Using the text prompt instead."

        return (Get-Credential -Message $Message)
    }
}
