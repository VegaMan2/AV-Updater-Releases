# ============================================================
# Q-Sys Updater -- Options
#
# Installed to %LOCALAPPDATA%\QSysUpdater by Install-QSysUpdater.ps1 and
# started by the "Q-Sys Updater Options" icon (Desktop and Start menu).
#
#   (no switch)       Shows the updater's status and one-key choices: stop or
#                     resume it, update the saved Q-SYS password, open the run
#                     history or the installers folder, undo the last update,
#                     turn error reports on or off (window only), or remove
#                     the updater. Opening it changes nothing by itself.
#   -UndoLastUpdate   Reverses the updater's most recent update in your
#                     installers folder: removes the ZIP and extracted
#                     folder it added and moves the archived version back,
#                     so the next run downloads the update again. Add
#                     -UndoAll to reverse every recorded update.
#   -Uninstall        Removes the scheduled tasks, the icons, and the
#                     updater's own folder (saved Q-SYS credential, Chrome
#                     profile, logs). Downloaded installers are kept unless
#                     you also choose to undo the updates (-UndoUpdates, or
#                     answer the question).
# ============================================================
[CmdletBinding()]
param (
    [string]$InstallDir = (Join-Path $env:LOCALAPPDATA "QSysUpdater"),
    [string]$TaskName = "Q-Sys Updater",
    [switch]$Uninstall,
    [switch]$UndoLastUpdate,
    [switch]$UndoAll,
    [switch]$UndoUpdates,
    [switch]$NoGui,   # keep the old console menu (also used automatically when input is redirected)
    [switch]$Yes      # with -Uninstall: the confirmation was already given (by the window)
)

$ErrorActionPreference = "Stop"

$configFile   = Join-Path $InstallDir "config.json"
$optionsLinkName = "Q-Sys Updater Options.lnk"
# Icons made by earlier versions of setup (removed on uninstall so nothing stale is left behind).
$legacyStopLink = "Stop Q-Sys Updater.lnk"
$legacyPassLink = "Update Q-SYS Password.lnk"
$optionsScript = Join-Path $InstallDir "Options-QSysUpdater.ps1"

# Error reports on/off (Set-ErrorReporting). Without the module (or with a damaged one) the
# window simply has no Error reports button.
$reportingScript = Join-Path $PSScriptRoot "Reporting.ps1"
if (Test-Path -LiteralPath $reportingScript) { try { . $reportingScript } catch { } }

$qsysFolder = $null
$noticeTaskName = $null

if (Test-Path $configFile) {

    $savedConfig = Get-Content $configFile -Raw | ConvertFrom-Json

    $qsysFolder = $savedConfig.QSysFolder

    # Use the task name this install was set up with, so a test install with its
    # own task name never touches a different install's task.
    if ($savedConfig.TaskName -and -not $PSBoundParameters.ContainsKey("TaskName")) {
        $TaskName = $savedConfig.TaskName
    }

    $noticeTaskName = $savedConfig.NoticeTaskName
}

if (-not $noticeTaskName) {
    $noticeTaskName = "$TaskName Notice"
}

$task       = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
$noticeTask = Get-ScheduledTask -TaskName $noticeTaskName -ErrorAction SilentlyContinue


function Invoke-TaskChange {

    # Runs one scheduled-task change. If Windows refuses, say why in plain words
    # and what to do, instead of showing a raw error. Returns $true on success.
    param (
        [scriptblock]$Change,
        [string]$Action,
        [switch]$Quiet   # window: keep the explanation in $global:QOptTaskMessage instead of printing it
    )

    try {
        & $Change
        return $true
    }
    catch {

        $text = @("Could not $Action the scheduled task. Windows said: $($_.Exception.Message)")

        if ($_.Exception.Message -match 'denied') {
            $text += ""
            $text += "This happens when the task was created from a PowerShell window opened with"
            $text += "'Run as administrator': Windows then lets only an administrator window change it."
            $text += "Either run Install-QSysUpdater.ps1 again (setup now gives your account control"
            $text += "of its own tasks), or run this same command from an administrator window."
        }

        if ($Quiet) {
            $global:QOptTaskMessage = $text -join "`r`n"
        }
        else {
            Write-Host ""
            foreach ($line in $text) { Write-Host $line }
        }

        return $false
    }
}

function Stop-RunningUpdater {

    # Ends only this updater's own processes: the updater script and the
    # dedicated Chrome that uses its profile. Your normal Chrome is untouched.
    $processes = Get-CimInstance Win32_Process |
        Where-Object {
            (
                $_.Name -eq "pwsh.exe" -and
                $_.CommandLine -like "*$InstallDir*QSys-Updater.ps1*"
            ) -or (
                $_.Name -eq "chrome.exe" -and
                $_.CommandLine -like "*$InstallDir*QSys-Chrome-Profile*"
            )
        }

    foreach ($process in $processes) {
        Stop-Process -Id $process.ProcessId -Force -ErrorAction SilentlyContinue
    }
}

function Stop-OpenNotice {

    Get-CimInstance Win32_Process |
        Where-Object {
            $_.Name -eq "pwsh.exe" -and
            $_.CommandLine -like "*$InstallDir*Show-QSysNotice.ps1*"
        } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

function Test-InsideFolder {

    # Safety: only ever touch paths inside the installers folder.
    param ([string]$Path, [string]$Root)

    if (-not $Path -or -not $Root) { return $false }

    $fullPath = [System.IO.Path]::GetFullPath($Path).TrimEnd("\")
    $fullRoot = [System.IO.Path]::GetFullPath($Root).TrimEnd("\")

    $fullPath.StartsWith($fullRoot + "\", [System.StringComparison]::OrdinalIgnoreCase)
}

function Get-UpdateJournals {

    @(
        Get-ChildItem (Join-Path $InstallDir "Journal") -Filter "update-*.json" -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -notlike "*.undone.json" } |
            Sort-Object Name -Descending
    )
}

function Get-UndoPlan {

    # Works out what undoing one recorded update would do, without doing it.
    # Returns the journal file, a heading and the plain-words lines to show.
    param ($File)

    $j = Get-Content $File.FullName -Raw | ConvertFrom-Json

    $lines = @()
    $moves = @($j.Moves)

    if ($j.NewZip)          { $lines += "remove the new installer ZIP:   $($j.NewZip)" }
    if ($j.ExtractedFolder) { $lines += "remove the extracted folder:    $($j.ExtractedFolder)" }

    for ($i = $moves.Count - 1; $i -ge 0; $i--) {
        $lines += "move back from the archive:     $($moves[$i].To)"
        $lines += "                        to:     $($moves[$i].From)"
    }

    $lines += "clear the 'new version' notice so it shows again next time"

    [pscustomobject]@{
        File    = $File
        Journal = $j
        Heading = "Update $($j.FromVersion) -> $($j.ToVersion)  ($($j.Time))"
        Lines   = $lines
    }
}

function Invoke-UndoJournal {

    # Reverses one recorded update. Returns the messages as objects
    # (Kind = Info or Warning) so the console and the window can each show them.
    param ($Plan)

    $file = $Plan.File
    $j    = $Plan.Journal
    $root = $j.QSysFolder
    $moves = @($j.Moves)
    $messages = New-Object System.Collections.ArrayList

    function Add-Message ($Kind, $Text) { [void]$messages.Add([pscustomobject]@{ Kind = $Kind; Text = $Text }) }

    # 1. Put archived items back where they were (last move first).
    for ($i = $moves.Count - 1; $i -ge 0; $i--) {

        $from = $moves[$i].From
        $to   = $moves[$i].To

        if (-not (Test-InsideFolder $from $root) -or -not (Test-InsideFolder $to $root)) {
            Add-Message Warning "Skipped a move outside the installers folder: $to"
            continue
        }

        if ((Test-Path $to) -and -not (Test-Path $from)) {
            Move-Item $to $from
            Add-Message Info "Moved back: $(Split-Path $from -Leaf)"
        }
        else {
            Add-Message Warning "Could not move back $(Split-Path $to -Leaf) (missing, or something is already at the original location)."
        }
    }

    # 2. Remove what the update added.
    foreach ($added in @($j.ExtractedFolder, $j.NewZip)) {

        if (-not $added) { continue }

        if (-not (Test-InsideFolder $added $root)) {
            Add-Message Warning "Skipped a path outside the installers folder: $added"
            continue
        }

        if (Test-Path $added) {
            Remove-Item $added -Recurse -Force
            Add-Message Info "Removed: $(Split-Path $added -Leaf)"
        }
    }

    # 3. Remove the Archive folder only if this update created it and it is empty.
    if (
        $j.ArchiveFolderCreated -and
        (Test-Path $j.ArchiveFolder) -and
        -not (Get-ChildItem $j.ArchiveFolder -Force)
    ) {
        Remove-Item $j.ArchiveFolder -Force
        Add-Message Info "Removed the empty Archive folder."
    }

    # 4. Make the notice appear again for this version.
    Remove-Item (Join-Path $InstallDir "pending-notice.json") -Force -ErrorAction SilentlyContinue

    $notifiedFile = Join-Path $InstallDir "last-notified-version.txt"

    if ((Test-Path $notifiedFile) -and ((Get-Content $notifiedFile -Raw).Trim() -eq $j.ToVersion)) {
        Remove-Item $notifiedFile -Force
    }

    # 5. Keep the journal for the record, marked as undone.
    Rename-Item $file.FullName ($file.BaseName + ".undone.json")

    Add-Message Info "Undone."

    $messages
}

function Undo-Updates {

    # Console version: reverses what the updater recorded in its journal (newest first).
    param ([switch]$All, [switch]$AssumeYes)

    $journals = Get-UpdateJournals

    if (-not $journals) {
        Write-Host "No updates are recorded, so there is nothing to undo."
        return
    }

    $targets = if ($All) { $journals } else { @($journals[0]) }

    Stop-RunningUpdater
    Stop-OpenNotice

    foreach ($file in $targets) {

        $plan = Get-UndoPlan $file

        Write-Host ""
        Write-Host $plan.Heading
        Write-Host "Undoing it will:"

        foreach ($line in $plan.Lines) { Write-Host "  - $line" }

        if (-not $AssumeYes) {

            $answer = Read-Host "Undo this update? [y/N]"

            if ($answer -notmatch '^(y|yes)$') {
                Write-Host "Skipped."
                continue
            }
        }

        foreach ($m in (Invoke-UndoJournal $plan)) {
            if ($m.Kind -eq "Warning") { Write-Warning $m.Text } else { Write-Host $m.Text }
        }
    }
}


# ------------------------------------------------------------
# Undo only
# ------------------------------------------------------------

if ($UndoLastUpdate -or $UndoAll) {

    Undo-Updates -All:$UndoAll
    return
}


# ------------------------------------------------------------
# Uninstall
# ------------------------------------------------------------

if ($Uninstall) {

    Write-Host "This removes the Q-Sys Updater from this PC:"
    Write-Host "  - the scheduled tasks '$TaskName' and '$noticeTaskName'"
    Write-Host "  - the Q-Sys Updater Options icons on the Desktop and in the Start menu"
    Write-Host "  - $InstallDir (saved Q-SYS credential, Chrome sign-in profile, logs, update history)"
    Write-Host ""
    Write-Host "Downloaded installers are NOT deleted unless you choose to undo the updates below."
    Write-Host ""

    if (-not $Yes) {

        $answer = Read-Host "Remove the updater now? [y/N]"

        if ($answer -notmatch '^(y|yes)$') {
            Write-Host "Nothing was removed."
            return
        }
    }

    # Offer to put the installers folder back the way it was (needs the update
    # history, which is deleted with the install folder, so do it first).
    if (Get-UpdateJournals) {

        Write-Host ""
        Write-Host "The updater has made changes in your installers folder (see 'Undo' below)."

        $doUndo = $UndoUpdates

        if (-not $doUndo -and -not $Yes) {
            $undoAnswer = Read-Host "Also undo those updates now (remove what it downloaded, restore the archived version)? [y/N]"
            $doUndo = ($undoAnswer -match '^(y|yes)$')
        }

        if ($doUndo) {
            Undo-Updates -All -AssumeYes
        }
    }

    Stop-RunningUpdater
    Stop-OpenNotice

    # If Windows will not let the tasks be removed, stop here and remove nothing
    # else: deleting the files while the tasks remain would leave broken tasks.
    if ($task) {

        if (-not (Invoke-TaskChange -Action "remove" -Change { Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction Stop })) {
            Write-Host ""
            Write-Host "Nothing else was removed."
            return
        }

        Write-Host "Removed the scheduled task."
    }

    if ($noticeTask) {

        if (-not (Invoke-TaskChange -Action "remove" -Change { Unregister-ScheduledTask -TaskName $noticeTaskName -Confirm:$false -ErrorAction Stop })) {
            Write-Host ""
            Write-Host "The main task was removed but the notice task was not, and nothing else was removed."
            return
        }
    }

    $desktop     = [Environment]::GetFolderPath("Desktop")
    $startFolder = Join-Path ([Environment]::GetFolderPath("Programs")) "Q-Sys Updater"

    foreach ($linkName in $optionsLinkName, $legacyStopLink, $legacyPassLink) {
        Remove-Item (Join-Path $desktop $linkName) -Force -ErrorAction SilentlyContinue
    }
    Remove-Item $startFolder -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Removed the icons."

    # Windows will not delete a folder a program is standing in, and this window
    # may have been started inside the install folder. Step out of it first.
    # (Set-Location only moves PowerShell's own location; the process's working
    # folder, the one Windows checks, has to be moved as well.)
    try {
        Set-Location $env:TEMP
        [System.IO.Directory]::SetCurrentDirectory($env:TEMP)
    }
    catch { }

    try {
        Remove-Item $InstallDir -Recurse -Force
        Write-Host "Removed $InstallDir."
    }
    catch {
        Write-Warning "Could not remove $InstallDir ($($_.Exception.Message)). Close any window that is open in that folder and delete it yourself: it holds your saved Q-SYS login (encrypted) and the updater's Chrome sign-in profile."
    }

    Write-Host ""
    Write-Host "Still on this PC (remove yourself if you want):"

    if ($qsysFolder) {
        Write-Host "  - Your installers folder: $qsysFolder"
    }

    Write-Host "  - PowerShell 7 and Google Chrome (Settings > Apps > Installed apps)"
    return
}


# ------------------------------------------------------------
# Options window (no switch): shows the status, then one-key choices
# ------------------------------------------------------------

$historyFile     = Join-Path $InstallDir "Logs\Run-History.log"
$passwordScript  = Join-Path $InstallDir "Update-QSysPassword.ps1"
$loginFailedFile = Join-Path $InstallDir "login-failed.json"

try { $Host.UI.RawUI.WindowTitle = "Q-Sys Updater Options" } catch { }

# One key, no Enter, no copying of commands. If there is no real console (for
# example when input is redirected) it falls back to typing a letter and Enter.
function Read-MenuKey {

    try {

        $pressed = [Console]::ReadKey($true)

        if ($pressed.Key -eq "Enter") {
            return ""
        }

        return $pressed.KeyChar.ToString().ToUpper()
    }
    catch {

        $typed = Read-Host "Choose"

        if ($null -eq $typed) {
            return ""
        }

        return $typed.Trim().ToUpper()
    }
}

function Get-UpdaterTask {

    Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
}

function Test-UpdaterRunning {

    @(
        Get-CimInstance Win32_Process |
            Where-Object {
                $_.Name -eq "pwsh.exe" -and
                $_.CommandLine -like "*$InstallDir*QSys-Updater.ps1*"
            }
    ).Count -gt 0
}

function Show-Status {

    $current = Get-UpdaterTask

    Write-Host ""
    Write-Host "============================================================"
    Write-Host " Q-Sys Updater"
    Write-Host "============================================================"

    if (-not $current) {
        Write-Host " Updater:   its scheduled task '$TaskName' was not found"
    }
    elseif ($current.State -eq "Disabled") {
        Write-Host " Updater:   STOPPED (it will not check at logon)"
    }
    elseif (Test-UpdaterRunning) {
        Write-Host " Updater:   checking for an update right now"
    }
    else {
        Write-Host " Updater:   ON (checks at logon)"
    }

    if (Test-Path $loginFailedFile) {

        $failed = Get-Content $loginFailedFile -Raw | ConvertFrom-Json
        $since  = try { ([datetime]$failed.Time).ToString("MMMM d") } catch { "earlier" }

        Write-Host " Sign-in:   PAUSED since ${since}: $($failed.Message)"
        Write-Host "            It will not try again until you update the password (press P)."
    }
    else {
        Write-Host " Sign-in:   OK"
    }

    if (Test-Path $historyFile) {

        $last = (Get-Content $historyFile -Tail 1)

        if ($last.Length -gt 100) {
            $last = $last.Substring(0, 97) + "..."
        }

        Write-Host " Last check: $last"
    }
    else {
        Write-Host " Last check: none yet"
    }

    if ($qsysFolder) {
        Write-Host " Installers: $qsysFolder"
    }

    Write-Host "------------------------------------------------------------"
}

function Show-Menu {

    $current = Get-UpdaterTask

    Write-Host "Press one key:"
    Write-Host ""

    if ($current -and $current.State -eq "Disabled") {
        Write-Host "   R       Resume the updater"
    }
    else {
        Write-Host "   S       Stop the updater (nothing is deleted)"
    }

    Write-Host "   P       Update my Q-SYS password"
    Write-Host "   H       Open the run history (one dated line per attempt)"

    if ($qsysFolder) {
        Write-Host "   F       Open the installers folder"
    }

    Write-Host "   U       Undo the last update (puts the installers folder back the way it"
    Write-Host "           was; asks you to confirm)"
    Write-Host "   X       Remove the updater from this PC (asks you to confirm first)"
    Write-Host "   Enter   Close this window"
    Write-Host ""
}

# ------------------------------------------------------------
# The window (default when a person opens it; the console menu below is used
# with -NoGui or when input is redirected, as in the automated tests)
# ------------------------------------------------------------

function Get-OptionsStatus {

    # The same facts the console status block shows, as data.
    $current = Get-UpdaterTask

    $status = @{
        TaskFound = [bool]$current
        Stopped   = [bool]($current -and $current.State -eq "Disabled")
    }

    if (-not $current) {
        $status.Updater = "Its scheduled task '$TaskName' was not found"
    }
    elseif ($current.State -eq "Disabled") {
        $status.Updater = "STOPPED (it will not check at logon)"
    }
    elseif (Test-UpdaterRunning) {
        $status.Updater = "Checking for an update right now"
    }
    else {
        $status.Updater = "ON (checks at logon)"
    }

    if (Test-Path $loginFailedFile) {

        $failed = Get-Content $loginFailedFile -Raw | ConvertFrom-Json
        $since  = try { ([datetime]$failed.Time).ToString("MMMM d") } catch { "earlier" }

        $status.SignIn = "PAUSED since ${since}: $($failed.Message)`r`nIt will not try again until you update the Q-SYS password."
    }
    else {
        $status.SignIn = "OK"
    }

    $status.LastCheck  = if (Test-Path $historyFile) { (Get-Content $historyFile -Tail 1) } else { "None yet" }
    $status.Installers = if ($qsysFolder) { $qsysFolder } else { "Not set" }

    $status
}

function Show-OptionsWindow {

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    # Windows will not delete a folder a program is standing in, and this window
    # may have been started inside the install folder.
    try {
        Set-Location $env:TEMP
        [System.IO.Directory]::SetCurrentDirectory($env:TEMP)
    }
    catch { }

    # Hide the console this script was started in, but only if it is ours alone
    # (not a terminal the person opened and is still using).
    try {
        Add-Type -Namespace QSysOpt -Name Native -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern System.IntPtr GetConsoleWindow();
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern uint GetConsoleProcessList(uint[] list, uint count);
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool ShowWindow(System.IntPtr hWnd, int cmd);
'@
        $consoleWindow = [QSysOpt.Native]::GetConsoleWindow()
        $ids = New-Object 'uint32[]' 4
        if ($consoleWindow -ne [IntPtr]::Zero -and [QSysOpt.Native]::GetConsoleProcessList($ids, 4) -le 1) {
            [void][QSysOpt.Native]::ShowWindow($consoleWindow, 0)
        }
    }
    catch { }

    $global:QOptForm = New-Object System.Windows.Forms.Form
    $form = $global:QOptForm
    $form.Text = "Q-Sys Updater Options"
    $form.ClientSize = New-Object System.Drawing.Size(600, 534)
    $form.StartPosition = "CenterScreen"
    $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false
    $form.MinimizeBox = $true
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    function Add-Label ($text, $x, $y, $w, $h, $bold) {
        $l = New-Object System.Windows.Forms.Label
        $l.Text = $text; $l.Location = New-Object System.Drawing.Point($x, $y); $l.Size = New-Object System.Drawing.Size($w, $h)
        if ($bold) { $l.Font = New-Object System.Drawing.Font("Segoe UI", 9.5, [System.Drawing.FontStyle]::Bold) }
        $form.Controls.Add($l); $l
    }

    $title = Add-Label "Q-Sys Updater" 20 14 560 28 $true
    $title.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)

    $rows = @(
        @{ Key = "Updater";    Caption = "Updater";    Height = 22 },
        @{ Key = "SignIn";     Caption = "Sign-in";    Height = 40 },
        @{ Key = "LastCheck";  Caption = "Last check"; Height = 40 },
        @{ Key = "Installers"; Caption = "Installers"; Height = 40 }
    )
    $global:QOptValues = @{}
    $y = 54
    foreach ($row in $rows) {
        [void](Add-Label $row.Caption 20 $y 100 $row.Height $true)
        $value = Add-Label "" 125 $y 455 $row.Height $false
        $value.Name = "Status" + $row.Key
        $global:QOptValues[$row.Key] = $value
        $y += $row.Height + 4
    }

    $line = New-Object System.Windows.Forms.Label
    $line.BorderStyle = "Fixed3D"; $line.Location = New-Object System.Drawing.Point(20, 218); $line.Size = New-Object System.Drawing.Size(560, 2)
    $form.Controls.Add($line)

    function Add-Button ($name, $text, $x, $y) {
        $b = New-Object System.Windows.Forms.Button
        $b.Name = $name; $b.Text = $text
        $b.Location = New-Object System.Drawing.Point($x, $y); $b.Size = New-Object System.Drawing.Size(275, 36)
        $form.Controls.Add($b); $b
    }

    $btnCheck    = Add-Button "CheckNow"              "Check for update now"          20  232
    $global:QOptStopResume = Add-Button "StopResume"  "Stop updater"                  305 232
    $btnPassword = Add-Button "UpdatePassword"        "Update Q-SYS password..."      20  276
    $btnHistory  = Add-Button "OpenHistory"           "Open run history"              305 276
    $btnFolder   = Add-Button "OpenFolder"            "Open installers folder"        20  320
    $btnUndo     = Add-Button "UndoLast"              "Undo last update..."           305 320
    $btnRemove   = Add-Button "RemoveUpdater"         "Remove updater..."             20  364
    $global:QOptErrorReports = Add-Button "ToggleErrorReports" "Error reports: on (click to turn off)" 305 364
    $btnClose    = Add-Button "Close"                 "Close"                         305 484

    # Chrome window: hidden (normal) or visible (for testing). Saved to the settings file;
    # used from the next check.
    [void](Add-Label "Chrome window" 20 414 110 24 $true)
    $radioHidden  = New-Object System.Windows.Forms.RadioButton
    $radioHidden.Name = "ChromeHidden"; $radioHidden.Text = "Hidden (recommended)"
    $radioHidden.Location = New-Object System.Drawing.Point(135, 412); $radioHidden.Size = New-Object System.Drawing.Size(210, 26)
    $radioVisible = New-Object System.Windows.Forms.RadioButton
    $radioVisible.Name = "ChromeVisible"; $radioVisible.Text = "Visible (for testing)"
    $radioVisible.Location = New-Object System.Drawing.Point(355, 412); $radioVisible.Size = New-Object System.Drawing.Size(220, 26)
    $form.Controls.AddRange(@($radioHidden, $radioVisible))
    $global:QOptRadioHidden = $radioHidden; $global:QOptRadioVisible = $radioVisible

    $savedMode = try { (Get-Content $configFile -Raw | ConvertFrom-Json).BrowserMode } catch { $null }
    $radioVisible.Checked = ($savedMode -eq "Visible"); $radioHidden.Checked = -not $radioVisible.Checked

    $note = Add-Label "Opening this window changes nothing by itself. Stopping the updater deletes nothing. The Chrome window setting applies from the next check." 20 446 560 36 $false
    $note.ForeColor = [System.Drawing.Color]::DimGray

    function Show-Box ($text, $buttons = "OK", $icon = "Information") {
        [System.Windows.Forms.MessageBox]::Show($global:QOptForm, $text, "Q-Sys Updater Options", $buttons, $icon)
    }

    function Update-OptionsStatus {
        $st = Get-OptionsStatus
        $global:QOptValues["Updater"].Text    = $st.Updater
        $global:QOptValues["SignIn"].Text     = $st.SignIn
        $global:QOptValues["LastCheck"].Text  = $st.LastCheck
        $global:QOptValues["Installers"].Text = $st.Installers
        $global:QOptStopResume.Text = if ($st.Stopped) { "Resume updater" } else { "Stop updater" }
        $global:QOptStopResume.Enabled = $st.TaskFound
    }

    # Every handler is wrapped so an error can never escape into Windows Forms'
    # "unhandled exception" box (a timer would repeat it every tick).
    function Invoke-Safely ($body) {
        try { & $body }
        catch {
            try { [void](Show-Box "Something went wrong and nothing further was changed.`r`n`r`n$($_.Exception.Message)" "OK" "Warning") } catch { }
        }
    }

    $global:QOptStopResume.Add_Click({ Invoke-Safely {
        $current = Get-UpdaterTask
        if (-not $current) {
            [void](Show-Box "The scheduled task '$TaskName' was not found, so there is nothing to stop or resume." "OK" "Warning")
        }
        elseif ($current.State -eq "Disabled") {
            if (Invoke-TaskChange -Quiet -Action "enable" -Change { Enable-ScheduledTask -TaskName $TaskName -ErrorAction Stop | Out-Null }) {
                [void](Show-Box "Resumed. The updater will run at the next logon.")
            }
            else { [void](Show-Box $global:QOptTaskMessage "OK" "Warning") }
        }
        else {
            $stopped = Invoke-TaskChange -Quiet -Action "disable" -Change {
                Disable-ScheduledTask -TaskName $TaskName -ErrorAction Stop | Out-Null
                Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
            }
            Stop-RunningUpdater
            if ($stopped) {
                [void](Show-Box "Stopped. It will not check for updates at logon. Nothing was deleted.")
            }
            else {
                [void](Show-Box ("NOT fully stopped: any run in progress was ended, but its scheduled task could not be disabled, so it WILL run again at the next logon.`r`n`r`n" + $global:QOptTaskMessage) "OK" "Warning")
            }
        }
        Update-OptionsStatus
    } })

    $btnCheck.Add_Click({ Invoke-Safely {
        $current = Get-UpdaterTask
        if (-not $current) {
            [void](Show-Box "The scheduled task '$TaskName' was not found, so the updater cannot be started." "OK" "Warning")
        }
        elseif ($current.State -eq "Disabled") {
            [void](Show-Box "The updater is stopped. Click 'Resume updater' first, then check for an update." "OK" "Warning")
        }
        elseif (Test-UpdaterRunning) {
            [void](Show-Box "The updater is already checking for an update right now.")
        }
        elseif (Test-Path $loginFailedFile) {
            [void](Show-Box "The updater is paused because the Q-SYS sign-in did not work. Click 'Update Q-SYS password...' first." "OK" "Warning")
        }
        elseif (Invoke-TaskChange -Quiet -Action "start" -Change { Start-ScheduledTask -TaskName $TaskName -ErrorAction Stop }) {
            [void](Show-Box "The check has started in the background. If a new version is found you will get a notice. The Last check line above shows the result when it finishes.")
        }
        else { [void](Show-Box $global:QOptTaskMessage "OK" "Warning") }
        Update-OptionsStatus
    } })

    $btnPassword.Add_Click({ Invoke-Safely {
        if (Test-Path $passwordScript) {
            & $passwordScript -StateDir $InstallDir -Gui
        }
        else {
            [void](Show-Box "The password script was not found:`r`n$passwordScript" "OK" "Warning")
        }
        Update-OptionsStatus
    } })

    $btnHistory.Add_Click({ Invoke-Safely {
        if (Test-Path $historyFile) { Start-Process -FilePath "notepad.exe" -ArgumentList "`"$historyFile`"" }
        else { [void](Show-Box "There is no run history yet.") }
    } })

    $btnFolder.Add_Click({ Invoke-Safely {
        if ($qsysFolder -and (Test-Path $qsysFolder)) { Start-Process -FilePath "explorer.exe" -ArgumentList "`"$qsysFolder`"" }
        else { [void](Show-Box "The installers folder does not exist yet:`r`n$qsysFolder") }
    } })

    $btnUndo.Add_Click({ Invoke-Safely {
        $journals = Get-UpdateJournals
        if (-not $journals) {
            [void](Show-Box "No updates are recorded, so there is nothing to undo.")
        }
        else {
            $plan = Get-UndoPlan $journals[0]
            $text = $plan.Heading + "`r`n`r`nUndoing it will:`r`n" + (($plan.Lines | ForEach-Object { "  - $_" }) -join "`r`n") + "`r`n`r`nUndo this update?"
            if ((Show-Box $text "YesNo" "Question") -eq "Yes") {
                Stop-RunningUpdater
                Stop-OpenNotice
                $messages = @(Invoke-UndoJournal $plan)
                $icon = if (@($messages | Where-Object { $_.Kind -eq "Warning" }).Count) { "Warning" } else { "Information" }
                [void](Show-Box (($messages | ForEach-Object { $_.Text }) -join "`r`n") "OK" $icon)
            }
        }
        Update-OptionsStatus
    } })

    $btnRemove.Add_Click({ Invoke-Safely {
        $dialog = New-Object System.Windows.Forms.Form
        $dialog.Text = "Remove the Q-Sys Updater"
        $dialog.ClientSize = New-Object System.Drawing.Size(560, 330)
        $dialog.StartPosition = "CenterParent"; $dialog.FormBorderStyle = "FixedDialog"
        $dialog.MaximizeBox = $false; $dialog.MinimizeBox = $false; $dialog.ShowInTaskbar = $false
        $dialog.Font = $global:QOptForm.Font

        $info = New-Object System.Windows.Forms.Label
        $info.Location = New-Object System.Drawing.Point(20, 16); $info.Size = New-Object System.Drawing.Size(520, 190)
        $info.Text = "This removes the Q-Sys Updater from this PC:`r`n`r`n" +
            "  - the scheduled tasks '$TaskName' and '$noticeTaskName'`r`n" +
            "  - the Q-Sys Updater Options icons on the Desktop and in the Start menu`r`n" +
            "  - $InstallDir (saved Q-SYS credential, Chrome sign-in profile, logs, update history)`r`n`r`n" +
            "Downloaded installers are NOT deleted unless you tick the box below."
        $dialog.Controls.Add($info)

        $check = New-Object System.Windows.Forms.CheckBox
        $check.Name = "AlsoUndo"
        $check.Location = New-Object System.Drawing.Point(20, 214); $check.Size = New-Object System.Drawing.Size(520, 44)
        $check.Text = "Also undo the downloaded updates (remove what it downloaded and put the archived version back)"
        $check.Enabled = [bool](Get-UpdateJournals)
        $dialog.Controls.Add($check)

        $ok = New-Object System.Windows.Forms.Button
        $ok.Name = "ConfirmRemove"; $ok.Text = "Remove updater"; $ok.DialogResult = "OK"
        $ok.Location = New-Object System.Drawing.Point(250, 276); $ok.Size = New-Object System.Drawing.Size(150, 36)
        $cancel = New-Object System.Windows.Forms.Button
        $cancel.Name = "CancelRemove"; $cancel.Text = "Cancel"; $cancel.DialogResult = "Cancel"
        $cancel.Location = New-Object System.Drawing.Point(410, 276); $cancel.Size = New-Object System.Drawing.Size(130, 36)
        $dialog.Controls.AddRange(@($ok, $cancel)); $dialog.CancelButton = $cancel

        $answer = $dialog.ShowDialog($global:QOptForm)
        $undoToo = $check.Checked
        $dialog.Dispose()

        if ($answer -eq "OK") {

            $global:QOptTimer.Stop()

            # The removal runs in its own hidden process started outside the install
            # folder (so the folder can be deleted); its report is read back here.
            $report = Join-Path $env:TEMP ("qsys-remove-" + [guid]::NewGuid().ToString("N").Substring(0, 8) + ".txt")
            $argList = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`"", "-Uninstall", "-Yes", "-NoGui", "-InstallDir", "`"$InstallDir`"", "-TaskName", "`"$TaskName`"")
            if ($undoToo) { $argList += "-UndoUpdates" }

            $pwshPath = (Get-Process -Id $PID).Path
            $child = Start-Process -FilePath $pwshPath -WorkingDirectory $env:TEMP -WindowStyle Hidden -PassThru -ArgumentList $argList -RedirectStandardOutput $report

            $global:QOptForm.Text = "Q-Sys Updater Options - removing..."
            $global:QOptForm.Enabled = $false
            while (-not $child.HasExited) {
                [System.Windows.Forms.Application]::DoEvents()
                Start-Sleep -Milliseconds 100
            }
            $global:QOptForm.Enabled = $true

            $result = if (Test-Path $report) { (Get-Content $report -Raw) } else { "" }
            Remove-Item $report -Force -ErrorAction SilentlyContinue
            [void](Show-Box ("Removal finished.`r`n`r`n" + "$result".Trim()))
            $global:QOptForm.Close()
        }
    } })

    $saveMode = {
        # Click fires only when the person clicks, so loading the saved value never rewrites the file.
        Invoke-Safely {
            $mode = if ($global:QOptRadioVisible.Checked) { "Visible" } else { "Hidden" }
            $saved = Get-Content $configFile -Raw | ConvertFrom-Json
            if ($saved.PSObject.Properties.Name -contains "BrowserMode") { $saved.BrowserMode = $mode }
            else { $saved | Add-Member -NotePropertyName BrowserMode -NotePropertyValue $mode }
            $saved | ConvertTo-Json | Set-Content -Path $configFile -Encoding UTF8
        }
    }
    $radioHidden.Add_Click($saveMode)
    $radioVisible.Add_Click($saveMode)

    # Error reports on/off: saved to the settings file at once (a missing setting means on).
    # Turning them off also deletes reports still waiting to be sent.
    function Update-ErrorReportsButton {
        $on = $true
        try { if ((Get-Content $configFile -Raw | ConvertFrom-Json).ErrorReporting -eq $false) { $on = $false } } catch { }
        $global:QOptErrorReports.Text = if ($on) { "Error reports: on (click to turn off)" } else { "Error reports: off (click to turn on)" }
        $on
    }

    $global:QOptErrorReports.Visible = [bool](Get-Command Set-ErrorReporting -CommandType Function -ErrorAction SilentlyContinue)
    [void](Update-ErrorReportsButton)

    $global:QOptErrorReports.Add_Click({ Invoke-Safely {
        $on = Update-ErrorReportsButton
        if (-not (Set-ErrorReporting -ConfigPath $configFile -Enabled (-not $on))) {
            [void](Show-Box "The error reports setting could not be saved:`r`n$configFile" "OK" "Warning")
        }
        [void](Update-ErrorReportsButton)
    } })

    $btnClose.Add_Click({ $global:QOptForm.Close() })
    $form.CancelButton = $btnClose

    $global:QOptTimer = New-Object System.Windows.Forms.Timer
    $global:QOptTimer.Interval = 5000
    $global:QOptTimer.Add_Tick({ try { Update-OptionsStatus } catch { } })

    $form.Add_Shown({ try { Update-OptionsStatus } catch { }; try { $global:QOptTimer.Start() } catch { } })

    [void]$form.ShowDialog()
    $global:QOptTimer.Stop()
}

$useGui = -not $NoGui
try { if ([Console]::IsInputRedirected) { $useGui = $false } } catch { }

if ($useGui) {
    Show-OptionsWindow
    return
}


while ($true) {

    Show-Status
    Show-Menu

    $choice = Read-MenuKey

    if ($choice -eq "") {
        return
    }

    if ($choice -eq "S") {

        $current = Get-UpdaterTask

        if (-not $current) {
            Write-Host "The scheduled task '$TaskName' was not found, so there is nothing to stop."
            continue
        }

        if ($current.State -eq "Disabled") {
            Write-Host "The updater is already stopped."
            continue
        }

        $stopped = Invoke-TaskChange -Action "disable" -Change {
            Disable-ScheduledTask -TaskName $TaskName -ErrorAction Stop | Out-Null
            Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
        }

        Stop-RunningUpdater

        if ($stopped) {
            Write-Host "Stopped. It will not check for updates at logon. Nothing was deleted."
        }
        else {
            Write-Host "NOT fully stopped: any run in progress was ended, but its scheduled task could"
            Write-Host "not be disabled, so it WILL run again at the next logon."
        }

        continue
    }

    if ($choice -eq "R") {

        $current = Get-UpdaterTask

        if (-not $current) {
            Write-Host "The scheduled task '$TaskName' was not found, so there is nothing to resume."
            continue
        }

        if ($current.State -ne "Disabled") {
            Write-Host "The updater is already on."
            continue
        }

        if (Invoke-TaskChange -Action "enable" -Change { Enable-ScheduledTask -TaskName $TaskName -ErrorAction Stop | Out-Null }) {
            Write-Host "Resumed. The updater will run at the next logon."
        }

        continue
    }

    if ($choice -eq "P") {

        if (Test-Path $passwordScript) {

            Write-Host ""
            & $passwordScript -StateDir $InstallDir
        }
        else {
            Write-Host "The password script was not found: $passwordScript"
        }

        continue
    }

    if ($choice -eq "H") {

        if (Test-Path $historyFile) {
            Start-Process -FilePath "notepad.exe" -ArgumentList "`"$historyFile`""
        }
        else {
            Write-Host "There is no run history yet: $historyFile"
        }

        continue
    }

    if ($choice -eq "F" -and $qsysFolder) {

        if (Test-Path $qsysFolder) {
            Start-Process -FilePath "explorer.exe" -ArgumentList "`"$qsysFolder`""
        }
        else {
            Write-Host "That folder does not exist yet: $qsysFolder"
        }

        continue
    }

    if ($choice -eq "U") {

        Undo-Updates
        continue
    }

    if ($choice -eq "X") {

        # Open the removal in its own window (it asks before it removes anything),
        # then close this one.
        $pwshPath = (Get-Process -Id $PID).Path

        # (Started in the temp folder, not in the install folder, so the install
        # folder can be deleted.)
        Start-Process -FilePath $pwshPath -WorkingDirectory $env:TEMP -ArgumentList @(
            "-NoProfile",
            "-ExecutionPolicy", "Bypass",
            "-File", "`"$PSCommandPath`"",
            "-Uninstall",
            "-InstallDir", "`"$InstallDir`""
        )

        return
    }

    Write-Host "That key is not one of the choices above."
}
